--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounting_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounting_periods (
    id integer NOT NULL,
    company_id integer,
    fiscal_year character varying(10) NOT NULL,
    period_name character varying(50) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_open boolean,
    is_closed boolean,
    is_active boolean,
    created_at timestamp without time zone,
    closed_at timestamp without time zone
);


--
-- Name: accounting_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounting_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounting_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounting_periods_id_seq OWNED BY public.accounting_periods.id;


--
-- Name: accounting_voucher_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounting_voucher_lines (
    id integer NOT NULL,
    company_id integer,
    voucher_id integer NOT NULL,
    line_no integer NOT NULL,
    account_id integer NOT NULL,
    description character varying(300),
    debit numeric(16,4),
    credit numeric(16,4),
    label_id integer
);


--
-- Name: accounting_voucher_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounting_voucher_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounting_voucher_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounting_voucher_lines_id_seq OWNED BY public.accounting_voucher_lines.id;


--
-- Name: accounting_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounting_vouchers (
    id integer NOT NULL,
    company_id integer,
    voucher_type character varying(10) NOT NULL,
    voucher_number character varying(50) NOT NULL,
    voucher_date timestamp without time zone NOT NULL,
    cash_bank_account_id integer,
    label_id integer,
    notes text,
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone
);


--
-- Name: accounting_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounting_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounting_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounting_vouchers_id_seq OWNED BY public.accounting_vouchers.id;


--
-- Name: additional_charges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.additional_charges (
    id integer NOT NULL,
    company_id integer,
    doc_type character varying(10) NOT NULL,
    doc_id integer NOT NULL,
    charge_account_id integer NOT NULL,
    description character varying(200),
    amount numeric(20,6),
    scope character varying(20),
    distribution character varying(20),
    manual_allocations text,
    treatment character varying(10),
    st_taxable boolean,
    wht_taxable boolean,
    extra_taxable boolean,
    taxable boolean,
    tax_base character varying(30),
    created_at timestamp without time zone
);


--
-- Name: additional_charges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.additional_charges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: additional_charges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.additional_charges_id_seq OWNED BY public.additional_charges.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id integer NOT NULL,
    company_id integer,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    priority character varying(20),
    author_id integer NOT NULL,
    pinned boolean,
    expires_at date,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.announcements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: approval_workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_workflows (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    module character varying(50) NOT NULL,
    leave_type_id integer,
    requires_approval boolean,
    approval_levels integer,
    auto_approve boolean,
    auto_approve_role character varying(50),
    notify_admins boolean,
    is_active boolean,
    created_at timestamp without time zone
);


--
-- Name: approval_workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.approval_workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: approval_workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.approval_workflows_id_seq OWNED BY public.approval_workflows.id;


--
-- Name: asset_depreciation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asset_depreciation (
    id integer NOT NULL,
    company_id integer,
    asset_id integer NOT NULL,
    entry_date date NOT NULL,
    amount numeric(20,6) NOT NULL,
    accumulated_after numeric(20,6) NOT NULL,
    net_book_value_after numeric(20,6) NOT NULL,
    journal_entry_id integer,
    notes character varying(200),
    created_at timestamp without time zone
);


--
-- Name: asset_depreciation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.asset_depreciation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_depreciation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.asset_depreciation_id_seq OWNED BY public.asset_depreciation.id;


--
-- Name: asset_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asset_transfers (
    id integer NOT NULL,
    company_id integer,
    voucher_number character varying(50) NOT NULL,
    direction character varying(20) NOT NULL,
    asset_id integer NOT NULL,
    product_id integer,
    new_product_name character varying(200),
    source_product_id integer,
    transfer_amount numeric(20,6),
    quantity numeric(20,6),
    description text,
    transfer_date date,
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone
);


--
-- Name: asset_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.asset_transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.asset_transfers_id_seq OWNED BY public.asset_transfers.id;


--
-- Name: attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    date date NOT NULL,
    clock_in timestamp without time zone,
    clock_out timestamp without time zone,
    ip_address character varying(50),
    geo_lat double precision,
    geo_lng double precision,
    status character varying(20),
    is_late boolean,
    is_half_day boolean,
    notes text,
    created_at timestamp without time zone
);


--
-- Name: attendance_corrections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_corrections (
    id integer NOT NULL,
    company_id integer,
    attendance_id integer NOT NULL,
    corrected_by integer NOT NULL,
    field character varying(50) NOT NULL,
    old_value character varying(255),
    new_value character varying(255) NOT NULL,
    reason text NOT NULL,
    corrected_at timestamp without time zone
);


--
-- Name: attendance_corrections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_corrections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_corrections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_corrections_id_seq OWNED BY public.attendance_corrections.id;


--
-- Name: attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_id_seq OWNED BY public.attendance.id;


--
-- Name: attendance_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_logs (
    id integer NOT NULL,
    company_id integer,
    attendance_id integer NOT NULL,
    event character varying(20) NOT NULL,
    "timestamp" timestamp without time zone,
    ip_address character varying(50),
    geo_lat double precision,
    geo_lng double precision
);


--
-- Name: attendance_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_logs_id_seq OWNED BY public.attendance_logs.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    company_id integer,
    created_at timestamp without time zone NOT NULL,
    user_id integer,
    user_name character varying(200),
    action character varying(30) NOT NULL,
    module character varying(30),
    entity_type character varying(60),
    entity_id integer,
    reference character varying(120),
    summary character varying(500),
    changes text,
    ip_address character varying(64),
    path character varying(300)
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: bank_rec_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_rec_items (
    id integer NOT NULL,
    company_id integer,
    reconciliation_id integer NOT NULL,
    journal_line_id integer NOT NULL
);


--
-- Name: bank_rec_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_rec_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_rec_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_rec_items_id_seq OWNED BY public.bank_rec_items.id;


--
-- Name: bank_reconciliations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_reconciliations (
    id integer NOT NULL,
    company_id integer,
    account_id integer NOT NULL,
    statement_date date NOT NULL,
    statement_balance numeric(20,6) NOT NULL,
    status character varying(20),
    notes text,
    created_by integer,
    created_at timestamp without time zone,
    completed_at timestamp without time zone
);


--
-- Name: bank_reconciliations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_reconciliations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_reconciliations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_reconciliations_id_seq OWNED BY public.bank_reconciliations.id;


--
-- Name: break_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.break_logs (
    id integer NOT NULL,
    company_id integer,
    attendance_id integer NOT NULL,
    break_start timestamp without time zone NOT NULL,
    break_end timestamp without time zone,
    break_type character varying(30),
    duration_minutes integer,
    created_at timestamp without time zone
);


--
-- Name: break_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.break_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: break_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.break_logs_id_seq OWNED BY public.break_logs.id;


--
-- Name: button_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.button_permissions (
    id integer NOT NULL,
    company_id integer,
    role_id integer NOT NULL,
    button_code character varying(100) NOT NULL,
    is_granted boolean,
    module character varying(50) NOT NULL,
    description character varying(200)
);


--
-- Name: button_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.button_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: button_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.button_permissions_id_seq OWNED BY public.button_permissions.id;


--
-- Name: category_revenue_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.category_revenue_accounts (
    id integer NOT NULL,
    company_id integer,
    category_id integer NOT NULL,
    account_id integer NOT NULL
);


--
-- Name: category_revenue_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.category_revenue_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: category_revenue_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.category_revenue_accounts_id_seq OWNED BY public.category_revenue_accounts.id;


--
-- Name: change_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_requests (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    field_name character varying(100) NOT NULL,
    old_value text,
    new_value text NOT NULL,
    status character varying(20),
    reviewed_by integer,
    review_notes text,
    created_at timestamp without time zone,
    reviewed_at timestamp without time zone
);


--
-- Name: change_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.change_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: change_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.change_requests_id_seq OWNED BY public.change_requests.id;


--
-- Name: charge_ledger_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.charge_ledger_defaults (
    id integer NOT NULL,
    company_id integer,
    account_id integer NOT NULL,
    treatment character varying(10),
    st_taxable boolean,
    wht_taxable boolean,
    extra_taxable boolean,
    applies_to character varying(10)
);


--
-- Name: charge_ledger_defaults_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.charge_ledger_defaults_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: charge_ledger_defaults_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.charge_ledger_defaults_id_seq OWNED BY public.charge_ledger_defaults.id;


--
-- Name: chart_of_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_of_accounts (
    id integer NOT NULL,
    company_id integer,
    code character varying(30) NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(50) NOT NULL,
    parent_id integer,
    level integer NOT NULL,
    is_fixed boolean,
    is_active boolean,
    description text,
    cash_flow_activity character varying(20),
    pl_section character varying(30),
    created_at timestamp without time zone
);


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chart_of_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chart_of_accounts_id_seq OWNED BY public.chart_of_accounts.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(120) NOT NULL,
    is_active boolean,
    plan_name character varying(50),
    max_members integer,
    created_by integer,
    mod_hr_enabled boolean,
    mod_inventory_enabled boolean,
    mod_invoicing_enabled boolean,
    mod_finance_enabled boolean,
    mod_accounting_enabled boolean,
    mod_fbr_enabled boolean,
    mod_fixed_assets_enabled boolean,
    mod_executive_enabled boolean,
    address text,
    city character varying(100),
    state character varying(100),
    country character varying(100),
    phone character varying(50),
    email character varying(200),
    website character varying(200),
    tax_id character varying(100),
    registration_number character varying(100),
    logo_url character varying(500),
    bank_name character varying(200),
    bank_account_title character varying(200),
    bank_account_number character varying(100),
    fiscal_year_start_month integer,
    currency character varying(10),
    currency_symbol character varying(10),
    date_format character varying(20),
    number_format character varying(10),
    timezone character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: company_holidays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_holidays (
    id integer NOT NULL,
    company_id integer,
    name character varying(200) NOT NULL,
    holiday_date date NOT NULL,
    is_recurring boolean,
    department character varying(100),
    location character varying(100),
    is_active boolean,
    created_at timestamp without time zone
);


--
-- Name: company_holidays_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.company_holidays_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: company_holidays_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.company_holidays_id_seq OWNED BY public.company_holidays.id;


--
-- Name: company_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_info (
    id integer NOT NULL,
    company_id integer,
    company_name character varying(200),
    address text,
    city character varying(100),
    state character varying(100),
    country character varying(100),
    phone character varying(50),
    email character varying(200),
    website character varying(200),
    tax_id character varying(100),
    registration_number character varying(100),
    logo_url character varying(500),
    bank_name character varying(200),
    bank_account_title character varying(200),
    bank_account_number character varying(100),
    fiscal_year_start_month integer,
    currency character varying(10),
    currency_symbol character varying(10),
    date_format character varying(20),
    number_format character varying(10),
    timezone character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: company_info_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.company_info_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: company_info_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.company_info_id_seq OWNED BY public.company_info.id;


--
-- Name: company_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_invitations (
    id integer NOT NULL,
    company_id integer NOT NULL,
    email character varying(120) NOT NULL,
    role_id integer NOT NULL,
    invited_by integer,
    status character varying(10) NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: company_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.company_invitations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: company_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.company_invitations_id_seq OWNED BY public.company_invitations.id;


--
-- Name: company_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_memberships (
    id integer NOT NULL,
    company_id integer NOT NULL,
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    status character varying(10) NOT NULL,
    employee_code character varying(20),
    joined_at timestamp without time zone,
    date_of_leaving date,
    module_flags text,
    manager_id integer,
    designation character varying(100),
    department character varying(100)
);


--
-- Name: company_memberships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.company_memberships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: company_memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.company_memberships_id_seq OWNED BY public.company_memberships.id;


--
-- Name: consumption_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consumption_items (
    id integer NOT NULL,
    company_id integer,
    voucher_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(200),
    quantity numeric(16,4) NOT NULL,
    unit_cost numeric(16,4),
    total_cost numeric(16,4)
);


--
-- Name: consumption_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.consumption_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consumption_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.consumption_items_id_seq OWNED BY public.consumption_items.id;


--
-- Name: consumption_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consumption_vouchers (
    id integer NOT NULL,
    company_id integer,
    voucher_number character varying(50) NOT NULL,
    date timestamp without time zone,
    department character varying(100),
    reason text,
    charge_account_id integer,
    label_id integer,
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone
);


--
-- Name: consumption_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.consumption_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consumption_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.consumption_vouchers_id_seq OWNED BY public.consumption_vouchers.id;


--
-- Name: digital_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digital_files (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    category_id integer,
    title character varying(200) NOT NULL,
    filename character varying(255) NOT NULL,
    original_name character varying(255) NOT NULL,
    file_size integer,
    mime_type character varying(100),
    notes text,
    expiry_date date,
    is_verified boolean,
    verified_by integer,
    verified_at timestamp without time zone,
    uploaded_at timestamp without time zone
);


--
-- Name: digital_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digital_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digital_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digital_files_id_seq OWNED BY public.digital_files.id;


--
-- Name: dotnet_data_protection_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dotnet_data_protection_keys (
    id integer NOT NULL,
    friendly_name character varying(200) NOT NULL,
    xml text NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: dotnet_data_protection_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dotnet_data_protection_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dotnet_data_protection_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dotnet_data_protection_keys_id_seq OWNED BY public.dotnet_data_protection_keys.id;


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_logs (
    id integer NOT NULL,
    company_id integer,
    recipient character varying(120) NOT NULL,
    subject character varying(200) NOT NULL,
    body text,
    module character varying(50),
    status character varying(20),
    error_message text,
    sent_at timestamp without time zone
);


--
-- Name: email_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_logs_id_seq OWNED BY public.email_logs.id;


--
-- Name: exec_account_selections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exec_account_selections (
    id integer NOT NULL,
    company_id integer,
    account_id integer NOT NULL,
    include_children boolean NOT NULL,
    created_by integer,
    created_at timestamp without time zone
);


--
-- Name: exec_account_selections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.exec_account_selections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exec_account_selections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.exec_account_selections_id_seq OWNED BY public.exec_account_selections.id;


--
-- Name: fa_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fa_categories (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    description text,
    default_useful_life integer,
    default_depreciation_method character varying(20),
    default_salvage_value_pct numeric(20,6),
    is_active boolean,
    created_at timestamp without time zone
);


--
-- Name: fa_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fa_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fa_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fa_categories_id_seq OWNED BY public.fa_categories.id;


--
-- Name: fbr_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fbr_config (
    id integer NOT NULL,
    company_id integer,
    environment character varying(20),
    access_token character varying(500),
    token_expiry timestamp without time zone,
    seller_ntn character varying(50),
    seller_strn character varying(50),
    seller_cnic character varying(50),
    seller_name character varying(200),
    seller_business_name character varying(200),
    seller_address text,
    seller_phone character varying(50),
    seller_email character varying(200),
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: fbr_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fbr_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fbr_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fbr_config_id_seq OWNED BY public.fbr_config.id;


--
-- Name: fbr_invoice_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fbr_invoice_records (
    id integer NOT NULL,
    company_id integer,
    inv_invoice_id integer NOT NULL,
    fbr_invoice_number character varying(100),
    fbr_submission_id character varying(100),
    status character varying(20),
    request_json text,
    response_json text,
    error_message text,
    invoice_type character varying(10),
    attempt_count integer,
    submitted_at timestamp without time zone,
    submitted_by integer,
    created_at timestamp without time zone
);


--
-- Name: fbr_invoice_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fbr_invoice_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fbr_invoice_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fbr_invoice_records_id_seq OWNED BY public.fbr_invoice_records.id;


--
-- Name: file_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_categories (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    description text
);


--
-- Name: file_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.file_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: file_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.file_categories_id_seq OWNED BY public.file_categories.id;


--
-- Name: fiscal_year_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_year_rule (
    id integer NOT NULL,
    company_id integer,
    start_month integer NOT NULL,
    start_day integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: fiscal_year_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_year_rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_year_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_year_rule_id_seq OWNED BY public.fiscal_year_rule.id;


--
-- Name: fixed_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fixed_assets (
    id integer NOT NULL,
    company_id integer,
    asset_code character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    category_id integer NOT NULL,
    purchase_date date NOT NULL,
    purchase_cost numeric(20,6) NOT NULL,
    useful_life integer NOT NULL,
    depreciation_method character varying(20) NOT NULL,
    salvage_value numeric(20,6),
    accumulated_depreciation numeric(20,6),
    current_book_value numeric(20,6) NOT NULL,
    status character varying(20),
    location character varying(200),
    assigned_to character varying(100),
    vendor character varying(200),
    serial_number character varying(100),
    fixed_asset_account_id integer,
    accum_dep_account_id integer,
    dep_expense_account_id integer,
    acquisition_credit_account_id integer,
    notes text,
    label_id integer,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: fixed_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fixed_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fixed_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fixed_assets_id_seq OWNED BY public.fixed_assets.id;


--
-- Name: gl_daily_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gl_daily_balances (
    id integer NOT NULL,
    company_id integer NOT NULL,
    account_id integer NOT NULL,
    label_id integer NOT NULL,
    day date NOT NULL,
    debit numeric(18,4) NOT NULL,
    credit numeric(18,4) NOT NULL,
    line_count integer NOT NULL
);


--
-- Name: gl_daily_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gl_daily_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gl_daily_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gl_daily_balances_id_seq OWNED BY public.gl_daily_balances.id;


--
-- Name: global_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.global_limits (
    id integer NOT NULL,
    max_companies_per_user integer NOT NULL,
    default_max_members integer NOT NULL,
    updated_by integer,
    updated_at timestamp without time zone
);


--
-- Name: global_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.global_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: global_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.global_limits_id_seq OWNED BY public.global_limits.id;


--
-- Name: income_tax_slabs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.income_tax_slabs (
    id integer NOT NULL,
    company_id integer,
    min_income numeric(20,6) NOT NULL,
    max_income numeric(20,6) NOT NULL,
    rate_pct numeric(20,6) NOT NULL,
    fixed_amount numeric(20,6) NOT NULL,
    is_active boolean,
    created_at timestamp without time zone
);


--
-- Name: income_tax_slabs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.income_tax_slabs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: income_tax_slabs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.income_tax_slabs_id_seq OWNED BY public.income_tax_slabs.id;


--
-- Name: inv_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_categories (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    description text,
    parent_id integer,
    is_active boolean,
    created_at timestamp without time zone
);


--
-- Name: inv_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_categories_id_seq OWNED BY public.inv_categories.id;


--
-- Name: inv_customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_customers (
    id integer NOT NULL,
    company_id integer,
    name character varying(200) NOT NULL,
    contact_person character varying(100),
    email character varying(120),
    phone character varying(20),
    mobile character varying(20),
    address text,
    city character varying(50),
    tax_id character varying(50),
    payment_terms character varying(100),
    credit_limit numeric(20,6),
    website character varying(200),
    notes text,
    is_active boolean,
    created_at timestamp without time zone
);


--
-- Name: inv_customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_customers_id_seq OWNED BY public.inv_customers.id;


--
-- Name: inv_invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_invoice_items (
    id integer NOT NULL,
    company_id integer,
    invoice_id integer NOT NULL,
    product_id integer,
    description character varying(300),
    quantity numeric(20,6),
    unit character varying(20),
    unit_price numeric(20,6),
    label_id integer,
    source_order_id integer,
    source_order_item_id integer,
    source_order_number character varying(50),
    discount_pct numeric(20,6),
    discount_amount numeric(20,6),
    delivery numeric(20,6),
    installation numeric(20,6),
    sales_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    comments text
);


--
-- Name: inv_invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_invoice_items_id_seq OWNED BY public.inv_invoice_items.id;


--
-- Name: inv_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_invoices (
    id integer NOT NULL,
    company_id integer,
    invoice_number character varying(50) NOT NULL,
    voucher_number character varying(50) NOT NULL,
    sales_order_id integer,
    customer_id integer NOT NULL,
    party_account_id integer,
    label_id integer,
    invoice_date timestamp without time zone,
    due_date timestamp without time zone,
    voucher_status character varying(20),
    payment_status character varying(20),
    discount_mode character varying(20),
    charges_mode character varying(20),
    tax_mode character varying(20),
    global_discount_pct numeric(20,6),
    global_discount_value numeric(20,6),
    global_delivery numeric(20,6),
    global_installation numeric(20,6),
    global_sales_tax_pct numeric(20,6),
    further_tax_pct numeric(20,6),
    apply_further_tax boolean,
    withholding_tax_pct numeric(20,6),
    apply_withholding_tax boolean,
    subtotal numeric(20,6),
    total_discount numeric(20,6),
    total_charges numeric(20,6),
    total_tax numeric(20,6),
    total_further_tax numeric(20,6),
    total_withholding_tax numeric(20,6),
    total_amount numeric(20,6),
    paid_amount numeric(20,6),
    notes text,
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);


--
-- Name: inv_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_invoices_id_seq OWNED BY public.inv_invoices.id;


--
-- Name: inv_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_products (
    id integer NOT NULL,
    company_id integer,
    sku character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    category_id integer,
    unit_price numeric(20,6),
    cost_price numeric(20,6),
    reorder_level integer,
    current_stock numeric(16,4),
    unit character varying(20),
    hs_code character varying(50),
    weight numeric(20,6),
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: inv_products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_products_id_seq OWNED BY public.inv_products.id;


--
-- Name: inv_purchase_invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_purchase_invoice_items (
    id integer NOT NULL,
    company_id integer,
    invoice_id integer NOT NULL,
    product_id integer,
    description character varying(300),
    quantity numeric(20,6),
    unit character varying(20),
    unit_price numeric(20,6),
    label_id integer,
    source_order_id integer,
    source_order_item_id integer,
    source_order_number character varying(50),
    discount_pct numeric(20,6),
    discount_amount numeric(20,6),
    commission numeric(20,6),
    freight numeric(20,6),
    loading_unloading numeric(20,6),
    sales_tax_pct numeric(20,6),
    withholding_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    comments text
);


--
-- Name: inv_purchase_invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_purchase_invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_purchase_invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_purchase_invoice_items_id_seq OWNED BY public.inv_purchase_invoice_items.id;


--
-- Name: inv_purchase_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_purchase_invoices (
    id integer NOT NULL,
    company_id integer,
    invoice_number character varying(50) NOT NULL,
    voucher_number character varying(50) NOT NULL,
    invoice_date timestamp without time zone,
    supplier_id integer NOT NULL,
    party_account_id integer,
    label_id integer,
    driver_name character varying(100),
    driver_contact character varying(50),
    vehicle_number character varying(50),
    gate_pass character varying(50),
    discount_mode character varying(20),
    expenses_mode character varying(20),
    tax_mode character varying(20),
    global_discount_pct numeric(20,6),
    global_discount_value numeric(20,6),
    global_commission numeric(20,6),
    global_freight numeric(20,6),
    global_loading numeric(20,6),
    global_sales_tax_pct numeric(20,6),
    global_withholding_tax_pct numeric(20,6),
    further_tax_pct numeric(20,6),
    apply_further_tax boolean,
    apply_withholding_tax boolean,
    subtotal numeric(20,6),
    total_discount numeric(20,6),
    total_expenses numeric(20,6),
    total_tax numeric(20,6),
    total_further_tax numeric(20,6),
    total_withholding_tax numeric(20,6),
    net_payable numeric(20,6),
    total_amount numeric(20,6),
    paid_amount numeric(20,6),
    payment_status character varying(20),
    purchase_order_id integer,
    notes text,
    status character varying(20),
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);


--
-- Name: inv_purchase_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_purchase_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_purchase_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_purchase_invoices_id_seq OWNED BY public.inv_purchase_invoices.id;


--
-- Name: inv_purchase_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_purchase_order_items (
    id integer NOT NULL,
    company_id integer,
    po_id integer NOT NULL,
    product_id integer NOT NULL,
    description character varying(200),
    unit character varying(20),
    quantity numeric(20,6),
    invoiced_qty numeric(20,6),
    unit_price numeric(20,6),
    sales_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    total_price numeric(20,6)
);


--
-- Name: inv_purchase_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_purchase_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_purchase_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_purchase_order_items_id_seq OWNED BY public.inv_purchase_order_items.id;


--
-- Name: inv_purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_purchase_orders (
    id integer NOT NULL,
    company_id integer,
    po_number character varying(50) NOT NULL,
    supplier_id integer NOT NULL,
    party_account_id integer,
    order_date date,
    expected_date date,
    status character varying(20),
    fulfilment_status character varying(20),
    tax_mode character varying(20),
    global_sales_tax_pct numeric(20,6),
    subtotal numeric(20,6),
    total_tax numeric(20,6),
    total_amount numeric(20,6),
    notes text,
    driver_name character varying(100),
    driver_contact character varying(50),
    vehicle_number character varying(50),
    gate_pass character varying(50),
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);


--
-- Name: inv_purchase_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_purchase_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_purchase_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_purchase_orders_id_seq OWNED BY public.inv_purchase_orders.id;


--
-- Name: inv_purchase_return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_purchase_return_items (
    id integer NOT NULL,
    company_id integer,
    return_id integer NOT NULL,
    product_id integer,
    description character varying(300),
    original_quantity numeric(20,6),
    previously_returned_qty numeric(20,6),
    max_returnable_qty numeric(20,6),
    current_return_qty numeric(20,6),
    unit character varying(20),
    unit_price numeric(20,6),
    discount_pct numeric(20,6),
    discount_amount numeric(20,6),
    commission numeric(20,6),
    freight numeric(20,6),
    loading_unloading numeric(20,6),
    sales_tax_pct numeric(20,6),
    withholding_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    proportional_discount numeric(20,6),
    proportional_sales_tax numeric(20,6),
    proportional_withholding_tax numeric(20,6),
    proportional_commission numeric(20,6),
    proportional_freight numeric(20,6),
    proportional_loading numeric(20,6),
    net_return_value numeric(20,6)
);


--
-- Name: inv_purchase_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_purchase_return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_purchase_return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_purchase_return_items_id_seq OWNED BY public.inv_purchase_return_items.id;


--
-- Name: inv_purchase_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_purchase_returns (
    id integer NOT NULL,
    company_id integer,
    return_number character varying(50) NOT NULL,
    original_invoice_id integer NOT NULL,
    supplier_id integer NOT NULL,
    return_date timestamp without time zone,
    notes text,
    gross_return_value numeric(20,6),
    total_discount numeric(20,6),
    total_expenses numeric(20,6),
    total_tax numeric(20,6),
    net_return_amount numeric(20,6),
    reverse_expenses boolean,
    status character varying(20),
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);


--
-- Name: inv_purchase_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_purchase_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_purchase_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_purchase_returns_id_seq OWNED BY public.inv_purchase_returns.id;


--
-- Name: inv_sales_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_sales_order_items (
    id integer NOT NULL,
    company_id integer,
    so_id integer NOT NULL,
    product_id integer NOT NULL,
    description character varying(200),
    unit character varying(20),
    quantity numeric(20,6),
    invoiced_qty numeric(20,6),
    unit_price numeric(20,6),
    sales_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    total_price numeric(20,6)
);


--
-- Name: inv_sales_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_sales_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_sales_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_sales_order_items_id_seq OWNED BY public.inv_sales_order_items.id;


--
-- Name: inv_sales_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_sales_orders (
    id integer NOT NULL,
    company_id integer,
    so_number character varying(50) NOT NULL,
    customer_id integer NOT NULL,
    party_account_id integer,
    order_date date,
    expected_date date,
    status character varying(20),
    fulfilment_status character varying(20),
    tax_mode character varying(20),
    global_sales_tax_pct numeric(20,6),
    subtotal numeric(20,6),
    total_tax numeric(20,6),
    total_amount numeric(20,6),
    notes text,
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);


--
-- Name: inv_sales_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_sales_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_sales_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_sales_orders_id_seq OWNED BY public.inv_sales_orders.id;


--
-- Name: inv_sales_return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_sales_return_items (
    id integer NOT NULL,
    company_id integer,
    return_id integer NOT NULL,
    product_id integer,
    description character varying(300),
    original_quantity numeric(20,6),
    previously_returned_qty numeric(20,6),
    max_returnable_qty numeric(20,6),
    current_return_qty numeric(20,6),
    unit character varying(20),
    unit_price numeric(20,6),
    discount_pct numeric(20,6),
    discount_amount numeric(20,6),
    delivery numeric(20,6),
    installation numeric(20,6),
    sales_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    proportional_discount numeric(20,6),
    proportional_sales_tax numeric(20,6),
    proportional_delivery numeric(20,6),
    proportional_installation numeric(20,6),
    net_return_value numeric(20,6),
    cost_basis numeric(20,6),
    total_cost_returned numeric(20,6)
);


--
-- Name: inv_sales_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_sales_return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_sales_return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_sales_return_items_id_seq OWNED BY public.inv_sales_return_items.id;


--
-- Name: inv_sales_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_sales_returns (
    id integer NOT NULL,
    company_id integer,
    return_number character varying(50) NOT NULL,
    original_invoice_id integer NOT NULL,
    customer_id integer NOT NULL,
    party_account_id integer,
    return_date timestamp without time zone,
    notes text,
    gross_return_value numeric(20,6),
    total_discount numeric(20,6),
    total_charges numeric(20,6),
    total_tax numeric(20,6),
    net_return_amount numeric(20,6),
    total_cost_returned numeric(20,6),
    reverse_charges boolean,
    status character varying(20),
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);


--
-- Name: inv_sales_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_sales_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_sales_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_sales_returns_id_seq OWNED BY public.inv_sales_returns.id;


--
-- Name: inv_stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_stock_movements (
    id integer NOT NULL,
    company_id integer,
    product_id integer NOT NULL,
    type character varying(20) NOT NULL,
    quantity numeric(16,4) NOT NULL,
    reference_type character varying(50),
    reference_id integer,
    notes text,
    created_by integer,
    created_at timestamp without time zone
);


--
-- Name: inv_stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_stock_movements_id_seq OWNED BY public.inv_stock_movements.id;


--
-- Name: inv_suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_suppliers (
    id integer NOT NULL,
    company_id integer,
    name character varying(200) NOT NULL,
    contact_person character varying(100),
    email character varying(120),
    phone character varying(20),
    mobile character varying(20),
    address text,
    city character varying(50),
    tax_id character varying(50),
    payment_terms character varying(100),
    website character varying(200),
    notes text,
    is_active boolean,
    created_at timestamp without time zone
);


--
-- Name: inv_suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_suppliers_id_seq OWNED BY public.inv_suppliers.id;


--
-- Name: inv_units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inv_units (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    abbreviation character varying(20) NOT NULL,
    explanation text,
    is_active boolean,
    created_at timestamp without time zone
);


--
-- Name: inv_units_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inv_units_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inv_units_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inv_units_id_seq OWNED BY public.inv_units.id;


--
-- Name: inventory_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_settings (
    id integer NOT NULL,
    company_id integer,
    valuation_method character varying(20),
    allow_negative_stock boolean,
    decimal_places integer,
    auto_generate_vouchers boolean,
    purchase_flow character varying(20),
    sales_flow character varying(20),
    default_cogs_account_id integer,
    default_inventory_account_id integer,
    default_return_account_id integer,
    per_line_labeling_voucher boolean,
    per_line_labeling_invoice boolean,
    default_voucher_label_id integer,
    default_invoice_label_id integer
);


--
-- Name: inventory_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_settings_id_seq OWNED BY public.inventory_settings.id;


--
-- Name: invoice_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_settings (
    id integer NOT NULL,
    company_id integer,
    default_sales_tax_pct numeric(20,6),
    default_further_tax_pct numeric(20,6),
    default_withholding_tax_pct numeric(20,6),
    default_discount_pct numeric(20,6),
    default_charges_mode character varying(20),
    default_discount_mode character varying(20),
    default_tax_mode character varying(20),
    show_discount_column boolean,
    show_charges_column boolean,
    show_tax_column boolean,
    auto_add_line boolean,
    require_approval boolean,
    allow_partial_payment boolean,
    default_party_mode character varying(10),
    over_invoice_tolerance_pct numeric(20,6),
    withholding_base character varying(10),
    show_further_tax boolean,
    show_withholding_tax boolean,
    show_transport_block boolean,
    create_from_orders_enabled boolean,
    per_line_discount_enabled boolean,
    per_line_tax_enabled boolean
);


--
-- Name: invoice_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_settings_id_seq OWNED BY public.invoice_settings.id;


--
-- Name: invoice_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_templates (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    type character varying(10) NOT NULL,
    body_html text NOT NULL,
    is_default boolean,
    design character varying(20),
    accent_color character varying(20),
    options_json text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: invoice_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_templates_id_seq OWNED BY public.invoice_templates.id;


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entries (
    id integer NOT NULL,
    company_id integer,
    voucher_type character varying(50) NOT NULL,
    voucher_id integer NOT NULL,
    voucher_number character varying(50) NOT NULL,
    description text,
    entry_date timestamp without time zone NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp without time zone,
    is_posted boolean
);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_entries_id_seq OWNED BY public.journal_entries.id;


--
-- Name: journal_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_lines (
    id integer NOT NULL,
    company_id integer,
    journal_entry_id integer NOT NULL,
    account_id integer NOT NULL,
    debit numeric(16,4),
    credit numeric(16,4),
    description text,
    label_id integer
);


--
-- Name: journal_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_lines_id_seq OWNED BY public.journal_lines.id;


--
-- Name: kanban_boards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kanban_boards (
    id integer NOT NULL,
    company_id integer,
    title character varying(200) NOT NULL,
    description text,
    created_by integer NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: kanban_boards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kanban_boards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kanban_boards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kanban_boards_id_seq OWNED BY public.kanban_boards.id;


--
-- Name: kanban_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kanban_tasks (
    id integer NOT NULL,
    company_id integer,
    board_id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    status character varying(30),
    priority character varying(20),
    assignee_id integer,
    due_date date,
    "position" integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: kanban_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kanban_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kanban_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kanban_tasks_id_seq OWNED BY public.kanban_tasks.id;


--
-- Name: layer_consumptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.layer_consumptions (
    id integer NOT NULL,
    company_id integer,
    layer_id integer NOT NULL,
    out_ledger_id integer NOT NULL,
    product_id integer NOT NULL,
    qty numeric(16,4) NOT NULL,
    unit_cost numeric(16,4) NOT NULL,
    total_cost numeric(16,4) NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: layer_consumptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.layer_consumptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: layer_consumptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.layer_consumptions_id_seq OWNED BY public.layer_consumptions.id;


--
-- Name: leave_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_approvals (
    id integer NOT NULL,
    company_id integer,
    leave_request_id integer NOT NULL,
    approver_id integer NOT NULL,
    level integer,
    status character varying(20),
    comment text,
    created_at timestamp without time zone
);


--
-- Name: leave_approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_approvals_id_seq OWNED BY public.leave_approvals.id;


--
-- Name: leave_quotas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_quotas (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    year integer NOT NULL,
    total numeric(20,6),
    used numeric(20,6),
    pending numeric(20,6),
    remaining numeric(20,6)
);


--
-- Name: leave_quotas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_quotas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_quotas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_quotas_id_seq OWNED BY public.leave_quotas.id;


--
-- Name: leave_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_requests (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    total_days numeric(20,6) NOT NULL,
    reason text NOT NULL,
    status character varying(20),
    is_half_day boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: leave_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_requests_id_seq OWNED BY public.leave_requests.id;


--
-- Name: leave_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_types (
    id integer NOT NULL,
    company_id integer,
    name character varying(50) NOT NULL,
    code character varying(10) NOT NULL,
    description text,
    default_quota integer,
    is_paid boolean,
    requires_approval boolean,
    carry_forward boolean,
    max_carry_forward integer
);


--
-- Name: leave_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_types_id_seq OWNED BY public.leave_types.id;


--
-- Name: loan_advance_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loan_advance_requests (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    request_type character varying(20) NOT NULL,
    amount numeric(20,6) NOT NULL,
    purpose text NOT NULL,
    installment_months integer,
    monthly_installment numeric(20,6),
    remaining_amount numeric(20,6),
    status character varying(20),
    approved_by integer,
    approved_at timestamp without time zone,
    disbursed_at timestamp without time zone,
    queue_for_payroll boolean,
    notes text,
    created_at timestamp without time zone
);


--
-- Name: loan_advance_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.loan_advance_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: loan_advance_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.loan_advance_requests_id_seq OWNED BY public.loan_advance_requests.id;


--
-- Name: loan_repayments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loan_repayments (
    id integer NOT NULL,
    company_id integer,
    loan_id integer NOT NULL,
    amount numeric(20,6) NOT NULL,
    paid_at timestamp without time zone,
    payroll_run_id integer,
    notes text
);


--
-- Name: loan_repayments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.loan_repayments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: loan_repayments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.loan_repayments_id_seq OWNED BY public.loan_repayments.id;


--
-- Name: notification_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_recipients (
    id integer NOT NULL,
    company_id integer,
    notification_id integer NOT NULL,
    user_id integer NOT NULL,
    is_read boolean,
    read_at timestamp without time zone
);


--
-- Name: notification_recipients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_recipients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_recipients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_recipients_id_seq OWNED BY public.notification_recipients.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    company_id integer,
    title character varying(200) NOT NULL,
    message text NOT NULL,
    notification_type character varying(50),
    module character varying(50),
    reference_id integer,
    created_by integer,
    created_at timestamp without time zone
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: overtime_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.overtime_accounts (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    date date NOT NULL,
    regular_hours double precision,
    overtime_hours double precision,
    double_overtime double precision,
    approved boolean,
    notes text,
    created_at timestamp without time zone
);


--
-- Name: overtime_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.overtime_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: overtime_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.overtime_accounts_id_seq OWNED BY public.overtime_accounts.id;


--
-- Name: payment_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_allocations (
    id integer NOT NULL,
    company_id integer,
    voucher_id integer NOT NULL,
    voucher_line_id integer NOT NULL,
    doc_type character varying(4) NOT NULL,
    doc_id integer NOT NULL,
    party_type character varying(10) NOT NULL,
    party_id integer NOT NULL,
    amount numeric(16,4) NOT NULL,
    note character varying(300),
    created_by integer,
    created_at timestamp without time zone
);


--
-- Name: payment_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_allocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_allocations_id_seq OWNED BY public.payment_allocations.id;


--
-- Name: payroll_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_audit_logs (
    id integer NOT NULL,
    company_id integer,
    payroll_run_id integer,
    action character varying(50) NOT NULL,
    performed_by integer NOT NULL,
    details text,
    ip_address character varying(50),
    performed_at timestamp without time zone
);


--
-- Name: payroll_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_audit_logs_id_seq OWNED BY public.payroll_audit_logs.id;


--
-- Name: payroll_components; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_components (
    id integer NOT NULL,
    company_id integer,
    profile_id integer NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(20) NOT NULL,
    calculation_method character varying(30),
    value numeric(20,6),
    is_taxable boolean
);


--
-- Name: payroll_components_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_components_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_components_id_seq OWNED BY public.payroll_components.id;


--
-- Name: payroll_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_profiles (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    basic_salary numeric(20,6),
    effective_from date NOT NULL,
    payment_method character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: payroll_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_profiles_id_seq OWNED BY public.payroll_profiles.id;


--
-- Name: payroll_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_runs (
    id integer NOT NULL,
    company_id integer,
    month integer NOT NULL,
    year integer NOT NULL,
    run_date timestamp without time zone,
    status character varying(20),
    total_gross numeric(20,6),
    total_deductions numeric(20,6),
    total_net numeric(20,6),
    employee_count integer,
    processed_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    notes text,
    paid_at timestamp without time zone
);


--
-- Name: payroll_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_runs_id_seq OWNED BY public.payroll_runs.id;


--
-- Name: payroll_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_settings (
    id integer NOT NULL,
    company_id integer,
    overtime_multiplier numeric(20,6),
    overtime_hours_basis numeric(20,6),
    eobi_enabled boolean,
    eobi_wage_base numeric(20,6),
    eobi_employee_pct numeric(20,6),
    eobi_employer_pct numeric(20,6),
    surcharge_threshold numeric(20,6),
    surcharge_pct numeric(20,6),
    gratuity_enabled boolean,
    gratuity_basis character varying(10),
    gratuity_days_per_year numeric(20,6),
    leave_encashment_enabled boolean
);


--
-- Name: payroll_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_settings_id_seq OWNED BY public.payroll_settings.id;


--
-- Name: payroll_slips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_slips (
    id integer NOT NULL,
    company_id integer,
    payroll_run_id integer NOT NULL,
    user_id integer NOT NULL,
    basic_salary numeric(20,6),
    allowances numeric(20,6),
    deductions numeric(20,6),
    gross_pay numeric(20,6),
    total_deductions numeric(20,6),
    net_pay numeric(20,6),
    taxable_pay numeric(20,6),
    components_json text,
    pdf_filename character varying(255),
    created_at timestamp without time zone
);


--
-- Name: payroll_slips_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_slips_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_slips_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_slips_id_seq OWNED BY public.payroll_slips.id;


--
-- Name: performance_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.performance_goals (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    target_date date,
    status character varying(20),
    progress_pct integer,
    created_by integer,
    created_at timestamp without time zone
);


--
-- Name: performance_goals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.performance_goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: performance_goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.performance_goals_id_seq OWNED BY public.performance_goals.id;


--
-- Name: performance_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.performance_reviews (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    reviewer_id integer NOT NULL,
    review_period character varying(50) NOT NULL,
    overall_score double precision,
    productivity_rating integer,
    quality_rating integer,
    teamwork_rating integer,
    punctuality_rating integer,
    strengths text,
    improvements text,
    feedback text,
    status character varying(20),
    completed_at timestamp without time zone,
    created_at timestamp without time zone
);


--
-- Name: performance_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.performance_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: performance_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.performance_reviews_id_seq OWNED BY public.performance_reviews.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    role_id integer NOT NULL,
    resource character varying(100) NOT NULL,
    can_read boolean,
    can_write boolean,
    can_delete boolean
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: pf_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pf_config (
    id integer NOT NULL,
    company_id integer,
    employee_contribution_pct numeric(20,6),
    employer_contribution_pct numeric(20,6),
    contribution_base character varying(10),
    max_loan_percentage numeric(20,6),
    interest_rate numeric(20,6),
    min_service_months_for_loan integer,
    is_active boolean,
    updated_at timestamp without time zone
);


--
-- Name: pf_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pf_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pf_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pf_config_id_seq OWNED BY public.pf_config.id;


--
-- Name: pf_contributions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pf_contributions (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    employee_amount numeric(20,6),
    employer_amount numeric(20,6),
    total_amount numeric(20,6),
    created_at timestamp without time zone
);


--
-- Name: pf_contributions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pf_contributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pf_contributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pf_contributions_id_seq OWNED BY public.pf_contributions.id;


--
-- Name: pf_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pf_ledger (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    transaction_date date NOT NULL,
    transaction_type character varying(30) NOT NULL,
    description text,
    debit numeric(20,6),
    credit numeric(20,6),
    balance numeric(20,6),
    reference_id integer,
    payroll_run_id integer,
    created_at timestamp without time zone
);


--
-- Name: pf_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pf_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pf_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pf_ledger_id_seq OWNED BY public.pf_ledger.id;


--
-- Name: pf_loan_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pf_loan_requests (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    amount numeric(20,6) NOT NULL,
    installment_months integer,
    purpose text NOT NULL,
    status character varying(20),
    approved_by integer,
    approved_at timestamp without time zone,
    monthly_installment numeric(20,6),
    remaining_amount numeric(20,6),
    created_at timestamp without time zone
);


--
-- Name: pf_loan_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pf_loan_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pf_loan_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pf_loan_requests_id_seq OWNED BY public.pf_loan_requests.id;


--
-- Name: pf_profit_distributions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pf_profit_distributions (
    id integer NOT NULL,
    company_id integer,
    month integer NOT NULL,
    year integer NOT NULL,
    total_profit numeric(20,6) NOT NULL,
    distributed_at timestamp without time zone,
    distributed_by integer,
    status character varying(20)
);


--
-- Name: pf_profit_distributions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pf_profit_distributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pf_profit_distributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pf_profit_distributions_id_seq OWNED BY public.pf_profit_distributions.id;


--
-- Name: pf_settlements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pf_settlements (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    total_employee_contrib numeric(20,6),
    total_employer_contrib numeric(20,6),
    total_profit_distributed numeric(20,6),
    outstanding_loan numeric(20,6),
    net_settlement numeric(20,6),
    status character varying(20),
    settled_by integer,
    settled_at timestamp without time zone,
    pdf_statement character varying(255),
    created_at timestamp without time zone
);


--
-- Name: pf_settlements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pf_settlements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pf_settlements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pf_settlements_id_seq OWNED BY public.pf_settlements.id;


--
-- Name: pf_withdrawal_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pf_withdrawal_requests (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    amount numeric(20,6) NOT NULL,
    reason text NOT NULL,
    status character varying(20),
    approved_by integer,
    approved_at timestamp without time zone,
    disbursed_at timestamp without time zone,
    created_at timestamp without time zone
);


--
-- Name: pf_withdrawal_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pf_withdrawal_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pf_withdrawal_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pf_withdrawal_requests_id_seq OWNED BY public.pf_withdrawal_requests.id;


--
-- Name: project_labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_labels (
    id integer NOT NULL,
    company_id integer,
    name character varying(120) NOT NULL,
    is_active boolean,
    created_at timestamp without time zone
);


--
-- Name: project_labels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_labels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_labels_id_seq OWNED BY public.project_labels.id;


--
-- Name: project_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_tasks (
    id integer NOT NULL,
    company_id integer,
    work_package_id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    estimated_hours double precision,
    assigned_to integer,
    due_date date,
    status character varying(20),
    created_at timestamp without time zone
);


--
-- Name: project_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_tasks_id_seq OWNED BY public.project_tasks.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    company_id integer,
    name character varying(200) NOT NULL,
    code character varying(20),
    description text,
    department character varying(100),
    project_manager_id integer,
    start_date date,
    end_date date,
    status character varying(20),
    is_billable boolean,
    created_at timestamp without time zone
);


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: registration_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registration_requests (
    id integer NOT NULL,
    full_name character varying(120) NOT NULL,
    email character varying(120) NOT NULL,
    phone character varying(30),
    password_hash character varying(255) NOT NULL,
    company_name character varying(200),
    notes text,
    status character varying(15) NOT NULL,
    seen boolean NOT NULL,
    reviewed_by integer,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: registration_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.registration_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: registration_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.registration_requests_id_seq OWNED BY public.registration_requests.id;


--
-- Name: report_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_settings (
    id integer NOT NULL,
    company_id integer,
    pl_structure_json text,
    pl_detail_rows integer,
    invoice_party_mode character varying(10),
    purchase_party_mode character varying(10),
    sales_party_mode character varying(10),
    purchase_template_text text,
    sales_template_text text,
    purchase_template_id integer,
    sales_template_id integer,
    cash_flow_method character varying(20),
    twcf_cash_floor numeric(16,4),
    updated_at timestamp without time zone
);


--
-- Name: report_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.report_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: report_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.report_settings_id_seq OWNED BY public.report_settings.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(200)
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: salary_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_revisions (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    previous_basic numeric(20,6),
    new_basic numeric(20,6) NOT NULL,
    reason text,
    approved_by integer,
    effective_from date NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: salary_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_revisions_id_seq OWNED BY public.salary_revisions.id;


--
-- Name: scrap_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scrap_items (
    id integer NOT NULL,
    company_id integer,
    voucher_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(200),
    quantity numeric(16,4) NOT NULL,
    unit_cost numeric(16,4),
    total_cost numeric(16,4)
);


--
-- Name: scrap_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scrap_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scrap_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scrap_items_id_seq OWNED BY public.scrap_items.id;


--
-- Name: scrap_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scrap_vouchers (
    id integer NOT NULL,
    company_id integer,
    voucher_number character varying(50) NOT NULL,
    date timestamp without time zone,
    reason text,
    charge_account_id integer,
    label_id integer,
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone
);


--
-- Name: scrap_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scrap_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scrap_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scrap_vouchers_id_seq OWNED BY public.scrap_vouchers.id;


--
-- Name: stock_adjustment_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_adjustment_items (
    id integer NOT NULL,
    company_id integer,
    voucher_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(200),
    system_qty numeric(16,4),
    physical_qty numeric(16,4),
    difference numeric(16,4),
    unit_cost numeric(16,4),
    total_cost numeric(16,4)
);


--
-- Name: stock_adjustment_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_adjustment_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_adjustment_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_adjustment_items_id_seq OWNED BY public.stock_adjustment_items.id;


--
-- Name: stock_adjustment_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_adjustment_vouchers (
    id integer NOT NULL,
    company_id integer,
    voucher_number character varying(50) NOT NULL,
    date timestamp without time zone,
    reason text,
    label_id integer,
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone
);


--
-- Name: stock_adjustment_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_adjustment_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_adjustment_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_adjustment_vouchers_id_seq OWNED BY public.stock_adjustment_vouchers.id;


--
-- Name: stock_cost_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_cost_adjustments (
    id integer NOT NULL,
    company_id integer,
    product_id integer NOT NULL,
    ledger_id integer,
    voucher_type character varying(50) NOT NULL,
    voucher_id integer NOT NULL,
    voucher_number character varying(50),
    old_cost numeric(16,4) NOT NULL,
    new_cost numeric(16,4) NOT NULL,
    delta numeric(16,4) NOT NULL,
    trigger character varying(120),
    journal_entry_id integer,
    entry_date date,
    created_at timestamp without time zone
);


--
-- Name: stock_cost_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_cost_adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_cost_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_cost_adjustments_id_seq OWNED BY public.stock_cost_adjustments.id;


--
-- Name: stock_layers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_layers (
    id integer NOT NULL,
    company_id integer,
    product_id integer NOT NULL,
    source_ledger_id integer,
    unit_cost numeric(16,4) NOT NULL,
    qty_original numeric(16,4) NOT NULL,
    qty_remaining numeric(16,4) NOT NULL,
    value_remaining numeric(18,4) NOT NULL,
    method character varying(20) NOT NULL,
    is_revaluation boolean,
    created_at timestamp without time zone,
    notes text
);


--
-- Name: stock_layers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_layers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_layers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_layers_id_seq OWNED BY public.stock_layers.id;


--
-- Name: stock_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_ledger (
    id integer NOT NULL,
    company_id integer,
    product_id integer NOT NULL,
    voucher_type character varying(50) NOT NULL,
    voucher_id integer NOT NULL,
    voucher_number character varying(50) NOT NULL,
    transaction_type character varying(10) NOT NULL,
    quantity numeric(16,4) NOT NULL,
    unit_cost numeric(16,4) NOT NULL,
    total_cost numeric(16,4) NOT NULL,
    running_qty numeric(16,4) NOT NULL,
    running_cost numeric(16,4) NOT NULL,
    running_avg numeric(16,4) NOT NULL,
    valuation_method character varying(20),
    txn_date date,
    created_at timestamp without time zone,
    created_by integer NOT NULL,
    notes text
);


--
-- Name: stock_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_ledger_id_seq OWNED BY public.stock_ledger.id;


--
-- Name: stock_take_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_take_items (
    id integer NOT NULL,
    company_id integer,
    stock_take_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(200),
    system_qty numeric(16,4),
    physical_qty numeric(16,4),
    difference numeric(16,4),
    unit_cost numeric(16,4)
);


--
-- Name: stock_take_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_take_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_take_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_take_items_id_seq OWNED BY public.stock_take_items.id;


--
-- Name: stock_takes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_takes (
    id integer NOT NULL,
    company_id integer,
    reference character varying(50) NOT NULL,
    date timestamp without time zone,
    location character varying(100),
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone,
    adjustment_voucher_id integer
);


--
-- Name: stock_takes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_takes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_takes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_takes_id_seq OWNED BY public.stock_takes.id;


--
-- Name: stored_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stored_files (
    id integer NOT NULL,
    company_id integer,
    key character varying(300) NOT NULL,
    content_type character varying(120),
    size integer NOT NULL,
    data bytea NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: stored_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stored_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stored_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stored_files_id_seq OWNED BY public.stored_files.id;


--
-- Name: tax_rate_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rate_accounts (
    id integer NOT NULL,
    company_id integer,
    rate_pct numeric(20,6) NOT NULL,
    account_id integer NOT NULL
);


--
-- Name: tax_rate_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tax_rate_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tax_rate_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tax_rate_accounts_id_seq OWNED BY public.tax_rate_accounts.id;


--
-- Name: team_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_events (
    id integer NOT NULL,
    company_id integer,
    title character varying(200) NOT NULL,
    description text,
    event_date date NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    location character varying(200),
    event_type character varying(50),
    created_by integer NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: team_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.team_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: team_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.team_events_id_seq OWNED BY public.team_events.id;


--
-- Name: time_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_policies (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    department character varying(100),
    shift_start time without time zone NOT NULL,
    shift_end time without time zone NOT NULL,
    grace_period_minutes integer,
    max_regular_hours double precision,
    max_overtime_hours double precision,
    max_consecutive_days integer,
    require_break boolean,
    min_break_minutes integer,
    is_active boolean,
    created_at timestamp without time zone
);


--
-- Name: time_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.time_policies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.time_policies_id_seq OWNED BY public.time_policies.id;


--
-- Name: timesheet_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timesheet_approvals (
    id integer NOT NULL,
    company_id integer,
    week_id integer NOT NULL,
    approver_id integer NOT NULL,
    status character varying(20),
    comment text,
    created_at timestamp without time zone
);


--
-- Name: timesheet_approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.timesheet_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: timesheet_approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.timesheet_approvals_id_seq OWNED BY public.timesheet_approvals.id;


--
-- Name: timesheet_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timesheet_entries (
    id integer NOT NULL,
    company_id integer,
    week_id integer NOT NULL,
    day date NOT NULL,
    project character varying(200),
    task character varying(200) NOT NULL,
    hours double precision NOT NULL,
    description text,
    created_at timestamp without time zone
);


--
-- Name: timesheet_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.timesheet_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: timesheet_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.timesheet_entries_id_seq OWNED BY public.timesheet_entries.id;


--
-- Name: timesheet_merged_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timesheet_merged_reports (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    total_hours double precision,
    overtime_hours double precision,
    project_breakdown text,
    generated_at timestamp without time zone
);


--
-- Name: timesheet_merged_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.timesheet_merged_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: timesheet_merged_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.timesheet_merged_reports_id_seq OWNED BY public.timesheet_merged_reports.id;


--
-- Name: timesheet_weeks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timesheet_weeks (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    week_start date NOT NULL,
    week_end date NOT NULL,
    status character varying(20),
    total_hours double precision,
    submitted_at timestamp without time zone,
    approved_at timestamp without time zone,
    approved_by integer,
    notes text,
    created_at timestamp without time zone
);


--
-- Name: timesheet_weeks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.timesheet_weeks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: timesheet_weeks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.timesheet_weeks_id_seq OWNED BY public.timesheet_weeks.id;


--
-- Name: twcf_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.twcf_lines (
    id integer NOT NULL,
    company_id integer,
    direction character varying(5) NOT NULL,
    category character varying(30) NOT NULL,
    description character varying(200) NOT NULL,
    amount numeric(16,4) NOT NULL,
    start_date date NOT NULL,
    frequency character varying(10) NOT NULL,
    day_of_week integer,
    day_of_month integer,
    month integer,
    created_at timestamp without time zone
);


--
-- Name: twcf_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.twcf_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: twcf_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.twcf_lines_id_seq OWNED BY public.twcf_lines.id;


--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_permissions (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    resource character varying(100) NOT NULL,
    can_view boolean,
    can_create boolean,
    can_edit boolean,
    can_approve boolean,
    can_delete boolean
);


--
-- Name: user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_permissions_id_seq OWNED BY public.user_permissions.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    token_hash character varying(64) NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    last_seen_at timestamp without time zone NOT NULL,
    ended_at timestamp without time zone,
    end_reason character varying(20),
    ip_address character varying(64),
    user_agent character varying(200)
);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    employee_code character varying(20) NOT NULL,
    email character varying(120) NOT NULL,
    login_id character varying(120),
    password_hash character varying(256) NOT NULL,
    full_name character varying(100) NOT NULL,
    role_id integer NOT NULL,
    manager_id integer,
    designation character varying(100),
    department character varying(100),
    date_of_birth date,
    date_of_joining date,
    phone character varying(20),
    cnic character varying(20),
    bank_name character varying(100),
    bank_account_title character varying(100),
    bank_account_number character varying(50),
    emergency_contact character varying(100),
    emergency_phone character varying(20),
    address text,
    profile_image character varying(255),
    is_active boolean,
    has_hr_access boolean,
    has_inventory_access boolean,
    has_invoicing_access boolean,
    has_finance_access boolean,
    has_accounting_access boolean,
    has_fbr_access boolean,
    has_fixed_assets_access boolean,
    has_executive_access boolean,
    is_super_admin boolean,
    max_companies_owned integer,
    max_companies_joined integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: voucher_numbers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.voucher_numbers (
    id integer NOT NULL,
    company_id integer,
    prefix character varying(20) NOT NULL,
    next_number integer NOT NULL
);


--
-- Name: voucher_numbers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.voucher_numbers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: voucher_numbers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.voucher_numbers_id_seq OWNED BY public.voucher_numbers.id;


--
-- Name: work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_packages (
    id integer NOT NULL,
    company_id integer,
    project_id integer NOT NULL,
    name character varying(200) NOT NULL,
    code character varying(20),
    description text,
    estimated_hours double precision,
    status character varying(20),
    created_at timestamp without time zone
);


--
-- Name: work_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_packages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_packages_id_seq OWNED BY public.work_packages.id;


--
-- Name: accounting_periods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_periods ALTER COLUMN id SET DEFAULT nextval('public.accounting_periods_id_seq'::regclass);


--
-- Name: accounting_voucher_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_voucher_lines ALTER COLUMN id SET DEFAULT nextval('public.accounting_voucher_lines_id_seq'::regclass);


--
-- Name: accounting_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_vouchers ALTER COLUMN id SET DEFAULT nextval('public.accounting_vouchers_id_seq'::regclass);


--
-- Name: additional_charges id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.additional_charges ALTER COLUMN id SET DEFAULT nextval('public.additional_charges_id_seq'::regclass);


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: approval_workflows id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows ALTER COLUMN id SET DEFAULT nextval('public.approval_workflows_id_seq'::regclass);


--
-- Name: asset_depreciation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_depreciation ALTER COLUMN id SET DEFAULT nextval('public.asset_depreciation_id_seq'::regclass);


--
-- Name: asset_transfers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_transfers ALTER COLUMN id SET DEFAULT nextval('public.asset_transfers_id_seq'::regclass);


--
-- Name: attendance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance ALTER COLUMN id SET DEFAULT nextval('public.attendance_id_seq'::regclass);


--
-- Name: attendance_corrections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_corrections ALTER COLUMN id SET DEFAULT nextval('public.attendance_corrections_id_seq'::regclass);


--
-- Name: attendance_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_logs ALTER COLUMN id SET DEFAULT nextval('public.attendance_logs_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: bank_rec_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_rec_items ALTER COLUMN id SET DEFAULT nextval('public.bank_rec_items_id_seq'::regclass);


--
-- Name: bank_reconciliations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations ALTER COLUMN id SET DEFAULT nextval('public.bank_reconciliations_id_seq'::regclass);


--
-- Name: break_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.break_logs ALTER COLUMN id SET DEFAULT nextval('public.break_logs_id_seq'::regclass);


--
-- Name: button_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.button_permissions ALTER COLUMN id SET DEFAULT nextval('public.button_permissions_id_seq'::regclass);


--
-- Name: category_revenue_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_revenue_accounts ALTER COLUMN id SET DEFAULT nextval('public.category_revenue_accounts_id_seq'::regclass);


--
-- Name: change_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_requests ALTER COLUMN id SET DEFAULT nextval('public.change_requests_id_seq'::regclass);


--
-- Name: charge_ledger_defaults id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.charge_ledger_defaults ALTER COLUMN id SET DEFAULT nextval('public.charge_ledger_defaults_id_seq'::regclass);


--
-- Name: chart_of_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_of_accounts ALTER COLUMN id SET DEFAULT nextval('public.chart_of_accounts_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: company_holidays id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_holidays ALTER COLUMN id SET DEFAULT nextval('public.company_holidays_id_seq'::regclass);


--
-- Name: company_info id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_info ALTER COLUMN id SET DEFAULT nextval('public.company_info_id_seq'::regclass);


--
-- Name: company_invitations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_invitations ALTER COLUMN id SET DEFAULT nextval('public.company_invitations_id_seq'::regclass);


--
-- Name: company_memberships id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_memberships ALTER COLUMN id SET DEFAULT nextval('public.company_memberships_id_seq'::regclass);


--
-- Name: consumption_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consumption_items ALTER COLUMN id SET DEFAULT nextval('public.consumption_items_id_seq'::regclass);


--
-- Name: consumption_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consumption_vouchers ALTER COLUMN id SET DEFAULT nextval('public.consumption_vouchers_id_seq'::regclass);


--
-- Name: digital_files id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digital_files ALTER COLUMN id SET DEFAULT nextval('public.digital_files_id_seq'::regclass);


--
-- Name: dotnet_data_protection_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dotnet_data_protection_keys ALTER COLUMN id SET DEFAULT nextval('public.dotnet_data_protection_keys_id_seq'::regclass);


--
-- Name: email_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs ALTER COLUMN id SET DEFAULT nextval('public.email_logs_id_seq'::regclass);


--
-- Name: exec_account_selections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exec_account_selections ALTER COLUMN id SET DEFAULT nextval('public.exec_account_selections_id_seq'::regclass);


--
-- Name: fa_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fa_categories ALTER COLUMN id SET DEFAULT nextval('public.fa_categories_id_seq'::regclass);


--
-- Name: fbr_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fbr_config ALTER COLUMN id SET DEFAULT nextval('public.fbr_config_id_seq'::regclass);


--
-- Name: fbr_invoice_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fbr_invoice_records ALTER COLUMN id SET DEFAULT nextval('public.fbr_invoice_records_id_seq'::regclass);


--
-- Name: file_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_categories ALTER COLUMN id SET DEFAULT nextval('public.file_categories_id_seq'::regclass);


--
-- Name: fiscal_year_rule id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_year_rule ALTER COLUMN id SET DEFAULT nextval('public.fiscal_year_rule_id_seq'::regclass);


--
-- Name: fixed_assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets ALTER COLUMN id SET DEFAULT nextval('public.fixed_assets_id_seq'::regclass);


--
-- Name: gl_daily_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gl_daily_balances ALTER COLUMN id SET DEFAULT nextval('public.gl_daily_balances_id_seq'::regclass);


--
-- Name: global_limits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_limits ALTER COLUMN id SET DEFAULT nextval('public.global_limits_id_seq'::regclass);


--
-- Name: income_tax_slabs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income_tax_slabs ALTER COLUMN id SET DEFAULT nextval('public.income_tax_slabs_id_seq'::regclass);


--
-- Name: inv_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_categories ALTER COLUMN id SET DEFAULT nextval('public.inv_categories_id_seq'::regclass);


--
-- Name: inv_customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_customers ALTER COLUMN id SET DEFAULT nextval('public.inv_customers_id_seq'::regclass);


--
-- Name: inv_invoice_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoice_items ALTER COLUMN id SET DEFAULT nextval('public.inv_invoice_items_id_seq'::regclass);


--
-- Name: inv_invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoices ALTER COLUMN id SET DEFAULT nextval('public.inv_invoices_id_seq'::regclass);


--
-- Name: inv_products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_products ALTER COLUMN id SET DEFAULT nextval('public.inv_products_id_seq'::regclass);


--
-- Name: inv_purchase_invoice_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoice_items ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_invoice_items_id_seq'::regclass);


--
-- Name: inv_purchase_invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoices ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_invoices_id_seq'::regclass);


--
-- Name: inv_purchase_order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_order_items ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_order_items_id_seq'::regclass);


--
-- Name: inv_purchase_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_orders ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_orders_id_seq'::regclass);


--
-- Name: inv_purchase_return_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_return_items ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_return_items_id_seq'::regclass);


--
-- Name: inv_purchase_returns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_returns ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_returns_id_seq'::regclass);


--
-- Name: inv_sales_order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_order_items ALTER COLUMN id SET DEFAULT nextval('public.inv_sales_order_items_id_seq'::regclass);


--
-- Name: inv_sales_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_orders ALTER COLUMN id SET DEFAULT nextval('public.inv_sales_orders_id_seq'::regclass);


--
-- Name: inv_sales_return_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_return_items ALTER COLUMN id SET DEFAULT nextval('public.inv_sales_return_items_id_seq'::regclass);


--
-- Name: inv_sales_returns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_returns ALTER COLUMN id SET DEFAULT nextval('public.inv_sales_returns_id_seq'::regclass);


--
-- Name: inv_stock_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_stock_movements ALTER COLUMN id SET DEFAULT nextval('public.inv_stock_movements_id_seq'::regclass);


--
-- Name: inv_suppliers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_suppliers ALTER COLUMN id SET DEFAULT nextval('public.inv_suppliers_id_seq'::regclass);


--
-- Name: inv_units id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_units ALTER COLUMN id SET DEFAULT nextval('public.inv_units_id_seq'::regclass);


--
-- Name: inventory_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_settings ALTER COLUMN id SET DEFAULT nextval('public.inventory_settings_id_seq'::regclass);


--
-- Name: invoice_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_settings ALTER COLUMN id SET DEFAULT nextval('public.invoice_settings_id_seq'::regclass);


--
-- Name: invoice_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_templates ALTER COLUMN id SET DEFAULT nextval('public.invoice_templates_id_seq'::regclass);


--
-- Name: journal_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries ALTER COLUMN id SET DEFAULT nextval('public.journal_entries_id_seq'::regclass);


--
-- Name: journal_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_lines ALTER COLUMN id SET DEFAULT nextval('public.journal_lines_id_seq'::regclass);


--
-- Name: kanban_boards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kanban_boards ALTER COLUMN id SET DEFAULT nextval('public.kanban_boards_id_seq'::regclass);


--
-- Name: kanban_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kanban_tasks ALTER COLUMN id SET DEFAULT nextval('public.kanban_tasks_id_seq'::regclass);


--
-- Name: layer_consumptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.layer_consumptions ALTER COLUMN id SET DEFAULT nextval('public.layer_consumptions_id_seq'::regclass);


--
-- Name: leave_approvals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_approvals ALTER COLUMN id SET DEFAULT nextval('public.leave_approvals_id_seq'::regclass);


--
-- Name: leave_quotas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_quotas ALTER COLUMN id SET DEFAULT nextval('public.leave_quotas_id_seq'::regclass);


--
-- Name: leave_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests ALTER COLUMN id SET DEFAULT nextval('public.leave_requests_id_seq'::regclass);


--
-- Name: leave_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types ALTER COLUMN id SET DEFAULT nextval('public.leave_types_id_seq'::regclass);


--
-- Name: loan_advance_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_advance_requests ALTER COLUMN id SET DEFAULT nextval('public.loan_advance_requests_id_seq'::regclass);


--
-- Name: loan_repayments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_repayments ALTER COLUMN id SET DEFAULT nextval('public.loan_repayments_id_seq'::regclass);


--
-- Name: notification_recipients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_recipients ALTER COLUMN id SET DEFAULT nextval('public.notification_recipients_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: overtime_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.overtime_accounts ALTER COLUMN id SET DEFAULT nextval('public.overtime_accounts_id_seq'::regclass);


--
-- Name: payment_allocations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations ALTER COLUMN id SET DEFAULT nextval('public.payment_allocations_id_seq'::regclass);


--
-- Name: payroll_audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.payroll_audit_logs_id_seq'::regclass);


--
-- Name: payroll_components id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_components ALTER COLUMN id SET DEFAULT nextval('public.payroll_components_id_seq'::regclass);


--
-- Name: payroll_profiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_profiles ALTER COLUMN id SET DEFAULT nextval('public.payroll_profiles_id_seq'::regclass);


--
-- Name: payroll_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_runs ALTER COLUMN id SET DEFAULT nextval('public.payroll_runs_id_seq'::regclass);


--
-- Name: payroll_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_settings ALTER COLUMN id SET DEFAULT nextval('public.payroll_settings_id_seq'::regclass);


--
-- Name: payroll_slips id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_slips ALTER COLUMN id SET DEFAULT nextval('public.payroll_slips_id_seq'::regclass);


--
-- Name: performance_goals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_goals ALTER COLUMN id SET DEFAULT nextval('public.performance_goals_id_seq'::regclass);


--
-- Name: performance_reviews id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_reviews ALTER COLUMN id SET DEFAULT nextval('public.performance_reviews_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: pf_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_config ALTER COLUMN id SET DEFAULT nextval('public.pf_config_id_seq'::regclass);


--
-- Name: pf_contributions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_contributions ALTER COLUMN id SET DEFAULT nextval('public.pf_contributions_id_seq'::regclass);


--
-- Name: pf_ledger id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_ledger ALTER COLUMN id SET DEFAULT nextval('public.pf_ledger_id_seq'::regclass);


--
-- Name: pf_loan_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_loan_requests ALTER COLUMN id SET DEFAULT nextval('public.pf_loan_requests_id_seq'::regclass);


--
-- Name: pf_profit_distributions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_profit_distributions ALTER COLUMN id SET DEFAULT nextval('public.pf_profit_distributions_id_seq'::regclass);


--
-- Name: pf_settlements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_settlements ALTER COLUMN id SET DEFAULT nextval('public.pf_settlements_id_seq'::regclass);


--
-- Name: pf_withdrawal_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_withdrawal_requests ALTER COLUMN id SET DEFAULT nextval('public.pf_withdrawal_requests_id_seq'::regclass);


--
-- Name: project_labels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_labels ALTER COLUMN id SET DEFAULT nextval('public.project_labels_id_seq'::regclass);


--
-- Name: project_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks ALTER COLUMN id SET DEFAULT nextval('public.project_tasks_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: registration_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests ALTER COLUMN id SET DEFAULT nextval('public.registration_requests_id_seq'::regclass);


--
-- Name: report_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_settings ALTER COLUMN id SET DEFAULT nextval('public.report_settings_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: salary_revisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_revisions ALTER COLUMN id SET DEFAULT nextval('public.salary_revisions_id_seq'::regclass);


--
-- Name: scrap_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_items ALTER COLUMN id SET DEFAULT nextval('public.scrap_items_id_seq'::regclass);


--
-- Name: scrap_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_vouchers ALTER COLUMN id SET DEFAULT nextval('public.scrap_vouchers_id_seq'::regclass);


--
-- Name: stock_adjustment_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustment_items ALTER COLUMN id SET DEFAULT nextval('public.stock_adjustment_items_id_seq'::regclass);


--
-- Name: stock_adjustment_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustment_vouchers ALTER COLUMN id SET DEFAULT nextval('public.stock_adjustment_vouchers_id_seq'::regclass);


--
-- Name: stock_cost_adjustments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_cost_adjustments ALTER COLUMN id SET DEFAULT nextval('public.stock_cost_adjustments_id_seq'::regclass);


--
-- Name: stock_layers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_layers ALTER COLUMN id SET DEFAULT nextval('public.stock_layers_id_seq'::regclass);


--
-- Name: stock_ledger id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger ALTER COLUMN id SET DEFAULT nextval('public.stock_ledger_id_seq'::regclass);


--
-- Name: stock_take_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items ALTER COLUMN id SET DEFAULT nextval('public.stock_take_items_id_seq'::regclass);


--
-- Name: stock_takes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes ALTER COLUMN id SET DEFAULT nextval('public.stock_takes_id_seq'::regclass);


--
-- Name: stored_files id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_files ALTER COLUMN id SET DEFAULT nextval('public.stored_files_id_seq'::regclass);


--
-- Name: tax_rate_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_accounts ALTER COLUMN id SET DEFAULT nextval('public.tax_rate_accounts_id_seq'::regclass);


--
-- Name: team_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_events ALTER COLUMN id SET DEFAULT nextval('public.team_events_id_seq'::regclass);


--
-- Name: time_policies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_policies ALTER COLUMN id SET DEFAULT nextval('public.time_policies_id_seq'::regclass);


--
-- Name: timesheet_approvals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_approvals ALTER COLUMN id SET DEFAULT nextval('public.timesheet_approvals_id_seq'::regclass);


--
-- Name: timesheet_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_entries ALTER COLUMN id SET DEFAULT nextval('public.timesheet_entries_id_seq'::regclass);


--
-- Name: timesheet_merged_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_merged_reports ALTER COLUMN id SET DEFAULT nextval('public.timesheet_merged_reports_id_seq'::regclass);


--
-- Name: timesheet_weeks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_weeks ALTER COLUMN id SET DEFAULT nextval('public.timesheet_weeks_id_seq'::regclass);


--
-- Name: twcf_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.twcf_lines ALTER COLUMN id SET DEFAULT nextval('public.twcf_lines_id_seq'::regclass);


--
-- Name: user_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions ALTER COLUMN id SET DEFAULT nextval('public.user_permissions_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: voucher_numbers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voucher_numbers ALTER COLUMN id SET DEFAULT nextval('public.voucher_numbers_id_seq'::regclass);


--
-- Name: work_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages ALTER COLUMN id SET DEFAULT nextval('public.work_packages_id_seq'::regclass);


--
-- Data for Name: accounting_periods; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.accounting_periods VALUES (1, 1, '2021', 'FY 2021', '2021-01-01', '2021-12-31', true, false, true, '2026-10-29 05:44:50.837503', NULL);
INSERT INTO public.accounting_periods VALUES (2, 1, '2022', 'FY 2022', '2022-01-01', '2022-12-31', true, false, true, '2026-10-29 05:44:50.837509', NULL);
INSERT INTO public.accounting_periods VALUES (3, 1, '2023', 'FY 2023', '2023-01-01', '2023-12-31', true, false, true, '2026-10-29 05:44:50.837511', NULL);
INSERT INTO public.accounting_periods VALUES (4, 1, '2024', 'FY 2024', '2024-01-01', '2024-12-31', true, false, true, '2026-10-29 05:44:50.837514', NULL);
INSERT INTO public.accounting_periods VALUES (5, 1, '2025', 'FY 2025', '2025-01-01', '2025-12-31', true, false, true, '2026-10-29 05:44:50.837516', NULL);
INSERT INTO public.accounting_periods VALUES (6, 1, '2026', 'FY 2026', '2026-01-01', '2026-12-31', true, false, true, '2026-10-29 05:44:50.837518', NULL);
INSERT INTO public.accounting_periods VALUES (7, 1, '2027', 'FY 2027', '2027-01-01', '2027-12-31', true, false, true, '2026-10-29 05:44:50.83752', NULL);
INSERT INTO public.accounting_periods VALUES (8, 1, '2028', 'FY 2028', '2028-01-01', '2028-12-31', true, false, true, '2026-10-29 05:44:50.837522', NULL);
INSERT INTO public.accounting_periods VALUES (9, 2, '2021', 'FY 2021', '2021-01-01', '2021-12-31', true, false, true, '2026-10-29 05:44:53.986409', NULL);
INSERT INTO public.accounting_periods VALUES (10, 2, '2022', 'FY 2022', '2022-01-01', '2022-12-31', true, false, true, '2026-10-29 05:44:53.986414', NULL);
INSERT INTO public.accounting_periods VALUES (11, 2, '2023', 'FY 2023', '2023-01-01', '2023-12-31', true, false, true, '2026-10-29 05:44:53.986416', NULL);
INSERT INTO public.accounting_periods VALUES (12, 2, '2024', 'FY 2024', '2024-01-01', '2024-12-31', true, false, true, '2026-10-29 05:44:53.986418', NULL);
INSERT INTO public.accounting_periods VALUES (13, 2, '2025', 'FY 2025', '2025-01-01', '2025-12-31', true, false, true, '2026-10-29 05:44:53.98642', NULL);
INSERT INTO public.accounting_periods VALUES (14, 2, '2026', 'FY 2026', '2026-01-01', '2026-12-31', true, false, true, '2026-10-29 05:44:53.986422', NULL);
INSERT INTO public.accounting_periods VALUES (15, 2, '2027', 'FY 2027', '2027-01-01', '2027-12-31', true, false, true, '2026-10-29 05:44:53.986424', NULL);
INSERT INTO public.accounting_periods VALUES (16, 2, '2028', 'FY 2028', '2028-01-01', '2028-12-31', true, false, true, '2026-10-29 05:44:53.986425', NULL);
INSERT INTO public.accounting_periods VALUES (17, 3, '2021', 'FY 2021', '2021-01-01', '2021-12-31', true, false, true, '2026-10-29 05:44:55.284115', NULL);
INSERT INTO public.accounting_periods VALUES (18, 3, '2022', 'FY 2022', '2022-01-01', '2022-12-31', true, false, true, '2026-10-29 05:44:55.28412', NULL);
INSERT INTO public.accounting_periods VALUES (19, 3, '2023', 'FY 2023', '2023-01-01', '2023-12-31', true, false, true, '2026-10-29 05:44:55.284122', NULL);
INSERT INTO public.accounting_periods VALUES (20, 3, '2024', 'FY 2024', '2024-01-01', '2024-12-31', true, false, true, '2026-10-29 05:44:55.284124', NULL);
INSERT INTO public.accounting_periods VALUES (21, 3, '2025', 'FY 2025', '2025-01-01', '2025-12-31', true, false, true, '2026-10-29 05:44:55.284126', NULL);
INSERT INTO public.accounting_periods VALUES (22, 3, '2026', 'FY 2026', '2026-01-01', '2026-12-31', true, false, true, '2026-10-29 05:44:55.284128', NULL);
INSERT INTO public.accounting_periods VALUES (23, 3, '2027', 'FY 2027', '2027-01-01', '2027-12-31', true, false, true, '2026-10-29 05:44:55.28413', NULL);
INSERT INTO public.accounting_periods VALUES (24, 3, '2028', 'FY 2028', '2028-01-01', '2028-12-31', true, false, true, '2026-10-29 05:44:55.284132', NULL);


--
-- Data for Name: accounting_voucher_lines; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: accounting_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: additional_charges; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.alembic_version VALUES ('0018_report_indexes');


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: approval_workflows; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_depreciation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_transfers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: attendance_corrections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: attendance_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.audit_logs VALUES (1, 1, '2026-10-29 05:44:48.868711', NULL, NULL, 'create', 'accounting', 'Account', 1, '1', 'Account 1 created', '{"company_id": 1, "code": "1", "name": "Assets", "type": "asset", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (2, 1, '2026-10-29 05:44:48.878667', NULL, NULL, 'create', 'accounting', 'Account', 2, '1-01', 'Account 1-01 created', '{"company_id": 1, "code": "1-01", "name": "Current Assets", "type": "asset", "parent_id": 1, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (3, 1, '2026-10-29 05:44:48.885099', NULL, NULL, 'create', 'accounting', 'Account', 3, '1-01-01', 'Account 1-01-01 created', '{"company_id": 1, "code": "1-01-01", "name": "Cash & Cash Equivalents", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true, "cash_flow_activity": "cash"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (4, 1, '2026-10-29 05:44:48.891832', NULL, NULL, 'create', 'accounting', 'Account', 4, '1-01-01-01', 'Account 1-01-01-01 created', '{"company_id": 1, "code": "1-01-01-01", "name": "Cash in Hand", "type": "asset", "parent_id": 3, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (5, 1, '2026-10-29 05:44:48.898497', NULL, NULL, 'create', 'accounting', 'Account', 5, '1-01-01-02', 'Account 1-01-01-02 created', '{"company_id": 1, "code": "1-01-01-02", "name": "Bank Accounts", "type": "asset", "parent_id": 3, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (6, 1, '2026-10-29 05:44:48.904874', NULL, NULL, 'create', 'accounting', 'Account', 6, '1-01-02', 'Account 1-01-02 created', '{"company_id": 1, "code": "1-01-02", "name": "Trade Receivables", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (7, 1, '2026-10-29 05:44:48.911158', NULL, NULL, 'create', 'accounting', 'Account', 7, '1-01-02-01', 'Account 1-01-02-01 created', '{"company_id": 1, "code": "1-01-02-01", "name": "Trade Debtors", "type": "asset", "parent_id": 6, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (8, 1, '2026-10-29 05:44:48.917528', NULL, NULL, 'create', 'accounting', 'Account', 8, '1-01-02-02', 'Account 1-01-02-02 created', '{"company_id": 1, "code": "1-01-02-02", "name": "Doubtful Receivables", "type": "asset", "parent_id": 6, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (9, 1, '2026-10-29 05:44:48.923851', NULL, NULL, 'create', 'accounting', 'Account', 9, '1-01-03', 'Account 1-01-03 created', '{"company_id": 1, "code": "1-01-03", "name": "Other Receivables", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (10, 1, '2026-10-29 05:44:48.930091', NULL, NULL, 'create', 'accounting', 'Account', 10, '1-01-03-01', 'Account 1-01-03-01 created', '{"company_id": 1, "code": "1-01-03-01", "name": "Employee Loans & Advances", "type": "asset", "parent_id": 9, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (11, 1, '2026-10-29 05:44:48.936392', NULL, NULL, 'create', 'accounting', 'Account', 11, '1-01-03-02', 'Account 1-01-03-02 created', '{"company_id": 1, "code": "1-01-03-02", "name": "Advances to Suppliers", "type": "asset", "parent_id": 9, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (12, 1, '2026-10-29 05:44:48.943123', NULL, NULL, 'create', 'accounting', 'Account', 12, '1-01-04', 'Account 1-01-04 created', '{"company_id": 1, "code": "1-01-04", "name": "Inventories", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (13, 1, '2026-10-29 05:44:48.949294', NULL, NULL, 'create', 'accounting', 'Account', 13, '1-01-04-01', 'Account 1-01-04-01 created', '{"company_id": 1, "code": "1-01-04-01", "name": "Trading Goods Stock", "type": "asset", "parent_id": 12, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (14, 1, '2026-10-29 05:44:48.95551', NULL, NULL, 'create', 'accounting', 'Account', 14, '1-01-05', 'Account 1-01-05 created', '{"company_id": 1, "code": "1-01-05", "name": "Tax Assets", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (15, 1, '2026-10-29 05:44:48.961989', NULL, NULL, 'create', 'accounting', 'Account', 15, '1-01-05-01', 'Account 1-01-05-01 created', '{"company_id": 1, "code": "1-01-05-01", "name": "Input Sales Tax", "type": "asset", "parent_id": 14, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (16, 1, '2026-10-29 05:44:48.968211', NULL, NULL, 'create', 'accounting', 'Account', 16, '1-01-05-02', 'Account 1-01-05-02 created', '{"company_id": 1, "code": "1-01-05-02", "name": "WHT Receivable", "type": "asset", "parent_id": 14, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (17, 1, '2026-10-29 05:44:48.974462', NULL, NULL, 'create', 'accounting', 'Account', 17, '1-01-06', 'Account 1-01-06 created', '{"company_id": 1, "code": "1-01-06", "name": "Prepayments & Other", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (18, 1, '2026-10-29 05:44:48.980665', NULL, NULL, 'create', 'accounting', 'Account', 18, '1-01-06-01', 'Account 1-01-06-01 created', '{"company_id": 1, "code": "1-01-06-01", "name": "Suspense & Clearing", "type": "asset", "parent_id": 17, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (19, 1, '2026-10-29 05:44:48.987233', NULL, NULL, 'create', 'accounting', 'Account', 19, '1-01-06-02', 'Account 1-01-06-02 created', '{"company_id": 1, "code": "1-01-06-02", "name": "Prepaid Expenses", "type": "asset", "parent_id": 17, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (20, 1, '2026-10-29 05:44:48.99382', NULL, NULL, 'create', 'accounting', 'Account', 20, '1-01-06-03', 'Account 1-01-06-03 created', '{"company_id": 1, "code": "1-01-06-03", "name": "Other Current Assets", "type": "asset", "parent_id": 17, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (21, 1, '2026-10-29 05:44:49.00033', NULL, NULL, 'create', 'accounting', 'Account', 21, '1-02', 'Account 1-02 created', '{"company_id": 1, "code": "1-02", "name": "Non-Current Assets", "type": "asset", "parent_id": 1, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "investing"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (22, 1, '2026-10-29 05:44:49.006917', NULL, NULL, 'create', 'accounting', 'Account', 22, '1-02-01', 'Account 1-02-01 created', '{"company_id": 1, "code": "1-02-01", "name": "Property, Plant & Equipment", "type": "asset", "parent_id": 21, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (23, 1, '2026-10-29 05:44:49.013286', NULL, NULL, 'create', 'accounting', 'Account', 23, '1-02-01-01', 'Account 1-02-01-01 created', '{"company_id": 1, "code": "1-02-01-01", "name": "Owned Assets", "type": "asset", "parent_id": 22, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (24, 1, '2026-10-29 05:44:49.019653', NULL, NULL, 'create', 'accounting', 'Account', 24, '1-02-02', 'Account 1-02-02 created', '{"company_id": 1, "code": "1-02-02", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 21, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (25, 1, '2026-10-29 05:44:49.026009', NULL, NULL, 'create', 'accounting', 'Account', 25, '1-02-02-01', 'Account 1-02-02-01 created', '{"company_id": 1, "code": "1-02-02-01", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 24, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (26, 1, '2026-10-29 05:44:49.032534', NULL, NULL, 'create', 'accounting', 'Account', 26, '1-02-03', 'Account 1-02-03 created', '{"company_id": 1, "code": "1-02-03", "name": "Intangible Assets", "type": "asset", "parent_id": 21, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (27, 1, '2026-10-29 05:44:49.038919', NULL, NULL, 'create', 'accounting', 'Account', 27, '1-02-03-01', 'Account 1-02-03-01 created', '{"company_id": 1, "code": "1-02-03-01", "name": "Intangibles", "type": "asset", "parent_id": 26, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (28, 1, '2026-10-29 05:44:49.043153', NULL, NULL, 'create', 'accounting', 'Account', 28, '2', 'Account 2 created', '{"company_id": 1, "code": "2", "name": "Liabilities", "type": "liability", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (29, 1, '2026-10-29 05:44:49.049567', NULL, NULL, 'create', 'accounting', 'Account', 29, '2-01', 'Account 2-01 created', '{"company_id": 1, "code": "2-01", "name": "Current Liabilities", "type": "liability", "parent_id": 28, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (30, 1, '2026-10-29 05:44:49.056446', NULL, NULL, 'create', 'accounting', 'Account', 30, '2-01-01', 'Account 2-01-01 created', '{"company_id": 1, "code": "2-01-01", "name": "Trade Payables", "type": "liability", "parent_id": 29, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (31, 1, '2026-10-29 05:44:49.062642', NULL, NULL, 'create', 'accounting', 'Account', 31, '2-01-01-01', 'Account 2-01-01-01 created', '{"company_id": 1, "code": "2-01-01-01", "name": "Trade Creditors", "type": "liability", "parent_id": 30, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (32, 1, '2026-10-29 05:44:49.068827', NULL, NULL, 'create', 'accounting', 'Account', 32, '2-01-02', 'Account 2-01-02 created', '{"company_id": 1, "code": "2-01-02", "name": "Accrued & Payroll Liabilities", "type": "liability", "parent_id": 29, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (33, 1, '2026-10-29 05:44:49.075263', NULL, NULL, 'create', 'accounting', 'Account', 33, '2-01-02-01', 'Account 2-01-02-01 created', '{"company_id": 1, "code": "2-01-02-01", "name": "Employee Payables", "type": "liability", "parent_id": 32, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (34, 1, '2026-10-29 05:44:49.081468', NULL, NULL, 'create', 'accounting', 'Account', 34, '2-01-02-02', 'Account 2-01-02-02 created', '{"company_id": 1, "code": "2-01-02-02", "name": "Payroll Liabilities", "type": "liability", "parent_id": 32, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (35, 1, '2026-10-29 05:44:49.087665', NULL, NULL, 'create', 'accounting', 'Account', 35, '2-01-02-03', 'Account 2-01-02-03 created', '{"company_id": 1, "code": "2-01-02-03", "name": "Accrued Expenses", "type": "liability", "parent_id": 32, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (36, 1, '2026-10-29 05:44:49.094107', NULL, NULL, 'create', 'accounting', 'Account', 36, '2-01-03', 'Account 2-01-03 created', '{"company_id": 1, "code": "2-01-03", "name": "Tax Liabilities", "type": "liability", "parent_id": 29, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (37, 1, '2026-10-29 05:44:49.100889', NULL, NULL, 'create', 'accounting', 'Account', 37, '2-01-03-01', 'Account 2-01-03-01 created', '{"company_id": 1, "code": "2-01-03-01", "name": "Output Sales Tax", "type": "liability", "parent_id": 36, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (38, 1, '2026-10-29 05:44:49.10727', NULL, NULL, 'create', 'accounting', 'Account', 38, '2-01-03-02', 'Account 2-01-03-02 created', '{"company_id": 1, "code": "2-01-03-02", "name": "Income Tax Payable", "type": "liability", "parent_id": 36, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (39, 1, '2026-10-29 05:44:49.113823', NULL, NULL, 'create', 'accounting', 'Account', 39, '2-01-03-03', 'Account 2-01-03-03 created', '{"company_id": 1, "code": "2-01-03-03", "name": "WHT Payable", "type": "liability", "parent_id": 36, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (40, 1, '2026-10-29 05:44:49.120261', NULL, NULL, 'create', 'accounting', 'Account', 40, '2-01-03-04', 'Account 2-01-03-04 created', '{"company_id": 1, "code": "2-01-03-04", "name": "Further Tax Payable", "type": "liability", "parent_id": 36, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (41, 1, '2026-10-29 05:44:49.12645', NULL, NULL, 'create', 'accounting', 'Account', 41, '2-01-04', 'Account 2-01-04 created', '{"company_id": 1, "code": "2-01-04", "name": "Advances from Customers", "type": "liability", "parent_id": 29, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (42, 1, '2026-10-29 05:44:49.132846', NULL, NULL, 'create', 'accounting', 'Account', 42, '2-01-04-01', 'Account 2-01-04-01 created', '{"company_id": 1, "code": "2-01-04-01", "name": "Customer Advances", "type": "liability", "parent_id": 41, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (43, 1, '2026-10-29 05:44:49.139157', NULL, NULL, 'create', 'accounting', 'Account', 43, '2-02', 'Account 2-02 created', '{"company_id": 1, "code": "2-02", "name": "Non-Current Liabilities", "type": "liability", "parent_id": 28, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (44, 1, '2026-10-29 05:44:49.146401', NULL, NULL, 'create', 'accounting', 'Account', 44, '2-02-01', 'Account 2-02-01 created', '{"company_id": 1, "code": "2-02-01", "name": "Long-term Loans", "type": "liability", "parent_id": 43, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (45, 1, '2026-10-29 05:44:49.153016', NULL, NULL, 'create', 'accounting', 'Account', 45, '2-02-01-01', 'Account 2-02-01-01 created', '{"company_id": 1, "code": "2-02-01-01", "name": "Long-term Loans", "type": "liability", "parent_id": 44, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (46, 1, '2026-10-29 05:44:49.159314', NULL, NULL, 'create', 'accounting', 'Account', 46, '2-02-02', 'Account 2-02-02 created', '{"company_id": 1, "code": "2-02-02", "name": "Employee End-of-Service Benefits", "type": "liability", "parent_id": 43, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (47, 1, '2026-10-29 05:44:49.165751', NULL, NULL, 'create', 'accounting', 'Account', 47, '2-02-02-01', 'Account 2-02-02-01 created', '{"company_id": 1, "code": "2-02-02-01", "name": "EOSB Provision", "type": "liability", "parent_id": 46, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (48, 1, '2026-10-29 05:44:49.169721', NULL, NULL, 'create', 'accounting', 'Account', 48, '3', 'Account 3 created', '{"company_id": 1, "code": "3", "name": "Equity", "type": "equity", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (49, 1, '2026-10-29 05:44:49.175969', NULL, NULL, 'create', 'accounting', 'Account', 49, '3-01', 'Account 3-01 created', '{"company_id": 1, "code": "3-01", "name": "Capital", "type": "equity", "parent_id": 48, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (50, 1, '2026-10-29 05:44:49.182202', NULL, NULL, 'create', 'accounting', 'Account', 50, '3-01-01', 'Account 3-01-01 created', '{"company_id": 1, "code": "3-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 49, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (51, 1, '2026-10-29 05:44:49.188663', NULL, NULL, 'create', 'accounting', 'Account', 51, '3-01-01-01', 'Account 3-01-01-01 created', '{"company_id": 1, "code": "3-01-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 50, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (52, 1, '2026-10-29 05:44:49.195219', NULL, NULL, 'create', 'accounting', 'Account', 52, '3-02', 'Account 3-02 created', '{"company_id": 1, "code": "3-02", "name": "Reserves & Retained Earnings", "type": "equity", "parent_id": 48, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (53, 1, '2026-10-29 05:44:49.201625', NULL, NULL, 'create', 'accounting', 'Account', 53, '3-02-01', 'Account 3-02-01 created', '{"company_id": 1, "code": "3-02-01", "name": "Retained Earnings", "type": "equity", "parent_id": 52, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (54, 1, '2026-10-29 05:44:49.208044', NULL, NULL, 'create', 'accounting', 'Account', 54, '3-02-01-01', 'Account 3-02-01-01 created', '{"company_id": 1, "code": "3-02-01-01", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 53, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (55, 1, '2026-10-29 05:44:49.214644', NULL, NULL, 'create', 'accounting', 'Account', 55, '3-02-01-02', 'Account 3-02-01-02 created', '{"company_id": 1, "code": "3-02-01-02", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 53, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (56, 1, '2026-10-29 05:44:49.221008', NULL, NULL, 'create', 'accounting', 'Account', 56, '3-02-02', 'Account 3-02-02 created', '{"company_id": 1, "code": "3-02-02", "name": "Dividends", "type": "equity", "parent_id": 52, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (57, 1, '2026-10-29 05:44:49.227375', NULL, NULL, 'create', 'accounting', 'Account', 57, '3-02-02-01', 'Account 3-02-02-01 created', '{"company_id": 1, "code": "3-02-02-01", "name": "Dividends", "type": "equity", "parent_id": 56, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (58, 1, '2026-10-29 05:44:49.233758', NULL, NULL, 'create', 'accounting', 'Account', 58, '3-02-03', 'Account 3-02-03 created', '{"company_id": 1, "code": "3-02-03", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 52, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (59, 1, '2026-10-29 05:44:49.239993', NULL, NULL, 'create', 'accounting', 'Account', 59, '3-02-03-01', 'Account 3-02-03-01 created', '{"company_id": 1, "code": "3-02-03-01", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 58, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (60, 1, '2026-10-29 05:44:49.243957', NULL, NULL, 'create', 'accounting', 'Account', 60, '4', 'Account 4 created', '{"company_id": 1, "code": "4", "name": "Revenue", "type": "revenue", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (61, 1, '2026-10-29 05:44:49.250178', NULL, NULL, 'create', 'accounting', 'Account', 61, '4-01', 'Account 4-01 created', '{"company_id": 1, "code": "4-01", "name": "Sales", "type": "revenue", "parent_id": 60, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (62, 1, '2026-10-29 05:44:49.25659', NULL, NULL, 'create', 'accounting', 'Account', 62, '4-01-01', 'Account 4-01-01 created', '{"company_id": 1, "code": "4-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 61, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (63, 1, '2026-10-29 05:44:49.262802', NULL, NULL, 'create', 'accounting', 'Account', 63, '4-01-01-01', 'Account 4-01-01-01 created', '{"company_id": 1, "code": "4-01-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 62, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (64, 1, '2026-10-29 05:44:49.269014', NULL, NULL, 'create', 'accounting', 'Account', 64, '4-01-02', 'Account 4-01-02 created', '{"company_id": 1, "code": "4-01-02", "name": "Service Income", "type": "revenue", "parent_id": 61, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (65, 1, '2026-10-29 05:44:49.275273', NULL, NULL, 'create', 'accounting', 'Account', 65, '4-01-02-01', 'Account 4-01-02-01 created', '{"company_id": 1, "code": "4-01-02-01", "name": "Service Income", "type": "revenue", "parent_id": 64, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (66, 1, '2026-10-29 05:44:49.281682', NULL, NULL, 'create', 'accounting', 'Account', 66, '4-02', 'Account 4-02 created', '{"company_id": 1, "code": "4-02", "name": "Sales Returns & Discounts", "type": "revenue", "parent_id": 60, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales_returns"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (67, 1, '2026-10-29 05:44:49.287874', NULL, NULL, 'create', 'accounting', 'Account', 67, '4-02-01', 'Account 4-02-01 created', '{"company_id": 1, "code": "4-02-01", "name": "Sales Returns", "type": "revenue", "parent_id": 66, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (68, 1, '2026-10-29 05:44:49.294092', NULL, NULL, 'create', 'accounting', 'Account', 68, '4-02-01-01', 'Account 4-02-01-01 created', '{"company_id": 1, "code": "4-02-01-01", "name": "Sales Returns", "type": "revenue", "parent_id": 67, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (69, 1, '2026-10-29 05:44:49.300499', NULL, NULL, 'create', 'accounting', 'Account', 69, '4-02-02', 'Account 4-02-02 created', '{"company_id": 1, "code": "4-02-02", "name": "Discounts Allowed", "type": "revenue", "parent_id": 66, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (70, 1, '2026-10-29 05:44:49.306699', NULL, NULL, 'create', 'accounting', 'Account', 70, '4-02-02-01', 'Account 4-02-02-01 created', '{"company_id": 1, "code": "4-02-02-01", "name": "Discounts Allowed", "type": "revenue", "parent_id": 69, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (71, 1, '2026-10-29 05:44:49.31301', NULL, NULL, 'create', 'accounting', 'Account', 71, '4-03', 'Account 4-03 created', '{"company_id": 1, "code": "4-03", "name": "Other Income", "type": "revenue", "parent_id": 60, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_income"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (72, 1, '2026-10-29 05:44:49.319354', NULL, NULL, 'create', 'accounting', 'Account', 72, '4-03-01', 'Account 4-03-01 created', '{"company_id": 1, "code": "4-03-01", "name": "Other Income", "type": "revenue", "parent_id": 71, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (73, 1, '2026-10-29 05:44:49.325885', NULL, NULL, 'create', 'accounting', 'Account', 73, '4-03-01-01', 'Account 4-03-01-01 created', '{"company_id": 1, "code": "4-03-01-01", "name": "Other Income", "type": "revenue", "parent_id": 72, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (74, 1, '2026-10-29 05:44:49.32992', NULL, NULL, 'create', 'accounting', 'Account', 74, '5', 'Account 5 created', '{"company_id": 1, "code": "5", "name": "Expenses", "type": "expense", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (75, 1, '2026-10-29 05:44:49.336279', NULL, NULL, 'create', 'accounting', 'Account', 75, '5-01', 'Account 5-01 created', '{"company_id": 1, "code": "5-01", "name": "Cost of Sales", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "cost_of_sales"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (76, 1, '2026-10-29 05:44:49.342644', NULL, NULL, 'create', 'accounting', 'Account', 76, '5-01-01', 'Account 5-01-01 created', '{"company_id": 1, "code": "5-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 75, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (77, 1, '2026-10-29 05:44:49.349284', NULL, NULL, 'create', 'accounting', 'Account', 77, '5-01-01-01', 'Account 5-01-01-01 created', '{"company_id": 1, "code": "5-01-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 76, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (78, 1, '2026-10-29 05:44:49.355545', NULL, NULL, 'create', 'accounting', 'Account', 78, '5-01-02', 'Account 5-01-02 created', '{"company_id": 1, "code": "5-01-02", "name": "Stock Losses, Scrap & Adjustments", "type": "expense", "parent_id": 75, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (79, 1, '2026-10-29 05:44:49.361753', NULL, NULL, 'create', 'accounting', 'Account', 79, '5-01-02-01', 'Account 5-01-02-01 created', '{"company_id": 1, "code": "5-01-02-01", "name": "Stock Losses & Scrap", "type": "expense", "parent_id": 78, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (80, 1, '2026-10-29 05:44:49.368692', NULL, NULL, 'create', 'accounting', 'Account', 80, '5-02', 'Account 5-02 created', '{"company_id": 1, "code": "5-02", "name": "Administrative Expenses", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "admin"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (81, 1, '2026-10-29 05:44:49.374964', NULL, NULL, 'create', 'accounting', 'Account', 81, '5-02-01', 'Account 5-02-01 created', '{"company_id": 1, "code": "5-02-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 80, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (82, 1, '2026-10-29 05:44:49.381195', NULL, NULL, 'create', 'accounting', 'Account', 82, '5-02-01-01', 'Account 5-02-01-01 created', '{"company_id": 1, "code": "5-02-01-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 81, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (253, 1, '2026-10-29 05:44:51.288513', NULL, NULL, 'post', 'accounting', 'Journal entry', 2, 'OPEN-00002', 'Journal entry OPEN-00002 posted — Opening stock — Monocrystalline Solar Panel 550W', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (83, 1, '2026-10-29 05:44:49.387549', NULL, NULL, 'create', 'accounting', 'Account', 83, '5-02-02', 'Account 5-02-02 created', '{"company_id": 1, "code": "5-02-02", "name": "Rent & Utilities", "type": "expense", "parent_id": 80, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (84, 1, '2026-10-29 05:44:49.394142', NULL, NULL, 'create', 'accounting', 'Account', 84, '5-02-02-01', 'Account 5-02-02-01 created', '{"company_id": 1, "code": "5-02-02-01", "name": "Rent & Utilities", "type": "expense", "parent_id": 83, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (85, 1, '2026-10-29 05:44:49.400467', NULL, NULL, 'create', 'accounting', 'Account', 85, '5-02-03', 'Account 5-02-03 created', '{"company_id": 1, "code": "5-02-03", "name": "Office & Supplies", "type": "expense", "parent_id": 80, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (86, 1, '2026-10-29 05:44:49.406768', NULL, NULL, 'create', 'accounting', 'Account', 86, '5-02-03-01', 'Account 5-02-03-01 created', '{"company_id": 1, "code": "5-02-03-01", "name": "Office & Supplies", "type": "expense", "parent_id": 85, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (87, 1, '2026-10-29 05:44:49.413569', NULL, NULL, 'create', 'accounting', 'Account', 87, '5-02-04', 'Account 5-02-04 created', '{"company_id": 1, "code": "5-02-04", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 80, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (88, 1, '2026-10-29 05:44:49.419851', NULL, NULL, 'create', 'accounting', 'Account', 88, '5-02-04-01', 'Account 5-02-04-01 created', '{"company_id": 1, "code": "5-02-04-01", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 87, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (89, 1, '2026-10-29 05:44:49.426137', NULL, NULL, 'create', 'accounting', 'Account', 89, '5-02-05', 'Account 5-02-05 created', '{"company_id": 1, "code": "5-02-05", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 80, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (90, 1, '2026-10-29 05:44:49.464094', NULL, NULL, 'create', 'accounting', 'Account', 90, '5-02-05-01', 'Account 5-02-05-01 created', '{"company_id": 1, "code": "5-02-05-01", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 89, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (91, 1, '2026-10-29 05:44:49.471795', NULL, NULL, 'create', 'accounting', 'Account', 91, '5-03', 'Account 5-03 created', '{"company_id": 1, "code": "5-03", "name": "Selling & Distribution", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "selling_distribution"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (92, 1, '2026-10-29 05:44:49.478742', NULL, NULL, 'create', 'accounting', 'Account', 92, '5-03-01', 'Account 5-03-01 created', '{"company_id": 1, "code": "5-03-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 91, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (93, 1, '2026-10-29 05:44:49.485194', NULL, NULL, 'create', 'accounting', 'Account', 93, '5-03-01-01', 'Account 5-03-01-01 created', '{"company_id": 1, "code": "5-03-01-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 92, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (94, 1, '2026-10-29 05:44:49.491872', NULL, NULL, 'create', 'accounting', 'Account', 94, '5-03-02', 'Account 5-03-02 created', '{"company_id": 1, "code": "5-03-02", "name": "Commissions", "type": "expense", "parent_id": 91, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (95, 1, '2026-10-29 05:44:49.498173', NULL, NULL, 'create', 'accounting', 'Account', 95, '5-03-02-01', 'Account 5-03-02-01 created', '{"company_id": 1, "code": "5-03-02-01", "name": "Commissions", "type": "expense", "parent_id": 94, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (96, 1, '2026-10-29 05:44:49.504496', NULL, NULL, 'create', 'accounting', 'Account', 96, '5-03-03', 'Account 5-03-03 created', '{"company_id": 1, "code": "5-03-03", "name": "Marketing & Advertising", "type": "expense", "parent_id": 91, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (97, 1, '2026-10-29 05:44:49.510763', NULL, NULL, 'create', 'accounting', 'Account', 97, '5-03-03-01', 'Account 5-03-03-01 created', '{"company_id": 1, "code": "5-03-03-01", "name": "Marketing & Advertising", "type": "expense", "parent_id": 96, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (98, 1, '2026-10-29 05:44:49.51717', NULL, NULL, 'create', 'accounting', 'Account', 98, '5-04', 'Account 5-04 created', '{"company_id": 1, "code": "5-04", "name": "Other Operating Expenses", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_operating"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (99, 1, '2026-10-29 05:44:49.523404', NULL, NULL, 'create', 'accounting', 'Account', 99, '5-04-01', 'Account 5-04-01 created', '{"company_id": 1, "code": "5-04-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 98, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (100, 1, '2026-10-29 05:44:49.529639', NULL, NULL, 'create', 'accounting', 'Account', 100, '5-04-01-01', 'Account 5-04-01-01 created', '{"company_id": 1, "code": "5-04-01-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 99, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (101, 1, '2026-10-29 05:44:49.536152', NULL, NULL, 'create', 'accounting', 'Account', 101, '5-05', 'Account 5-05 created', '{"company_id": 1, "code": "5-05", "name": "Finance Costs", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "finance_cost"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (102, 1, '2026-10-29 05:44:49.542549', NULL, NULL, 'create', 'accounting', 'Account', 102, '5-05-01', 'Account 5-05-01 created', '{"company_id": 1, "code": "5-05-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 101, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (103, 1, '2026-10-29 05:44:49.548927', NULL, NULL, 'create', 'accounting', 'Account', 103, '5-05-01-01', 'Account 5-05-01-01 created', '{"company_id": 1, "code": "5-05-01-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 102, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (104, 1, '2026-10-29 05:44:49.555317', NULL, NULL, 'create', 'accounting', 'Account', 104, '5-06', 'Account 5-06 created', '{"company_id": 1, "code": "5-06", "name": "Taxation", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "income_tax"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (105, 1, '2026-10-29 05:44:49.561832', NULL, NULL, 'create', 'accounting', 'Account', 105, '5-06-01', 'Account 5-06-01 created', '{"company_id": 1, "code": "5-06-01", "name": "Income Tax", "type": "expense", "parent_id": 104, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (106, 1, '2026-10-29 05:44:49.568174', NULL, NULL, 'create', 'accounting', 'Account', 106, '5-06-01-01', 'Account 5-06-01-01 created', '{"company_id": 1, "code": "5-06-01-01", "name": "Income Tax", "type": "expense", "parent_id": 105, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (107, 1, '2026-10-29 05:44:49.579112', NULL, NULL, 'create', 'accounting', 'Account', 107, '1-01-01-01-0001', 'Account 1-01-01-01-0001 created', '{"company_id": 1, "code": "1-01-01-01-0001", "name": "Main Cash", "type": "asset", "parent_id": 4, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (108, 1, '2026-10-29 05:44:49.585402', NULL, NULL, 'create', 'accounting', 'Account', 108, '1-01-02-01-0001', 'Account 1-01-02-01-0001 created', '{"company_id": 1, "code": "1-01-02-01-0001", "name": "Trade Debtors \u2014 General", "type": "asset", "parent_id": 7, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (109, 1, '2026-10-29 05:44:49.591897', NULL, NULL, 'create', 'accounting', 'Account', 109, '1-01-03-02-0001', 'Account 1-01-03-02-0001 created', '{"company_id": 1, "code": "1-01-03-02-0001", "name": "Advances to Suppliers \u2014 General", "type": "asset", "parent_id": 11, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (110, 1, '2026-10-29 05:44:49.598193', NULL, NULL, 'create', 'accounting', 'Account', 110, '1-01-04-01-0001', 'Account 1-01-04-01-0001 created', '{"company_id": 1, "code": "1-01-04-01-0001", "name": "Stock \u2014 General", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (111, 1, '2026-10-29 05:44:49.604791', NULL, NULL, 'create', 'accounting', 'Account', 111, '1-01-05-01-0001', 'Account 1-01-05-01-0001 created', '{"company_id": 1, "code": "1-01-05-01-0001", "name": "Input Sales Tax", "type": "asset", "parent_id": 15, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (112, 1, '2026-10-29 05:44:49.611083', NULL, NULL, 'create', 'accounting', 'Account', 112, '1-01-05-02-0001', 'Account 1-01-05-02-0001 created', '{"company_id": 1, "code": "1-01-05-02-0001", "name": "WHT Receivable", "type": "asset", "parent_id": 16, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (113, 1, '2026-10-29 05:44:49.617527', NULL, NULL, 'create', 'accounting', 'Account', 113, '1-01-06-01-0001', 'Account 1-01-06-01-0001 created', '{"company_id": 1, "code": "1-01-06-01-0001", "name": "Suspense Account", "type": "asset", "parent_id": 18, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (114, 1, '2026-10-29 05:44:49.623974', NULL, NULL, 'create', 'accounting', 'Account', 114, '1-01-06-02-0001', 'Account 1-01-06-02-0001 created', '{"company_id": 1, "code": "1-01-06-02-0001", "name": "Prepaid Expenses \u2014 General", "type": "asset", "parent_id": 19, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (115, 1, '2026-10-29 05:44:49.630318', NULL, NULL, 'create', 'accounting', 'Account', 115, '1-02-01-01-0001', 'Account 1-02-01-01-0001 created', '{"company_id": 1, "code": "1-02-01-01-0001", "name": "Fixed Assets \u2014 General", "type": "asset", "parent_id": 23, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (116, 1, '2026-10-29 05:44:49.636885', NULL, NULL, 'create', 'accounting', 'Account', 116, '1-02-02-01-0001', 'Account 1-02-02-01-0001 created', '{"company_id": 1, "code": "1-02-02-01-0001", "name": "Accumulated Depreciation \u2014 General", "type": "asset", "parent_id": 25, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (117, 1, '2026-10-29 05:44:49.643207', NULL, NULL, 'create', 'accounting', 'Account', 117, '1-02-03-01-0001', 'Account 1-02-03-01-0001 created', '{"company_id": 1, "code": "1-02-03-01-0001", "name": "Intangibles \u2014 General", "type": "asset", "parent_id": 27, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (118, 1, '2026-10-29 05:44:49.649532', NULL, NULL, 'create', 'accounting', 'Account', 118, '2-01-01-01-0001', 'Account 2-01-01-01-0001 created', '{"company_id": 1, "code": "2-01-01-01-0001", "name": "Trade Creditors \u2014 General", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (119, 1, '2026-10-29 05:44:49.655855', NULL, NULL, 'create', 'accounting', 'Account', 119, '2-01-02-02-0001', 'Account 2-01-02-02-0001 created', '{"company_id": 1, "code": "2-01-02-02-0001", "name": "Salary Payable", "type": "liability", "parent_id": 34, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (120, 1, '2026-10-29 05:44:49.662333', NULL, NULL, 'create', 'accounting', 'Account', 120, '2-01-02-02-0002', 'Account 2-01-02-02-0002 created', '{"company_id": 1, "code": "2-01-02-02-0002", "name": "PF Payable", "type": "liability", "parent_id": 34, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (121, 1, '2026-10-29 05:44:49.668748', NULL, NULL, 'create', 'accounting', 'Account', 121, '2-01-02-02-0003', 'Account 2-01-02-02-0003 created', '{"company_id": 1, "code": "2-01-02-02-0003", "name": "Loan Deductions Clearing", "type": "liability", "parent_id": 34, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (122, 1, '2026-10-29 05:44:49.6751', NULL, NULL, 'create', 'accounting', 'Account', 122, '2-01-02-02-0004', 'Account 2-01-02-02-0004 created', '{"company_id": 1, "code": "2-01-02-02-0004", "name": "Other Payroll Deductions Payable", "type": "liability", "parent_id": 34, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (123, 1, '2026-10-29 05:44:49.681656', NULL, NULL, 'create', 'accounting', 'Account', 123, '2-01-02-03-0001', 'Account 2-01-02-03-0001 created', '{"company_id": 1, "code": "2-01-02-03-0001", "name": "Accrued Expenses \u2014 General", "type": "liability", "parent_id": 35, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (124, 1, '2026-10-29 05:44:49.688045', NULL, NULL, 'create', 'accounting', 'Account', 124, '2-01-03-01-0001', 'Account 2-01-03-01-0001 created', '{"company_id": 1, "code": "2-01-03-01-0001", "name": "Output Sales Tax", "type": "liability", "parent_id": 37, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (125, 1, '2026-10-29 05:44:49.694357', NULL, NULL, 'create', 'accounting', 'Account', 125, '2-01-03-02-0001', 'Account 2-01-03-02-0001 created', '{"company_id": 1, "code": "2-01-03-02-0001", "name": "Income Tax Payable", "type": "liability", "parent_id": 38, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (126, 1, '2026-10-29 05:44:49.700593', NULL, NULL, 'create', 'accounting', 'Account', 126, '2-01-03-03-0001', 'Account 2-01-03-03-0001 created', '{"company_id": 1, "code": "2-01-03-03-0001", "name": "WHT Payable", "type": "liability", "parent_id": 39, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (127, 1, '2026-10-29 05:44:49.707634', NULL, NULL, 'create', 'accounting', 'Account', 127, '2-01-03-04-0001', 'Account 2-01-03-04-0001 created', '{"company_id": 1, "code": "2-01-03-04-0001", "name": "Further Tax Payable", "type": "liability", "parent_id": 40, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (128, 1, '2026-10-29 05:44:49.714099', NULL, NULL, 'create', 'accounting', 'Account', 128, '2-01-04-01-0001', 'Account 2-01-04-01-0001 created', '{"company_id": 1, "code": "2-01-04-01-0001", "name": "Customer Advances \u2014 General", "type": "liability", "parent_id": 42, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (129, 1, '2026-10-29 05:44:49.720476', NULL, NULL, 'create', 'accounting', 'Account', 129, '2-02-01-01-0001', 'Account 2-02-01-01-0001 created', '{"company_id": 1, "code": "2-02-01-01-0001", "name": "Long-term Loans \u2014 General", "type": "liability", "parent_id": 45, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (130, 1, '2026-10-29 05:44:49.727106', NULL, NULL, 'create', 'accounting', 'Account', 130, '2-02-02-01-0001', 'Account 2-02-02-01-0001 created', '{"company_id": 1, "code": "2-02-02-01-0001", "name": "EOSB Provision \u2014 General", "type": "liability", "parent_id": 47, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (131, 1, '2026-10-29 05:44:49.733487', NULL, NULL, 'create', 'accounting', 'Account', 131, '3-01-01-01-0001', 'Account 3-01-01-01-0001 created', '{"company_id": 1, "code": "3-01-01-01-0001", "name": "Share Capital", "type": "equity", "parent_id": 51, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (132, 1, '2026-10-29 05:44:49.739839', NULL, NULL, 'create', 'accounting', 'Account', 132, '3-01-01-01-0002', 'Account 3-01-01-01-0002 created', '{"company_id": 1, "code": "3-01-01-01-0002", "name": "Suspense Equity", "type": "equity", "parent_id": 51, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (133, 1, '2026-10-29 05:44:49.746192', NULL, NULL, 'create', 'accounting', 'Account', 133, '3-02-01-01-0001', 'Account 3-02-01-01-0001 created', '{"company_id": 1, "code": "3-02-01-01-0001", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 54, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (134, 1, '2026-10-29 05:44:49.752728', NULL, NULL, 'create', 'accounting', 'Account', 134, '3-02-01-02-0001', 'Account 3-02-01-02-0001 created', '{"company_id": 1, "code": "3-02-01-02-0001", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 55, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (135, 1, '2026-10-29 05:44:49.759044', NULL, NULL, 'create', 'accounting', 'Account', 135, '3-02-02-01-0001', 'Account 3-02-02-01-0001 created', '{"company_id": 1, "code": "3-02-02-01-0001", "name": "Dividends", "type": "equity", "parent_id": 57, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (136, 1, '2026-10-29 05:44:49.765344', NULL, NULL, 'create', 'accounting', 'Account', 136, '3-02-03-01-0001', 'Account 3-02-03-01-0001 created', '{"company_id": 1, "code": "3-02-03-01-0001", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 59, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (137, 1, '2026-10-29 05:44:49.771872', NULL, NULL, 'create', 'accounting', 'Account', 137, '4-01-01-01-0001', 'Account 4-01-01-01-0001 created', '{"company_id": 1, "code": "4-01-01-01-0001", "name": "Sales \u2014 General", "type": "revenue", "parent_id": 63, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (138, 1, '2026-10-29 05:44:49.778197', NULL, NULL, 'create', 'accounting', 'Account', 138, '4-01-02-01-0001', 'Account 4-01-02-01-0001 created', '{"company_id": 1, "code": "4-01-02-01-0001", "name": "Service Income \u2014 General", "type": "revenue", "parent_id": 65, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (139, 1, '2026-10-29 05:44:49.784437', NULL, NULL, 'create', 'accounting', 'Account', 139, '4-02-01-01-0001', 'Account 4-02-01-01-0001 created', '{"company_id": 1, "code": "4-02-01-01-0001", "name": "Sales Returns \u2014 General", "type": "revenue", "parent_id": 68, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (140, 1, '2026-10-29 05:44:49.790677', NULL, NULL, 'create', 'accounting', 'Account', 140, '4-02-02-01-0001', 'Account 4-02-02-01-0001 created', '{"company_id": 1, "code": "4-02-02-01-0001", "name": "Discounts Allowed \u2014 General", "type": "revenue", "parent_id": 70, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (141, 1, '2026-10-29 05:44:49.797102', NULL, NULL, 'create', 'accounting', 'Account', 141, '4-03-01-01-0001', 'Account 4-03-01-01-0001 created', '{"company_id": 1, "code": "4-03-01-01-0001", "name": "Other Income \u2014 General", "type": "revenue", "parent_id": 73, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (142, 1, '2026-10-29 05:44:49.803337', NULL, NULL, 'create', 'accounting', 'Account', 142, '5-01-01-01-0001', 'Account 5-01-01-01-0001 created', '{"company_id": 1, "code": "5-01-01-01-0001", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 77, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (143, 1, '2026-10-29 05:44:49.809563', NULL, NULL, 'create', 'accounting', 'Account', 143, '5-01-02-01-0001', 'Account 5-01-02-01-0001 created', '{"company_id": 1, "code": "5-01-02-01-0001", "name": "Scrap / Write-off", "type": "expense", "parent_id": 79, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (144, 1, '2026-10-29 05:44:49.815999', NULL, NULL, 'create', 'accounting', 'Account', 144, '5-01-02-01-0002', 'Account 5-01-02-01-0002 created', '{"company_id": 1, "code": "5-01-02-01-0002", "name": "Inventory Adjustment", "type": "expense", "parent_id": 79, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (145, 1, '2026-10-29 05:44:49.822202', NULL, NULL, 'create', 'accounting', 'Account', 145, '5-01-02-01-0003', 'Account 5-01-02-01-0003 created', '{"company_id": 1, "code": "5-01-02-01-0003", "name": "Consumption Expense", "type": "expense", "parent_id": 79, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (146, 1, '2026-10-29 05:44:49.828835', NULL, NULL, 'create', 'accounting', 'Account', 146, '5-01-02-01-0004', 'Account 5-01-02-01-0004 created', '{"company_id": 1, "code": "5-01-02-01-0004", "name": "Inventory Cost Variance", "type": "expense", "parent_id": 79, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (147, 1, '2026-10-29 05:44:49.835181', NULL, NULL, 'create', 'accounting', 'Account', 147, '5-02-01-01-0001', 'Account 5-02-01-01-0001 created', '{"company_id": 1, "code": "5-02-01-01-0001", "name": "Salary Expense", "type": "expense", "parent_id": 82, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (148, 1, '2026-10-29 05:44:49.841614', NULL, NULL, 'create', 'accounting', 'Account', 148, '5-02-01-01-0002', 'Account 5-02-01-01-0002 created', '{"company_id": 1, "code": "5-02-01-01-0002", "name": "PF Employer Expense", "type": "expense", "parent_id": 82, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (149, 1, '2026-10-29 05:44:49.847934', NULL, NULL, 'create', 'accounting', 'Account', 149, '5-02-02-01-0001', 'Account 5-02-02-01-0001 created', '{"company_id": 1, "code": "5-02-02-01-0001", "name": "Rent Expense", "type": "expense", "parent_id": 84, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (150, 1, '2026-10-29 05:44:49.854229', NULL, NULL, 'create', 'accounting', 'Account', 150, '5-02-02-01-0002', 'Account 5-02-02-01-0002 created', '{"company_id": 1, "code": "5-02-02-01-0002", "name": "Utilities Expense", "type": "expense", "parent_id": 84, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (151, 1, '2026-10-29 05:44:49.860684', NULL, NULL, 'create', 'accounting', 'Account', 151, '5-02-03-01-0001', 'Account 5-02-03-01-0001 created', '{"company_id": 1, "code": "5-02-03-01-0001", "name": "Office Supplies", "type": "expense", "parent_id": 86, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (152, 1, '2026-10-29 05:44:49.86707', NULL, NULL, 'create', 'accounting', 'Account', 152, '5-02-04-01-0001', 'Account 5-02-04-01-0001 created', '{"company_id": 1, "code": "5-02-04-01-0001", "name": "Depreciation Expense", "type": "expense", "parent_id": 88, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (153, 1, '2026-10-29 05:44:49.873501', NULL, NULL, 'create', 'accounting', 'Account', 153, '5-02-05-01-0001', 'Account 5-02-05-01-0001 created', '{"company_id": 1, "code": "5-02-05-01-0001", "name": "Fees, Taxes & Licenses \u2014 General", "type": "expense", "parent_id": 90, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (154, 1, '2026-10-29 05:44:49.879833', NULL, NULL, 'create', 'accounting', 'Account', 154, '5-03-01-01-0001', 'Account 5-03-01-01-0001 created', '{"company_id": 1, "code": "5-03-01-01-0001", "name": "Freight & Transportation \u2014 General", "type": "expense", "parent_id": 93, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (155, 1, '2026-10-29 05:44:49.88635', NULL, NULL, 'create', 'accounting', 'Account', 155, '5-03-02-01-0001', 'Account 5-03-02-01-0001 created', '{"company_id": 1, "code": "5-03-02-01-0001", "name": "Commissions \u2014 General", "type": "expense", "parent_id": 95, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (156, 1, '2026-10-29 05:44:49.892709', NULL, NULL, 'create', 'accounting', 'Account', 156, '5-03-03-01-0001', 'Account 5-03-03-01-0001 created', '{"company_id": 1, "code": "5-03-03-01-0001", "name": "Marketing & Advertising \u2014 General", "type": "expense", "parent_id": 97, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (157, 1, '2026-10-29 05:44:49.899001', NULL, NULL, 'create', 'accounting', 'Account', 157, '5-04-01-01-0001', 'Account 5-04-01-01-0001 created', '{"company_id": 1, "code": "5-04-01-01-0001", "name": "Other Expenses \u2014 General", "type": "expense", "parent_id": 100, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (158, 1, '2026-10-29 05:44:49.905426', NULL, NULL, 'create', 'accounting', 'Account', 158, '5-04-01-01-0002', 'Account 5-04-01-01-0002 created', '{"company_id": 1, "code": "5-04-01-01-0002", "name": "Loss/(Gain) on Disposal of Fixed Assets", "type": "expense", "parent_id": 100, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (159, 1, '2026-10-29 05:44:49.911644', NULL, NULL, 'create', 'accounting', 'Account', 159, '5-05-01-01-0001', 'Account 5-05-01-01-0001 created', '{"company_id": 1, "code": "5-05-01-01-0001", "name": "Bank Charges", "type": "expense", "parent_id": 103, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (160, 1, '2026-10-29 05:44:49.91788', NULL, NULL, 'create', 'accounting', 'Account', 160, '5-05-01-01-0002', 'Account 5-05-01-01-0002 created', '{"company_id": 1, "code": "5-05-01-01-0002", "name": "Interest Expense", "type": "expense", "parent_id": 103, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (161, 1, '2026-10-29 05:44:49.922629', NULL, NULL, 'create', 'accounting', 'Account', 161, '5-06-01-01-0001', 'Account 5-06-01-01-0001 created', '{"company_id": 1, "code": "5-06-01-01-0001", "name": "Income Tax Expense", "type": "expense", "parent_id": 106, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (162, 1, '2026-10-29 05:44:50.242289', NULL, NULL, 'create', 'admin', 'User', 1, 'admin@gmail.com', 'User admin@gmail.com created', '{"employee_code": "SYSADMIN", "email": "admin@gmail.com", "password_hash": "\u2022\u2022\u2022", "full_name": "Administrator", "role_id": 1, "designation": "System Administrator", "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true, "has_inventory_access": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (254, 1, '2026-10-29 05:44:51.343778', NULL, NULL, 'post', 'accounting', 'Journal entry', 3, 'OPEN-00003', 'Journal entry OPEN-00003 posted — Opening stock — Polycrystalline Solar Panel 330W', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (163, 1, '2026-10-29 05:44:50.354618', NULL, NULL, 'create', 'admin', 'User', 2, 'admin@solarkon.com', 'User admin@solarkon.com created', '{"employee_code": "ADM001", "email": "admin@solarkon.com", "password_hash": "\u2022\u2022\u2022", "full_name": "System Admin", "role_id": 3, "designation": "Employee", "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (164, 1, '2026-10-29 05:44:50.466362', NULL, NULL, 'create', 'admin', 'User', 3, 'manager@solarkon.com', 'User manager@solarkon.com created', '{"employee_code": "MGR002", "email": "manager@solarkon.com", "password_hash": "\u2022\u2022\u2022", "full_name": "Manager User", "role_id": 2, "designation": "Manager", "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true, "has_inventory_access": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (165, 1, '2026-10-29 05:44:50.577242', NULL, NULL, 'create', 'admin', 'User', 4, 'emp@solarkon.com', 'User emp@solarkon.com created', '{"employee_code": "EMP001", "email": "emp@solarkon.com", "password_hash": "\u2022\u2022\u2022", "full_name": "Employee User", "role_id": 3, "designation": "Employee", "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (166, 1, '2026-10-29 05:44:50.589314', NULL, NULL, 'create', 'admin', 'User', 5, 'john.doe@solarkon.com', 'User john.doe@solarkon.com created', '{"employee_code": "EMP002", "email": "john.doe@solarkon.com", "password_hash": "\u2022\u2022\u2022", "full_name": "John Doe", "role_id": 3, "designation": "Employee", "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (167, 1, '2026-10-29 05:44:50.661266', NULL, NULL, 'create', 'inventory', 'Product', 1, 'SOL-MONO-450', 'Product SOL-MONO-450 created', '{"company_id": 1, "sku": "SOL-MONO-450", "name": "Monocrystalline Solar Panel 450W", "category_id": 1, "unit_price": 32000.0, "cost_price": 28000.0, "reorder_level": 10, "current_stock": 50, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (168, 1, '2026-10-29 05:44:50.665601', NULL, NULL, 'create', 'inventory', 'Product', 2, 'SOL-MONO-550', 'Product SOL-MONO-550 created', '{"company_id": 1, "sku": "SOL-MONO-550", "name": "Monocrystalline Solar Panel 550W", "category_id": 1, "unit_price": 42000.0, "cost_price": 37000.0, "reorder_level": 5, "current_stock": 30, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (169, 1, '2026-10-29 05:44:50.669923', NULL, NULL, 'create', 'inventory', 'Product', 3, 'SOL-POLY-330', 'Product SOL-POLY-330 created', '{"company_id": 1, "sku": "SOL-POLY-330", "name": "Polycrystalline Solar Panel 330W", "category_id": 1, "unit_price": 22000.0, "cost_price": 18500.0, "reorder_level": 8, "current_stock": 40, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (170, 1, '2026-10-29 05:44:50.67424', NULL, NULL, 'create', 'inventory', 'Product', 4, 'INV-5KW', 'Product INV-5KW created', '{"company_id": 1, "sku": "INV-5KW", "name": "5kW Hybrid Inverter", "category_id": 2, "unit_price": 85000.0, "cost_price": 72000.0, "reorder_level": 3, "current_stock": 15, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (171, 1, '2026-10-29 05:44:50.678568', NULL, NULL, 'create', 'inventory', 'Product', 5, 'INV-10KW', 'Product INV-10KW created', '{"company_id": 1, "sku": "INV-10KW", "name": "10kW Hybrid Inverter", "category_id": 2, "unit_price": 145000.0, "cost_price": 125000.0, "reorder_level": 2, "current_stock": 10, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (172, 1, '2026-10-29 05:44:50.682862', NULL, NULL, 'create', 'inventory', 'Product', 6, 'INV-3KW', 'Product INV-3KW created', '{"company_id": 1, "sku": "INV-3KW", "name": "3kW String Inverter", "category_id": 2, "unit_price": 55000.0, "cost_price": 46000.0, "reorder_level": 4, "current_stock": 20, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (173, 1, '2026-10-29 05:44:50.68734', NULL, NULL, 'create', 'inventory', 'Product', 7, 'BAT-LFP-5KWH', 'Product BAT-LFP-5KWH created', '{"company_id": 1, "sku": "BAT-LFP-5KWH", "name": "5kWh LiFePO4 Battery", "category_id": 3, "unit_price": 180000.0, "cost_price": 155000.0, "reorder_level": 5, "current_stock": 25, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (174, 1, '2026-10-29 05:44:50.69163', NULL, NULL, 'create', 'inventory', 'Product', 8, 'BAT-LFP-10KWH', 'Product BAT-LFP-10KWH created', '{"company_id": 1, "sku": "BAT-LFP-10KWH", "name": "10kWh LiFePO4 Battery", "category_id": 3, "unit_price": 320000.0, "cost_price": 280000.0, "reorder_level": 3, "current_stock": 15, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (175, 1, '2026-10-29 05:44:50.695904', NULL, NULL, 'create', 'inventory', 'Product', 9, 'BAT-TUB-200', 'Product BAT-TUB-200 created', '{"company_id": 1, "sku": "BAT-TUB-200", "name": "200Ah Tubular Battery", "category_id": 3, "unit_price": 45000.0, "cost_price": 38000.0, "reorder_level": 5, "current_stock": 30, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (176, 1, '2026-10-29 05:44:50.700187', NULL, NULL, 'create', 'inventory', 'Product', 10, 'CBL-SOL-4MM', 'Product CBL-SOL-4MM created', '{"company_id": 1, "sku": "CBL-SOL-4MM", "name": "Solar DC Cable 4mm (per meter)", "category_id": 4, "unit_price": 180.0, "cost_price": 120.0, "reorder_level": 100, "current_stock": 500, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (177, 1, '2026-10-29 05:44:50.704481', NULL, NULL, 'create', 'inventory', 'Product', 11, 'CBL-AC-2.5MM', 'Product CBL-AC-2.5MM created', '{"company_id": 1, "sku": "CBL-AC-2.5MM", "name": "AC Cable 2.5mm (per meter)", "category_id": 4, "unit_price": 120.0, "cost_price": 80.0, "reorder_level": 200, "current_stock": 1000, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (178, 1, '2026-10-29 05:44:50.708895', NULL, NULL, 'create', 'inventory', 'Product', 12, 'CBL-MC4', 'Product CBL-MC4 created', '{"company_id": 1, "sku": "CBL-MC4", "name": "MC4 Connector Pair", "category_id": 4, "unit_price": 350.0, "cost_price": 250.0, "reorder_level": 50, "current_stock": 200, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (179, 1, '2026-10-29 05:44:50.713411', NULL, NULL, 'create', 'inventory', 'Product', 13, 'MNT-ALU-RACK', 'Product MNT-ALU-RACK created', '{"company_id": 1, "sku": "MNT-ALU-RACK", "name": "Aluminum Mounting Rack (set)", "category_id": 5, "unit_price": 8500.0, "cost_price": 6500.0, "reorder_level": 5, "current_stock": 20, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (180, 1, '2026-10-29 05:44:50.717704', NULL, NULL, 'create', 'inventory', 'Product', 14, 'MNT-RAIL-2M', 'Product MNT-RAIL-2M created', '{"company_id": 1, "sku": "MNT-RAIL-2M", "name": "Mounting Rail 2m", "category_id": 5, "unit_price": 2200.0, "cost_price": 1600.0, "reorder_level": 10, "current_stock": 50, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (181, 1, '2026-10-29 05:44:50.722007', NULL, NULL, 'create', 'inventory', 'Product', 15, 'ELEC-DB', 'Product ELEC-DB created', '{"company_id": 1, "sku": "ELEC-DB", "name": "Distribution Board 16-way", "category_id": 6, "unit_price": 4500.0, "cost_price": 3200.0, "reorder_level": 5, "current_stock": 30, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (182, 1, '2026-10-29 05:44:50.726337', NULL, NULL, 'create', 'inventory', 'Product', 16, 'ELEC-SPD', 'Product ELEC-SPD created', '{"company_id": 1, "sku": "ELEC-SPD", "name": "Surge Protection Device", "category_id": 6, "unit_price": 2800.0, "cost_price": 2000.0, "reorder_level": 8, "current_stock": 40, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (183, 1, '2026-10-29 05:44:50.730621', NULL, NULL, 'create', 'inventory', 'Product', 17, 'ELEC-MCB-16A', 'Product ELEC-MCB-16A created', '{"company_id": 1, "sku": "ELEC-MCB-16A", "name": "MCB 16A Single Pole", "category_id": 6, "unit_price": 350.0, "cost_price": 220.0, "reorder_level": 20, "current_stock": 100, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (184, 1, '2026-10-29 05:44:50.734922', NULL, NULL, 'create', 'inventory', 'Product', 18, 'TOOL-CRIMP', 'Product TOOL-CRIMP created', '{"company_id": 1, "sku": "TOOL-CRIMP", "name": "Solar Crimping Tool", "category_id": 7, "unit_price": 5500.0, "cost_price": 4200.0, "reorder_level": 2, "current_stock": 10, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (185, 1, '2026-10-29 05:44:50.739395', NULL, NULL, 'create', 'inventory', 'Product', 19, 'TOOL-MULTI', 'Product TOOL-MULTI created', '{"company_id": 1, "sku": "TOOL-MULTI", "name": "Digital Multimeter", "category_id": 7, "unit_price": 3500.0, "cost_price": 2500.0, "reorder_level": 3, "current_stock": 15, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (186, 1, '2026-10-29 05:44:50.743783', NULL, NULL, 'create', 'inventory', 'Product', 20, 'SAFE-HLMT', 'Product SAFE-HLMT created', '{"company_id": 1, "sku": "SAFE-HLMT", "name": "Safety Helmet", "category_id": 8, "unit_price": 800.0, "cost_price": 500.0, "reorder_level": 10, "current_stock": 50, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (187, 1, '2026-10-29 05:44:50.748571', NULL, NULL, 'create', 'inventory', 'Product', 21, 'SAFE-GLOVES', 'Product SAFE-GLOVES created', '{"company_id": 1, "sku": "SAFE-GLOVES", "name": "Insulated Gloves (pair)", "category_id": 8, "unit_price": 1200.0, "cost_price": 800.0, "reorder_level": 10, "current_stock": 40, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (188, 1, '2026-10-29 05:44:50.755371', NULL, NULL, 'create', 'inventory', 'Product', 22, 'SAFE-HARNESS', 'Product SAFE-HARNESS created', '{"company_id": 1, "sku": "SAFE-HARNESS", "name": "Safety Harness", "category_id": 8, "unit_price": 4500.0, "cost_price": 3200.0, "reorder_level": 3, "current_stock": 15, "unit": "pcs", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (189, 1, '2026-10-29 05:44:50.759439', NULL, NULL, 'create', 'invoicing', 'Supplier', 1, 'Longi Solar Pakistan', 'Supplier Longi Solar Pakistan created', '{"company_id": 1, "name": "Longi Solar Pakistan", "contact_person": "Mr. Ahmed", "email": "ahmed@longi.pk", "phone": "021-34567890", "address": "PLOT 12, SITE AREA", "city": "Karachi", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (190, 1, '2026-10-29 05:44:50.763363', NULL, NULL, 'create', 'invoicing', 'Supplier', 2, 'JA Solar Technologies', 'Supplier JA Solar Technologies created', '{"company_id": 1, "name": "JA Solar Technologies", "contact_person": "Mr. Usman", "email": "usman@jasolar.com", "phone": "042-35678901", "address": "23-G, Gulberg III", "city": "Lahore", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (191, 1, '2026-10-29 05:44:50.767291', NULL, NULL, 'create', 'invoicing', 'Supplier', 3, 'BYD Energy Solutions', 'Supplier BYD Energy Solutions created', '{"company_id": 1, "name": "BYD Energy Solutions", "contact_person": "Mr. Kamran", "email": "kamran@byd.com", "phone": "021-36789012", "address": "Business Bay, Clifton", "city": "Karachi", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (192, 1, '2026-10-29 05:44:50.771223', NULL, NULL, 'create', 'invoicing', 'Supplier', 4, 'Growatt Inverters', 'Supplier Growatt Inverters created', '{"company_id": 1, "name": "Growatt Inverters", "contact_person": "Mr. Hassan", "email": "hassan@growatt.com", "phone": "042-37890123", "address": "55 Main Boulevard", "city": "Lahore", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (193, 1, '2026-10-29 05:44:50.776075', NULL, NULL, 'create', 'invoicing', 'Supplier', 5, 'Al-Rashid Traders', 'Supplier Al-Rashid Traders created', '{"company_id": 1, "name": "Al-Rashid Traders", "contact_person": "Mr. Rashid", "email": "rashid@alrashid.com", "phone": "0315-1234567", "address": "Steel Market, Bolton Market", "city": "Karachi", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (194, 1, '2026-10-29 05:44:50.782777', NULL, NULL, 'create', 'invoicing', 'Supplier', 6, 'Pakistan Cable Co.', 'Supplier Pakistan Cable Co. created', '{"company_id": 1, "name": "Pakistan Cable Co.", "contact_person": "Mr. Faisal", "email": "faisal@pakcable.com", "phone": "021-38901234", "address": "Industrial Area, Kot Lakhpat", "city": "Lahore", "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (195, 1, '2026-10-29 05:44:50.787469', NULL, NULL, 'create', 'invoicing', 'Customer', 1, 'SolarTech Solutions', 'Customer SolarTech Solutions created', '{"company_id": 1, "name": "SolarTech Solutions", "email": "imran@solartech.com", "phone": "0300-1111111", "address": "7-A, Johar Town", "city": "Lahore", "credit_limit": 1000000, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (196, 1, '2026-10-29 05:44:50.791573', NULL, NULL, 'create', 'invoicing', 'Customer', 2, 'Green Energy Pakistan', 'Customer Green Energy Pakistan created', '{"company_id": 1, "name": "Green Energy Pakistan", "email": "fatima@greenenergy.com", "phone": "0300-2222222", "address": "15-B, Phase 2, DHA", "city": "Karachi", "credit_limit": 2000000, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (197, 1, '2026-10-29 05:44:50.796198', NULL, NULL, 'create', 'invoicing', 'Customer', 3, 'BuildRight Construction', 'Customer BuildRight Construction created', '{"company_id": 1, "name": "BuildRight Construction", "email": "ali@buildright.com", "phone": "0300-3333333", "address": "3rd Floor, Al-Falah Plaza", "city": "Islamabad", "credit_limit": 1500000, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (198, 1, '2026-10-29 05:44:50.801429', NULL, NULL, 'create', 'invoicing', 'Customer', 4, 'Home Solutions Ltd.', 'Customer Home Solutions Ltd. created', '{"company_id": 1, "name": "Home Solutions Ltd.", "email": "zafar@homesol.com", "phone": "0300-4444444", "address": "88, Garden Town", "city": "Lahore", "credit_limit": 500000, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (199, 1, '2026-10-29 05:44:50.808488', NULL, NULL, 'create', 'inventory', 'Inventory settings', 1, '1', 'Inventory settings 1 created', '{"company_id": 1, "valuation_method": "weighted_average", "decimal_places": 4, "auto_generate_vouchers": true, "purchase_flow": "with_po", "sales_flow": "with_so"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (200, 1, '2026-10-29 05:44:50.818912', NULL, NULL, 'create', 'settings', 'Company profile', 1, 'SolarKon Energy Solutions', 'Company profile SolarKon Energy Solutions created', '{"company_id": 1, "company_name": "SolarKon Energy Solutions", "country": "Pakistan", "fiscal_year_start_month": 1, "currency": "PKR", "currency_symbol": "Rs.", "date_format": "Y-m-d", "number_format": "en", "timezone": "Asia/Karachi"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (201, 1, '2026-10-29 05:44:50.842059', NULL, NULL, 'create', 'accounting', 'Accounting period', 1, 'FY 2021', 'Accounting period FY 2021 created', '{"company_id": 1, "fiscal_year": "2021", "period_name": "FY 2021", "start_date": "2021-01-01", "end_date": "2021-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (202, 1, '2026-10-29 05:44:50.842064', NULL, NULL, 'create', 'accounting', 'Accounting period', 2, 'FY 2022', 'Accounting period FY 2022 created', '{"company_id": 1, "fiscal_year": "2022", "period_name": "FY 2022", "start_date": "2022-01-01", "end_date": "2022-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (203, 1, '2026-10-29 05:44:50.842066', NULL, NULL, 'create', 'accounting', 'Accounting period', 3, 'FY 2023', 'Accounting period FY 2023 created', '{"company_id": 1, "fiscal_year": "2023", "period_name": "FY 2023", "start_date": "2023-01-01", "end_date": "2023-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (204, 1, '2026-10-29 05:44:50.842068', NULL, NULL, 'create', 'accounting', 'Accounting period', 4, 'FY 2024', 'Accounting period FY 2024 created', '{"company_id": 1, "fiscal_year": "2024", "period_name": "FY 2024", "start_date": "2024-01-01", "end_date": "2024-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (205, 1, '2026-10-29 05:44:50.84207', NULL, NULL, 'create', 'accounting', 'Accounting period', 5, 'FY 2025', 'Accounting period FY 2025 created', '{"company_id": 1, "fiscal_year": "2025", "period_name": "FY 2025", "start_date": "2025-01-01", "end_date": "2025-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (206, 1, '2026-10-29 05:44:50.842071', NULL, NULL, 'create', 'accounting', 'Accounting period', 6, 'FY 2026', 'Accounting period FY 2026 created', '{"company_id": 1, "fiscal_year": "2026", "period_name": "FY 2026", "start_date": "2026-01-01", "end_date": "2026-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (207, 1, '2026-10-29 05:44:50.842073', NULL, NULL, 'create', 'accounting', 'Accounting period', 7, 'FY 2027', 'Accounting period FY 2027 created', '{"company_id": 1, "fiscal_year": "2027", "period_name": "FY 2027", "start_date": "2027-01-01", "end_date": "2027-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (255, 1, '2026-10-29 05:44:51.398541', NULL, NULL, 'post', 'accounting', 'Journal entry', 4, 'OPEN-00004', 'Journal entry OPEN-00004 posted — Opening stock — 5kW Hybrid Inverter', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (208, 1, '2026-10-29 05:44:50.842074', NULL, NULL, 'create', 'accounting', 'Accounting period', 8, 'FY 2028', 'Accounting period FY 2028 created', '{"company_id": 1, "fiscal_year": "2028", "period_name": "FY 2028", "start_date": "2028-01-01", "end_date": "2028-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (209, 1, '2026-10-29 05:44:50.859255', NULL, NULL, 'create', 'settings', 'Report settings', 1, '1', 'Report settings 1 created', '{"company_id": 1, "pl_detail_rows": 10, "invoice_party_mode": "relevant", "purchase_party_mode": "relevant", "sales_party_mode": "relevant", "cash_flow_method": "indirect"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (210, 1, '2026-10-29 05:44:50.870531', NULL, NULL, 'create', 'accounting', 'Account', 162, '2-01-01-01-0101', 'Account 2-01-01-01-0101 created', '{"company_id": 1, "code": "2-01-01-01-0101", "name": "Longi Solar Pakistan", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (211, 1, '2026-10-29 05:44:50.876925', NULL, NULL, 'create', 'accounting', 'Account', 163, '2-01-01-01-0102', 'Account 2-01-01-01-0102 created', '{"company_id": 1, "code": "2-01-01-01-0102", "name": "JA Solar Technologies", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (212, 1, '2026-10-29 05:44:50.883506', NULL, NULL, 'create', 'accounting', 'Account', 164, '2-01-01-01-0103', 'Account 2-01-01-01-0103 created', '{"company_id": 1, "code": "2-01-01-01-0103", "name": "BYD Energy Solutions", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (213, 1, '2026-10-29 05:44:50.889946', NULL, NULL, 'create', 'accounting', 'Account', 165, '2-01-01-01-0104', 'Account 2-01-01-01-0104 created', '{"company_id": 1, "code": "2-01-01-01-0104", "name": "Growatt Inverters", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (214, 1, '2026-10-29 05:44:50.896274', NULL, NULL, 'create', 'accounting', 'Account', 166, '2-01-01-01-0105', 'Account 2-01-01-01-0105 created', '{"company_id": 1, "code": "2-01-01-01-0105", "name": "Al-Rashid Traders", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (215, 1, '2026-10-29 05:44:50.902559', NULL, NULL, 'create', 'accounting', 'Account', 167, '2-01-01-01-0106', 'Account 2-01-01-01-0106 created', '{"company_id": 1, "code": "2-01-01-01-0106", "name": "Pakistan Cable Co.", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (216, 1, '2026-10-29 05:44:50.912456', NULL, NULL, 'create', 'accounting', 'Account', 168, '1-01-02-01-0101', 'Account 1-01-02-01-0101 created', '{"company_id": 1, "code": "1-01-02-01-0101", "name": "SolarTech Solutions", "type": "asset", "parent_id": 7, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (217, 1, '2026-10-29 05:44:50.91882', NULL, NULL, 'create', 'accounting', 'Account', 169, '1-01-02-01-0102', 'Account 1-01-02-01-0102 created', '{"company_id": 1, "code": "1-01-02-01-0102", "name": "Green Energy Pakistan", "type": "asset", "parent_id": 7, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (218, 1, '2026-10-29 05:44:50.925101', NULL, NULL, 'create', 'accounting', 'Account', 170, '1-01-02-01-0103', 'Account 1-01-02-01-0103 created', '{"company_id": 1, "code": "1-01-02-01-0103", "name": "BuildRight Construction", "type": "asset", "parent_id": 7, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (219, 1, '2026-10-29 05:44:50.931585', NULL, NULL, 'create', 'accounting', 'Account', 171, '1-01-02-01-0104', 'Account 1-01-02-01-0104 created', '{"company_id": 1, "code": "1-01-02-01-0104", "name": "Home Solutions Ltd.", "type": "asset", "parent_id": 7, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (220, 1, '2026-10-29 05:44:50.941687', NULL, NULL, 'create', 'accounting', 'Account', 172, '1-01-04-01-0101', 'Account 1-01-04-01-0101 created', '{"company_id": 1, "code": "1-01-04-01-0101", "name": "Monocrystalline Solar Panel 450W (SOL-MONO-450)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (221, 1, '2026-10-29 05:44:50.948328', NULL, NULL, 'create', 'accounting', 'Account', 173, '1-01-04-01-0102', 'Account 1-01-04-01-0102 created', '{"company_id": 1, "code": "1-01-04-01-0102", "name": "Monocrystalline Solar Panel 550W (SOL-MONO-550)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (222, 1, '2026-10-29 05:44:50.954734', NULL, NULL, 'create', 'accounting', 'Account', 174, '1-01-04-01-0103', 'Account 1-01-04-01-0103 created', '{"company_id": 1, "code": "1-01-04-01-0103", "name": "Polycrystalline Solar Panel 330W (SOL-POLY-330)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (223, 1, '2026-10-29 05:44:50.961309', NULL, NULL, 'create', 'accounting', 'Account', 175, '1-01-04-01-0104', 'Account 1-01-04-01-0104 created', '{"company_id": 1, "code": "1-01-04-01-0104", "name": "5kW Hybrid Inverter (INV-5KW)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (224, 1, '2026-10-29 05:44:50.967673', NULL, NULL, 'create', 'accounting', 'Account', 176, '1-01-04-01-0105', 'Account 1-01-04-01-0105 created', '{"company_id": 1, "code": "1-01-04-01-0105", "name": "10kW Hybrid Inverter (INV-10KW)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (225, 1, '2026-10-29 05:44:50.974013', NULL, NULL, 'create', 'accounting', 'Account', 177, '1-01-04-01-0106', 'Account 1-01-04-01-0106 created', '{"company_id": 1, "code": "1-01-04-01-0106", "name": "3kW String Inverter (INV-3KW)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (226, 1, '2026-10-29 05:44:50.980364', NULL, NULL, 'create', 'accounting', 'Account', 178, '1-01-04-01-0107', 'Account 1-01-04-01-0107 created', '{"company_id": 1, "code": "1-01-04-01-0107", "name": "5kWh LiFePO4 Battery (BAT-LFP-5KWH)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (227, 1, '2026-10-29 05:44:50.986927', NULL, NULL, 'create', 'accounting', 'Account', 179, '1-01-04-01-0108', 'Account 1-01-04-01-0108 created', '{"company_id": 1, "code": "1-01-04-01-0108", "name": "10kWh LiFePO4 Battery (BAT-LFP-10KWH)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (228, 1, '2026-10-29 05:44:50.993295', NULL, NULL, 'create', 'accounting', 'Account', 180, '1-01-04-01-0109', 'Account 1-01-04-01-0109 created', '{"company_id": 1, "code": "1-01-04-01-0109", "name": "200Ah Tubular Battery (BAT-TUB-200)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (229, 1, '2026-10-29 05:44:50.999719', NULL, NULL, 'create', 'accounting', 'Account', 181, '1-01-04-01-0110', 'Account 1-01-04-01-0110 created', '{"company_id": 1, "code": "1-01-04-01-0110", "name": "Solar DC Cable 4mm (per meter) (CBL-SOL-4MM)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (230, 1, '2026-10-29 05:44:51.006039', NULL, NULL, 'create', 'accounting', 'Account', 182, '1-01-04-01-0111', 'Account 1-01-04-01-0111 created', '{"company_id": 1, "code": "1-01-04-01-0111", "name": "AC Cable 2.5mm (per meter) (CBL-AC-2.5MM)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (231, 1, '2026-10-29 05:44:51.012583', NULL, NULL, 'create', 'accounting', 'Account', 183, '1-01-04-01-0112', 'Account 1-01-04-01-0112 created', '{"company_id": 1, "code": "1-01-04-01-0112", "name": "MC4 Connector Pair (CBL-MC4)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (232, 1, '2026-10-29 05:44:51.018897', NULL, NULL, 'create', 'accounting', 'Account', 184, '1-01-04-01-0113', 'Account 1-01-04-01-0113 created', '{"company_id": 1, "code": "1-01-04-01-0113", "name": "Aluminum Mounting Rack (set) (MNT-ALU-RACK)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (233, 1, '2026-10-29 05:44:51.025291', NULL, NULL, 'create', 'accounting', 'Account', 185, '1-01-04-01-0114', 'Account 1-01-04-01-0114 created', '{"company_id": 1, "code": "1-01-04-01-0114", "name": "Mounting Rail 2m (MNT-RAIL-2M)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (252, 1, '2026-10-29 05:44:51.228966', NULL, NULL, 'post', 'accounting', 'Journal entry', 1, 'OPEN-00001', 'Journal entry OPEN-00001 posted — Opening stock — Monocrystalline Solar Panel 450W', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (234, 1, '2026-10-29 05:44:51.031905', NULL, NULL, 'create', 'accounting', 'Account', 186, '1-01-04-01-0115', 'Account 1-01-04-01-0115 created', '{"company_id": 1, "code": "1-01-04-01-0115", "name": "Distribution Board 16-way (ELEC-DB)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (235, 1, '2026-10-29 05:44:51.041729', NULL, NULL, 'create', 'accounting', 'Account', 187, '1-01-04-01-0116', 'Account 1-01-04-01-0116 created', '{"company_id": 1, "code": "1-01-04-01-0116", "name": "Surge Protection Device (ELEC-SPD)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (236, 1, '2026-10-29 05:44:51.048145', NULL, NULL, 'create', 'accounting', 'Account', 188, '1-01-04-01-0117', 'Account 1-01-04-01-0117 created', '{"company_id": 1, "code": "1-01-04-01-0117", "name": "MCB 16A Single Pole (ELEC-MCB-16A)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (237, 1, '2026-10-29 05:44:51.054381', NULL, NULL, 'create', 'accounting', 'Account', 189, '1-01-04-01-0118', 'Account 1-01-04-01-0118 created', '{"company_id": 1, "code": "1-01-04-01-0118", "name": "Solar Crimping Tool (TOOL-CRIMP)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (238, 1, '2026-10-29 05:44:51.060608', NULL, NULL, 'create', 'accounting', 'Account', 190, '1-01-04-01-0119', 'Account 1-01-04-01-0119 created', '{"company_id": 1, "code": "1-01-04-01-0119", "name": "Digital Multimeter (TOOL-MULTI)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (239, 1, '2026-10-29 05:44:51.067906', NULL, NULL, 'create', 'accounting', 'Account', 191, '1-01-04-01-0120', 'Account 1-01-04-01-0120 created', '{"company_id": 1, "code": "1-01-04-01-0120", "name": "Safety Helmet (SAFE-HLMT)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (240, 1, '2026-10-29 05:44:51.074097', NULL, NULL, 'create', 'accounting', 'Account', 192, '1-01-04-01-0121', 'Account 1-01-04-01-0121 created', '{"company_id": 1, "code": "1-01-04-01-0121", "name": "Insulated Gloves (pair) (SAFE-GLOVES)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (241, 1, '2026-10-29 05:44:51.081533', NULL, NULL, 'create', 'accounting', 'Account', 193, '1-01-04-01-0122', 'Account 1-01-04-01-0122 created', '{"company_id": 1, "code": "1-01-04-01-0122", "name": "Safety Harness (SAFE-HARNESS)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (242, 1, '2026-10-29 05:44:51.09136', NULL, NULL, 'create', 'accounting', 'Account', 194, '2-01-02-01-0101', 'Account 2-01-02-01-0101 created', '{"company_id": 1, "code": "2-01-02-01-0101", "name": "Administrator (SYSADMIN)", "type": "liability", "parent_id": 33, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (243, 1, '2026-10-29 05:44:51.096', NULL, NULL, 'update', 'admin', 'User', 1, 'admin@gmail.com', 'User admin@gmail.com edited (login id)', '[{"field": "login_id", "old": null, "new": "admin@gmail.com"}]', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (244, 1, '2026-10-29 05:44:51.101107', NULL, NULL, 'create', 'accounting', 'Account', 195, '2-01-02-01-0102', 'Account 2-01-02-01-0102 created', '{"company_id": 1, "code": "2-01-02-01-0102", "name": "System Admin (ADM001)", "type": "liability", "parent_id": 33, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (245, 1, '2026-10-29 05:44:51.104823', NULL, NULL, 'update', 'admin', 'User', 2, 'admin@solarkon.com', 'User admin@solarkon.com edited (login id)', '[{"field": "login_id", "old": null, "new": "admin@solarkon.com"}]', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (246, 1, '2026-10-29 05:44:51.109827', NULL, NULL, 'create', 'accounting', 'Account', 196, '2-01-02-01-0103', 'Account 2-01-02-01-0103 created', '{"company_id": 1, "code": "2-01-02-01-0103", "name": "Manager User (MGR002)", "type": "liability", "parent_id": 33, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (247, 1, '2026-10-29 05:44:51.113471', NULL, NULL, 'update', 'admin', 'User', 3, 'manager@solarkon.com', 'User manager@solarkon.com edited (login id)', '[{"field": "login_id", "old": null, "new": "manager@solarkon.com"}]', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (248, 1, '2026-10-29 05:44:51.118712', NULL, NULL, 'create', 'accounting', 'Account', 197, '2-01-02-01-0104', 'Account 2-01-02-01-0104 created', '{"company_id": 1, "code": "2-01-02-01-0104", "name": "Employee User (EMP001)", "type": "liability", "parent_id": 33, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (249, 1, '2026-10-29 05:44:51.122359', NULL, NULL, 'update', 'admin', 'User', 4, 'emp@solarkon.com', 'User emp@solarkon.com edited (login id)', '[{"field": "login_id", "old": null, "new": "emp@solarkon.com"}]', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (250, 1, '2026-10-29 05:44:51.128308', NULL, NULL, 'create', 'accounting', 'Account', 198, '2-01-02-01-0105', 'Account 2-01-02-01-0105 created', '{"company_id": 1, "code": "2-01-02-01-0105", "name": "John Doe (EMP002)", "type": "liability", "parent_id": 33, "level": 5, "is_active": true}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (251, 1, '2026-10-29 05:44:51.133659', NULL, NULL, 'update', 'admin', 'User', 5, 'john.doe@solarkon.com', 'User john.doe@solarkon.com edited (login id)', '[{"field": "login_id", "old": null, "new": "john.doe@solarkon.com"}]', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (279, NULL, '2026-10-29 05:44:52.715438', 1, 'Administrator', 'login', 'admin', NULL, NULL, NULL, 'Super admin Administrator entered the console', NULL, '127.0.0.1', '/superadmin/login');
INSERT INTO public.audit_logs VALUES (280, 1, '2026-10-29 05:44:52.869208', 1, 'Administrator', 'create', 'admin', 'User', 6, 'owner.a.db6e12@ref.test', 'User owner.a.db6e12@ref.test created', '{"employee_code": "SA0006", "email": "owner.a.db6e12@ref.test", "login_id": "owner.a.db6e12@ref.test", "password_hash": "\u2022\u2022\u2022", "full_name": "Owner.A.Db6E12", "role_id": 1, "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true, "has_inventory_access": true, "has_invoicing_access": true, "has_finance_access": true, "has_accounting_access": true, "has_fbr_access": true, "has_fixed_assets_access": true, "has_executive_access": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (281, 2, '2026-10-29 05:44:52.875443', 1, 'Administrator', 'create', 'admin', 'Membership', 5, '6', 'Membership 6 created', '{"company_id": 2, "user_id": 6, "role_id": 1, "status": "active", "employee_code": "SA0006", "joined_at": "2026-10-29T05:44:52.874173", "module_flags": "{\"accounting\": true, \"executive\": true, \"fbr\": true, \"finance\": true, \"fixed_assets\": true, \"hr\": true, \"inventory\": true, \"invoicing\": true}"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (452, 2, '2026-10-29 05:44:54.005306', 1, 'Administrator', 'create', 'settings', 'Report settings', 2, '2', 'Report settings 2 created', '{"company_id": 2, "pl_detail_rows": 10, "invoice_party_mode": "relevant", "purchase_party_mode": "relevant", "sales_party_mode": "relevant", "cash_flow_method": "indirect"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (453, 2, '2026-10-29 05:44:54.0121', 1, 'Administrator', 'create', 'inventory', 'Inventory settings', 2, '2', 'Inventory settings 2 created', '{"company_id": 2, "valuation_method": "weighted_average", "decimal_places": 4, "auto_generate_vouchers": true, "purchase_flow": "with_po", "sales_flow": "with_so"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (454, 1, '2026-10-29 05:44:54.172592', 1, 'Administrator', 'create', 'admin', 'User', 7, 'owner.b.6603bc@ref.test', 'User owner.b.6603bc@ref.test created', '{"employee_code": "SA0007", "email": "owner.b.6603bc@ref.test", "login_id": "owner.b.6603bc@ref.test", "password_hash": "\u2022\u2022\u2022", "full_name": "Owner.B.6603Bc", "role_id": 1, "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true, "has_inventory_access": true, "has_invoicing_access": true, "has_finance_access": true, "has_accounting_access": true, "has_fbr_access": true, "has_fixed_assets_access": true, "has_executive_access": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (455, 3, '2026-10-29 05:44:54.178469', 1, 'Administrator', 'create', 'admin', 'Membership', 6, '7', 'Membership 7 created', '{"company_id": 3, "user_id": 7, "role_id": 1, "status": "active", "employee_code": "SA0007", "joined_at": "2026-10-29T05:44:54.177431", "module_flags": "{\"accounting\": true, \"executive\": true, \"fbr\": true, \"finance\": true, \"fixed_assets\": true, \"hr\": true, \"inventory\": true, \"invoicing\": true}"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (256, 1, '2026-10-29 05:44:51.453866', NULL, NULL, 'post', 'accounting', 'Journal entry', 5, 'OPEN-00005', 'Journal entry OPEN-00005 posted — Opening stock — 10kW Hybrid Inverter', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (257, 1, '2026-10-29 05:44:51.508376', NULL, NULL, 'post', 'accounting', 'Journal entry', 6, 'OPEN-00006', 'Journal entry OPEN-00006 posted — Opening stock — 3kW String Inverter', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (258, 1, '2026-10-29 05:44:51.56347', NULL, NULL, 'post', 'accounting', 'Journal entry', 7, 'OPEN-00007', 'Journal entry OPEN-00007 posted — Opening stock — 5kWh LiFePO4 Battery', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (259, 1, '2026-10-29 05:44:51.618205', NULL, NULL, 'post', 'accounting', 'Journal entry', 8, 'OPEN-00008', 'Journal entry OPEN-00008 posted — Opening stock — 10kWh LiFePO4 Battery', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (260, 1, '2026-10-29 05:44:51.673524', NULL, NULL, 'post', 'accounting', 'Journal entry', 9, 'OPEN-00009', 'Journal entry OPEN-00009 posted — Opening stock — 200Ah Tubular Battery', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (261, 1, '2026-10-29 05:44:51.72752', NULL, NULL, 'post', 'accounting', 'Journal entry', 10, 'OPEN-00010', 'Journal entry OPEN-00010 posted — Opening stock — Solar DC Cable 4mm (per meter)', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (262, 1, '2026-10-29 05:44:51.783224', NULL, NULL, 'post', 'accounting', 'Journal entry', 11, 'OPEN-00011', 'Journal entry OPEN-00011 posted — Opening stock — AC Cable 2.5mm (per meter)', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (263, 1, '2026-10-29 05:44:51.83815', NULL, NULL, 'post', 'accounting', 'Journal entry', 12, 'OPEN-00012', 'Journal entry OPEN-00012 posted — Opening stock — MC4 Connector Pair', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (264, 1, '2026-10-29 05:44:51.892937', NULL, NULL, 'post', 'accounting', 'Journal entry', 13, 'OPEN-00013', 'Journal entry OPEN-00013 posted — Opening stock — Aluminum Mounting Rack (set)', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (265, 1, '2026-10-29 05:44:51.948212', NULL, NULL, 'post', 'accounting', 'Journal entry', 14, 'OPEN-00014', 'Journal entry OPEN-00014 posted — Opening stock — Mounting Rail 2m', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (266, 1, '2026-10-29 05:44:52.003396', NULL, NULL, 'post', 'accounting', 'Journal entry', 15, 'OPEN-00015', 'Journal entry OPEN-00015 posted — Opening stock — Distribution Board 16-way', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (267, 1, '2026-10-29 05:44:52.058994', NULL, NULL, 'post', 'accounting', 'Journal entry', 16, 'OPEN-00016', 'Journal entry OPEN-00016 posted — Opening stock — Surge Protection Device', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (268, 1, '2026-10-29 05:44:52.114086', NULL, NULL, 'post', 'accounting', 'Journal entry', 17, 'OPEN-00017', 'Journal entry OPEN-00017 posted — Opening stock — MCB 16A Single Pole', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (269, 1, '2026-10-29 05:44:52.168976', NULL, NULL, 'post', 'accounting', 'Journal entry', 18, 'OPEN-00018', 'Journal entry OPEN-00018 posted — Opening stock — Solar Crimping Tool', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (270, 1, '2026-10-29 05:44:52.22302', NULL, NULL, 'post', 'accounting', 'Journal entry', 19, 'OPEN-00019', 'Journal entry OPEN-00019 posted — Opening stock — Digital Multimeter', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (271, 1, '2026-10-29 05:44:52.27913', NULL, NULL, 'post', 'accounting', 'Journal entry', 20, 'OPEN-00020', 'Journal entry OPEN-00020 posted — Opening stock — Safety Helmet', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (272, 1, '2026-10-29 05:44:52.333202', NULL, NULL, 'post', 'accounting', 'Journal entry', 21, 'OPEN-00021', 'Journal entry OPEN-00021 posted — Opening stock — Insulated Gloves (pair)', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (273, 1, '2026-10-29 05:44:52.38852', NULL, NULL, 'post', 'accounting', 'Journal entry', 22, 'OPEN-00022', 'Journal entry OPEN-00022 posted — Opening stock — Safety Harness', NULL, '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (274, 1, '2026-10-29 05:44:52.532788', NULL, NULL, 'create', 'admin', 'Membership', 1, '1', 'Membership 1 created', '{"company_id": 1, "user_id": 1, "role_id": 1, "status": "active", "employee_code": "SYSADMIN", "joined_at": "2026-10-29T05:44:52.528494", "module_flags": "{\"accounting\": false, \"executive\": false, \"fbr\": false, \"finance\": false, \"fixed_assets\": false, \"hr\": true, \"inventory\": true, \"invoicing\": false}", "designation": "System Administrator"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (275, 1, '2026-10-29 05:44:52.537814', NULL, NULL, 'create', 'admin', 'Membership', 2, '3', 'Membership 3 created', '{"company_id": 1, "user_id": 3, "role_id": 2, "status": "active", "employee_code": "MGR002", "joined_at": "2026-10-29T05:44:52.534382", "module_flags": "{\"accounting\": false, \"executive\": false, \"fbr\": false, \"finance\": false, \"fixed_assets\": false, \"hr\": true, \"inventory\": true, \"invoicing\": false}", "designation": "Manager"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (276, 1, '2026-10-29 05:44:52.544604', NULL, NULL, 'create', 'admin', 'Membership', 3, '4', 'Membership 4 created', '{"company_id": 1, "user_id": 4, "role_id": 3, "status": "active", "employee_code": "EMP001", "joined_at": "2026-10-29T05:44:52.539421", "module_flags": "{\"accounting\": false, \"executive\": false, \"fbr\": false, \"finance\": false, \"fixed_assets\": false, \"hr\": true, \"inventory\": false, \"invoicing\": false}", "designation": "Employee"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (277, 1, '2026-10-29 05:44:52.550357', NULL, NULL, 'create', 'admin', 'Membership', 4, '5', 'Membership 5 created', '{"company_id": 1, "user_id": 5, "role_id": 3, "status": "active", "employee_code": "EMP002", "joined_at": "2026-10-29T05:44:52.546210", "module_flags": "{\"accounting\": false, \"executive\": false, \"fbr\": false, \"finance\": false, \"fixed_assets\": false, \"hr\": true, \"inventory\": false, \"invoicing\": false}", "designation": "Employee"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (278, 1, '2026-10-29 05:44:52.555172', NULL, NULL, 'update', 'admin', 'User', 1, 'admin@gmail.com', 'User admin@gmail.com edited (is super admin)', '[{"field": "is_super_admin", "old": false, "new": true}]', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES (282, 2, '2026-10-29 05:44:52.89234', 1, 'Administrator', 'create', 'accounting', 'Account', 199, '1', 'Account 1 created', '{"company_id": 2, "code": "1", "name": "Assets", "type": "asset", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (283, 2, '2026-10-29 05:44:52.898816', 1, 'Administrator', 'create', 'accounting', 'Account', 200, '1-01', 'Account 1-01 created', '{"company_id": 2, "code": "1-01", "name": "Current Assets", "type": "asset", "parent_id": 199, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (284, 2, '2026-10-29 05:44:52.905474', 1, 'Administrator', 'create', 'accounting', 'Account', 201, '1-01-01', 'Account 1-01-01 created', '{"company_id": 2, "code": "1-01-01", "name": "Cash & Cash Equivalents", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true, "cash_flow_activity": "cash"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (285, 2, '2026-10-29 05:44:52.911851', 1, 'Administrator', 'create', 'accounting', 'Account', 202, '1-01-01-01', 'Account 1-01-01-01 created', '{"company_id": 2, "code": "1-01-01-01", "name": "Cash in Hand", "type": "asset", "parent_id": 201, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (286, 2, '2026-10-29 05:44:52.91829', 1, 'Administrator', 'create', 'accounting', 'Account', 203, '1-01-01-02', 'Account 1-01-01-02 created', '{"company_id": 2, "code": "1-01-01-02", "name": "Bank Accounts", "type": "asset", "parent_id": 201, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (287, 2, '2026-10-29 05:44:52.924642', 1, 'Administrator', 'create', 'accounting', 'Account', 204, '1-01-02', 'Account 1-01-02 created', '{"company_id": 2, "code": "1-01-02", "name": "Trade Receivables", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (288, 2, '2026-10-29 05:44:52.932656', 1, 'Administrator', 'create', 'accounting', 'Account', 205, '1-01-02-01', 'Account 1-01-02-01 created', '{"company_id": 2, "code": "1-01-02-01", "name": "Trade Debtors", "type": "asset", "parent_id": 204, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (289, 2, '2026-10-29 05:44:52.93897', 1, 'Administrator', 'create', 'accounting', 'Account', 206, '1-01-02-02', 'Account 1-01-02-02 created', '{"company_id": 2, "code": "1-01-02-02", "name": "Doubtful Receivables", "type": "asset", "parent_id": 204, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (290, 2, '2026-10-29 05:44:52.945321', 1, 'Administrator', 'create', 'accounting', 'Account', 207, '1-01-03', 'Account 1-01-03 created', '{"company_id": 2, "code": "1-01-03", "name": "Other Receivables", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (291, 2, '2026-10-29 05:44:52.952147', 1, 'Administrator', 'create', 'accounting', 'Account', 208, '1-01-03-01', 'Account 1-01-03-01 created', '{"company_id": 2, "code": "1-01-03-01", "name": "Employee Loans & Advances", "type": "asset", "parent_id": 207, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (292, 2, '2026-10-29 05:44:52.958338', 1, 'Administrator', 'create', 'accounting', 'Account', 209, '1-01-03-02', 'Account 1-01-03-02 created', '{"company_id": 2, "code": "1-01-03-02", "name": "Advances to Suppliers", "type": "asset", "parent_id": 207, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (293, 2, '2026-10-29 05:44:52.964622', 1, 'Administrator', 'create', 'accounting', 'Account', 210, '1-01-04', 'Account 1-01-04 created', '{"company_id": 2, "code": "1-01-04", "name": "Inventories", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (294, 2, '2026-10-29 05:44:52.970848', 1, 'Administrator', 'create', 'accounting', 'Account', 211, '1-01-04-01', 'Account 1-01-04-01 created', '{"company_id": 2, "code": "1-01-04-01", "name": "Trading Goods Stock", "type": "asset", "parent_id": 210, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (295, 2, '2026-10-29 05:44:52.977215', 1, 'Administrator', 'create', 'accounting', 'Account', 212, '1-01-05', 'Account 1-01-05 created', '{"company_id": 2, "code": "1-01-05", "name": "Tax Assets", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (296, 2, '2026-10-29 05:44:52.983403', 1, 'Administrator', 'create', 'accounting', 'Account', 213, '1-01-05-01', 'Account 1-01-05-01 created', '{"company_id": 2, "code": "1-01-05-01", "name": "Input Sales Tax", "type": "asset", "parent_id": 212, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (297, 2, '2026-10-29 05:44:52.989606', 1, 'Administrator', 'create', 'accounting', 'Account', 214, '1-01-05-02', 'Account 1-01-05-02 created', '{"company_id": 2, "code": "1-01-05-02", "name": "WHT Receivable", "type": "asset", "parent_id": 212, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (298, 2, '2026-10-29 05:44:52.995999', 1, 'Administrator', 'create', 'accounting', 'Account', 215, '1-01-06', 'Account 1-01-06 created', '{"company_id": 2, "code": "1-01-06", "name": "Prepayments & Other", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (299, 2, '2026-10-29 05:44:53.002173', 1, 'Administrator', 'create', 'accounting', 'Account', 216, '1-01-06-01', 'Account 1-01-06-01 created', '{"company_id": 2, "code": "1-01-06-01", "name": "Suspense & Clearing", "type": "asset", "parent_id": 215, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (300, 2, '2026-10-29 05:44:53.008483', 1, 'Administrator', 'create', 'accounting', 'Account', 217, '1-01-06-02', 'Account 1-01-06-02 created', '{"company_id": 2, "code": "1-01-06-02", "name": "Prepaid Expenses", "type": "asset", "parent_id": 215, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (301, 2, '2026-10-29 05:44:53.014678', 1, 'Administrator', 'create', 'accounting', 'Account', 218, '1-01-06-03', 'Account 1-01-06-03 created', '{"company_id": 2, "code": "1-01-06-03", "name": "Other Current Assets", "type": "asset", "parent_id": 215, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (302, 2, '2026-10-29 05:44:53.021224', 1, 'Administrator', 'create', 'accounting', 'Account', 219, '1-02', 'Account 1-02 created', '{"company_id": 2, "code": "1-02", "name": "Non-Current Assets", "type": "asset", "parent_id": 199, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "investing"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (303, 2, '2026-10-29 05:44:53.027565', 1, 'Administrator', 'create', 'accounting', 'Account', 220, '1-02-01', 'Account 1-02-01 created', '{"company_id": 2, "code": "1-02-01", "name": "Property, Plant & Equipment", "type": "asset", "parent_id": 219, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (304, 2, '2026-10-29 05:44:53.03393', 1, 'Administrator', 'create', 'accounting', 'Account', 221, '1-02-01-01', 'Account 1-02-01-01 created', '{"company_id": 2, "code": "1-02-01-01", "name": "Owned Assets", "type": "asset", "parent_id": 220, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (305, 2, '2026-10-29 05:44:53.040471', 1, 'Administrator', 'create', 'accounting', 'Account', 222, '1-02-02', 'Account 1-02-02 created', '{"company_id": 2, "code": "1-02-02", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 219, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (306, 2, '2026-10-29 05:44:53.046811', 1, 'Administrator', 'create', 'accounting', 'Account', 223, '1-02-02-01', 'Account 1-02-02-01 created', '{"company_id": 2, "code": "1-02-02-01", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 222, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (307, 2, '2026-10-29 05:44:53.05317', 1, 'Administrator', 'create', 'accounting', 'Account', 224, '1-02-03', 'Account 1-02-03 created', '{"company_id": 2, "code": "1-02-03", "name": "Intangible Assets", "type": "asset", "parent_id": 219, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (308, 2, '2026-10-29 05:44:53.059516', 1, 'Administrator', 'create', 'accounting', 'Account', 225, '1-02-03-01', 'Account 1-02-03-01 created', '{"company_id": 2, "code": "1-02-03-01", "name": "Intangibles", "type": "asset", "parent_id": 224, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (309, 2, '2026-10-29 05:44:53.063639', 1, 'Administrator', 'create', 'accounting', 'Account', 226, '2', 'Account 2 created', '{"company_id": 2, "code": "2", "name": "Liabilities", "type": "liability", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (310, 2, '2026-10-29 05:44:53.069847', 1, 'Administrator', 'create', 'accounting', 'Account', 227, '2-01', 'Account 2-01 created', '{"company_id": 2, "code": "2-01", "name": "Current Liabilities", "type": "liability", "parent_id": 226, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (311, 2, '2026-10-29 05:44:53.076102', 1, 'Administrator', 'create', 'accounting', 'Account', 228, '2-01-01', 'Account 2-01-01 created', '{"company_id": 2, "code": "2-01-01", "name": "Trade Payables", "type": "liability", "parent_id": 227, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (312, 2, '2026-10-29 05:44:53.082629', 1, 'Administrator', 'create', 'accounting', 'Account', 229, '2-01-01-01', 'Account 2-01-01-01 created', '{"company_id": 2, "code": "2-01-01-01", "name": "Trade Creditors", "type": "liability", "parent_id": 228, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (313, 2, '2026-10-29 05:44:53.089271', 1, 'Administrator', 'create', 'accounting', 'Account', 230, '2-01-02', 'Account 2-01-02 created', '{"company_id": 2, "code": "2-01-02", "name": "Accrued & Payroll Liabilities", "type": "liability", "parent_id": 227, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (314, 2, '2026-10-29 05:44:53.095552', 1, 'Administrator', 'create', 'accounting', 'Account', 231, '2-01-02-01', 'Account 2-01-02-01 created', '{"company_id": 2, "code": "2-01-02-01", "name": "Employee Payables", "type": "liability", "parent_id": 230, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (315, 2, '2026-10-29 05:44:53.10178', 1, 'Administrator', 'create', 'accounting', 'Account', 232, '2-01-02-02', 'Account 2-01-02-02 created', '{"company_id": 2, "code": "2-01-02-02", "name": "Payroll Liabilities", "type": "liability", "parent_id": 230, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (316, 2, '2026-10-29 05:44:53.108407', 1, 'Administrator', 'create', 'accounting', 'Account', 233, '2-01-02-03', 'Account 2-01-02-03 created', '{"company_id": 2, "code": "2-01-02-03", "name": "Accrued Expenses", "type": "liability", "parent_id": 230, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (317, 2, '2026-10-29 05:44:53.11471', 1, 'Administrator', 'create', 'accounting', 'Account', 234, '2-01-03', 'Account 2-01-03 created', '{"company_id": 2, "code": "2-01-03", "name": "Tax Liabilities", "type": "liability", "parent_id": 227, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (318, 2, '2026-10-29 05:44:53.121017', 1, 'Administrator', 'create', 'accounting', 'Account', 235, '2-01-03-01', 'Account 2-01-03-01 created', '{"company_id": 2, "code": "2-01-03-01", "name": "Output Sales Tax", "type": "liability", "parent_id": 234, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (319, 2, '2026-10-29 05:44:53.12734', 1, 'Administrator', 'create', 'accounting', 'Account', 236, '2-01-03-02', 'Account 2-01-03-02 created', '{"company_id": 2, "code": "2-01-03-02", "name": "Income Tax Payable", "type": "liability", "parent_id": 234, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (320, 2, '2026-10-29 05:44:53.133837', 1, 'Administrator', 'create', 'accounting', 'Account', 237, '2-01-03-03', 'Account 2-01-03-03 created', '{"company_id": 2, "code": "2-01-03-03", "name": "WHT Payable", "type": "liability", "parent_id": 234, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (321, 2, '2026-10-29 05:44:53.140161', 1, 'Administrator', 'create', 'accounting', 'Account', 238, '2-01-03-04', 'Account 2-01-03-04 created', '{"company_id": 2, "code": "2-01-03-04", "name": "Further Tax Payable", "type": "liability", "parent_id": 234, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (322, 2, '2026-10-29 05:44:53.14647', 1, 'Administrator', 'create', 'accounting', 'Account', 239, '2-01-04', 'Account 2-01-04 created', '{"company_id": 2, "code": "2-01-04", "name": "Advances from Customers", "type": "liability", "parent_id": 227, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (323, 2, '2026-10-29 05:44:53.15311', 1, 'Administrator', 'create', 'accounting', 'Account', 240, '2-01-04-01', 'Account 2-01-04-01 created', '{"company_id": 2, "code": "2-01-04-01", "name": "Customer Advances", "type": "liability", "parent_id": 239, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (324, 2, '2026-10-29 05:44:53.159521', 1, 'Administrator', 'create', 'accounting', 'Account', 241, '2-02', 'Account 2-02 created', '{"company_id": 2, "code": "2-02", "name": "Non-Current Liabilities", "type": "liability", "parent_id": 226, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (325, 2, '2026-10-29 05:44:53.165913', 1, 'Administrator', 'create', 'accounting', 'Account', 242, '2-02-01', 'Account 2-02-01 created', '{"company_id": 2, "code": "2-02-01", "name": "Long-term Loans", "type": "liability", "parent_id": 241, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (326, 2, '2026-10-29 05:44:53.17233', 1, 'Administrator', 'create', 'accounting', 'Account', 243, '2-02-01-01', 'Account 2-02-01-01 created', '{"company_id": 2, "code": "2-02-01-01", "name": "Long-term Loans", "type": "liability", "parent_id": 242, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (327, 2, '2026-10-29 05:44:53.17889', 1, 'Administrator', 'create', 'accounting', 'Account', 244, '2-02-02', 'Account 2-02-02 created', '{"company_id": 2, "code": "2-02-02", "name": "Employee End-of-Service Benefits", "type": "liability", "parent_id": 241, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (328, 2, '2026-10-29 05:44:53.18531', 1, 'Administrator', 'create', 'accounting', 'Account', 245, '2-02-02-01', 'Account 2-02-02-01 created', '{"company_id": 2, "code": "2-02-02-01", "name": "EOSB Provision", "type": "liability", "parent_id": 244, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (329, 2, '2026-10-29 05:44:53.18961', 1, 'Administrator', 'create', 'accounting', 'Account', 246, '3', 'Account 3 created', '{"company_id": 2, "code": "3", "name": "Equity", "type": "equity", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (330, 2, '2026-10-29 05:44:53.195916', 1, 'Administrator', 'create', 'accounting', 'Account', 247, '3-01', 'Account 3-01 created', '{"company_id": 2, "code": "3-01", "name": "Capital", "type": "equity", "parent_id": 246, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (331, 2, '2026-10-29 05:44:53.202769', 1, 'Administrator', 'create', 'accounting', 'Account', 248, '3-01-01', 'Account 3-01-01 created', '{"company_id": 2, "code": "3-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 247, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (332, 2, '2026-10-29 05:44:53.209179', 1, 'Administrator', 'create', 'accounting', 'Account', 249, '3-01-01-01', 'Account 3-01-01-01 created', '{"company_id": 2, "code": "3-01-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 248, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (333, 2, '2026-10-29 05:44:53.215498', 1, 'Administrator', 'create', 'accounting', 'Account', 250, '3-02', 'Account 3-02 created', '{"company_id": 2, "code": "3-02", "name": "Reserves & Retained Earnings", "type": "equity", "parent_id": 246, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (334, 2, '2026-10-29 05:44:53.222111', 1, 'Administrator', 'create', 'accounting', 'Account', 251, '3-02-01', 'Account 3-02-01 created', '{"company_id": 2, "code": "3-02-01", "name": "Retained Earnings", "type": "equity", "parent_id": 250, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (335, 2, '2026-10-29 05:44:53.22846', 1, 'Administrator', 'create', 'accounting', 'Account', 252, '3-02-01-01', 'Account 3-02-01-01 created', '{"company_id": 2, "code": "3-02-01-01", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 251, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (336, 2, '2026-10-29 05:44:53.234832', 1, 'Administrator', 'create', 'accounting', 'Account', 253, '3-02-01-02', 'Account 3-02-01-02 created', '{"company_id": 2, "code": "3-02-01-02", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 251, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (337, 2, '2026-10-29 05:44:53.241194', 1, 'Administrator', 'create', 'accounting', 'Account', 254, '3-02-02', 'Account 3-02-02 created', '{"company_id": 2, "code": "3-02-02", "name": "Dividends", "type": "equity", "parent_id": 250, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (338, 2, '2026-10-29 05:44:53.247711', 1, 'Administrator', 'create', 'accounting', 'Account', 255, '3-02-02-01', 'Account 3-02-02-01 created', '{"company_id": 2, "code": "3-02-02-01", "name": "Dividends", "type": "equity", "parent_id": 254, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (339, 2, '2026-10-29 05:44:53.254289', 1, 'Administrator', 'create', 'accounting', 'Account', 256, '3-02-03', 'Account 3-02-03 created', '{"company_id": 2, "code": "3-02-03", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 250, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (340, 2, '2026-10-29 05:44:53.260566', 1, 'Administrator', 'create', 'accounting', 'Account', 257, '3-02-03-01', 'Account 3-02-03-01 created', '{"company_id": 2, "code": "3-02-03-01", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 256, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (341, 2, '2026-10-29 05:44:53.264595', 1, 'Administrator', 'create', 'accounting', 'Account', 258, '4', 'Account 4 created', '{"company_id": 2, "code": "4", "name": "Revenue", "type": "revenue", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (342, 2, '2026-10-29 05:44:53.270995', 1, 'Administrator', 'create', 'accounting', 'Account', 259, '4-01', 'Account 4-01 created', '{"company_id": 2, "code": "4-01", "name": "Sales", "type": "revenue", "parent_id": 258, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (343, 2, '2026-10-29 05:44:53.277317', 1, 'Administrator', 'create', 'accounting', 'Account', 260, '4-01-01', 'Account 4-01-01 created', '{"company_id": 2, "code": "4-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 259, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (344, 2, '2026-10-29 05:44:53.283638', 1, 'Administrator', 'create', 'accounting', 'Account', 261, '4-01-01-01', 'Account 4-01-01-01 created', '{"company_id": 2, "code": "4-01-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 260, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (345, 2, '2026-10-29 05:44:53.290085', 1, 'Administrator', 'create', 'accounting', 'Account', 262, '4-01-02', 'Account 4-01-02 created', '{"company_id": 2, "code": "4-01-02", "name": "Service Income", "type": "revenue", "parent_id": 259, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (346, 2, '2026-10-29 05:44:53.296338', 1, 'Administrator', 'create', 'accounting', 'Account', 263, '4-01-02-01', 'Account 4-01-02-01 created', '{"company_id": 2, "code": "4-01-02-01", "name": "Service Income", "type": "revenue", "parent_id": 262, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (347, 2, '2026-10-29 05:44:53.302634', 1, 'Administrator', 'create', 'accounting', 'Account', 264, '4-02', 'Account 4-02 created', '{"company_id": 2, "code": "4-02", "name": "Sales Returns & Discounts", "type": "revenue", "parent_id": 258, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales_returns"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (348, 2, '2026-10-29 05:44:53.309171', 1, 'Administrator', 'create', 'accounting', 'Account', 265, '4-02-01', 'Account 4-02-01 created', '{"company_id": 2, "code": "4-02-01", "name": "Sales Returns", "type": "revenue", "parent_id": 264, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (349, 2, '2026-10-29 05:44:53.315761', 1, 'Administrator', 'create', 'accounting', 'Account', 266, '4-02-01-01', 'Account 4-02-01-01 created', '{"company_id": 2, "code": "4-02-01-01", "name": "Sales Returns", "type": "revenue", "parent_id": 265, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (350, 2, '2026-10-29 05:44:53.322031', 1, 'Administrator', 'create', 'accounting', 'Account', 267, '4-02-02', 'Account 4-02-02 created', '{"company_id": 2, "code": "4-02-02", "name": "Discounts Allowed", "type": "revenue", "parent_id": 264, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (351, 2, '2026-10-29 05:44:53.3286', 1, 'Administrator', 'create', 'accounting', 'Account', 268, '4-02-02-01', 'Account 4-02-02-01 created', '{"company_id": 2, "code": "4-02-02-01", "name": "Discounts Allowed", "type": "revenue", "parent_id": 267, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (352, 2, '2026-10-29 05:44:53.335067', 1, 'Administrator', 'create', 'accounting', 'Account', 269, '4-03', 'Account 4-03 created', '{"company_id": 2, "code": "4-03", "name": "Other Income", "type": "revenue", "parent_id": 258, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_income"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (353, 2, '2026-10-29 05:44:53.341344', 1, 'Administrator', 'create', 'accounting', 'Account', 270, '4-03-01', 'Account 4-03-01 created', '{"company_id": 2, "code": "4-03-01", "name": "Other Income", "type": "revenue", "parent_id": 269, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (354, 2, '2026-10-29 05:44:53.347657', 1, 'Administrator', 'create', 'accounting', 'Account', 271, '4-03-01-01', 'Account 4-03-01-01 created', '{"company_id": 2, "code": "4-03-01-01", "name": "Other Income", "type": "revenue", "parent_id": 270, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (355, 2, '2026-10-29 05:44:53.351629', 1, 'Administrator', 'create', 'accounting', 'Account', 272, '5', 'Account 5 created', '{"company_id": 2, "code": "5", "name": "Expenses", "type": "expense", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (356, 2, '2026-10-29 05:44:53.35808', 1, 'Administrator', 'create', 'accounting', 'Account', 273, '5-01', 'Account 5-01 created', '{"company_id": 2, "code": "5-01", "name": "Cost of Sales", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "cost_of_sales"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (357, 2, '2026-10-29 05:44:53.364321', 1, 'Administrator', 'create', 'accounting', 'Account', 274, '5-01-01', 'Account 5-01-01 created', '{"company_id": 2, "code": "5-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 273, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (358, 2, '2026-10-29 05:44:53.370578', 1, 'Administrator', 'create', 'accounting', 'Account', 275, '5-01-01-01', 'Account 5-01-01-01 created', '{"company_id": 2, "code": "5-01-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 274, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (359, 2, '2026-10-29 05:44:53.376926', 1, 'Administrator', 'create', 'accounting', 'Account', 276, '5-01-02', 'Account 5-01-02 created', '{"company_id": 2, "code": "5-01-02", "name": "Stock Losses, Scrap & Adjustments", "type": "expense", "parent_id": 273, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (360, 2, '2026-10-29 05:44:53.383512', 1, 'Administrator', 'create', 'accounting', 'Account', 277, '5-01-02-01', 'Account 5-01-02-01 created', '{"company_id": 2, "code": "5-01-02-01", "name": "Stock Losses & Scrap", "type": "expense", "parent_id": 276, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (361, 2, '2026-10-29 05:44:53.38992', 1, 'Administrator', 'create', 'accounting', 'Account', 278, '5-02', 'Account 5-02 created', '{"company_id": 2, "code": "5-02", "name": "Administrative Expenses", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "admin"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (362, 2, '2026-10-29 05:44:53.396316', 1, 'Administrator', 'create', 'accounting', 'Account', 279, '5-02-01', 'Account 5-02-01 created', '{"company_id": 2, "code": "5-02-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 278, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (363, 2, '2026-10-29 05:44:53.402861', 1, 'Administrator', 'create', 'accounting', 'Account', 280, '5-02-01-01', 'Account 5-02-01-01 created', '{"company_id": 2, "code": "5-02-01-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 279, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (364, 2, '2026-10-29 05:44:53.409181', 1, 'Administrator', 'create', 'accounting', 'Account', 281, '5-02-02', 'Account 5-02-02 created', '{"company_id": 2, "code": "5-02-02", "name": "Rent & Utilities", "type": "expense", "parent_id": 278, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (365, 2, '2026-10-29 05:44:53.415522', 1, 'Administrator', 'create', 'accounting', 'Account', 282, '5-02-02-01', 'Account 5-02-02-01 created', '{"company_id": 2, "code": "5-02-02-01", "name": "Rent & Utilities", "type": "expense", "parent_id": 281, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (366, 2, '2026-10-29 05:44:53.421935', 1, 'Administrator', 'create', 'accounting', 'Account', 283, '5-02-03', 'Account 5-02-03 created', '{"company_id": 2, "code": "5-02-03", "name": "Office & Supplies", "type": "expense", "parent_id": 278, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (367, 2, '2026-10-29 05:44:53.428558', 1, 'Administrator', 'create', 'accounting', 'Account', 284, '5-02-03-01', 'Account 5-02-03-01 created', '{"company_id": 2, "code": "5-02-03-01", "name": "Office & Supplies", "type": "expense", "parent_id": 283, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (368, 2, '2026-10-29 05:44:53.435018', 1, 'Administrator', 'create', 'accounting', 'Account', 285, '5-02-04', 'Account 5-02-04 created', '{"company_id": 2, "code": "5-02-04", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 278, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (369, 2, '2026-10-29 05:44:53.441316', 1, 'Administrator', 'create', 'accounting', 'Account', 286, '5-02-04-01', 'Account 5-02-04-01 created', '{"company_id": 2, "code": "5-02-04-01", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 285, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (370, 2, '2026-10-29 05:44:53.447856', 1, 'Administrator', 'create', 'accounting', 'Account', 287, '5-02-05', 'Account 5-02-05 created', '{"company_id": 2, "code": "5-02-05", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 278, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (371, 2, '2026-10-29 05:44:53.454192', 1, 'Administrator', 'create', 'accounting', 'Account', 288, '5-02-05-01', 'Account 5-02-05-01 created', '{"company_id": 2, "code": "5-02-05-01", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 287, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (372, 2, '2026-10-29 05:44:53.460569', 1, 'Administrator', 'create', 'accounting', 'Account', 289, '5-03', 'Account 5-03 created', '{"company_id": 2, "code": "5-03", "name": "Selling & Distribution", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "selling_distribution"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (373, 2, '2026-10-29 05:44:53.466936', 1, 'Administrator', 'create', 'accounting', 'Account', 290, '5-03-01', 'Account 5-03-01 created', '{"company_id": 2, "code": "5-03-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 289, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (374, 2, '2026-10-29 05:44:53.473734', 1, 'Administrator', 'create', 'accounting', 'Account', 291, '5-03-01-01', 'Account 5-03-01-01 created', '{"company_id": 2, "code": "5-03-01-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 290, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (375, 2, '2026-10-29 05:44:53.480026', 1, 'Administrator', 'create', 'accounting', 'Account', 292, '5-03-02', 'Account 5-03-02 created', '{"company_id": 2, "code": "5-03-02", "name": "Commissions", "type": "expense", "parent_id": 289, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (376, 2, '2026-10-29 05:44:53.486487', 1, 'Administrator', 'create', 'accounting', 'Account', 293, '5-03-02-01', 'Account 5-03-02-01 created', '{"company_id": 2, "code": "5-03-02-01", "name": "Commissions", "type": "expense", "parent_id": 292, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (377, 2, '2026-10-29 05:44:53.493379', 1, 'Administrator', 'create', 'accounting', 'Account', 294, '5-03-03', 'Account 5-03-03 created', '{"company_id": 2, "code": "5-03-03", "name": "Marketing & Advertising", "type": "expense", "parent_id": 289, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (378, 2, '2026-10-29 05:44:53.499726', 1, 'Administrator', 'create', 'accounting', 'Account', 295, '5-03-03-01', 'Account 5-03-03-01 created', '{"company_id": 2, "code": "5-03-03-01", "name": "Marketing & Advertising", "type": "expense", "parent_id": 294, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (379, 2, '2026-10-29 05:44:53.506111', 1, 'Administrator', 'create', 'accounting', 'Account', 296, '5-04', 'Account 5-04 created', '{"company_id": 2, "code": "5-04", "name": "Other Operating Expenses", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_operating"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (380, 2, '2026-10-29 05:44:53.512457', 1, 'Administrator', 'create', 'accounting', 'Account', 297, '5-04-01', 'Account 5-04-01 created', '{"company_id": 2, "code": "5-04-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 296, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (381, 2, '2026-10-29 05:44:53.518896', 1, 'Administrator', 'create', 'accounting', 'Account', 298, '5-04-01-01', 'Account 5-04-01-01 created', '{"company_id": 2, "code": "5-04-01-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 297, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (382, 2, '2026-10-29 05:44:53.525129', 1, 'Administrator', 'create', 'accounting', 'Account', 299, '5-05', 'Account 5-05 created', '{"company_id": 2, "code": "5-05", "name": "Finance Costs", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "finance_cost"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (383, 2, '2026-10-29 05:44:53.531401', 1, 'Administrator', 'create', 'accounting', 'Account', 300, '5-05-01', 'Account 5-05-01 created', '{"company_id": 2, "code": "5-05-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 299, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (384, 2, '2026-10-29 05:44:53.537843', 1, 'Administrator', 'create', 'accounting', 'Account', 301, '5-05-01-01', 'Account 5-05-01-01 created', '{"company_id": 2, "code": "5-05-01-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 300, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (385, 2, '2026-10-29 05:44:53.544387', 1, 'Administrator', 'create', 'accounting', 'Account', 302, '5-06', 'Account 5-06 created', '{"company_id": 2, "code": "5-06", "name": "Taxation", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "income_tax"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (386, 2, '2026-10-29 05:44:53.550904', 1, 'Administrator', 'create', 'accounting', 'Account', 303, '5-06-01', 'Account 5-06-01 created', '{"company_id": 2, "code": "5-06-01", "name": "Income Tax", "type": "expense", "parent_id": 302, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (387, 2, '2026-10-29 05:44:53.55738', 1, 'Administrator', 'create', 'accounting', 'Account', 304, '5-06-01-01', 'Account 5-06-01-01 created', '{"company_id": 2, "code": "5-06-01-01", "name": "Income Tax", "type": "expense", "parent_id": 303, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (388, 2, '2026-10-29 05:44:53.567675', 1, 'Administrator', 'create', 'accounting', 'Account', 305, '1-01-01-01-0001', 'Account 1-01-01-01-0001 created', '{"company_id": 2, "code": "1-01-01-01-0001", "name": "Main Cash", "type": "asset", "parent_id": 202, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (389, 2, '2026-10-29 05:44:53.574108', 1, 'Administrator', 'create', 'accounting', 'Account', 306, '1-01-02-01-0001', 'Account 1-01-02-01-0001 created', '{"company_id": 2, "code": "1-01-02-01-0001", "name": "Trade Debtors \u2014 General", "type": "asset", "parent_id": 205, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (390, 2, '2026-10-29 05:44:53.58064', 1, 'Administrator', 'create', 'accounting', 'Account', 307, '1-01-03-02-0001', 'Account 1-01-03-02-0001 created', '{"company_id": 2, "code": "1-01-03-02-0001", "name": "Advances to Suppliers \u2014 General", "type": "asset", "parent_id": 209, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (391, 2, '2026-10-29 05:44:53.587115', 1, 'Administrator', 'create', 'accounting', 'Account', 308, '1-01-04-01-0001', 'Account 1-01-04-01-0001 created', '{"company_id": 2, "code": "1-01-04-01-0001", "name": "Stock \u2014 General", "type": "asset", "parent_id": 211, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (392, 2, '2026-10-29 05:44:53.593641', 1, 'Administrator', 'create', 'accounting', 'Account', 309, '1-01-05-01-0001', 'Account 1-01-05-01-0001 created', '{"company_id": 2, "code": "1-01-05-01-0001", "name": "Input Sales Tax", "type": "asset", "parent_id": 213, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (393, 2, '2026-10-29 05:44:53.600156', 1, 'Administrator', 'create', 'accounting', 'Account', 310, '1-01-05-02-0001', 'Account 1-01-05-02-0001 created', '{"company_id": 2, "code": "1-01-05-02-0001", "name": "WHT Receivable", "type": "asset", "parent_id": 214, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (394, 2, '2026-10-29 05:44:53.606696', 1, 'Administrator', 'create', 'accounting', 'Account', 311, '1-01-06-01-0001', 'Account 1-01-06-01-0001 created', '{"company_id": 2, "code": "1-01-06-01-0001", "name": "Suspense Account", "type": "asset", "parent_id": 216, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (395, 2, '2026-10-29 05:44:53.612993', 1, 'Administrator', 'create', 'accounting', 'Account', 312, '1-01-06-02-0001', 'Account 1-01-06-02-0001 created', '{"company_id": 2, "code": "1-01-06-02-0001", "name": "Prepaid Expenses \u2014 General", "type": "asset", "parent_id": 217, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (396, 2, '2026-10-29 05:44:53.619249', 1, 'Administrator', 'create', 'accounting', 'Account', 313, '1-02-01-01-0001', 'Account 1-02-01-01-0001 created', '{"company_id": 2, "code": "1-02-01-01-0001", "name": "Fixed Assets \u2014 General", "type": "asset", "parent_id": 221, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (397, 2, '2026-10-29 05:44:53.625681', 1, 'Administrator', 'create', 'accounting', 'Account', 314, '1-02-02-01-0001', 'Account 1-02-02-01-0001 created', '{"company_id": 2, "code": "1-02-02-01-0001", "name": "Accumulated Depreciation \u2014 General", "type": "asset", "parent_id": 223, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (398, 2, '2026-10-29 05:44:53.631922', 1, 'Administrator', 'create', 'accounting', 'Account', 315, '1-02-03-01-0001', 'Account 1-02-03-01-0001 created', '{"company_id": 2, "code": "1-02-03-01-0001", "name": "Intangibles \u2014 General", "type": "asset", "parent_id": 225, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (399, 2, '2026-10-29 05:44:53.638157', 1, 'Administrator', 'create', 'accounting', 'Account', 316, '2-01-01-01-0001', 'Account 2-01-01-01-0001 created', '{"company_id": 2, "code": "2-01-01-01-0001", "name": "Trade Creditors \u2014 General", "type": "liability", "parent_id": 229, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (400, 2, '2026-10-29 05:44:53.64471', 1, 'Administrator', 'create', 'accounting', 'Account', 317, '2-01-02-02-0001', 'Account 2-01-02-02-0001 created', '{"company_id": 2, "code": "2-01-02-02-0001", "name": "Salary Payable", "type": "liability", "parent_id": 232, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (401, 2, '2026-10-29 05:44:53.651536', 1, 'Administrator', 'create', 'accounting', 'Account', 318, '2-01-02-02-0002', 'Account 2-01-02-02-0002 created', '{"company_id": 2, "code": "2-01-02-02-0002", "name": "PF Payable", "type": "liability", "parent_id": 232, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (402, 2, '2026-10-29 05:44:53.658014', 1, 'Administrator', 'create', 'accounting', 'Account', 319, '2-01-02-02-0003', 'Account 2-01-02-02-0003 created', '{"company_id": 2, "code": "2-01-02-02-0003", "name": "Loan Deductions Clearing", "type": "liability", "parent_id": 232, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (403, 2, '2026-10-29 05:44:53.664446', 1, 'Administrator', 'create', 'accounting', 'Account', 320, '2-01-02-02-0004', 'Account 2-01-02-02-0004 created', '{"company_id": 2, "code": "2-01-02-02-0004", "name": "Other Payroll Deductions Payable", "type": "liability", "parent_id": 232, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (404, 2, '2026-10-29 05:44:53.671032', 1, 'Administrator', 'create', 'accounting', 'Account', 321, '2-01-02-03-0001', 'Account 2-01-02-03-0001 created', '{"company_id": 2, "code": "2-01-02-03-0001", "name": "Accrued Expenses \u2014 General", "type": "liability", "parent_id": 233, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (405, 2, '2026-10-29 05:44:53.677559', 1, 'Administrator', 'create', 'accounting', 'Account', 322, '2-01-03-01-0001', 'Account 2-01-03-01-0001 created', '{"company_id": 2, "code": "2-01-03-01-0001", "name": "Output Sales Tax", "type": "liability", "parent_id": 235, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (406, 2, '2026-10-29 05:44:53.68411', 1, 'Administrator', 'create', 'accounting', 'Account', 323, '2-01-03-02-0001', 'Account 2-01-03-02-0001 created', '{"company_id": 2, "code": "2-01-03-02-0001", "name": "Income Tax Payable", "type": "liability", "parent_id": 236, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (407, 2, '2026-10-29 05:44:53.690555', 1, 'Administrator', 'create', 'accounting', 'Account', 324, '2-01-03-03-0001', 'Account 2-01-03-03-0001 created', '{"company_id": 2, "code": "2-01-03-03-0001", "name": "WHT Payable", "type": "liability", "parent_id": 237, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (408, 2, '2026-10-29 05:44:53.697424', 1, 'Administrator', 'create', 'accounting', 'Account', 325, '2-01-03-04-0001', 'Account 2-01-03-04-0001 created', '{"company_id": 2, "code": "2-01-03-04-0001", "name": "Further Tax Payable", "type": "liability", "parent_id": 238, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (409, 2, '2026-10-29 05:44:53.70441', 1, 'Administrator', 'create', 'accounting', 'Account', 326, '2-01-04-01-0001', 'Account 2-01-04-01-0001 created', '{"company_id": 2, "code": "2-01-04-01-0001", "name": "Customer Advances \u2014 General", "type": "liability", "parent_id": 240, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (410, 2, '2026-10-29 05:44:53.710847', 1, 'Administrator', 'create', 'accounting', 'Account', 327, '2-02-01-01-0001', 'Account 2-02-01-01-0001 created', '{"company_id": 2, "code": "2-02-01-01-0001", "name": "Long-term Loans \u2014 General", "type": "liability", "parent_id": 243, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (411, 2, '2026-10-29 05:44:53.717558', 1, 'Administrator', 'create', 'accounting', 'Account', 328, '2-02-02-01-0001', 'Account 2-02-02-01-0001 created', '{"company_id": 2, "code": "2-02-02-01-0001", "name": "EOSB Provision \u2014 General", "type": "liability", "parent_id": 245, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (412, 2, '2026-10-29 05:44:53.724009', 1, 'Administrator', 'create', 'accounting', 'Account', 329, '3-01-01-01-0001', 'Account 3-01-01-01-0001 created', '{"company_id": 2, "code": "3-01-01-01-0001", "name": "Share Capital", "type": "equity", "parent_id": 249, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (413, 2, '2026-10-29 05:44:53.7304', 1, 'Administrator', 'create', 'accounting', 'Account', 330, '3-01-01-01-0002', 'Account 3-01-01-01-0002 created', '{"company_id": 2, "code": "3-01-01-01-0002", "name": "Suspense Equity", "type": "equity", "parent_id": 249, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (414, 2, '2026-10-29 05:44:53.736761', 1, 'Administrator', 'create', 'accounting', 'Account', 331, '3-02-01-01-0001', 'Account 3-02-01-01-0001 created', '{"company_id": 2, "code": "3-02-01-01-0001", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 252, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (415, 2, '2026-10-29 05:44:53.743791', 1, 'Administrator', 'create', 'accounting', 'Account', 332, '3-02-01-02-0001', 'Account 3-02-01-02-0001 created', '{"company_id": 2, "code": "3-02-01-02-0001", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 253, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (416, 2, '2026-10-29 05:44:53.750479', 1, 'Administrator', 'create', 'accounting', 'Account', 333, '3-02-02-01-0001', 'Account 3-02-02-01-0001 created', '{"company_id": 2, "code": "3-02-02-01-0001", "name": "Dividends", "type": "equity", "parent_id": 255, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (417, 2, '2026-10-29 05:44:53.756861', 1, 'Administrator', 'create', 'accounting', 'Account', 334, '3-02-03-01-0001', 'Account 3-02-03-01-0001 created', '{"company_id": 2, "code": "3-02-03-01-0001", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 257, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (418, 2, '2026-10-29 05:44:53.763332', 1, 'Administrator', 'create', 'accounting', 'Account', 335, '4-01-01-01-0001', 'Account 4-01-01-01-0001 created', '{"company_id": 2, "code": "4-01-01-01-0001", "name": "Sales \u2014 General", "type": "revenue", "parent_id": 261, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (419, 2, '2026-10-29 05:44:53.769676', 1, 'Administrator', 'create', 'accounting', 'Account', 336, '4-01-02-01-0001', 'Account 4-01-02-01-0001 created', '{"company_id": 2, "code": "4-01-02-01-0001", "name": "Service Income \u2014 General", "type": "revenue", "parent_id": 263, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (420, 2, '2026-10-29 05:44:53.776061', 1, 'Administrator', 'create', 'accounting', 'Account', 337, '4-02-01-01-0001', 'Account 4-02-01-01-0001 created', '{"company_id": 2, "code": "4-02-01-01-0001", "name": "Sales Returns \u2014 General", "type": "revenue", "parent_id": 266, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (421, 2, '2026-10-29 05:44:53.782397', 1, 'Administrator', 'create', 'accounting', 'Account', 338, '4-02-02-01-0001', 'Account 4-02-02-01-0001 created', '{"company_id": 2, "code": "4-02-02-01-0001", "name": "Discounts Allowed \u2014 General", "type": "revenue", "parent_id": 268, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (422, 2, '2026-10-29 05:44:53.78888', 1, 'Administrator', 'create', 'accounting', 'Account', 339, '4-03-01-01-0001', 'Account 4-03-01-01-0001 created', '{"company_id": 2, "code": "4-03-01-01-0001", "name": "Other Income \u2014 General", "type": "revenue", "parent_id": 271, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (423, 2, '2026-10-29 05:44:53.795308', 1, 'Administrator', 'create', 'accounting', 'Account', 340, '5-01-01-01-0001', 'Account 5-01-01-01-0001 created', '{"company_id": 2, "code": "5-01-01-01-0001", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 275, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (424, 2, '2026-10-29 05:44:53.802105', 1, 'Administrator', 'create', 'accounting', 'Account', 341, '5-01-02-01-0001', 'Account 5-01-02-01-0001 created', '{"company_id": 2, "code": "5-01-02-01-0001", "name": "Scrap / Write-off", "type": "expense", "parent_id": 277, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (425, 2, '2026-10-29 05:44:53.808746', 1, 'Administrator', 'create', 'accounting', 'Account', 342, '5-01-02-01-0002', 'Account 5-01-02-01-0002 created', '{"company_id": 2, "code": "5-01-02-01-0002", "name": "Inventory Adjustment", "type": "expense", "parent_id": 277, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (426, 2, '2026-10-29 05:44:53.815119', 1, 'Administrator', 'create', 'accounting', 'Account', 343, '5-01-02-01-0003', 'Account 5-01-02-01-0003 created', '{"company_id": 2, "code": "5-01-02-01-0003", "name": "Consumption Expense", "type": "expense", "parent_id": 277, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (427, 2, '2026-10-29 05:44:53.821486', 1, 'Administrator', 'create', 'accounting', 'Account', 344, '5-01-02-01-0004', 'Account 5-01-02-01-0004 created', '{"company_id": 2, "code": "5-01-02-01-0004", "name": "Inventory Cost Variance", "type": "expense", "parent_id": 277, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (428, 2, '2026-10-29 05:44:53.827865', 1, 'Administrator', 'create', 'accounting', 'Account', 345, '5-02-01-01-0001', 'Account 5-02-01-01-0001 created', '{"company_id": 2, "code": "5-02-01-01-0001", "name": "Salary Expense", "type": "expense", "parent_id": 280, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (429, 2, '2026-10-29 05:44:53.834403', 1, 'Administrator', 'create', 'accounting', 'Account', 346, '5-02-01-01-0002', 'Account 5-02-01-01-0002 created', '{"company_id": 2, "code": "5-02-01-01-0002", "name": "PF Employer Expense", "type": "expense", "parent_id": 280, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (430, 2, '2026-10-29 05:44:53.84077', 1, 'Administrator', 'create', 'accounting', 'Account', 347, '5-02-02-01-0001', 'Account 5-02-02-01-0001 created', '{"company_id": 2, "code": "5-02-02-01-0001", "name": "Rent Expense", "type": "expense", "parent_id": 282, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (431, 2, '2026-10-29 05:44:53.847233', 1, 'Administrator', 'create', 'accounting', 'Account', 348, '5-02-02-01-0002', 'Account 5-02-02-01-0002 created', '{"company_id": 2, "code": "5-02-02-01-0002", "name": "Utilities Expense", "type": "expense", "parent_id": 282, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (432, 2, '2026-10-29 05:44:53.854068', 1, 'Administrator', 'create', 'accounting', 'Account', 349, '5-02-03-01-0001', 'Account 5-02-03-01-0001 created', '{"company_id": 2, "code": "5-02-03-01-0001", "name": "Office Supplies", "type": "expense", "parent_id": 284, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (433, 2, '2026-10-29 05:44:53.86053', 1, 'Administrator', 'create', 'accounting', 'Account', 350, '5-02-04-01-0001', 'Account 5-02-04-01-0001 created', '{"company_id": 2, "code": "5-02-04-01-0001", "name": "Depreciation Expense", "type": "expense", "parent_id": 286, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (434, 2, '2026-10-29 05:44:53.866983', 1, 'Administrator', 'create', 'accounting', 'Account', 351, '5-02-05-01-0001', 'Account 5-02-05-01-0001 created', '{"company_id": 2, "code": "5-02-05-01-0001", "name": "Fees, Taxes & Licenses \u2014 General", "type": "expense", "parent_id": 288, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (435, 2, '2026-10-29 05:44:53.873392', 1, 'Administrator', 'create', 'accounting', 'Account', 352, '5-03-01-01-0001', 'Account 5-03-01-01-0001 created', '{"company_id": 2, "code": "5-03-01-01-0001", "name": "Freight & Transportation \u2014 General", "type": "expense", "parent_id": 291, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (436, 2, '2026-10-29 05:44:53.879949', 1, 'Administrator', 'create', 'accounting', 'Account', 353, '5-03-02-01-0001', 'Account 5-03-02-01-0001 created', '{"company_id": 2, "code": "5-03-02-01-0001", "name": "Commissions \u2014 General", "type": "expense", "parent_id": 293, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (437, 2, '2026-10-29 05:44:53.886324', 1, 'Administrator', 'create', 'accounting', 'Account', 354, '5-03-03-01-0001', 'Account 5-03-03-01-0001 created', '{"company_id": 2, "code": "5-03-03-01-0001", "name": "Marketing & Advertising \u2014 General", "type": "expense", "parent_id": 295, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (438, 2, '2026-10-29 05:44:53.892712', 1, 'Administrator', 'create', 'accounting', 'Account', 355, '5-04-01-01-0001', 'Account 5-04-01-01-0001 created', '{"company_id": 2, "code": "5-04-01-01-0001", "name": "Other Expenses \u2014 General", "type": "expense", "parent_id": 298, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (439, 2, '2026-10-29 05:44:53.899592', 1, 'Administrator', 'create', 'accounting', 'Account', 356, '5-04-01-01-0002', 'Account 5-04-01-01-0002 created', '{"company_id": 2, "code": "5-04-01-01-0002", "name": "Loss/(Gain) on Disposal of Fixed Assets", "type": "expense", "parent_id": 298, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (440, 2, '2026-10-29 05:44:53.906126', 1, 'Administrator', 'create', 'accounting', 'Account', 357, '5-05-01-01-0001', 'Account 5-05-01-01-0001 created', '{"company_id": 2, "code": "5-05-01-01-0001", "name": "Bank Charges", "type": "expense", "parent_id": 301, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (441, 2, '2026-10-29 05:44:53.912459', 1, 'Administrator', 'create', 'accounting', 'Account', 358, '5-05-01-01-0002', 'Account 5-05-01-01-0002 created', '{"company_id": 2, "code": "5-05-01-01-0002", "name": "Interest Expense", "type": "expense", "parent_id": 301, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (442, 2, '2026-10-29 05:44:53.917645', 1, 'Administrator', 'create', 'accounting', 'Account', 359, '5-06-01-01-0001', 'Account 5-06-01-01-0001 created', '{"company_id": 2, "code": "5-06-01-01-0001", "name": "Income Tax Expense", "type": "expense", "parent_id": 304, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (443, 2, '2026-10-29 05:44:53.976332', 1, 'Administrator', 'create', 'settings', 'Company profile', 2, 'SolarKon Energy Solutions', 'Company profile SolarKon Energy Solutions created', '{"company_id": 2, "company_name": "SolarKon Energy Solutions", "country": "Pakistan", "fiscal_year_start_month": 1, "currency": "PKR", "currency_symbol": "Rs.", "date_format": "Y-m-d", "number_format": "en", "timezone": "Asia/Karachi"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (444, 2, '2026-10-29 05:44:53.989061', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 9, 'FY 2021', 'Accounting period FY 2021 created', '{"company_id": 2, "fiscal_year": "2021", "period_name": "FY 2021", "start_date": "2021-01-01", "end_date": "2021-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (445, 2, '2026-10-29 05:44:53.989065', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 10, 'FY 2022', 'Accounting period FY 2022 created', '{"company_id": 2, "fiscal_year": "2022", "period_name": "FY 2022", "start_date": "2022-01-01", "end_date": "2022-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (446, 2, '2026-10-29 05:44:53.989067', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 11, 'FY 2023', 'Accounting period FY 2023 created', '{"company_id": 2, "fiscal_year": "2023", "period_name": "FY 2023", "start_date": "2023-01-01", "end_date": "2023-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (447, 2, '2026-10-29 05:44:53.989069', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 12, 'FY 2024', 'Accounting period FY 2024 created', '{"company_id": 2, "fiscal_year": "2024", "period_name": "FY 2024", "start_date": "2024-01-01", "end_date": "2024-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (448, 2, '2026-10-29 05:44:53.98907', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 13, 'FY 2025', 'Accounting period FY 2025 created', '{"company_id": 2, "fiscal_year": "2025", "period_name": "FY 2025", "start_date": "2025-01-01", "end_date": "2025-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (449, 2, '2026-10-29 05:44:53.989072', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 14, 'FY 2026', 'Accounting period FY 2026 created', '{"company_id": 2, "fiscal_year": "2026", "period_name": "FY 2026", "start_date": "2026-01-01", "end_date": "2026-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (450, 2, '2026-10-29 05:44:53.989074', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 15, 'FY 2027', 'Accounting period FY 2027 created', '{"company_id": 2, "fiscal_year": "2027", "period_name": "FY 2027", "start_date": "2027-01-01", "end_date": "2027-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (451, 2, '2026-10-29 05:44:53.989075', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 16, 'FY 2028', 'Accounting period FY 2028 created', '{"company_id": 2, "fiscal_year": "2028", "period_name": "FY 2028", "start_date": "2028-01-01", "end_date": "2028-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (456, 3, '2026-10-29 05:44:54.192678', 1, 'Administrator', 'create', 'accounting', 'Account', 360, '1', 'Account 1 created', '{"company_id": 3, "code": "1", "name": "Assets", "type": "asset", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (457, 3, '2026-10-29 05:44:54.199113', 1, 'Administrator', 'create', 'accounting', 'Account', 361, '1-01', 'Account 1-01 created', '{"company_id": 3, "code": "1-01", "name": "Current Assets", "type": "asset", "parent_id": 360, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (458, 3, '2026-10-29 05:44:54.205539', 1, 'Administrator', 'create', 'accounting', 'Account', 362, '1-01-01', 'Account 1-01-01 created', '{"company_id": 3, "code": "1-01-01", "name": "Cash & Cash Equivalents", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true, "cash_flow_activity": "cash"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (459, 3, '2026-10-29 05:44:54.21212', 1, 'Administrator', 'create', 'accounting', 'Account', 363, '1-01-01-01', 'Account 1-01-01-01 created', '{"company_id": 3, "code": "1-01-01-01", "name": "Cash in Hand", "type": "asset", "parent_id": 362, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (460, 3, '2026-10-29 05:44:54.218507', 1, 'Administrator', 'create', 'accounting', 'Account', 364, '1-01-01-02', 'Account 1-01-01-02 created', '{"company_id": 3, "code": "1-01-01-02", "name": "Bank Accounts", "type": "asset", "parent_id": 362, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (461, 3, '2026-10-29 05:44:54.224936', 1, 'Administrator', 'create', 'accounting', 'Account', 365, '1-01-02', 'Account 1-01-02 created', '{"company_id": 3, "code": "1-01-02", "name": "Trade Receivables", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (462, 3, '2026-10-29 05:44:54.231228', 1, 'Administrator', 'create', 'accounting', 'Account', 366, '1-01-02-01', 'Account 1-01-02-01 created', '{"company_id": 3, "code": "1-01-02-01", "name": "Trade Debtors", "type": "asset", "parent_id": 365, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (463, 3, '2026-10-29 05:44:54.237792', 1, 'Administrator', 'create', 'accounting', 'Account', 367, '1-01-02-02', 'Account 1-01-02-02 created', '{"company_id": 3, "code": "1-01-02-02", "name": "Doubtful Receivables", "type": "asset", "parent_id": 365, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (464, 3, '2026-10-29 05:44:54.244178', 1, 'Administrator', 'create', 'accounting', 'Account', 368, '1-01-03', 'Account 1-01-03 created', '{"company_id": 3, "code": "1-01-03", "name": "Other Receivables", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (465, 3, '2026-10-29 05:44:54.250643', 1, 'Administrator', 'create', 'accounting', 'Account', 369, '1-01-03-01', 'Account 1-01-03-01 created', '{"company_id": 3, "code": "1-01-03-01", "name": "Employee Loans & Advances", "type": "asset", "parent_id": 368, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (466, 3, '2026-10-29 05:44:54.257029', 1, 'Administrator', 'create', 'accounting', 'Account', 370, '1-01-03-02', 'Account 1-01-03-02 created', '{"company_id": 3, "code": "1-01-03-02", "name": "Advances to Suppliers", "type": "asset", "parent_id": 368, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (467, 3, '2026-10-29 05:44:54.263527', 1, 'Administrator', 'create', 'accounting', 'Account', 371, '1-01-04', 'Account 1-01-04 created', '{"company_id": 3, "code": "1-01-04", "name": "Inventories", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (468, 3, '2026-10-29 05:44:54.26999', 1, 'Administrator', 'create', 'accounting', 'Account', 372, '1-01-04-01', 'Account 1-01-04-01 created', '{"company_id": 3, "code": "1-01-04-01", "name": "Trading Goods Stock", "type": "asset", "parent_id": 371, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (469, 3, '2026-10-29 05:44:54.276342', 1, 'Administrator', 'create', 'accounting', 'Account', 373, '1-01-05', 'Account 1-01-05 created', '{"company_id": 3, "code": "1-01-05", "name": "Tax Assets", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (470, 3, '2026-10-29 05:44:54.282893', 1, 'Administrator', 'create', 'accounting', 'Account', 374, '1-01-05-01', 'Account 1-01-05-01 created', '{"company_id": 3, "code": "1-01-05-01", "name": "Input Sales Tax", "type": "asset", "parent_id": 373, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (471, 3, '2026-10-29 05:44:54.289241', 1, 'Administrator', 'create', 'accounting', 'Account', 375, '1-01-05-02', 'Account 1-01-05-02 created', '{"company_id": 3, "code": "1-01-05-02", "name": "WHT Receivable", "type": "asset", "parent_id": 373, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (472, 3, '2026-10-29 05:44:54.295666', 1, 'Administrator', 'create', 'accounting', 'Account', 376, '1-01-06', 'Account 1-01-06 created', '{"company_id": 3, "code": "1-01-06", "name": "Prepayments & Other", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (473, 3, '2026-10-29 05:44:54.302213', 1, 'Administrator', 'create', 'accounting', 'Account', 377, '1-01-06-01', 'Account 1-01-06-01 created', '{"company_id": 3, "code": "1-01-06-01", "name": "Suspense & Clearing", "type": "asset", "parent_id": 376, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (474, 3, '2026-10-29 05:44:54.308498', 1, 'Administrator', 'create', 'accounting', 'Account', 378, '1-01-06-02', 'Account 1-01-06-02 created', '{"company_id": 3, "code": "1-01-06-02", "name": "Prepaid Expenses", "type": "asset", "parent_id": 376, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (475, 3, '2026-10-29 05:44:54.314767', 1, 'Administrator', 'create', 'accounting', 'Account', 379, '1-01-06-03', 'Account 1-01-06-03 created', '{"company_id": 3, "code": "1-01-06-03", "name": "Other Current Assets", "type": "asset", "parent_id": 376, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (476, 3, '2026-10-29 05:44:54.321031', 1, 'Administrator', 'create', 'accounting', 'Account', 380, '1-02', 'Account 1-02 created', '{"company_id": 3, "code": "1-02", "name": "Non-Current Assets", "type": "asset", "parent_id": 360, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "investing"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (477, 3, '2026-10-29 05:44:54.327436', 1, 'Administrator', 'create', 'accounting', 'Account', 381, '1-02-01', 'Account 1-02-01 created', '{"company_id": 3, "code": "1-02-01", "name": "Property, Plant & Equipment", "type": "asset", "parent_id": 380, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (478, 3, '2026-10-29 05:44:54.333711', 1, 'Administrator', 'create', 'accounting', 'Account', 382, '1-02-01-01', 'Account 1-02-01-01 created', '{"company_id": 3, "code": "1-02-01-01", "name": "Owned Assets", "type": "asset", "parent_id": 381, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (479, 3, '2026-10-29 05:44:54.339974', 1, 'Administrator', 'create', 'accounting', 'Account', 383, '1-02-02', 'Account 1-02-02 created', '{"company_id": 3, "code": "1-02-02", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 380, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (480, 3, '2026-10-29 05:44:54.347251', 1, 'Administrator', 'create', 'accounting', 'Account', 384, '1-02-02-01', 'Account 1-02-02-01 created', '{"company_id": 3, "code": "1-02-02-01", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 383, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (481, 3, '2026-10-29 05:44:54.353454', 1, 'Administrator', 'create', 'accounting', 'Account', 385, '1-02-03', 'Account 1-02-03 created', '{"company_id": 3, "code": "1-02-03", "name": "Intangible Assets", "type": "asset", "parent_id": 380, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (482, 3, '2026-10-29 05:44:54.359676', 1, 'Administrator', 'create', 'accounting', 'Account', 386, '1-02-03-01', 'Account 1-02-03-01 created', '{"company_id": 3, "code": "1-02-03-01", "name": "Intangibles", "type": "asset", "parent_id": 385, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (483, 3, '2026-10-29 05:44:54.363602', 1, 'Administrator', 'create', 'accounting', 'Account', 387, '2', 'Account 2 created', '{"company_id": 3, "code": "2", "name": "Liabilities", "type": "liability", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (484, 3, '2026-10-29 05:44:54.370032', 1, 'Administrator', 'create', 'accounting', 'Account', 388, '2-01', 'Account 2-01 created', '{"company_id": 3, "code": "2-01", "name": "Current Liabilities", "type": "liability", "parent_id": 387, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (485, 3, '2026-10-29 05:44:54.376246', 1, 'Administrator', 'create', 'accounting', 'Account', 389, '2-01-01', 'Account 2-01-01 created', '{"company_id": 3, "code": "2-01-01", "name": "Trade Payables", "type": "liability", "parent_id": 388, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (486, 3, '2026-10-29 05:44:54.382541', 1, 'Administrator', 'create', 'accounting', 'Account', 390, '2-01-01-01', 'Account 2-01-01-01 created', '{"company_id": 3, "code": "2-01-01-01", "name": "Trade Creditors", "type": "liability", "parent_id": 389, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (487, 3, '2026-10-29 05:44:54.389155', 1, 'Administrator', 'create', 'accounting', 'Account', 391, '2-01-02', 'Account 2-01-02 created', '{"company_id": 3, "code": "2-01-02", "name": "Accrued & Payroll Liabilities", "type": "liability", "parent_id": 388, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (488, 3, '2026-10-29 05:44:54.395966', 1, 'Administrator', 'create', 'accounting', 'Account', 392, '2-01-02-01', 'Account 2-01-02-01 created', '{"company_id": 3, "code": "2-01-02-01", "name": "Employee Payables", "type": "liability", "parent_id": 391, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (489, 3, '2026-10-29 05:44:54.402306', 1, 'Administrator', 'create', 'accounting', 'Account', 393, '2-01-02-02', 'Account 2-01-02-02 created', '{"company_id": 3, "code": "2-01-02-02", "name": "Payroll Liabilities", "type": "liability", "parent_id": 391, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (490, 3, '2026-10-29 05:44:54.408702', 1, 'Administrator', 'create', 'accounting', 'Account', 394, '2-01-02-03', 'Account 2-01-02-03 created', '{"company_id": 3, "code": "2-01-02-03", "name": "Accrued Expenses", "type": "liability", "parent_id": 391, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (491, 3, '2026-10-29 05:44:54.415246', 1, 'Administrator', 'create', 'accounting', 'Account', 395, '2-01-03', 'Account 2-01-03 created', '{"company_id": 3, "code": "2-01-03", "name": "Tax Liabilities", "type": "liability", "parent_id": 388, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (492, 3, '2026-10-29 05:44:54.421646', 1, 'Administrator', 'create', 'accounting', 'Account', 396, '2-01-03-01', 'Account 2-01-03-01 created', '{"company_id": 3, "code": "2-01-03-01", "name": "Output Sales Tax", "type": "liability", "parent_id": 395, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (493, 3, '2026-10-29 05:44:54.428005', 1, 'Administrator', 'create', 'accounting', 'Account', 397, '2-01-03-02', 'Account 2-01-03-02 created', '{"company_id": 3, "code": "2-01-03-02", "name": "Income Tax Payable", "type": "liability", "parent_id": 395, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (494, 3, '2026-10-29 05:44:54.434344', 1, 'Administrator', 'create', 'accounting', 'Account', 398, '2-01-03-03', 'Account 2-01-03-03 created', '{"company_id": 3, "code": "2-01-03-03", "name": "WHT Payable", "type": "liability", "parent_id": 395, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (495, 3, '2026-10-29 05:44:54.440854', 1, 'Administrator', 'create', 'accounting', 'Account', 399, '2-01-03-04', 'Account 2-01-03-04 created', '{"company_id": 3, "code": "2-01-03-04", "name": "Further Tax Payable", "type": "liability", "parent_id": 395, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (496, 3, '2026-10-29 05:44:54.447168', 1, 'Administrator', 'create', 'accounting', 'Account', 400, '2-01-04', 'Account 2-01-04 created', '{"company_id": 3, "code": "2-01-04", "name": "Advances from Customers", "type": "liability", "parent_id": 388, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (497, 3, '2026-10-29 05:44:54.453511', 1, 'Administrator', 'create', 'accounting', 'Account', 401, '2-01-04-01', 'Account 2-01-04-01 created', '{"company_id": 3, "code": "2-01-04-01", "name": "Customer Advances", "type": "liability", "parent_id": 400, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (498, 3, '2026-10-29 05:44:54.460009', 1, 'Administrator', 'create', 'accounting', 'Account', 402, '2-02', 'Account 2-02 created', '{"company_id": 3, "code": "2-02", "name": "Non-Current Liabilities", "type": "liability", "parent_id": 387, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (499, 3, '2026-10-29 05:44:54.466272', 1, 'Administrator', 'create', 'accounting', 'Account', 403, '2-02-01', 'Account 2-02-01 created', '{"company_id": 3, "code": "2-02-01", "name": "Long-term Loans", "type": "liability", "parent_id": 402, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (500, 3, '2026-10-29 05:44:54.472635', 1, 'Administrator', 'create', 'accounting', 'Account', 404, '2-02-01-01', 'Account 2-02-01-01 created', '{"company_id": 3, "code": "2-02-01-01", "name": "Long-term Loans", "type": "liability", "parent_id": 403, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (501, 3, '2026-10-29 05:44:54.479026', 1, 'Administrator', 'create', 'accounting', 'Account', 405, '2-02-02', 'Account 2-02-02 created', '{"company_id": 3, "code": "2-02-02", "name": "Employee End-of-Service Benefits", "type": "liability", "parent_id": 402, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (502, 3, '2026-10-29 05:44:54.485602', 1, 'Administrator', 'create', 'accounting', 'Account', 406, '2-02-02-01', 'Account 2-02-02-01 created', '{"company_id": 3, "code": "2-02-02-01", "name": "EOSB Provision", "type": "liability", "parent_id": 405, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (503, 3, '2026-10-29 05:44:54.489644', 1, 'Administrator', 'create', 'accounting', 'Account', 407, '3', 'Account 3 created', '{"company_id": 3, "code": "3", "name": "Equity", "type": "equity", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (504, 3, '2026-10-29 05:44:54.496249', 1, 'Administrator', 'create', 'accounting', 'Account', 408, '3-01', 'Account 3-01 created', '{"company_id": 3, "code": "3-01", "name": "Capital", "type": "equity", "parent_id": 407, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (505, 3, '2026-10-29 05:44:54.502646', 1, 'Administrator', 'create', 'accounting', 'Account', 409, '3-01-01', 'Account 3-01-01 created', '{"company_id": 3, "code": "3-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 408, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (506, 3, '2026-10-29 05:44:54.509272', 1, 'Administrator', 'create', 'accounting', 'Account', 410, '3-01-01-01', 'Account 3-01-01-01 created', '{"company_id": 3, "code": "3-01-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 409, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (507, 3, '2026-10-29 05:44:54.515941', 1, 'Administrator', 'create', 'accounting', 'Account', 411, '3-02', 'Account 3-02 created', '{"company_id": 3, "code": "3-02", "name": "Reserves & Retained Earnings", "type": "equity", "parent_id": 407, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (508, 3, '2026-10-29 05:44:54.522251', 1, 'Administrator', 'create', 'accounting', 'Account', 412, '3-02-01', 'Account 3-02-01 created', '{"company_id": 3, "code": "3-02-01", "name": "Retained Earnings", "type": "equity", "parent_id": 411, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (509, 3, '2026-10-29 05:44:54.528812', 1, 'Administrator', 'create', 'accounting', 'Account', 413, '3-02-01-01', 'Account 3-02-01-01 created', '{"company_id": 3, "code": "3-02-01-01", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 412, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (510, 3, '2026-10-29 05:44:54.535154', 1, 'Administrator', 'create', 'accounting', 'Account', 414, '3-02-01-02', 'Account 3-02-01-02 created', '{"company_id": 3, "code": "3-02-01-02", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 412, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (511, 3, '2026-10-29 05:44:54.541554', 1, 'Administrator', 'create', 'accounting', 'Account', 415, '3-02-02', 'Account 3-02-02 created', '{"company_id": 3, "code": "3-02-02", "name": "Dividends", "type": "equity", "parent_id": 411, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (512, 3, '2026-10-29 05:44:54.548007', 1, 'Administrator', 'create', 'accounting', 'Account', 416, '3-02-02-01', 'Account 3-02-02-01 created', '{"company_id": 3, "code": "3-02-02-01", "name": "Dividends", "type": "equity", "parent_id": 415, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (513, 3, '2026-10-29 05:44:54.554465', 1, 'Administrator', 'create', 'accounting', 'Account', 417, '3-02-03', 'Account 3-02-03 created', '{"company_id": 3, "code": "3-02-03", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 411, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (514, 3, '2026-10-29 05:44:54.560753', 1, 'Administrator', 'create', 'accounting', 'Account', 418, '3-02-03-01', 'Account 3-02-03-01 created', '{"company_id": 3, "code": "3-02-03-01", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 417, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (515, 3, '2026-10-29 05:44:54.564731', 1, 'Administrator', 'create', 'accounting', 'Account', 419, '4', 'Account 4 created', '{"company_id": 3, "code": "4", "name": "Revenue", "type": "revenue", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (516, 3, '2026-10-29 05:44:54.571128', 1, 'Administrator', 'create', 'accounting', 'Account', 420, '4-01', 'Account 4-01 created', '{"company_id": 3, "code": "4-01", "name": "Sales", "type": "revenue", "parent_id": 419, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (517, 3, '2026-10-29 05:44:54.577756', 1, 'Administrator', 'create', 'accounting', 'Account', 421, '4-01-01', 'Account 4-01-01 created', '{"company_id": 3, "code": "4-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 420, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (518, 3, '2026-10-29 05:44:54.58417', 1, 'Administrator', 'create', 'accounting', 'Account', 422, '4-01-01-01', 'Account 4-01-01-01 created', '{"company_id": 3, "code": "4-01-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 421, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (519, 3, '2026-10-29 05:44:54.590591', 1, 'Administrator', 'create', 'accounting', 'Account', 423, '4-01-02', 'Account 4-01-02 created', '{"company_id": 3, "code": "4-01-02", "name": "Service Income", "type": "revenue", "parent_id": 420, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (520, 3, '2026-10-29 05:44:54.597168', 1, 'Administrator', 'create', 'accounting', 'Account', 424, '4-01-02-01', 'Account 4-01-02-01 created', '{"company_id": 3, "code": "4-01-02-01", "name": "Service Income", "type": "revenue", "parent_id": 423, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (521, 3, '2026-10-29 05:44:54.603573', 1, 'Administrator', 'create', 'accounting', 'Account', 425, '4-02', 'Account 4-02 created', '{"company_id": 3, "code": "4-02", "name": "Sales Returns & Discounts", "type": "revenue", "parent_id": 419, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales_returns"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (522, 3, '2026-10-29 05:44:54.609988', 1, 'Administrator', 'create', 'accounting', 'Account', 426, '4-02-01', 'Account 4-02-01 created', '{"company_id": 3, "code": "4-02-01", "name": "Sales Returns", "type": "revenue", "parent_id": 425, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (523, 3, '2026-10-29 05:44:54.616384', 1, 'Administrator', 'create', 'accounting', 'Account', 427, '4-02-01-01', 'Account 4-02-01-01 created', '{"company_id": 3, "code": "4-02-01-01", "name": "Sales Returns", "type": "revenue", "parent_id": 426, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (524, 3, '2026-10-29 05:44:54.623206', 1, 'Administrator', 'create', 'accounting', 'Account', 428, '4-02-02', 'Account 4-02-02 created', '{"company_id": 3, "code": "4-02-02", "name": "Discounts Allowed", "type": "revenue", "parent_id": 425, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (525, 3, '2026-10-29 05:44:54.629883', 1, 'Administrator', 'create', 'accounting', 'Account', 429, '4-02-02-01', 'Account 4-02-02-01 created', '{"company_id": 3, "code": "4-02-02-01", "name": "Discounts Allowed", "type": "revenue", "parent_id": 428, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (526, 3, '2026-10-29 05:44:54.636225', 1, 'Administrator', 'create', 'accounting', 'Account', 430, '4-03', 'Account 4-03 created', '{"company_id": 3, "code": "4-03", "name": "Other Income", "type": "revenue", "parent_id": 419, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_income"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (527, 3, '2026-10-29 05:44:54.642818', 1, 'Administrator', 'create', 'accounting', 'Account', 431, '4-03-01', 'Account 4-03-01 created', '{"company_id": 3, "code": "4-03-01", "name": "Other Income", "type": "revenue", "parent_id": 430, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (528, 3, '2026-10-29 05:44:54.649413', 1, 'Administrator', 'create', 'accounting', 'Account', 432, '4-03-01-01', 'Account 4-03-01-01 created', '{"company_id": 3, "code": "4-03-01-01", "name": "Other Income", "type": "revenue", "parent_id": 431, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (529, 3, '2026-10-29 05:44:54.653428', 1, 'Administrator', 'create', 'accounting', 'Account', 433, '5', 'Account 5 created', '{"company_id": 3, "code": "5", "name": "Expenses", "type": "expense", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (530, 3, '2026-10-29 05:44:54.659715', 1, 'Administrator', 'create', 'accounting', 'Account', 434, '5-01', 'Account 5-01 created', '{"company_id": 3, "code": "5-01", "name": "Cost of Sales", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "cost_of_sales"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (531, 3, '2026-10-29 05:44:54.666188', 1, 'Administrator', 'create', 'accounting', 'Account', 435, '5-01-01', 'Account 5-01-01 created', '{"company_id": 3, "code": "5-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 434, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (532, 3, '2026-10-29 05:44:54.672483', 1, 'Administrator', 'create', 'accounting', 'Account', 436, '5-01-01-01', 'Account 5-01-01-01 created', '{"company_id": 3, "code": "5-01-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 435, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (533, 3, '2026-10-29 05:44:54.678951', 1, 'Administrator', 'create', 'accounting', 'Account', 437, '5-01-02', 'Account 5-01-02 created', '{"company_id": 3, "code": "5-01-02", "name": "Stock Losses, Scrap & Adjustments", "type": "expense", "parent_id": 434, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (534, 3, '2026-10-29 05:44:54.685328', 1, 'Administrator', 'create', 'accounting', 'Account', 438, '5-01-02-01', 'Account 5-01-02-01 created', '{"company_id": 3, "code": "5-01-02-01", "name": "Stock Losses & Scrap", "type": "expense", "parent_id": 437, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (535, 3, '2026-10-29 05:44:54.691776', 1, 'Administrator', 'create', 'accounting', 'Account', 439, '5-02', 'Account 5-02 created', '{"company_id": 3, "code": "5-02", "name": "Administrative Expenses", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "admin"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (536, 3, '2026-10-29 05:44:54.698019', 1, 'Administrator', 'create', 'accounting', 'Account', 440, '5-02-01', 'Account 5-02-01 created', '{"company_id": 3, "code": "5-02-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 439, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (537, 3, '2026-10-29 05:44:54.704299', 1, 'Administrator', 'create', 'accounting', 'Account', 441, '5-02-01-01', 'Account 5-02-01-01 created', '{"company_id": 3, "code": "5-02-01-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 440, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (538, 3, '2026-10-29 05:44:54.710858', 1, 'Administrator', 'create', 'accounting', 'Account', 442, '5-02-02', 'Account 5-02-02 created', '{"company_id": 3, "code": "5-02-02", "name": "Rent & Utilities", "type": "expense", "parent_id": 439, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (539, 3, '2026-10-29 05:44:54.717138', 1, 'Administrator', 'create', 'accounting', 'Account', 443, '5-02-02-01', 'Account 5-02-02-01 created', '{"company_id": 3, "code": "5-02-02-01", "name": "Rent & Utilities", "type": "expense", "parent_id": 442, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (540, 3, '2026-10-29 05:44:54.723621', 1, 'Administrator', 'create', 'accounting', 'Account', 444, '5-02-03', 'Account 5-02-03 created', '{"company_id": 3, "code": "5-02-03", "name": "Office & Supplies", "type": "expense", "parent_id": 439, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (541, 3, '2026-10-29 05:44:54.73005', 1, 'Administrator', 'create', 'accounting', 'Account', 445, '5-02-03-01', 'Account 5-02-03-01 created', '{"company_id": 3, "code": "5-02-03-01", "name": "Office & Supplies", "type": "expense", "parent_id": 444, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (542, 3, '2026-10-29 05:44:54.736702', 1, 'Administrator', 'create', 'accounting', 'Account', 446, '5-02-04', 'Account 5-02-04 created', '{"company_id": 3, "code": "5-02-04", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 439, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (543, 3, '2026-10-29 05:44:54.743115', 1, 'Administrator', 'create', 'accounting', 'Account', 447, '5-02-04-01', 'Account 5-02-04-01 created', '{"company_id": 3, "code": "5-02-04-01", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 446, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (544, 3, '2026-10-29 05:44:54.749685', 1, 'Administrator', 'create', 'accounting', 'Account', 448, '5-02-05', 'Account 5-02-05 created', '{"company_id": 3, "code": "5-02-05", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 439, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (545, 3, '2026-10-29 05:44:54.75625', 1, 'Administrator', 'create', 'accounting', 'Account', 449, '5-02-05-01', 'Account 5-02-05-01 created', '{"company_id": 3, "code": "5-02-05-01", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 448, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (546, 3, '2026-10-29 05:44:54.762562', 1, 'Administrator', 'create', 'accounting', 'Account', 450, '5-03', 'Account 5-03 created', '{"company_id": 3, "code": "5-03", "name": "Selling & Distribution", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "selling_distribution"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (547, 3, '2026-10-29 05:44:54.769067', 1, 'Administrator', 'create', 'accounting', 'Account', 451, '5-03-01', 'Account 5-03-01 created', '{"company_id": 3, "code": "5-03-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 450, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (548, 3, '2026-10-29 05:44:54.775591', 1, 'Administrator', 'create', 'accounting', 'Account', 452, '5-03-01-01', 'Account 5-03-01-01 created', '{"company_id": 3, "code": "5-03-01-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 451, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (549, 3, '2026-10-29 05:44:54.782218', 1, 'Administrator', 'create', 'accounting', 'Account', 453, '5-03-02', 'Account 5-03-02 created', '{"company_id": 3, "code": "5-03-02", "name": "Commissions", "type": "expense", "parent_id": 450, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (550, 3, '2026-10-29 05:44:54.788735', 1, 'Administrator', 'create', 'accounting', 'Account', 454, '5-03-02-01', 'Account 5-03-02-01 created', '{"company_id": 3, "code": "5-03-02-01", "name": "Commissions", "type": "expense", "parent_id": 453, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (551, 3, '2026-10-29 05:44:54.795144', 1, 'Administrator', 'create', 'accounting', 'Account', 455, '5-03-03', 'Account 5-03-03 created', '{"company_id": 3, "code": "5-03-03", "name": "Marketing & Advertising", "type": "expense", "parent_id": 450, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (552, 3, '2026-10-29 05:44:54.801799', 1, 'Administrator', 'create', 'accounting', 'Account', 456, '5-03-03-01', 'Account 5-03-03-01 created', '{"company_id": 3, "code": "5-03-03-01", "name": "Marketing & Advertising", "type": "expense", "parent_id": 455, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (553, 3, '2026-10-29 05:44:54.808187', 1, 'Administrator', 'create', 'accounting', 'Account', 457, '5-04', 'Account 5-04 created', '{"company_id": 3, "code": "5-04", "name": "Other Operating Expenses", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_operating"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (554, 3, '2026-10-29 05:44:54.814564', 1, 'Administrator', 'create', 'accounting', 'Account', 458, '5-04-01', 'Account 5-04-01 created', '{"company_id": 3, "code": "5-04-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 457, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (555, 3, '2026-10-29 05:44:54.82092', 1, 'Administrator', 'create', 'accounting', 'Account', 459, '5-04-01-01', 'Account 5-04-01-01 created', '{"company_id": 3, "code": "5-04-01-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 458, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (556, 3, '2026-10-29 05:44:54.827432', 1, 'Administrator', 'create', 'accounting', 'Account', 460, '5-05', 'Account 5-05 created', '{"company_id": 3, "code": "5-05", "name": "Finance Costs", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "finance_cost"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (557, 3, '2026-10-29 05:44:54.8338', 1, 'Administrator', 'create', 'accounting', 'Account', 461, '5-05-01', 'Account 5-05-01 created', '{"company_id": 3, "code": "5-05-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 460, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (558, 3, '2026-10-29 05:44:54.840172', 1, 'Administrator', 'create', 'accounting', 'Account', 462, '5-05-01-01', 'Account 5-05-01-01 created', '{"company_id": 3, "code": "5-05-01-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 461, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (559, 3, '2026-10-29 05:44:54.8467', 1, 'Administrator', 'create', 'accounting', 'Account', 463, '5-06', 'Account 5-06 created', '{"company_id": 3, "code": "5-06", "name": "Taxation", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "income_tax"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (560, 3, '2026-10-29 05:44:54.853041', 1, 'Administrator', 'create', 'accounting', 'Account', 464, '5-06-01', 'Account 5-06-01 created', '{"company_id": 3, "code": "5-06-01", "name": "Income Tax", "type": "expense", "parent_id": 463, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (561, 3, '2026-10-29 05:44:54.859383', 1, 'Administrator', 'create', 'accounting', 'Account', 465, '5-06-01-01', 'Account 5-06-01-01 created', '{"company_id": 3, "code": "5-06-01-01", "name": "Income Tax", "type": "expense", "parent_id": 464, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (562, 3, '2026-10-29 05:44:54.869829', 1, 'Administrator', 'create', 'accounting', 'Account', 466, '1-01-01-01-0001', 'Account 1-01-01-01-0001 created', '{"company_id": 3, "code": "1-01-01-01-0001", "name": "Main Cash", "type": "asset", "parent_id": 363, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (563, 3, '2026-10-29 05:44:54.876327', 1, 'Administrator', 'create', 'accounting', 'Account', 467, '1-01-02-01-0001', 'Account 1-01-02-01-0001 created', '{"company_id": 3, "code": "1-01-02-01-0001", "name": "Trade Debtors \u2014 General", "type": "asset", "parent_id": 366, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (564, 3, '2026-10-29 05:44:54.883106', 1, 'Administrator', 'create', 'accounting', 'Account', 468, '1-01-03-02-0001', 'Account 1-01-03-02-0001 created', '{"company_id": 3, "code": "1-01-03-02-0001", "name": "Advances to Suppliers \u2014 General", "type": "asset", "parent_id": 370, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (565, 3, '2026-10-29 05:44:54.889381', 1, 'Administrator', 'create', 'accounting', 'Account', 469, '1-01-04-01-0001', 'Account 1-01-04-01-0001 created', '{"company_id": 3, "code": "1-01-04-01-0001", "name": "Stock \u2014 General", "type": "asset", "parent_id": 372, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (566, 3, '2026-10-29 05:44:54.895765', 1, 'Administrator', 'create', 'accounting', 'Account', 470, '1-01-05-01-0001', 'Account 1-01-05-01-0001 created', '{"company_id": 3, "code": "1-01-05-01-0001", "name": "Input Sales Tax", "type": "asset", "parent_id": 374, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (567, 3, '2026-10-29 05:44:54.902142', 1, 'Administrator', 'create', 'accounting', 'Account', 471, '1-01-05-02-0001', 'Account 1-01-05-02-0001 created', '{"company_id": 3, "code": "1-01-05-02-0001", "name": "WHT Receivable", "type": "asset", "parent_id": 375, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (568, 3, '2026-10-29 05:44:54.90865', 1, 'Administrator', 'create', 'accounting', 'Account', 472, '1-01-06-01-0001', 'Account 1-01-06-01-0001 created', '{"company_id": 3, "code": "1-01-06-01-0001", "name": "Suspense Account", "type": "asset", "parent_id": 377, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (569, 3, '2026-10-29 05:44:54.915021', 1, 'Administrator', 'create', 'accounting', 'Account', 473, '1-01-06-02-0001', 'Account 1-01-06-02-0001 created', '{"company_id": 3, "code": "1-01-06-02-0001", "name": "Prepaid Expenses \u2014 General", "type": "asset", "parent_id": 378, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (570, 3, '2026-10-29 05:44:54.921505', 1, 'Administrator', 'create', 'accounting', 'Account', 474, '1-02-01-01-0001', 'Account 1-02-01-01-0001 created', '{"company_id": 3, "code": "1-02-01-01-0001", "name": "Fixed Assets \u2014 General", "type": "asset", "parent_id": 382, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (571, 3, '2026-10-29 05:44:54.929164', 1, 'Administrator', 'create', 'accounting', 'Account', 475, '1-02-02-01-0001', 'Account 1-02-02-01-0001 created', '{"company_id": 3, "code": "1-02-02-01-0001", "name": "Accumulated Depreciation \u2014 General", "type": "asset", "parent_id": 384, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (572, 3, '2026-10-29 05:44:54.93544', 1, 'Administrator', 'create', 'accounting', 'Account', 476, '1-02-03-01-0001', 'Account 1-02-03-01-0001 created', '{"company_id": 3, "code": "1-02-03-01-0001", "name": "Intangibles \u2014 General", "type": "asset", "parent_id": 386, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (573, 3, '2026-10-29 05:44:54.94172', 1, 'Administrator', 'create', 'accounting', 'Account', 477, '2-01-01-01-0001', 'Account 2-01-01-01-0001 created', '{"company_id": 3, "code": "2-01-01-01-0001", "name": "Trade Creditors \u2014 General", "type": "liability", "parent_id": 390, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (574, 3, '2026-10-29 05:44:54.948024', 1, 'Administrator', 'create', 'accounting', 'Account', 478, '2-01-02-02-0001', 'Account 2-01-02-02-0001 created', '{"company_id": 3, "code": "2-01-02-02-0001", "name": "Salary Payable", "type": "liability", "parent_id": 393, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (575, 3, '2026-10-29 05:44:54.954587', 1, 'Administrator', 'create', 'accounting', 'Account', 479, '2-01-02-02-0002', 'Account 2-01-02-02-0002 created', '{"company_id": 3, "code": "2-01-02-02-0002", "name": "PF Payable", "type": "liability", "parent_id": 393, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (576, 3, '2026-10-29 05:44:54.960999', 1, 'Administrator', 'create', 'accounting', 'Account', 480, '2-01-02-02-0003', 'Account 2-01-02-02-0003 created', '{"company_id": 3, "code": "2-01-02-02-0003", "name": "Loan Deductions Clearing", "type": "liability", "parent_id": 393, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (577, 3, '2026-10-29 05:44:54.967431', 1, 'Administrator', 'create', 'accounting', 'Account', 481, '2-01-02-02-0004', 'Account 2-01-02-02-0004 created', '{"company_id": 3, "code": "2-01-02-02-0004", "name": "Other Payroll Deductions Payable", "type": "liability", "parent_id": 393, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (578, 3, '2026-10-29 05:44:54.974107', 1, 'Administrator', 'create', 'accounting', 'Account', 482, '2-01-02-03-0001', 'Account 2-01-02-03-0001 created', '{"company_id": 3, "code": "2-01-02-03-0001", "name": "Accrued Expenses \u2014 General", "type": "liability", "parent_id": 394, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (579, 3, '2026-10-29 05:44:54.980424', 1, 'Administrator', 'create', 'accounting', 'Account', 483, '2-01-03-01-0001', 'Account 2-01-03-01-0001 created', '{"company_id": 3, "code": "2-01-03-01-0001", "name": "Output Sales Tax", "type": "liability", "parent_id": 396, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (580, 3, '2026-10-29 05:44:54.986723', 1, 'Administrator', 'create', 'accounting', 'Account', 484, '2-01-03-02-0001', 'Account 2-01-03-02-0001 created', '{"company_id": 3, "code": "2-01-03-02-0001", "name": "Income Tax Payable", "type": "liability", "parent_id": 397, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (581, 3, '2026-10-29 05:44:54.993017', 1, 'Administrator', 'create', 'accounting', 'Account', 485, '2-01-03-03-0001', 'Account 2-01-03-03-0001 created', '{"company_id": 3, "code": "2-01-03-03-0001", "name": "WHT Payable", "type": "liability", "parent_id": 398, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (582, 3, '2026-10-29 05:44:54.999513', 1, 'Administrator', 'create', 'accounting', 'Account', 486, '2-01-03-04-0001', 'Account 2-01-03-04-0001 created', '{"company_id": 3, "code": "2-01-03-04-0001", "name": "Further Tax Payable", "type": "liability", "parent_id": 399, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (583, 3, '2026-10-29 05:44:55.00581', 1, 'Administrator', 'create', 'accounting', 'Account', 487, '2-01-04-01-0001', 'Account 2-01-04-01-0001 created', '{"company_id": 3, "code": "2-01-04-01-0001", "name": "Customer Advances \u2014 General", "type": "liability", "parent_id": 401, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (584, 3, '2026-10-29 05:44:55.012258', 1, 'Administrator', 'create', 'accounting', 'Account', 488, '2-02-01-01-0001', 'Account 2-02-01-01-0001 created', '{"company_id": 3, "code": "2-02-01-01-0001", "name": "Long-term Loans \u2014 General", "type": "liability", "parent_id": 404, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (585, 3, '2026-10-29 05:44:55.018967', 1, 'Administrator', 'create', 'accounting', 'Account', 489, '2-02-02-01-0001', 'Account 2-02-02-01-0001 created', '{"company_id": 3, "code": "2-02-02-01-0001", "name": "EOSB Provision \u2014 General", "type": "liability", "parent_id": 406, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (586, 3, '2026-10-29 05:44:55.025366', 1, 'Administrator', 'create', 'accounting', 'Account', 490, '3-01-01-01-0001', 'Account 3-01-01-01-0001 created', '{"company_id": 3, "code": "3-01-01-01-0001", "name": "Share Capital", "type": "equity", "parent_id": 410, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (587, 3, '2026-10-29 05:44:55.031756', 1, 'Administrator', 'create', 'accounting', 'Account', 491, '3-01-01-01-0002', 'Account 3-01-01-01-0002 created', '{"company_id": 3, "code": "3-01-01-01-0002", "name": "Suspense Equity", "type": "equity", "parent_id": 410, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (588, 3, '2026-10-29 05:44:55.038174', 1, 'Administrator', 'create', 'accounting', 'Account', 492, '3-02-01-01-0001', 'Account 3-02-01-01-0001 created', '{"company_id": 3, "code": "3-02-01-01-0001", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 413, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (589, 3, '2026-10-29 05:44:55.044726', 1, 'Administrator', 'create', 'accounting', 'Account', 493, '3-02-01-02-0001', 'Account 3-02-01-02-0001 created', '{"company_id": 3, "code": "3-02-01-02-0001", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 414, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (590, 3, '2026-10-29 05:44:55.05109', 1, 'Administrator', 'create', 'accounting', 'Account', 494, '3-02-02-01-0001', 'Account 3-02-02-01-0001 created', '{"company_id": 3, "code": "3-02-02-01-0001", "name": "Dividends", "type": "equity", "parent_id": 416, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (591, 3, '2026-10-29 05:44:55.057362', 1, 'Administrator', 'create', 'accounting', 'Account', 495, '3-02-03-01-0001', 'Account 3-02-03-01-0001 created', '{"company_id": 3, "code": "3-02-03-01-0001", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 418, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (592, 3, '2026-10-29 05:44:55.063816', 1, 'Administrator', 'create', 'accounting', 'Account', 496, '4-01-01-01-0001', 'Account 4-01-01-01-0001 created', '{"company_id": 3, "code": "4-01-01-01-0001", "name": "Sales \u2014 General", "type": "revenue", "parent_id": 422, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (593, 3, '2026-10-29 05:44:55.070085', 1, 'Administrator', 'create', 'accounting', 'Account', 497, '4-01-02-01-0001', 'Account 4-01-02-01-0001 created', '{"company_id": 3, "code": "4-01-02-01-0001", "name": "Service Income \u2014 General", "type": "revenue", "parent_id": 424, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (594, 3, '2026-10-29 05:44:55.076374', 1, 'Administrator', 'create', 'accounting', 'Account', 498, '4-02-01-01-0001', 'Account 4-02-01-01-0001 created', '{"company_id": 3, "code": "4-02-01-01-0001", "name": "Sales Returns \u2014 General", "type": "revenue", "parent_id": 427, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (595, 3, '2026-10-29 05:44:55.082668', 1, 'Administrator', 'create', 'accounting', 'Account', 499, '4-02-02-01-0001', 'Account 4-02-02-01-0001 created', '{"company_id": 3, "code": "4-02-02-01-0001", "name": "Discounts Allowed \u2014 General", "type": "revenue", "parent_id": 429, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (596, 3, '2026-10-29 05:44:55.089119', 1, 'Administrator', 'create', 'accounting', 'Account', 500, '4-03-01-01-0001', 'Account 4-03-01-01-0001 created', '{"company_id": 3, "code": "4-03-01-01-0001", "name": "Other Income \u2014 General", "type": "revenue", "parent_id": 432, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (597, 3, '2026-10-29 05:44:55.095428', 1, 'Administrator', 'create', 'accounting', 'Account', 501, '5-01-01-01-0001', 'Account 5-01-01-01-0001 created', '{"company_id": 3, "code": "5-01-01-01-0001", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 436, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (598, 3, '2026-10-29 05:44:55.101742', 1, 'Administrator', 'create', 'accounting', 'Account', 502, '5-01-02-01-0001', 'Account 5-01-02-01-0001 created', '{"company_id": 3, "code": "5-01-02-01-0001", "name": "Scrap / Write-off", "type": "expense", "parent_id": 438, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (599, 3, '2026-10-29 05:44:55.10882', 1, 'Administrator', 'create', 'accounting', 'Account', 503, '5-01-02-01-0002', 'Account 5-01-02-01-0002 created', '{"company_id": 3, "code": "5-01-02-01-0002", "name": "Inventory Adjustment", "type": "expense", "parent_id": 438, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (600, 3, '2026-10-29 05:44:55.115497', 1, 'Administrator', 'create', 'accounting', 'Account', 504, '5-01-02-01-0003', 'Account 5-01-02-01-0003 created', '{"company_id": 3, "code": "5-01-02-01-0003", "name": "Consumption Expense", "type": "expense", "parent_id": 438, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (601, 3, '2026-10-29 05:44:55.122015', 1, 'Administrator', 'create', 'accounting', 'Account', 505, '5-01-02-01-0004', 'Account 5-01-02-01-0004 created', '{"company_id": 3, "code": "5-01-02-01-0004", "name": "Inventory Cost Variance", "type": "expense", "parent_id": 438, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (602, 3, '2026-10-29 05:44:55.128493', 1, 'Administrator', 'create', 'accounting', 'Account', 506, '5-02-01-01-0001', 'Account 5-02-01-01-0001 created', '{"company_id": 3, "code": "5-02-01-01-0001", "name": "Salary Expense", "type": "expense", "parent_id": 441, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (603, 3, '2026-10-29 05:44:55.135213', 1, 'Administrator', 'create', 'accounting', 'Account', 507, '5-02-01-01-0002', 'Account 5-02-01-01-0002 created', '{"company_id": 3, "code": "5-02-01-01-0002", "name": "PF Employer Expense", "type": "expense", "parent_id": 441, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (604, 3, '2026-10-29 05:44:55.141679', 1, 'Administrator', 'create', 'accounting', 'Account', 508, '5-02-02-01-0001', 'Account 5-02-02-01-0001 created', '{"company_id": 3, "code": "5-02-02-01-0001", "name": "Rent Expense", "type": "expense", "parent_id": 443, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (605, 3, '2026-10-29 05:44:55.148135', 1, 'Administrator', 'create', 'accounting', 'Account', 509, '5-02-02-01-0002', 'Account 5-02-02-01-0002 created', '{"company_id": 3, "code": "5-02-02-01-0002", "name": "Utilities Expense", "type": "expense", "parent_id": 443, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (606, 3, '2026-10-29 05:44:55.155127', 1, 'Administrator', 'create', 'accounting', 'Account', 510, '5-02-03-01-0001', 'Account 5-02-03-01-0001 created', '{"company_id": 3, "code": "5-02-03-01-0001", "name": "Office Supplies", "type": "expense", "parent_id": 445, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (607, 3, '2026-10-29 05:44:55.161412', 1, 'Administrator', 'create', 'accounting', 'Account', 511, '5-02-04-01-0001', 'Account 5-02-04-01-0001 created', '{"company_id": 3, "code": "5-02-04-01-0001", "name": "Depreciation Expense", "type": "expense", "parent_id": 447, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (608, 3, '2026-10-29 05:44:55.1677', 1, 'Administrator', 'create', 'accounting', 'Account', 512, '5-02-05-01-0001', 'Account 5-02-05-01-0001 created', '{"company_id": 3, "code": "5-02-05-01-0001", "name": "Fees, Taxes & Licenses \u2014 General", "type": "expense", "parent_id": 449, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (609, 3, '2026-10-29 05:44:55.174012', 1, 'Administrator', 'create', 'accounting', 'Account', 513, '5-03-01-01-0001', 'Account 5-03-01-01-0001 created', '{"company_id": 3, "code": "5-03-01-01-0001", "name": "Freight & Transportation \u2014 General", "type": "expense", "parent_id": 452, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (610, 3, '2026-10-29 05:44:55.180461', 1, 'Administrator', 'create', 'accounting', 'Account', 514, '5-03-02-01-0001', 'Account 5-03-02-01-0001 created', '{"company_id": 3, "code": "5-03-02-01-0001", "name": "Commissions \u2014 General", "type": "expense", "parent_id": 454, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (611, 3, '2026-10-29 05:44:55.186755', 1, 'Administrator', 'create', 'accounting', 'Account', 515, '5-03-03-01-0001', 'Account 5-03-03-01-0001 created', '{"company_id": 3, "code": "5-03-03-01-0001", "name": "Marketing & Advertising \u2014 General", "type": "expense", "parent_id": 456, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (612, 3, '2026-10-29 05:44:55.193048', 1, 'Administrator', 'create', 'accounting', 'Account', 516, '5-04-01-01-0001', 'Account 5-04-01-01-0001 created', '{"company_id": 3, "code": "5-04-01-01-0001", "name": "Other Expenses \u2014 General", "type": "expense", "parent_id": 459, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (613, 3, '2026-10-29 05:44:55.199547', 1, 'Administrator', 'create', 'accounting', 'Account', 517, '5-04-01-01-0002', 'Account 5-04-01-01-0002 created', '{"company_id": 3, "code": "5-04-01-01-0002", "name": "Loss/(Gain) on Disposal of Fixed Assets", "type": "expense", "parent_id": 459, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (614, 3, '2026-10-29 05:44:55.205923', 1, 'Administrator', 'create', 'accounting', 'Account', 518, '5-05-01-01-0001', 'Account 5-05-01-01-0001 created', '{"company_id": 3, "code": "5-05-01-01-0001", "name": "Bank Charges", "type": "expense", "parent_id": 462, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (615, 3, '2026-10-29 05:44:55.212241', 1, 'Administrator', 'create', 'accounting', 'Account', 519, '5-05-01-01-0002', 'Account 5-05-01-01-0002 created', '{"company_id": 3, "code": "5-05-01-01-0002", "name": "Interest Expense", "type": "expense", "parent_id": 462, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (616, 3, '2026-10-29 05:44:55.217052', 1, 'Administrator', 'create', 'accounting', 'Account', 520, '5-06-01-01-0001', 'Account 5-06-01-01-0001 created', '{"company_id": 3, "code": "5-06-01-01-0001", "name": "Income Tax Expense", "type": "expense", "parent_id": 465, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (617, 3, '2026-10-29 05:44:55.274301', 1, 'Administrator', 'create', 'settings', 'Company profile', 3, 'SolarKon Energy Solutions', 'Company profile SolarKon Energy Solutions created', '{"company_id": 3, "company_name": "SolarKon Energy Solutions", "country": "Pakistan", "fiscal_year_start_month": 1, "currency": "PKR", "currency_symbol": "Rs.", "date_format": "Y-m-d", "number_format": "en", "timezone": "Asia/Karachi"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (618, 3, '2026-10-29 05:44:55.286724', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 17, 'FY 2021', 'Accounting period FY 2021 created', '{"company_id": 3, "fiscal_year": "2021", "period_name": "FY 2021", "start_date": "2021-01-01", "end_date": "2021-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (619, 3, '2026-10-29 05:44:55.286729', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 18, 'FY 2022', 'Accounting period FY 2022 created', '{"company_id": 3, "fiscal_year": "2022", "period_name": "FY 2022", "start_date": "2022-01-01", "end_date": "2022-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (620, 3, '2026-10-29 05:44:55.286731', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 19, 'FY 2023', 'Accounting period FY 2023 created', '{"company_id": 3, "fiscal_year": "2023", "period_name": "FY 2023", "start_date": "2023-01-01", "end_date": "2023-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (621, 3, '2026-10-29 05:44:55.286732', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 20, 'FY 2024', 'Accounting period FY 2024 created', '{"company_id": 3, "fiscal_year": "2024", "period_name": "FY 2024", "start_date": "2024-01-01", "end_date": "2024-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (622, 3, '2026-10-29 05:44:55.286734', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 21, 'FY 2025', 'Accounting period FY 2025 created', '{"company_id": 3, "fiscal_year": "2025", "period_name": "FY 2025", "start_date": "2025-01-01", "end_date": "2025-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (623, 3, '2026-10-29 05:44:55.286735', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 22, 'FY 2026', 'Accounting period FY 2026 created', '{"company_id": 3, "fiscal_year": "2026", "period_name": "FY 2026", "start_date": "2026-01-01", "end_date": "2026-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (624, 3, '2026-10-29 05:44:55.286737', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 23, 'FY 2027', 'Accounting period FY 2027 created', '{"company_id": 3, "fiscal_year": "2027", "period_name": "FY 2027", "start_date": "2027-01-01", "end_date": "2027-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (625, 3, '2026-10-29 05:44:55.286739', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 24, 'FY 2028', 'Accounting period FY 2028 created', '{"company_id": 3, "fiscal_year": "2028", "period_name": "FY 2028", "start_date": "2028-01-01", "end_date": "2028-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (628, NULL, '2026-10-29 05:44:55.446033', 7, 'Owner.B.6603Bc', 'login', 'admin', NULL, NULL, NULL, 'Owner.B.6603Bc signed in', NULL, '127.0.0.1', '/auth/login');
INSERT INTO public.audit_logs VALUES (629, NULL, '2026-10-29 05:44:55.681131', 6, 'Owner.A.Db6E12', 'login', 'admin', NULL, NULL, NULL, 'Owner.A.Db6E12 signed in', NULL, '127.0.0.1', '/auth/login');
INSERT INTO public.audit_logs VALUES (630, 3, '2026-10-29 05:44:55.721882', 6, 'Owner.A.Db6E12', 'create', 'admin', 'Membership', 7, '6', 'Membership 6 created', '{"company_id": 3, "user_id": 6, "role_id": 3, "status": "active", "joined_at": "2026-10-29T05:44:55.711295", "module_flags": "{\"accounting\": false, \"executive\": false, \"fbr\": false, \"finance\": false, \"fixed_assets\": false, \"hr\": true, \"inventory\": false, \"invoicing\": false}"}', '127.0.0.1', '/settings/invitations/1/accept');
INSERT INTO public.audit_logs VALUES (631, 1, '2026-10-29 05:44:55.869733', 1, 'Administrator', 'create', 'admin', 'User', 8, 'restricted.a194de@ref.test', 'User restricted.a194de@ref.test created', '{"employee_code": "SA0008", "email": "restricted.a194de@ref.test", "login_id": "restricted.a194de@ref.test", "password_hash": "\u2022\u2022\u2022", "full_name": "Restricted Person", "role_id": 3, "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true}', '127.0.0.1', '/superadmin/users/');
INSERT INTO public.audit_logs VALUES (634, 3, '2026-10-29 05:44:56.109767', 7, 'Owner.B.6603Bc', 'update', 'admin', 'Membership', 8, '8', 'Membership 8 edited (module flags)', '[{"field": "module_flags", "old": "{\"accounting\": false, \"executive\": false, \"fbr\": false, \"finance\": false, \"fixed_assets\": false, \"hr\": true, \"inventory\": false, \"invoicing\": false}", "new": "{\"accounting\": true, \"executive\": false, \"fbr\": false, \"finance\": false, \"fixed_assets\": false, \"hr\": true, \"inventory\": false, \"invoicing\": false}"}]', '127.0.0.1', '/settings/users/8/rights');
INSERT INTO public.audit_logs VALUES (635, 1, '2026-10-29 05:44:56.260406', 1, 'Administrator', 'create', 'admin', 'User', 9, 'blocked.8a31c1@ref.test', 'User blocked.8a31c1@ref.test created', '{"employee_code": "SA0009", "email": "blocked.8a31c1@ref.test", "login_id": "blocked.8a31c1@ref.test", "password_hash": "\u2022\u2022\u2022", "full_name": "Blocked Person", "role_id": 3, "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true}', '127.0.0.1', '/superadmin/users/');
INSERT INTO public.audit_logs VALUES (638, 3, '2026-10-29 05:44:56.494183', 1, 'Administrator', 'update', 'admin', 'Membership', 9, '9', 'Membership 9 edited (status)', '[{"field": "status", "old": "active", "new": "blocked"}]', '127.0.0.1', '/superadmin/companies/3/members/9/block');
INSERT INTO public.audit_logs VALUES (639, NULL, '2026-10-29 05:45:00.704651', 7, 'Owner.B.6603Bc', 'login', 'admin', NULL, NULL, NULL, 'Owner.B.6603Bc signed in', NULL, '127.0.0.1', '/auth/login');
INSERT INTO public.audit_logs VALUES (640, NULL, '2026-10-29 05:45:00.862067', 6, 'Owner.A.Db6E12', 'login', 'admin', NULL, NULL, NULL, 'Owner.A.Db6E12 signed in', NULL, '127.0.0.1', '/auth/login');
INSERT INTO public.audit_logs VALUES (644, NULL, '2026-10-29 05:45:01.508312', NULL, NULL, 'update', 'admin', 'User', 6, 'owner.a.db6e12@ref.test', 'User owner.a.db6e12@ref.test edited (password hash)', '[{"field": "password_hash", "old": "\u2022\u2022\u2022", "new": "\u2022\u2022\u2022"}]', NULL, NULL);
INSERT INTO public.audit_logs VALUES (645, NULL, '2026-10-29 05:45:01.632709', 6, 'Owner.A.Db6E12', 'login', 'admin', NULL, NULL, NULL, 'Owner.A.Db6E12 signed in', NULL, '127.0.0.1', '/auth/login');
INSERT INTO public.audit_logs VALUES (626, 3, '2026-10-29 05:44:55.302634', 1, 'Administrator', 'create', 'settings', 'Report settings', 3, '3', 'Report settings 3 created', '{"company_id": 3, "pl_detail_rows": 10, "invoice_party_mode": "relevant", "purchase_party_mode": "relevant", "sales_party_mode": "relevant", "cash_flow_method": "indirect"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (627, 3, '2026-10-29 05:44:55.309061', 1, 'Administrator', 'create', 'inventory', 'Inventory settings', 3, '3', 'Inventory settings 3 created', '{"company_id": 3, "valuation_method": "weighted_average", "decimal_places": 4, "auto_generate_vouchers": true, "purchase_flow": "with_po", "sales_flow": "with_so"}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES (632, NULL, '2026-10-29 05:44:56.037751', 8, 'Restricted Person', 'login', 'admin', NULL, NULL, NULL, 'Restricted Person signed in', NULL, '127.0.0.1', '/auth/login');
INSERT INTO public.audit_logs VALUES (633, 3, '2026-10-29 05:44:56.069881', 8, 'Restricted Person', 'create', 'admin', 'Membership', 8, '8', 'Membership 8 created', '{"company_id": 3, "user_id": 8, "role_id": 2, "status": "active", "joined_at": "2026-10-29T05:44:56.068271", "module_flags": "{\"accounting\": false, \"executive\": false, \"fbr\": false, \"finance\": false, \"fixed_assets\": false, \"hr\": true, \"inventory\": false, \"invoicing\": false}"}', '127.0.0.1', '/settings/invitations/2/accept');
INSERT INTO public.audit_logs VALUES (636, NULL, '2026-10-29 05:44:56.428909', 9, 'Blocked Person', 'login', 'admin', NULL, NULL, NULL, 'Blocked Person signed in', NULL, '127.0.0.1', '/auth/login');
INSERT INTO public.audit_logs VALUES (637, 3, '2026-10-29 05:44:56.459395', 9, 'Blocked Person', 'create', 'admin', 'Membership', 9, '9', 'Membership 9 created', '{"company_id": 3, "user_id": 9, "role_id": 3, "status": "active", "joined_at": "2026-10-29T05:44:56.457175", "module_flags": "{\"accounting\": false, \"executive\": false, \"fbr\": false, \"finance\": false, \"fixed_assets\": false, \"hr\": true, \"inventory\": false, \"invoicing\": false}"}', '127.0.0.1', '/settings/invitations/3/accept');
INSERT INTO public.audit_logs VALUES (641, NULL, '2026-10-29 05:45:01.04466', 8, 'Restricted Person', 'login', 'admin', NULL, NULL, NULL, 'Restricted Person signed in', NULL, '127.0.0.1', '/auth/login');
INSERT INTO public.audit_logs VALUES (642, NULL, '2026-10-29 05:45:01.209', 9, 'Blocked Person', 'login', 'admin', NULL, NULL, NULL, 'Blocked Person signed in', NULL, '127.0.0.1', '/auth/login');
INSERT INTO public.audit_logs VALUES (643, NULL, '2026-10-29 05:45:01.360819', 6, 'Owner.A.Db6E12', 'login', 'admin', NULL, NULL, NULL, 'Owner.A.Db6E12 signed in', NULL, '127.0.0.1', '/auth/login');


--
-- Data for Name: bank_rec_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: bank_reconciliations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: break_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: button_permissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: category_revenue_accounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: change_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: charge_ledger_defaults; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.chart_of_accounts VALUES (1, 1, '1', 'Assets', 'asset', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.864592');
INSERT INTO public.chart_of_accounts VALUES (2, 1, '1-01', 'Current Assets', 'asset', 1, 2, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:48.875981');
INSERT INTO public.chart_of_accounts VALUES (3, 1, '1-01-01', 'Cash & Cash Equivalents', 'asset', 2, 3, true, true, NULL, 'cash', NULL, '2026-10-29 05:44:48.882528');
INSERT INTO public.chart_of_accounts VALUES (4, 1, '1-01-01-01', 'Cash in Hand', 'asset', 3, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.889119');
INSERT INTO public.chart_of_accounts VALUES (5, 1, '1-01-01-02', 'Bank Accounts', 'asset', 3, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.89594');
INSERT INTO public.chart_of_accounts VALUES (6, 1, '1-01-02', 'Trade Receivables', 'asset', 2, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.902343');
INSERT INTO public.chart_of_accounts VALUES (7, 1, '1-01-02-01', 'Trade Debtors', 'asset', 6, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.908632');
INSERT INTO public.chart_of_accounts VALUES (8, 1, '1-01-02-02', 'Doubtful Receivables', 'asset', 6, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.914889');
INSERT INTO public.chart_of_accounts VALUES (9, 1, '1-01-03', 'Other Receivables', 'asset', 2, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.921349');
INSERT INTO public.chart_of_accounts VALUES (10, 1, '1-01-03-01', 'Employee Loans & Advances', 'asset', 9, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.927599');
INSERT INTO public.chart_of_accounts VALUES (11, 1, '1-01-03-02', 'Advances to Suppliers', 'asset', 9, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.93386');
INSERT INTO public.chart_of_accounts VALUES (12, 1, '1-01-04', 'Inventories', 'asset', 2, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.940613');
INSERT INTO public.chart_of_accounts VALUES (13, 1, '1-01-04-01', 'Trading Goods Stock', 'asset', 12, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.946832');
INSERT INTO public.chart_of_accounts VALUES (14, 1, '1-01-05', 'Tax Assets', 'asset', 2, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.953029');
INSERT INTO public.chart_of_accounts VALUES (15, 1, '1-01-05-01', 'Input Sales Tax', 'asset', 14, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.959274');
INSERT INTO public.chart_of_accounts VALUES (16, 1, '1-01-05-02', 'WHT Receivable', 'asset', 14, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.965741');
INSERT INTO public.chart_of_accounts VALUES (17, 1, '1-01-06', 'Prepayments & Other', 'asset', 2, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.971976');
INSERT INTO public.chart_of_accounts VALUES (18, 1, '1-01-06-01', 'Suspense & Clearing', 'asset', 17, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.978177');
INSERT INTO public.chart_of_accounts VALUES (19, 1, '1-01-06-02', 'Prepaid Expenses', 'asset', 17, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.984728');
INSERT INTO public.chart_of_accounts VALUES (20, 1, '1-01-06-03', 'Other Current Assets', 'asset', 17, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:48.991214');
INSERT INTO public.chart_of_accounts VALUES (21, 1, '1-02', 'Non-Current Assets', 'asset', 1, 2, true, true, NULL, 'investing', NULL, '2026-10-29 05:44:48.997744');
INSERT INTO public.chart_of_accounts VALUES (22, 1, '1-02-01', 'Property, Plant & Equipment', 'asset', 21, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.004169');
INSERT INTO public.chart_of_accounts VALUES (23, 1, '1-02-01-01', 'Owned Assets', 'asset', 22, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.010743');
INSERT INTO public.chart_of_accounts VALUES (24, 1, '1-02-02', 'Accumulated Depreciation', 'asset', 21, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.01713');
INSERT INTO public.chart_of_accounts VALUES (25, 1, '1-02-02-01', 'Accumulated Depreciation', 'asset', 24, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.023465');
INSERT INTO public.chart_of_accounts VALUES (26, 1, '1-02-03', 'Intangible Assets', 'asset', 21, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.030014');
INSERT INTO public.chart_of_accounts VALUES (27, 1, '1-02-03-01', 'Intangibles', 'asset', 26, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.036366');
INSERT INTO public.chart_of_accounts VALUES (28, 1, '2', 'Liabilities', 'liability', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.040649');
INSERT INTO public.chart_of_accounts VALUES (29, 1, '2-01', 'Current Liabilities', 'liability', 28, 2, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:49.047029');
INSERT INTO public.chart_of_accounts VALUES (30, 1, '2-01-01', 'Trade Payables', 'liability', 29, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.053977');
INSERT INTO public.chart_of_accounts VALUES (31, 1, '2-01-01-01', 'Trade Creditors', 'liability', 30, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.060168');
INSERT INTO public.chart_of_accounts VALUES (32, 1, '2-01-02', 'Accrued & Payroll Liabilities', 'liability', 29, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.066371');
INSERT INTO public.chart_of_accounts VALUES (33, 1, '2-01-02-01', 'Employee Payables', 'liability', 32, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.072595');
INSERT INTO public.chart_of_accounts VALUES (34, 1, '2-01-02-02', 'Payroll Liabilities', 'liability', 32, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.078995');
INSERT INTO public.chart_of_accounts VALUES (35, 1, '2-01-02-03', 'Accrued Expenses', 'liability', 32, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.085209');
INSERT INTO public.chart_of_accounts VALUES (36, 1, '2-01-03', 'Tax Liabilities', 'liability', 29, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.091456');
INSERT INTO public.chart_of_accounts VALUES (37, 1, '2-01-03-01', 'Output Sales Tax', 'liability', 36, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.098319');
INSERT INTO public.chart_of_accounts VALUES (38, 1, '2-01-03-02', 'Income Tax Payable', 'liability', 36, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.104719');
INSERT INTO public.chart_of_accounts VALUES (39, 1, '2-01-03-03', 'WHT Payable', 'liability', 36, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.11129');
INSERT INTO public.chart_of_accounts VALUES (40, 1, '2-01-03-04', 'Further Tax Payable', 'liability', 36, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.117591');
INSERT INTO public.chart_of_accounts VALUES (41, 1, '2-01-04', 'Advances from Customers', 'liability', 29, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.123983');
INSERT INTO public.chart_of_accounts VALUES (42, 1, '2-01-04-01', 'Customer Advances', 'liability', 41, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.130296');
INSERT INTO public.chart_of_accounts VALUES (43, 1, '2-02', 'Non-Current Liabilities', 'liability', 28, 2, true, true, NULL, 'financing', NULL, '2026-10-29 05:44:49.136643');
INSERT INTO public.chart_of_accounts VALUES (44, 1, '2-02-01', 'Long-term Loans', 'liability', 43, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.143742');
INSERT INTO public.chart_of_accounts VALUES (45, 1, '2-02-01-01', 'Long-term Loans', 'liability', 44, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.150472');
INSERT INTO public.chart_of_accounts VALUES (46, 1, '2-02-02', 'Employee End-of-Service Benefits', 'liability', 43, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.156821');
INSERT INTO public.chart_of_accounts VALUES (47, 1, '2-02-02-01', 'EOSB Provision', 'liability', 46, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.163071');
INSERT INTO public.chart_of_accounts VALUES (48, 1, '3', 'Equity', 'equity', NULL, 1, true, true, NULL, 'financing', NULL, '2026-10-29 05:44:49.167276');
INSERT INTO public.chart_of_accounts VALUES (49, 1, '3-01', 'Capital', 'equity', 48, 2, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.173477');
INSERT INTO public.chart_of_accounts VALUES (50, 1, '3-01-01', 'Owner Capital', 'equity', 49, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.179724');
INSERT INTO public.chart_of_accounts VALUES (51, 1, '3-01-01-01', 'Owner Capital', 'equity', 50, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.185988');
INSERT INTO public.chart_of_accounts VALUES (52, 1, '3-02', 'Reserves & Retained Earnings', 'equity', 48, 2, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.192547');
INSERT INTO public.chart_of_accounts VALUES (53, 1, '3-02-01', 'Retained Earnings', 'equity', 52, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.199109');
INSERT INTO public.chart_of_accounts VALUES (54, 1, '3-02-01-01', 'Retained Earnings — Opening', 'equity', 53, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.20544');
INSERT INTO public.chart_of_accounts VALUES (55, 1, '3-02-01-02', 'Retained Earnings — Closing', 'equity', 53, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.212116');
INSERT INTO public.chart_of_accounts VALUES (56, 1, '3-02-02', 'Dividends', 'equity', 52, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.218476');
INSERT INTO public.chart_of_accounts VALUES (57, 1, '3-02-02-01', 'Dividends', 'equity', 56, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.224901');
INSERT INTO public.chart_of_accounts VALUES (58, 1, '3-02-03', 'Other Comprehensive Income', 'equity', 52, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.231105');
INSERT INTO public.chart_of_accounts VALUES (59, 1, '3-02-03-01', 'Other Comprehensive Income', 'equity', 58, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.237519');
INSERT INTO public.chart_of_accounts VALUES (60, 1, '4', 'Revenue', 'revenue', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:49.241507');
INSERT INTO public.chart_of_accounts VALUES (61, 1, '4-01', 'Sales', 'revenue', 60, 2, true, true, NULL, NULL, 'sales', '2026-10-29 05:44:49.247697');
INSERT INTO public.chart_of_accounts VALUES (62, 1, '4-01-01', 'Product Sales', 'revenue', 61, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.253933');
INSERT INTO public.chart_of_accounts VALUES (63, 1, '4-01-01-01', 'Product Sales', 'revenue', 62, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.260332');
INSERT INTO public.chart_of_accounts VALUES (64, 1, '4-01-02', 'Service Income', 'revenue', 61, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.266554');
INSERT INTO public.chart_of_accounts VALUES (65, 1, '4-01-02-01', 'Service Income', 'revenue', 64, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.272786');
INSERT INTO public.chart_of_accounts VALUES (66, 1, '4-02', 'Sales Returns & Discounts', 'revenue', 60, 2, true, true, NULL, NULL, 'sales_returns', '2026-10-29 05:44:49.279218');
INSERT INTO public.chart_of_accounts VALUES (67, 1, '4-02-01', 'Sales Returns', 'revenue', 66, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.285412');
INSERT INTO public.chart_of_accounts VALUES (68, 1, '4-02-01-01', 'Sales Returns', 'revenue', 67, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.291628');
INSERT INTO public.chart_of_accounts VALUES (69, 1, '4-02-02', 'Discounts Allowed', 'revenue', 66, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.297835');
INSERT INTO public.chart_of_accounts VALUES (70, 1, '4-02-02-01', 'Discounts Allowed', 'revenue', 69, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.304225');
INSERT INTO public.chart_of_accounts VALUES (71, 1, '4-03', 'Other Income', 'revenue', 60, 2, true, true, NULL, NULL, 'other_income', '2026-10-29 05:44:49.310469');
INSERT INTO public.chart_of_accounts VALUES (72, 1, '4-03-01', 'Other Income', 'revenue', 71, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.31682');
INSERT INTO public.chart_of_accounts VALUES (73, 1, '4-03-01-01', 'Other Income', 'revenue', 72, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.323357');
INSERT INTO public.chart_of_accounts VALUES (74, 1, '5', 'Expenses', 'expense', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:49.327418');
INSERT INTO public.chart_of_accounts VALUES (75, 1, '5-01', 'Cost of Sales', 'expense', 74, 2, true, true, NULL, NULL, 'cost_of_sales', '2026-10-29 05:44:49.333749');
INSERT INTO public.chart_of_accounts VALUES (76, 1, '5-01-01', 'Cost of Goods Sold', 'expense', 75, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.340124');
INSERT INTO public.chart_of_accounts VALUES (77, 1, '5-01-01-01', 'Cost of Goods Sold', 'expense', 76, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.346699');
INSERT INTO public.chart_of_accounts VALUES (78, 1, '5-01-02', 'Stock Losses, Scrap & Adjustments', 'expense', 75, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.353073');
INSERT INTO public.chart_of_accounts VALUES (79, 1, '5-01-02-01', 'Stock Losses & Scrap', 'expense', 78, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.359287');
INSERT INTO public.chart_of_accounts VALUES (80, 1, '5-02', 'Administrative Expenses', 'expense', 74, 2, true, true, NULL, NULL, 'admin', '2026-10-29 05:44:49.365567');
INSERT INTO public.chart_of_accounts VALUES (81, 1, '5-02-01', 'Salaries & Benefits', 'expense', 80, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.372482');
INSERT INTO public.chart_of_accounts VALUES (82, 1, '5-02-01-01', 'Salaries & Benefits', 'expense', 81, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.378709');
INSERT INTO public.chart_of_accounts VALUES (83, 1, '5-02-02', 'Rent & Utilities', 'expense', 80, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.385039');
INSERT INTO public.chart_of_accounts VALUES (84, 1, '5-02-02-01', 'Rent & Utilities', 'expense', 83, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.391618');
INSERT INTO public.chart_of_accounts VALUES (85, 1, '5-02-03', 'Office & Supplies', 'expense', 80, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.397966');
INSERT INTO public.chart_of_accounts VALUES (86, 1, '5-02-03-01', 'Office & Supplies', 'expense', 85, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.404267');
INSERT INTO public.chart_of_accounts VALUES (87, 1, '5-02-04', 'Depreciation & Amortisation', 'expense', 80, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.410585');
INSERT INTO public.chart_of_accounts VALUES (88, 1, '5-02-04-01', 'Depreciation & Amortisation', 'expense', 87, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.417355');
INSERT INTO public.chart_of_accounts VALUES (89, 1, '5-02-05', 'Fees, Taxes & Licenses', 'expense', 80, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.423647');
INSERT INTO public.chart_of_accounts VALUES (90, 1, '5-02-05-01', 'Fees, Taxes & Licenses', 'expense', 89, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.432689');
INSERT INTO public.chart_of_accounts VALUES (91, 1, '5-03', 'Selling & Distribution', 'expense', 74, 2, true, true, NULL, NULL, 'selling_distribution', '2026-10-29 05:44:49.469067');
INSERT INTO public.chart_of_accounts VALUES (92, 1, '5-03-01', 'Freight & Transportation', 'expense', 91, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.475887');
INSERT INTO public.chart_of_accounts VALUES (93, 1, '5-03-01-01', 'Freight & Transportation', 'expense', 92, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.482627');
INSERT INTO public.chart_of_accounts VALUES (94, 1, '5-03-02', 'Commissions', 'expense', 91, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.489142');
INSERT INTO public.chart_of_accounts VALUES (95, 1, '5-03-02-01', 'Commissions', 'expense', 94, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.495673');
INSERT INTO public.chart_of_accounts VALUES (96, 1, '5-03-03', 'Marketing & Advertising', 'expense', 91, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.502016');
INSERT INTO public.chart_of_accounts VALUES (97, 1, '5-03-03-01', 'Marketing & Advertising', 'expense', 96, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.508278');
INSERT INTO public.chart_of_accounts VALUES (98, 1, '5-04', 'Other Operating Expenses', 'expense', 74, 2, true, true, NULL, NULL, 'other_operating', '2026-10-29 05:44:49.514702');
INSERT INTO public.chart_of_accounts VALUES (99, 1, '5-04-01', 'Other Operating Expenses', 'expense', 98, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.520938');
INSERT INTO public.chart_of_accounts VALUES (100, 1, '5-04-01-01', 'Other Operating Expenses', 'expense', 99, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.527156');
INSERT INTO public.chart_of_accounts VALUES (101, 1, '5-05', 'Finance Costs', 'expense', 74, 2, true, true, NULL, NULL, 'finance_cost', '2026-10-29 05:44:49.533457');
INSERT INTO public.chart_of_accounts VALUES (102, 1, '5-05-01', 'Bank & Interest Charges', 'expense', 101, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.540034');
INSERT INTO public.chart_of_accounts VALUES (103, 1, '5-05-01-01', 'Bank & Interest Charges', 'expense', 102, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.546393');
INSERT INTO public.chart_of_accounts VALUES (104, 1, '5-06', 'Taxation', 'expense', 74, 2, true, true, NULL, NULL, 'income_tax', '2026-10-29 05:44:49.552803');
INSERT INTO public.chart_of_accounts VALUES (105, 1, '5-06-01', 'Income Tax', 'expense', 104, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.559332');
INSERT INTO public.chart_of_accounts VALUES (106, 1, '5-06-01-01', 'Income Tax', 'expense', 105, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:49.565656');
INSERT INTO public.chart_of_accounts VALUES (107, 1, '1-01-01-01-0001', 'Main Cash', 'asset', 4, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.576606');
INSERT INTO public.chart_of_accounts VALUES (108, 1, '1-01-02-01-0001', 'Trade Debtors — General', 'asset', 7, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.582905');
INSERT INTO public.chart_of_accounts VALUES (109, 1, '1-01-03-02-0001', 'Advances to Suppliers — General', 'asset', 11, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.58919');
INSERT INTO public.chart_of_accounts VALUES (110, 1, '1-01-04-01-0001', 'Stock — General', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.5957');
INSERT INTO public.chart_of_accounts VALUES (111, 1, '1-01-05-01-0001', 'Input Sales Tax', 'asset', 15, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.602123');
INSERT INTO public.chart_of_accounts VALUES (112, 1, '1-01-05-02-0001', 'WHT Receivable', 'asset', 16, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.608596');
INSERT INTO public.chart_of_accounts VALUES (113, 1, '1-01-06-01-0001', 'Suspense Account', 'asset', 18, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.615051');
INSERT INTO public.chart_of_accounts VALUES (114, 1, '1-01-06-02-0001', 'Prepaid Expenses — General', 'asset', 19, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.621381');
INSERT INTO public.chart_of_accounts VALUES (115, 1, '1-02-01-01-0001', 'Fixed Assets — General', 'asset', 23, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.627773');
INSERT INTO public.chart_of_accounts VALUES (116, 1, '1-02-02-01-0001', 'Accumulated Depreciation — General', 'asset', 25, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.634176');
INSERT INTO public.chart_of_accounts VALUES (117, 1, '1-02-03-01-0001', 'Intangibles — General', 'asset', 27, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.640693');
INSERT INTO public.chart_of_accounts VALUES (118, 1, '2-01-01-01-0001', 'Trade Creditors — General', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.647027');
INSERT INTO public.chart_of_accounts VALUES (119, 1, '2-01-02-02-0001', 'Salary Payable', 'liability', 34, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.653347');
INSERT INTO public.chart_of_accounts VALUES (120, 1, '2-01-02-02-0002', 'PF Payable', 'liability', 34, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.659843');
INSERT INTO public.chart_of_accounts VALUES (121, 1, '2-01-02-02-0003', 'Loan Deductions Clearing', 'liability', 34, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.666219');
INSERT INTO public.chart_of_accounts VALUES (122, 1, '2-01-02-02-0004', 'Other Payroll Deductions Payable', 'liability', 34, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.672585');
INSERT INTO public.chart_of_accounts VALUES (123, 1, '2-01-02-03-0001', 'Accrued Expenses — General', 'liability', 35, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.678944');
INSERT INTO public.chart_of_accounts VALUES (124, 1, '2-01-03-01-0001', 'Output Sales Tax', 'liability', 37, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.685519');
INSERT INTO public.chart_of_accounts VALUES (125, 1, '2-01-03-02-0001', 'Income Tax Payable', 'liability', 38, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.691856');
INSERT INTO public.chart_of_accounts VALUES (126, 1, '2-01-03-03-0001', 'WHT Payable', 'liability', 39, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.698121');
INSERT INTO public.chart_of_accounts VALUES (127, 1, '2-01-03-04-0001', 'Further Tax Payable', 'liability', 40, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.705');
INSERT INTO public.chart_of_accounts VALUES (128, 1, '2-01-04-01-0001', 'Customer Advances — General', 'liability', 42, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.711563');
INSERT INTO public.chart_of_accounts VALUES (129, 1, '2-02-01-01-0001', 'Long-term Loans — General', 'liability', 45, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.717951');
INSERT INTO public.chart_of_accounts VALUES (130, 1, '2-02-02-01-0001', 'EOSB Provision — General', 'liability', 47, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.724347');
INSERT INTO public.chart_of_accounts VALUES (131, 1, '3-01-01-01-0001', 'Share Capital', 'equity', 51, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.730959');
INSERT INTO public.chart_of_accounts VALUES (132, 1, '3-01-01-01-0002', 'Suspense Equity', 'equity', 51, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.737325');
INSERT INTO public.chart_of_accounts VALUES (133, 1, '3-02-01-01-0001', 'Retained Earnings — Opening', 'equity', 54, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.743673');
INSERT INTO public.chart_of_accounts VALUES (134, 1, '3-02-01-02-0001', 'Retained Earnings — Closing', 'equity', 55, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.75022');
INSERT INTO public.chart_of_accounts VALUES (135, 1, '3-02-02-01-0001', 'Dividends', 'equity', 57, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.756548');
INSERT INTO public.chart_of_accounts VALUES (136, 1, '3-02-03-01-0001', 'Other Comprehensive Income', 'equity', 59, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.762842');
INSERT INTO public.chart_of_accounts VALUES (137, 1, '4-01-01-01-0001', 'Sales — General', 'revenue', 63, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.769198');
INSERT INTO public.chart_of_accounts VALUES (138, 1, '4-01-02-01-0001', 'Service Income — General', 'revenue', 65, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.775715');
INSERT INTO public.chart_of_accounts VALUES (139, 1, '4-02-01-01-0001', 'Sales Returns — General', 'revenue', 68, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.781964');
INSERT INTO public.chart_of_accounts VALUES (140, 1, '4-02-02-01-0001', 'Discounts Allowed — General', 'revenue', 70, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.788204');
INSERT INTO public.chart_of_accounts VALUES (141, 1, '4-03-01-01-0001', 'Other Income — General', 'revenue', 73, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.794621');
INSERT INTO public.chart_of_accounts VALUES (142, 1, '5-01-01-01-0001', 'Cost of Goods Sold', 'expense', 77, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.800869');
INSERT INTO public.chart_of_accounts VALUES (143, 1, '5-01-02-01-0001', 'Scrap / Write-off', 'expense', 79, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.807102');
INSERT INTO public.chart_of_accounts VALUES (144, 1, '5-01-02-01-0002', 'Inventory Adjustment', 'expense', 79, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.81334');
INSERT INTO public.chart_of_accounts VALUES (145, 1, '5-01-02-01-0003', 'Consumption Expense', 'expense', 79, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.819748');
INSERT INTO public.chart_of_accounts VALUES (146, 1, '5-01-02-01-0004', 'Inventory Cost Variance', 'expense', 79, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.826114');
INSERT INTO public.chart_of_accounts VALUES (147, 1, '5-02-01-01-0001', 'Salary Expense', 'expense', 82, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.832698');
INSERT INTO public.chart_of_accounts VALUES (148, 1, '5-02-01-01-0002', 'PF Employer Expense', 'expense', 82, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.839146');
INSERT INTO public.chart_of_accounts VALUES (149, 1, '5-02-02-01-0001', 'Rent Expense', 'expense', 84, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.845421');
INSERT INTO public.chart_of_accounts VALUES (150, 1, '5-02-02-01-0002', 'Utilities Expense', 'expense', 84, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.851748');
INSERT INTO public.chart_of_accounts VALUES (151, 1, '5-02-03-01-0001', 'Office Supplies', 'expense', 86, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.858013');
INSERT INTO public.chart_of_accounts VALUES (152, 1, '5-02-04-01-0001', 'Depreciation Expense', 'expense', 88, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.864563');
INSERT INTO public.chart_of_accounts VALUES (153, 1, '5-02-05-01-0001', 'Fees, Taxes & Licenses — General', 'expense', 90, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.870899');
INSERT INTO public.chart_of_accounts VALUES (154, 1, '5-03-01-01-0001', 'Freight & Transportation — General', 'expense', 93, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.87733');
INSERT INTO public.chart_of_accounts VALUES (155, 1, '5-03-02-01-0001', 'Commissions — General', 'expense', 95, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.883845');
INSERT INTO public.chart_of_accounts VALUES (156, 1, '5-03-03-01-0001', 'Marketing & Advertising — General', 'expense', 97, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.890191');
INSERT INTO public.chart_of_accounts VALUES (157, 1, '5-04-01-01-0001', 'Other Expenses — General', 'expense', 100, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.896539');
INSERT INTO public.chart_of_accounts VALUES (158, 1, '5-04-01-01-0002', 'Loss/(Gain) on Disposal of Fixed Assets', 'expense', 100, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.902778');
INSERT INTO public.chart_of_accounts VALUES (159, 1, '5-05-01-01-0001', 'Bank Charges', 'expense', 103, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.909182');
INSERT INTO public.chart_of_accounts VALUES (160, 1, '5-05-01-01-0002', 'Interest Expense', 'expense', 103, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.915417');
INSERT INTO public.chart_of_accounts VALUES (161, 1, '5-06-01-01-0001', 'Income Tax Expense', 'expense', 106, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:49.921653');
INSERT INTO public.chart_of_accounts VALUES (162, 1, '2-01-01-01-0101', 'Longi Solar Pakistan', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.867744');
INSERT INTO public.chart_of_accounts VALUES (163, 1, '2-01-01-01-0102', 'JA Solar Technologies', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.87437');
INSERT INTO public.chart_of_accounts VALUES (164, 1, '2-01-01-01-0103', 'BYD Energy Solutions', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.880715');
INSERT INTO public.chart_of_accounts VALUES (165, 1, '2-01-01-01-0104', 'Growatt Inverters', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.887345');
INSERT INTO public.chart_of_accounts VALUES (166, 1, '2-01-01-01-0105', 'Al-Rashid Traders', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.893724');
INSERT INTO public.chart_of_accounts VALUES (167, 1, '2-01-01-01-0106', 'Pakistan Cable Co.', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.900031');
INSERT INTO public.chart_of_accounts VALUES (168, 1, '1-01-02-01-0101', 'SolarTech Solutions', 'asset', 7, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.909871');
INSERT INTO public.chart_of_accounts VALUES (169, 1, '1-01-02-01-0102', 'Green Energy Pakistan', 'asset', 7, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.916257');
INSERT INTO public.chart_of_accounts VALUES (170, 1, '1-01-02-01-0103', 'BuildRight Construction', 'asset', 7, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.92256');
INSERT INTO public.chart_of_accounts VALUES (171, 1, '1-01-02-01-0104', 'Home Solutions Ltd.', 'asset', 7, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.929055');
INSERT INTO public.chart_of_accounts VALUES (172, 1, '1-01-04-01-0101', 'Monocrystalline Solar Panel 450W (SOL-MONO-450)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.939164');
INSERT INTO public.chart_of_accounts VALUES (173, 1, '1-01-04-01-0102', 'Monocrystalline Solar Panel 550W (SOL-MONO-550)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.945773');
INSERT INTO public.chart_of_accounts VALUES (174, 1, '1-01-04-01-0103', 'Polycrystalline Solar Panel 330W (SOL-POLY-330)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.952187');
INSERT INTO public.chart_of_accounts VALUES (175, 1, '1-01-04-01-0104', '5kW Hybrid Inverter (INV-5KW)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.958578');
INSERT INTO public.chart_of_accounts VALUES (176, 1, '1-01-04-01-0105', '10kW Hybrid Inverter (INV-10KW)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.965132');
INSERT INTO public.chart_of_accounts VALUES (177, 1, '1-01-04-01-0106', '3kW String Inverter (INV-3KW)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.971482');
INSERT INTO public.chart_of_accounts VALUES (178, 1, '1-01-04-01-0107', '5kWh LiFePO4 Battery (BAT-LFP-5KWH)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.977818');
INSERT INTO public.chart_of_accounts VALUES (179, 1, '1-01-04-01-0108', '10kWh LiFePO4 Battery (BAT-LFP-10KWH)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.984198');
INSERT INTO public.chart_of_accounts VALUES (180, 1, '1-01-04-01-0109', '200Ah Tubular Battery (BAT-TUB-200)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.990751');
INSERT INTO public.chart_of_accounts VALUES (181, 1, '1-01-04-01-0110', 'Solar DC Cable 4mm (per meter) (CBL-SOL-4MM)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:50.997174');
INSERT INTO public.chart_of_accounts VALUES (182, 1, '1-01-04-01-0111', 'AC Cable 2.5mm (per meter) (CBL-AC-2.5MM)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.003524');
INSERT INTO public.chart_of_accounts VALUES (183, 1, '1-01-04-01-0112', 'MC4 Connector Pair (CBL-MC4)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.009851');
INSERT INTO public.chart_of_accounts VALUES (184, 1, '1-01-04-01-0113', 'Aluminum Mounting Rack (set) (MNT-ALU-RACK)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.016375');
INSERT INTO public.chart_of_accounts VALUES (185, 1, '1-01-04-01-0114', 'Mounting Rail 2m (MNT-RAIL-2M)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.022704');
INSERT INTO public.chart_of_accounts VALUES (186, 1, '1-01-04-01-0115', 'Distribution Board 16-way (ELEC-DB)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.029328');
INSERT INTO public.chart_of_accounts VALUES (187, 1, '1-01-04-01-0116', 'Surge Protection Device (ELEC-SPD)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.038992');
INSERT INTO public.chart_of_accounts VALUES (188, 1, '1-01-04-01-0117', 'MCB 16A Single Pole (ELEC-MCB-16A)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.045587');
INSERT INTO public.chart_of_accounts VALUES (189, 1, '1-01-04-01-0118', 'Solar Crimping Tool (TOOL-CRIMP)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.051895');
INSERT INTO public.chart_of_accounts VALUES (190, 1, '1-01-04-01-0119', 'Digital Multimeter (TOOL-MULTI)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.058131');
INSERT INTO public.chart_of_accounts VALUES (191, 1, '1-01-04-01-0120', 'Safety Helmet (SAFE-HLMT)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.064342');
INSERT INTO public.chart_of_accounts VALUES (192, 1, '1-01-04-01-0121', 'Insulated Gloves (pair) (SAFE-GLOVES)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.071633');
INSERT INTO public.chart_of_accounts VALUES (193, 1, '1-01-04-01-0122', 'Safety Harness (SAFE-HARNESS)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.077813');
INSERT INTO public.chart_of_accounts VALUES (194, 1, '2-01-02-01-0101', 'Administrator (SYSADMIN)', 'liability', 33, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.08758');
INSERT INTO public.chart_of_accounts VALUES (195, 1, '2-01-02-01-0102', 'System Admin (ADM001)', 'liability', 33, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.097513');
INSERT INTO public.chart_of_accounts VALUES (196, 1, '2-01-02-01-0103', 'Manager User (MGR002)', 'liability', 33, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.106365');
INSERT INTO public.chart_of_accounts VALUES (197, 1, '2-01-02-01-0104', 'Employee User (EMP001)', 'liability', 33, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.115094');
INSERT INTO public.chart_of_accounts VALUES (198, 1, '2-01-02-01-0105', 'John Doe (EMP002)', 'liability', 33, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:51.123893');
INSERT INTO public.chart_of_accounts VALUES (199, 2, '1', 'Assets', 'asset', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.88434');
INSERT INTO public.chart_of_accounts VALUES (200, 2, '1-01', 'Current Assets', 'asset', 199, 2, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:52.896164');
INSERT INTO public.chart_of_accounts VALUES (201, 2, '1-01-01', 'Cash & Cash Equivalents', 'asset', 200, 3, true, true, NULL, 'cash', NULL, '2026-10-29 05:44:52.902644');
INSERT INTO public.chart_of_accounts VALUES (202, 2, '1-01-01-01', 'Cash in Hand', 'asset', 201, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.909268');
INSERT INTO public.chart_of_accounts VALUES (203, 2, '1-01-01-02', 'Bank Accounts', 'asset', 201, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.915706');
INSERT INTO public.chart_of_accounts VALUES (204, 2, '1-01-02', 'Trade Receivables', 'asset', 200, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.922076');
INSERT INTO public.chart_of_accounts VALUES (205, 2, '1-01-02-01', 'Trade Debtors', 'asset', 204, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.930093');
INSERT INTO public.chart_of_accounts VALUES (206, 2, '1-01-02-02', 'Doubtful Receivables', 'asset', 204, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.936445');
INSERT INTO public.chart_of_accounts VALUES (207, 2, '1-01-03', 'Other Receivables', 'asset', 200, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.942772');
INSERT INTO public.chart_of_accounts VALUES (208, 2, '1-01-03-01', 'Employee Loans & Advances', 'asset', 207, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.949428');
INSERT INTO public.chart_of_accounts VALUES (209, 2, '1-01-03-02', 'Advances to Suppliers', 'asset', 207, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.95586');
INSERT INTO public.chart_of_accounts VALUES (210, 2, '1-01-04', 'Inventories', 'asset', 200, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.962094');
INSERT INTO public.chart_of_accounts VALUES (211, 2, '1-01-04-01', 'Trading Goods Stock', 'asset', 210, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.96836');
INSERT INTO public.chart_of_accounts VALUES (212, 2, '1-01-05', 'Tax Assets', 'asset', 200, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.974742');
INSERT INTO public.chart_of_accounts VALUES (213, 2, '1-01-05-01', 'Input Sales Tax', 'asset', 212, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.980932');
INSERT INTO public.chart_of_accounts VALUES (214, 2, '1-01-05-02', 'WHT Receivable', 'asset', 212, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.98712');
INSERT INTO public.chart_of_accounts VALUES (215, 2, '1-01-06', 'Prepayments & Other', 'asset', 200, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.993342');
INSERT INTO public.chart_of_accounts VALUES (216, 2, '1-01-06-01', 'Suspense & Clearing', 'asset', 215, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:52.999682');
INSERT INTO public.chart_of_accounts VALUES (217, 2, '1-01-06-02', 'Prepaid Expenses', 'asset', 215, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.005986');
INSERT INTO public.chart_of_accounts VALUES (218, 2, '1-01-06-03', 'Other Current Assets', 'asset', 215, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.012195');
INSERT INTO public.chart_of_accounts VALUES (219, 2, '1-02', 'Non-Current Assets', 'asset', 199, 2, true, true, NULL, 'investing', NULL, '2026-10-29 05:44:53.018692');
INSERT INTO public.chart_of_accounts VALUES (220, 2, '1-02-01', 'Property, Plant & Equipment', 'asset', 219, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.025031');
INSERT INTO public.chart_of_accounts VALUES (221, 2, '1-02-01-01', 'Owned Assets', 'asset', 220, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.031368');
INSERT INTO public.chart_of_accounts VALUES (222, 2, '1-02-02', 'Accumulated Depreciation', 'asset', 219, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.03774');
INSERT INTO public.chart_of_accounts VALUES (223, 2, '1-02-02-01', 'Accumulated Depreciation', 'asset', 222, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.04427');
INSERT INTO public.chart_of_accounts VALUES (224, 2, '1-02-03', 'Intangible Assets', 'asset', 219, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.05065');
INSERT INTO public.chart_of_accounts VALUES (225, 2, '1-02-03-01', 'Intangibles', 'asset', 224, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.056905');
INSERT INTO public.chart_of_accounts VALUES (226, 2, '2', 'Liabilities', 'liability', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.061024');
INSERT INTO public.chart_of_accounts VALUES (227, 2, '2-01', 'Current Liabilities', 'liability', 226, 2, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:53.067365');
INSERT INTO public.chart_of_accounts VALUES (228, 2, '2-01-01', 'Trade Payables', 'liability', 227, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.073582');
INSERT INTO public.chart_of_accounts VALUES (229, 2, '2-01-01-01', 'Trade Creditors', 'liability', 228, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.080085');
INSERT INTO public.chart_of_accounts VALUES (230, 2, '2-01-02', 'Accrued & Payroll Liabilities', 'liability', 227, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.086715');
INSERT INTO public.chart_of_accounts VALUES (231, 2, '2-01-02-01', 'Employee Payables', 'liability', 230, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.093053');
INSERT INTO public.chart_of_accounts VALUES (232, 2, '2-01-02-02', 'Payroll Liabilities', 'liability', 230, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.099286');
INSERT INTO public.chart_of_accounts VALUES (233, 2, '2-01-02-03', 'Accrued Expenses', 'liability', 230, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.105684');
INSERT INTO public.chart_of_accounts VALUES (234, 2, '2-01-03', 'Tax Liabilities', 'liability', 227, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.112195');
INSERT INTO public.chart_of_accounts VALUES (235, 2, '2-01-03-01', 'Output Sales Tax', 'liability', 234, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.118496');
INSERT INTO public.chart_of_accounts VALUES (236, 2, '2-01-03-02', 'Income Tax Payable', 'liability', 234, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.124815');
INSERT INTO public.chart_of_accounts VALUES (237, 2, '2-01-03-03', 'WHT Payable', 'liability', 234, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.131317');
INSERT INTO public.chart_of_accounts VALUES (238, 2, '2-01-03-04', 'Further Tax Payable', 'liability', 234, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.13763');
INSERT INTO public.chart_of_accounts VALUES (239, 2, '2-01-04', 'Advances from Customers', 'liability', 227, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.14395');
INSERT INTO public.chart_of_accounts VALUES (240, 2, '2-01-04-01', 'Customer Advances', 'liability', 239, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.150281');
INSERT INTO public.chart_of_accounts VALUES (241, 2, '2-02', 'Non-Current Liabilities', 'liability', 226, 2, true, true, NULL, 'financing', NULL, '2026-10-29 05:44:53.156971');
INSERT INTO public.chart_of_accounts VALUES (242, 2, '2-02-01', 'Long-term Loans', 'liability', 241, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.163354');
INSERT INTO public.chart_of_accounts VALUES (243, 2, '2-02-01-01', 'Long-term Loans', 'liability', 242, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.169772');
INSERT INTO public.chart_of_accounts VALUES (244, 2, '2-02-02', 'Employee End-of-Service Benefits', 'liability', 241, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.176339');
INSERT INTO public.chart_of_accounts VALUES (245, 2, '2-02-02-01', 'EOSB Provision', 'liability', 244, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.182718');
INSERT INTO public.chart_of_accounts VALUES (246, 2, '3', 'Equity', 'equity', NULL, 1, true, true, NULL, 'financing', NULL, '2026-10-29 05:44:53.186997');
INSERT INTO public.chart_of_accounts VALUES (247, 2, '3-01', 'Capital', 'equity', 246, 2, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.193409');
INSERT INTO public.chart_of_accounts VALUES (248, 2, '3-01-01', 'Owner Capital', 'equity', 247, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.200142');
INSERT INTO public.chart_of_accounts VALUES (249, 2, '3-01-01-01', 'Owner Capital', 'equity', 248, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.206624');
INSERT INTO public.chart_of_accounts VALUES (250, 2, '3-02', 'Reserves & Retained Earnings', 'equity', 246, 2, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.21299');
INSERT INTO public.chart_of_accounts VALUES (251, 2, '3-02-01', 'Retained Earnings', 'equity', 250, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.219399');
INSERT INTO public.chart_of_accounts VALUES (252, 2, '3-02-01-01', 'Retained Earnings — Opening', 'equity', 251, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.225918');
INSERT INTO public.chart_of_accounts VALUES (253, 2, '3-02-01-02', 'Retained Earnings — Closing', 'equity', 251, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.232293');
INSERT INTO public.chart_of_accounts VALUES (254, 2, '3-02-02', 'Dividends', 'equity', 250, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.238646');
INSERT INTO public.chart_of_accounts VALUES (255, 2, '3-02-02-01', 'Dividends', 'equity', 254, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.245188');
INSERT INTO public.chart_of_accounts VALUES (256, 2, '3-02-03', 'Other Comprehensive Income', 'equity', 250, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.251742');
INSERT INTO public.chart_of_accounts VALUES (257, 2, '3-02-03-01', 'Other Comprehensive Income', 'equity', 256, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.25807');
INSERT INTO public.chart_of_accounts VALUES (258, 2, '4', 'Revenue', 'revenue', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:53.262136');
INSERT INTO public.chart_of_accounts VALUES (259, 2, '4-01', 'Sales', 'revenue', 258, 2, true, true, NULL, NULL, 'sales', '2026-10-29 05:44:53.268516');
INSERT INTO public.chart_of_accounts VALUES (260, 2, '4-01-01', 'Product Sales', 'revenue', 259, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.274811');
INSERT INTO public.chart_of_accounts VALUES (261, 2, '4-01-01-01', 'Product Sales', 'revenue', 260, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.281108');
INSERT INTO public.chart_of_accounts VALUES (262, 2, '4-01-02', 'Service Income', 'revenue', 259, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.287409');
INSERT INTO public.chart_of_accounts VALUES (263, 2, '4-01-02-01', 'Service Income', 'revenue', 262, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.293839');
INSERT INTO public.chart_of_accounts VALUES (264, 2, '4-02', 'Sales Returns & Discounts', 'revenue', 258, 2, true, true, NULL, NULL, 'sales_returns', '2026-10-29 05:44:53.300112');
INSERT INTO public.chart_of_accounts VALUES (265, 2, '4-02-01', 'Sales Returns', 'revenue', 264, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.306473');
INSERT INTO public.chart_of_accounts VALUES (266, 2, '4-02-01-01', 'Sales Returns', 'revenue', 265, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.313247');
INSERT INTO public.chart_of_accounts VALUES (267, 2, '4-02-02', 'Discounts Allowed', 'revenue', 264, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.319517');
INSERT INTO public.chart_of_accounts VALUES (268, 2, '4-02-02-01', 'Discounts Allowed', 'revenue', 267, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.325853');
INSERT INTO public.chart_of_accounts VALUES (269, 2, '4-03', 'Other Income', 'revenue', 258, 2, true, true, NULL, NULL, 'other_income', '2026-10-29 05:44:53.332371');
INSERT INTO public.chart_of_accounts VALUES (270, 2, '4-03-01', 'Other Income', 'revenue', 269, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.338818');
INSERT INTO public.chart_of_accounts VALUES (271, 2, '4-03-01-01', 'Other Income', 'revenue', 270, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.345131');
INSERT INTO public.chart_of_accounts VALUES (272, 2, '5', 'Expenses', 'expense', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:53.349172');
INSERT INTO public.chart_of_accounts VALUES (273, 2, '5-01', 'Cost of Sales', 'expense', 272, 2, true, true, NULL, NULL, 'cost_of_sales', '2026-10-29 05:44:53.355405');
INSERT INTO public.chart_of_accounts VALUES (274, 2, '5-01-01', 'Cost of Goods Sold', 'expense', 273, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.361824');
INSERT INTO public.chart_of_accounts VALUES (275, 2, '5-01-01-01', 'Cost of Goods Sold', 'expense', 274, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.368086');
INSERT INTO public.chart_of_accounts VALUES (276, 2, '5-01-02', 'Stock Losses, Scrap & Adjustments', 'expense', 273, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.374359');
INSERT INTO public.chart_of_accounts VALUES (277, 2, '5-01-02-01', 'Stock Losses & Scrap', 'expense', 276, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.380943');
INSERT INTO public.chart_of_accounts VALUES (278, 2, '5-02', 'Administrative Expenses', 'expense', 272, 2, true, true, NULL, NULL, 'admin', '2026-10-29 05:44:53.387364');
INSERT INTO public.chart_of_accounts VALUES (279, 2, '5-02-01', 'Salaries & Benefits', 'expense', 278, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.39379');
INSERT INTO public.chart_of_accounts VALUES (280, 2, '5-02-01-01', 'Salaries & Benefits', 'expense', 279, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.400118');
INSERT INTO public.chart_of_accounts VALUES (281, 2, '5-02-02', 'Rent & Utilities', 'expense', 278, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.406651');
INSERT INTO public.chart_of_accounts VALUES (282, 2, '5-02-02-01', 'Rent & Utilities', 'expense', 281, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.41299');
INSERT INTO public.chart_of_accounts VALUES (283, 2, '5-02-03', 'Office & Supplies', 'expense', 278, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.419391');
INSERT INTO public.chart_of_accounts VALUES (284, 2, '5-02-03-01', 'Office & Supplies', 'expense', 283, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.42595');
INSERT INTO public.chart_of_accounts VALUES (285, 2, '5-02-04', 'Depreciation & Amortisation', 'expense', 278, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.432493');
INSERT INTO public.chart_of_accounts VALUES (286, 2, '5-02-04-01', 'Depreciation & Amortisation', 'expense', 285, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.438797');
INSERT INTO public.chart_of_accounts VALUES (287, 2, '5-02-05', 'Fees, Taxes & Licenses', 'expense', 278, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.445132');
INSERT INTO public.chart_of_accounts VALUES (288, 2, '5-02-05-01', 'Fees, Taxes & Licenses', 'expense', 287, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.451634');
INSERT INTO public.chart_of_accounts VALUES (289, 2, '5-03', 'Selling & Distribution', 'expense', 272, 2, true, true, NULL, NULL, 'selling_distribution', '2026-10-29 05:44:53.458029');
INSERT INTO public.chart_of_accounts VALUES (290, 2, '5-03-01', 'Freight & Transportation', 'expense', 289, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.4644');
INSERT INTO public.chart_of_accounts VALUES (291, 2, '5-03-01-01', 'Freight & Transportation', 'expense', 290, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.471226');
INSERT INTO public.chart_of_accounts VALUES (292, 2, '5-03-02', 'Commissions', 'expense', 289, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.47753');
INSERT INTO public.chart_of_accounts VALUES (293, 2, '5-03-02-01', 'Commissions', 'expense', 292, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.483829');
INSERT INTO public.chart_of_accounts VALUES (294, 2, '5-03-03', 'Marketing & Advertising', 'expense', 289, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.490638');
INSERT INTO public.chart_of_accounts VALUES (295, 2, '5-03-03-01', 'Marketing & Advertising', 'expense', 294, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.497209');
INSERT INTO public.chart_of_accounts VALUES (296, 2, '5-04', 'Other Operating Expenses', 'expense', 272, 2, true, true, NULL, NULL, 'other_operating', '2026-10-29 05:44:53.503589');
INSERT INTO public.chart_of_accounts VALUES (297, 2, '5-04-01', 'Other Operating Expenses', 'expense', 296, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.509942');
INSERT INTO public.chart_of_accounts VALUES (298, 2, '5-04-01-01', 'Other Operating Expenses', 'expense', 297, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.516403');
INSERT INTO public.chart_of_accounts VALUES (299, 2, '5-05', 'Finance Costs', 'expense', 272, 2, true, true, NULL, NULL, 'finance_cost', '2026-10-29 05:44:53.52265');
INSERT INTO public.chart_of_accounts VALUES (300, 2, '5-05-01', 'Bank & Interest Charges', 'expense', 299, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.528897');
INSERT INTO public.chart_of_accounts VALUES (301, 2, '5-05-01-01', 'Bank & Interest Charges', 'expense', 300, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.53516');
INSERT INTO public.chart_of_accounts VALUES (302, 2, '5-06', 'Taxation', 'expense', 272, 2, true, true, NULL, NULL, 'income_tax', '2026-10-29 05:44:53.541635');
INSERT INTO public.chart_of_accounts VALUES (303, 2, '5-06-01', 'Income Tax', 'expense', 302, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.548297');
INSERT INTO public.chart_of_accounts VALUES (304, 2, '5-06-01-01', 'Income Tax', 'expense', 303, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:53.5548');
INSERT INTO public.chart_of_accounts VALUES (305, 2, '1-01-01-01-0001', 'Main Cash', 'asset', 202, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.565087');
INSERT INTO public.chart_of_accounts VALUES (306, 2, '1-01-02-01-0001', 'Trade Debtors — General', 'asset', 205, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.571523');
INSERT INTO public.chart_of_accounts VALUES (307, 2, '1-01-03-02-0001', 'Advances to Suppliers — General', 'asset', 209, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.577922');
INSERT INTO public.chart_of_accounts VALUES (308, 2, '1-01-04-01-0001', 'Stock — General', 'asset', 211, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.584602');
INSERT INTO public.chart_of_accounts VALUES (309, 2, '1-01-05-01-0001', 'Input Sales Tax', 'asset', 213, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.590972');
INSERT INTO public.chart_of_accounts VALUES (310, 2, '1-01-05-02-0001', 'WHT Receivable', 'asset', 214, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.597557');
INSERT INTO public.chart_of_accounts VALUES (311, 2, '1-01-06-01-0001', 'Suspense Account', 'asset', 216, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.604186');
INSERT INTO public.chart_of_accounts VALUES (312, 2, '1-01-06-02-0001', 'Prepaid Expenses — General', 'asset', 217, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.610486');
INSERT INTO public.chart_of_accounts VALUES (313, 2, '1-02-01-01-0001', 'Fixed Assets — General', 'asset', 221, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.61675');
INSERT INTO public.chart_of_accounts VALUES (314, 2, '1-02-02-01-0001', 'Accumulated Depreciation — General', 'asset', 223, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.623001');
INSERT INTO public.chart_of_accounts VALUES (315, 2, '1-02-03-01-0001', 'Intangibles — General', 'asset', 225, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.629429');
INSERT INTO public.chart_of_accounts VALUES (316, 2, '2-01-01-01-0001', 'Trade Creditors — General', 'liability', 229, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.63566');
INSERT INTO public.chart_of_accounts VALUES (317, 2, '2-01-02-02-0001', 'Salary Payable', 'liability', 232, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.642058');
INSERT INTO public.chart_of_accounts VALUES (318, 2, '2-01-02-02-0002', 'PF Payable', 'liability', 232, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.648884');
INSERT INTO public.chart_of_accounts VALUES (319, 2, '2-01-02-02-0003', 'Loan Deductions Clearing', 'liability', 232, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.655423');
INSERT INTO public.chart_of_accounts VALUES (320, 2, '2-01-02-02-0004', 'Other Payroll Deductions Payable', 'liability', 232, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.661868');
INSERT INTO public.chart_of_accounts VALUES (321, 2, '2-01-02-03-0001', 'Accrued Expenses — General', 'liability', 233, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.668283');
INSERT INTO public.chart_of_accounts VALUES (322, 2, '2-01-03-01-0001', 'Output Sales Tax', 'liability', 235, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.674855');
INSERT INTO public.chart_of_accounts VALUES (323, 2, '2-01-03-02-0001', 'Income Tax Payable', 'liability', 236, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.681496');
INSERT INTO public.chart_of_accounts VALUES (324, 2, '2-01-03-03-0001', 'WHT Payable', 'liability', 237, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.687982');
INSERT INTO public.chart_of_accounts VALUES (325, 2, '2-01-03-04-0001', 'Further Tax Payable', 'liability', 238, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.694648');
INSERT INTO public.chart_of_accounts VALUES (326, 2, '2-01-04-01-0001', 'Customer Advances — General', 'liability', 240, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.701838');
INSERT INTO public.chart_of_accounts VALUES (327, 2, '2-02-01-01-0001', 'Long-term Loans — General', 'liability', 243, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.708274');
INSERT INTO public.chart_of_accounts VALUES (328, 2, '2-02-02-01-0001', 'EOSB Provision — General', 'liability', 245, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.714698');
INSERT INTO public.chart_of_accounts VALUES (329, 2, '3-01-01-01-0001', 'Share Capital', 'equity', 249, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.721459');
INSERT INTO public.chart_of_accounts VALUES (330, 2, '3-01-01-01-0002', 'Suspense Equity', 'equity', 249, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.727847');
INSERT INTO public.chart_of_accounts VALUES (331, 2, '3-02-01-01-0001', 'Retained Earnings — Opening', 'equity', 252, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.73422');
INSERT INTO public.chart_of_accounts VALUES (332, 2, '3-02-01-02-0001', 'Retained Earnings — Closing', 'equity', 253, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.741219');
INSERT INTO public.chart_of_accounts VALUES (333, 2, '3-02-02-01-0001', 'Dividends', 'equity', 255, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.747799');
INSERT INTO public.chart_of_accounts VALUES (334, 2, '3-02-03-01-0001', 'Other Comprehensive Income', 'equity', 257, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.754323');
INSERT INTO public.chart_of_accounts VALUES (335, 2, '4-01-01-01-0001', 'Sales — General', 'revenue', 261, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.760634');
INSERT INTO public.chart_of_accounts VALUES (336, 2, '4-01-02-01-0001', 'Service Income — General', 'revenue', 263, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.767138');
INSERT INTO public.chart_of_accounts VALUES (337, 2, '4-02-01-01-0001', 'Sales Returns — General', 'revenue', 266, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.773492');
INSERT INTO public.chart_of_accounts VALUES (338, 2, '4-02-02-01-0001', 'Discounts Allowed — General', 'revenue', 268, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.779873');
INSERT INTO public.chart_of_accounts VALUES (339, 2, '4-03-01-01-0001', 'Other Income — General', 'revenue', 271, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.786376');
INSERT INTO public.chart_of_accounts VALUES (340, 2, '5-01-01-01-0001', 'Cost of Goods Sold', 'expense', 275, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.79269');
INSERT INTO public.chart_of_accounts VALUES (341, 2, '5-01-02-01-0001', 'Scrap / Write-off', 'expense', 277, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.799432');
INSERT INTO public.chart_of_accounts VALUES (342, 2, '5-01-02-01-0002', 'Inventory Adjustment', 'expense', 277, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.805992');
INSERT INTO public.chart_of_accounts VALUES (343, 2, '5-01-02-01-0003', 'Consumption Expense', 'expense', 277, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.812581');
INSERT INTO public.chart_of_accounts VALUES (344, 2, '5-01-02-01-0004', 'Inventory Cost Variance', 'expense', 277, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.818945');
INSERT INTO public.chart_of_accounts VALUES (345, 2, '5-02-01-01-0001', 'Salary Expense', 'expense', 280, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.825322');
INSERT INTO public.chart_of_accounts VALUES (346, 2, '5-02-01-01-0002', 'PF Employer Expense', 'expense', 280, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.831877');
INSERT INTO public.chart_of_accounts VALUES (347, 2, '5-02-02-01-0001', 'Rent Expense', 'expense', 282, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.838226');
INSERT INTO public.chart_of_accounts VALUES (348, 2, '5-02-02-01-0002', 'Utilities Expense', 'expense', 282, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.844616');
INSERT INTO public.chart_of_accounts VALUES (349, 2, '5-02-03-01-0001', 'Office Supplies', 'expense', 284, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.851182');
INSERT INTO public.chart_of_accounts VALUES (350, 2, '5-02-04-01-0001', 'Depreciation Expense', 'expense', 286, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.857965');
INSERT INTO public.chart_of_accounts VALUES (351, 2, '5-02-05-01-0001', 'Fees, Taxes & Licenses — General', 'expense', 288, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.864387');
INSERT INTO public.chart_of_accounts VALUES (352, 2, '5-03-01-01-0001', 'Freight & Transportation — General', 'expense', 291, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.870837');
INSERT INTO public.chart_of_accounts VALUES (353, 2, '5-03-02-01-0001', 'Commissions — General', 'expense', 293, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.877406');
INSERT INTO public.chart_of_accounts VALUES (354, 2, '5-03-03-01-0001', 'Marketing & Advertising — General', 'expense', 295, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.883779');
INSERT INTO public.chart_of_accounts VALUES (355, 2, '5-04-01-01-0001', 'Other Expenses — General', 'expense', 298, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.890162');
INSERT INTO public.chart_of_accounts VALUES (356, 2, '5-04-01-01-0002', 'Loss/(Gain) on Disposal of Fixed Assets', 'expense', 298, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.896681');
INSERT INTO public.chart_of_accounts VALUES (357, 2, '5-05-01-01-0001', 'Bank Charges', 'expense', 301, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.90356');
INSERT INTO public.chart_of_accounts VALUES (358, 2, '5-05-01-01-0002', 'Interest Expense', 'expense', 301, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.909922');
INSERT INTO public.chart_of_accounts VALUES (359, 2, '5-06-01-01-0001', 'Income Tax Expense', 'expense', 304, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:53.91651');
INSERT INTO public.chart_of_accounts VALUES (360, 3, '1', 'Assets', 'asset', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.186257');
INSERT INTO public.chart_of_accounts VALUES (361, 3, '1-01', 'Current Assets', 'asset', 360, 2, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:54.196489');
INSERT INTO public.chart_of_accounts VALUES (362, 3, '1-01-01', 'Cash & Cash Equivalents', 'asset', 361, 3, true, true, NULL, 'cash', NULL, '2026-10-29 05:44:54.202958');
INSERT INTO public.chart_of_accounts VALUES (363, 3, '1-01-01-01', 'Cash in Hand', 'asset', 362, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.209368');
INSERT INTO public.chart_of_accounts VALUES (364, 3, '1-01-01-02', 'Bank Accounts', 'asset', 362, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.215931');
INSERT INTO public.chart_of_accounts VALUES (365, 3, '1-01-02', 'Trade Receivables', 'asset', 361, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.222396');
INSERT INTO public.chart_of_accounts VALUES (366, 3, '1-01-02-01', 'Trade Debtors', 'asset', 365, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.228705');
INSERT INTO public.chart_of_accounts VALUES (367, 3, '1-01-02-02', 'Doubtful Receivables', 'asset', 365, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.235244');
INSERT INTO public.chart_of_accounts VALUES (368, 3, '1-01-03', 'Other Receivables', 'asset', 361, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.241603');
INSERT INTO public.chart_of_accounts VALUES (369, 3, '1-01-03-01', 'Employee Loans & Advances', 'asset', 368, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.248118');
INSERT INTO public.chart_of_accounts VALUES (370, 3, '1-01-03-02', 'Advances to Suppliers', 'asset', 368, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.254364');
INSERT INTO public.chart_of_accounts VALUES (371, 3, '1-01-04', 'Inventories', 'asset', 361, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.261007');
INSERT INTO public.chart_of_accounts VALUES (372, 3, '1-01-04-01', 'Trading Goods Stock', 'asset', 371, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.267422');
INSERT INTO public.chart_of_accounts VALUES (373, 3, '1-01-05', 'Tax Assets', 'asset', 361, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.273796');
INSERT INTO public.chart_of_accounts VALUES (374, 3, '1-01-05-01', 'Input Sales Tax', 'asset', 373, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.280326');
INSERT INTO public.chart_of_accounts VALUES (375, 3, '1-01-05-02', 'WHT Receivable', 'asset', 373, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.286694');
INSERT INTO public.chart_of_accounts VALUES (376, 3, '1-01-06', 'Prepayments & Other', 'asset', 361, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.29304');
INSERT INTO public.chart_of_accounts VALUES (377, 3, '1-01-06-01', 'Suspense & Clearing', 'asset', 376, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.299482');
INSERT INTO public.chart_of_accounts VALUES (378, 3, '1-01-06-02', 'Prepaid Expenses', 'asset', 376, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.305973');
INSERT INTO public.chart_of_accounts VALUES (379, 3, '1-01-06-03', 'Other Current Assets', 'asset', 376, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.312257');
INSERT INTO public.chart_of_accounts VALUES (380, 3, '1-02', 'Non-Current Assets', 'asset', 360, 2, true, true, NULL, 'investing', NULL, '2026-10-29 05:44:54.318517');
INSERT INTO public.chart_of_accounts VALUES (381, 3, '1-02-01', 'Property, Plant & Equipment', 'asset', 380, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.324944');
INSERT INTO public.chart_of_accounts VALUES (382, 3, '1-02-01-01', 'Owned Assets', 'asset', 381, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.331188');
INSERT INTO public.chart_of_accounts VALUES (383, 3, '1-02-02', 'Accumulated Depreciation', 'asset', 380, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.337464');
INSERT INTO public.chart_of_accounts VALUES (384, 3, '1-02-02-01', 'Accumulated Depreciation', 'asset', 383, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.343711');
INSERT INTO public.chart_of_accounts VALUES (385, 3, '1-02-03', 'Intangible Assets', 'asset', 380, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.35097');
INSERT INTO public.chart_of_accounts VALUES (386, 3, '1-02-03-01', 'Intangibles', 'asset', 385, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.357173');
INSERT INTO public.chart_of_accounts VALUES (387, 3, '2', 'Liabilities', 'liability', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.361177');
INSERT INTO public.chart_of_accounts VALUES (388, 3, '2-01', 'Current Liabilities', 'liability', 387, 2, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:54.367354');
INSERT INTO public.chart_of_accounts VALUES (389, 3, '2-01-01', 'Trade Payables', 'liability', 388, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.373753');
INSERT INTO public.chart_of_accounts VALUES (390, 3, '2-01-01-01', 'Trade Creditors', 'liability', 389, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.379971');
INSERT INTO public.chart_of_accounts VALUES (391, 3, '2-01-02', 'Accrued & Payroll Liabilities', 'liability', 388, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.386459');
INSERT INTO public.chart_of_accounts VALUES (392, 3, '2-01-02-01', 'Employee Payables', 'liability', 391, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.393383');
INSERT INTO public.chart_of_accounts VALUES (393, 3, '2-01-02-02', 'Payroll Liabilities', 'liability', 391, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.399765');
INSERT INTO public.chart_of_accounts VALUES (394, 3, '2-01-02-03', 'Accrued Expenses', 'liability', 391, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.40611');
INSERT INTO public.chart_of_accounts VALUES (395, 3, '2-01-03', 'Tax Liabilities', 'liability', 388, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.412504');
INSERT INTO public.chart_of_accounts VALUES (396, 3, '2-01-03-01', 'Output Sales Tax', 'liability', 395, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.419092');
INSERT INTO public.chart_of_accounts VALUES (397, 3, '2-01-03-02', 'Income Tax Payable', 'liability', 395, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.425463');
INSERT INTO public.chart_of_accounts VALUES (398, 3, '2-01-03-03', 'WHT Payable', 'liability', 395, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.431787');
INSERT INTO public.chart_of_accounts VALUES (399, 3, '2-01-03-04', 'Further Tax Payable', 'liability', 395, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.43832');
INSERT INTO public.chart_of_accounts VALUES (400, 3, '2-01-04', 'Advances from Customers', 'liability', 388, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.444631');
INSERT INTO public.chart_of_accounts VALUES (401, 3, '2-01-04-01', 'Customer Advances', 'liability', 400, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.450976');
INSERT INTO public.chart_of_accounts VALUES (402, 3, '2-02', 'Non-Current Liabilities', 'liability', 387, 2, true, true, NULL, 'financing', NULL, '2026-10-29 05:44:54.457301');
INSERT INTO public.chart_of_accounts VALUES (403, 3, '2-02-01', 'Long-term Loans', 'liability', 402, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.463756');
INSERT INTO public.chart_of_accounts VALUES (404, 3, '2-02-01-01', 'Long-term Loans', 'liability', 403, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.470046');
INSERT INTO public.chart_of_accounts VALUES (405, 3, '2-02-02', 'Employee End-of-Service Benefits', 'liability', 402, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.476458');
INSERT INTO public.chart_of_accounts VALUES (406, 3, '2-02-02-01', 'EOSB Provision', 'liability', 405, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.48304');
INSERT INTO public.chart_of_accounts VALUES (407, 3, '3', 'Equity', 'equity', NULL, 1, true, true, NULL, 'financing', NULL, '2026-10-29 05:44:54.487143');
INSERT INTO public.chart_of_accounts VALUES (408, 3, '3-01', 'Capital', 'equity', 407, 2, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.493452');
INSERT INTO public.chart_of_accounts VALUES (409, 3, '3-01-01', 'Owner Capital', 'equity', 408, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.500079');
INSERT INTO public.chart_of_accounts VALUES (410, 3, '3-01-01-01', 'Owner Capital', 'equity', 409, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.506689');
INSERT INTO public.chart_of_accounts VALUES (411, 3, '3-02', 'Reserves & Retained Earnings', 'equity', 407, 2, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.513367');
INSERT INTO public.chart_of_accounts VALUES (412, 3, '3-02-01', 'Retained Earnings', 'equity', 411, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.519728');
INSERT INTO public.chart_of_accounts VALUES (413, 3, '3-02-01-01', 'Retained Earnings — Opening', 'equity', 412, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.526038');
INSERT INTO public.chart_of_accounts VALUES (414, 3, '3-02-01-02', 'Retained Earnings — Closing', 'equity', 412, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.53261');
INSERT INTO public.chart_of_accounts VALUES (415, 3, '3-02-02', 'Dividends', 'equity', 411, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.538949');
INSERT INTO public.chart_of_accounts VALUES (416, 3, '3-02-02-01', 'Dividends', 'equity', 415, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.545458');
INSERT INTO public.chart_of_accounts VALUES (417, 3, '3-02-03', 'Other Comprehensive Income', 'equity', 411, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.551949');
INSERT INTO public.chart_of_accounts VALUES (418, 3, '3-02-03-01', 'Other Comprehensive Income', 'equity', 417, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.558225');
INSERT INTO public.chart_of_accounts VALUES (419, 3, '4', 'Revenue', 'revenue', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:54.562284');
INSERT INTO public.chart_of_accounts VALUES (420, 3, '4-01', 'Sales', 'revenue', 419, 2, true, true, NULL, NULL, 'sales', '2026-10-29 05:44:54.568578');
INSERT INTO public.chart_of_accounts VALUES (421, 3, '4-01-01', 'Product Sales', 'revenue', 420, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.575204');
INSERT INTO public.chart_of_accounts VALUES (422, 3, '4-01-01-01', 'Product Sales', 'revenue', 421, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.581608');
INSERT INTO public.chart_of_accounts VALUES (423, 3, '4-01-02', 'Service Income', 'revenue', 420, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.588024');
INSERT INTO public.chart_of_accounts VALUES (424, 3, '4-01-02-01', 'Service Income', 'revenue', 423, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.59442');
INSERT INTO public.chart_of_accounts VALUES (425, 3, '4-02', 'Sales Returns & Discounts', 'revenue', 419, 2, true, true, NULL, NULL, 'sales_returns', '2026-10-29 05:44:54.601007');
INSERT INTO public.chart_of_accounts VALUES (426, 3, '4-02-01', 'Sales Returns', 'revenue', 425, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.607428');
INSERT INTO public.chart_of_accounts VALUES (427, 3, '4-02-01-01', 'Sales Returns', 'revenue', 426, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.61382');
INSERT INTO public.chart_of_accounts VALUES (428, 3, '4-02-02', 'Discounts Allowed', 'revenue', 425, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.620668');
INSERT INTO public.chart_of_accounts VALUES (429, 3, '4-02-02-01', 'Discounts Allowed', 'revenue', 428, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.627161');
INSERT INTO public.chart_of_accounts VALUES (430, 3, '4-03', 'Other Income', 'revenue', 419, 2, true, true, NULL, NULL, 'other_income', '2026-10-29 05:44:54.633684');
INSERT INTO public.chart_of_accounts VALUES (431, 3, '4-03-01', 'Other Income', 'revenue', 430, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.640042');
INSERT INTO public.chart_of_accounts VALUES (432, 3, '4-03-01-01', 'Other Income', 'revenue', 431, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.646771');
INSERT INTO public.chart_of_accounts VALUES (433, 3, '5', 'Expenses', 'expense', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 05:44:54.65097');
INSERT INTO public.chart_of_accounts VALUES (434, 3, '5-01', 'Cost of Sales', 'expense', 433, 2, true, true, NULL, NULL, 'cost_of_sales', '2026-10-29 05:44:54.657183');
INSERT INTO public.chart_of_accounts VALUES (435, 3, '5-01-01', 'Cost of Goods Sold', 'expense', 434, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.663482');
INSERT INTO public.chart_of_accounts VALUES (436, 3, '5-01-01-01', 'Cost of Goods Sold', 'expense', 435, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.66996');
INSERT INTO public.chart_of_accounts VALUES (437, 3, '5-01-02', 'Stock Losses, Scrap & Adjustments', 'expense', 434, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.676369');
INSERT INTO public.chart_of_accounts VALUES (438, 3, '5-01-02-01', 'Stock Losses & Scrap', 'expense', 437, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.682771');
INSERT INTO public.chart_of_accounts VALUES (439, 3, '5-02', 'Administrative Expenses', 'expense', 433, 2, true, true, NULL, NULL, 'admin', '2026-10-29 05:44:54.68927');
INSERT INTO public.chart_of_accounts VALUES (440, 3, '5-02-01', 'Salaries & Benefits', 'expense', 439, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.695523');
INSERT INTO public.chart_of_accounts VALUES (441, 3, '5-02-01-01', 'Salaries & Benefits', 'expense', 440, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.701777');
INSERT INTO public.chart_of_accounts VALUES (442, 3, '5-02-02', 'Rent & Utilities', 'expense', 439, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.708145');
INSERT INTO public.chart_of_accounts VALUES (443, 3, '5-02-02-01', 'Rent & Utilities', 'expense', 442, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.714624');
INSERT INTO public.chart_of_accounts VALUES (444, 3, '5-02-03', 'Office & Supplies', 'expense', 439, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.721043');
INSERT INTO public.chart_of_accounts VALUES (445, 3, '5-02-03-01', 'Office & Supplies', 'expense', 444, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.727467');
INSERT INTO public.chart_of_accounts VALUES (446, 3, '5-02-04', 'Depreciation & Amortisation', 'expense', 439, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.734136');
INSERT INTO public.chart_of_accounts VALUES (447, 3, '5-02-04-01', 'Depreciation & Amortisation', 'expense', 446, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.740534');
INSERT INTO public.chart_of_accounts VALUES (448, 3, '5-02-05', 'Fees, Taxes & Licenses', 'expense', 439, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.747005');
INSERT INTO public.chart_of_accounts VALUES (449, 3, '5-02-05-01', 'Fees, Taxes & Licenses', 'expense', 448, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.753516');
INSERT INTO public.chart_of_accounts VALUES (450, 3, '5-03', 'Selling & Distribution', 'expense', 433, 2, true, true, NULL, NULL, 'selling_distribution', '2026-10-29 05:44:54.760022');
INSERT INTO public.chart_of_accounts VALUES (451, 3, '5-03-01', 'Freight & Transportation', 'expense', 450, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.76636');
INSERT INTO public.chart_of_accounts VALUES (452, 3, '5-03-01-01', 'Freight & Transportation', 'expense', 451, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.772992');
INSERT INTO public.chart_of_accounts VALUES (453, 3, '5-03-02', 'Commissions', 'expense', 450, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.779652');
INSERT INTO public.chart_of_accounts VALUES (454, 3, '5-03-02-01', 'Commissions', 'expense', 453, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.786074');
INSERT INTO public.chart_of_accounts VALUES (455, 3, '5-03-03', 'Marketing & Advertising', 'expense', 450, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.792581');
INSERT INTO public.chart_of_accounts VALUES (456, 3, '5-03-03-01', 'Marketing & Advertising', 'expense', 455, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.799056');
INSERT INTO public.chart_of_accounts VALUES (457, 3, '5-04', 'Other Operating Expenses', 'expense', 433, 2, true, true, NULL, NULL, 'other_operating', '2026-10-29 05:44:54.805633');
INSERT INTO public.chart_of_accounts VALUES (458, 3, '5-04-01', 'Other Operating Expenses', 'expense', 457, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.812006');
INSERT INTO public.chart_of_accounts VALUES (459, 3, '5-04-01-01', 'Other Operating Expenses', 'expense', 458, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.818379');
INSERT INTO public.chart_of_accounts VALUES (460, 3, '5-05', 'Finance Costs', 'expense', 433, 2, true, true, NULL, NULL, 'finance_cost', '2026-10-29 05:44:54.824896');
INSERT INTO public.chart_of_accounts VALUES (461, 3, '5-05-01', 'Bank & Interest Charges', 'expense', 460, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.831247');
INSERT INTO public.chart_of_accounts VALUES (462, 3, '5-05-01-01', 'Bank & Interest Charges', 'expense', 461, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.83763');
INSERT INTO public.chart_of_accounts VALUES (463, 3, '5-06', 'Taxation', 'expense', 433, 2, true, true, NULL, NULL, 'income_tax', '2026-10-29 05:44:54.843969');
INSERT INTO public.chart_of_accounts VALUES (464, 3, '5-06-01', 'Income Tax', 'expense', 463, 3, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.850507');
INSERT INTO public.chart_of_accounts VALUES (465, 3, '5-06-01-01', 'Income Tax', 'expense', 464, 4, true, true, NULL, NULL, NULL, '2026-10-29 05:44:54.856848');
INSERT INTO public.chart_of_accounts VALUES (466, 3, '1-01-01-01-0001', 'Main Cash', 'asset', 363, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.86723');
INSERT INTO public.chart_of_accounts VALUES (467, 3, '1-01-02-01-0001', 'Trade Debtors — General', 'asset', 366, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.873749');
INSERT INTO public.chart_of_accounts VALUES (468, 3, '1-01-03-02-0001', 'Advances to Suppliers — General', 'asset', 370, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.880133');
INSERT INTO public.chart_of_accounts VALUES (469, 3, '1-01-04-01-0001', 'Stock — General', 'asset', 372, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.886871');
INSERT INTO public.chart_of_accounts VALUES (470, 3, '1-01-05-01-0001', 'Input Sales Tax', 'asset', 374, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.893209');
INSERT INTO public.chart_of_accounts VALUES (471, 3, '1-01-05-02-0001', 'WHT Receivable', 'asset', 375, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.8996');
INSERT INTO public.chart_of_accounts VALUES (472, 3, '1-01-06-01-0001', 'Suspense Account', 'asset', 377, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.906122');
INSERT INTO public.chart_of_accounts VALUES (473, 3, '1-01-06-02-0001', 'Prepaid Expenses — General', 'asset', 378, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.912463');
INSERT INTO public.chart_of_accounts VALUES (474, 3, '1-02-01-01-0001', 'Fixed Assets — General', 'asset', 382, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.918927');
INSERT INTO public.chart_of_accounts VALUES (475, 3, '1-02-02-01-0001', 'Accumulated Depreciation — General', 'asset', 384, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.92645');
INSERT INTO public.chart_of_accounts VALUES (476, 3, '1-02-03-01-0001', 'Intangibles — General', 'asset', 386, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.932938');
INSERT INTO public.chart_of_accounts VALUES (477, 3, '2-01-01-01-0001', 'Trade Creditors — General', 'liability', 390, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.939203');
INSERT INTO public.chart_of_accounts VALUES (478, 3, '2-01-02-02-0001', 'Salary Payable', 'liability', 393, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.945495');
INSERT INTO public.chart_of_accounts VALUES (479, 3, '2-01-02-02-0002', 'PF Payable', 'liability', 393, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.952011');
INSERT INTO public.chart_of_accounts VALUES (480, 3, '2-01-02-02-0003', 'Loan Deductions Clearing', 'liability', 393, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.958436');
INSERT INTO public.chart_of_accounts VALUES (481, 3, '2-01-02-02-0004', 'Other Payroll Deductions Payable', 'liability', 393, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.964864');
INSERT INTO public.chart_of_accounts VALUES (482, 3, '2-01-02-03-0001', 'Accrued Expenses — General', 'liability', 394, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.971379');
INSERT INTO public.chart_of_accounts VALUES (483, 3, '2-01-03-01-0001', 'Output Sales Tax', 'liability', 396, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.977887');
INSERT INTO public.chart_of_accounts VALUES (484, 3, '2-01-03-02-0001', 'Income Tax Payable', 'liability', 397, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.984191');
INSERT INTO public.chart_of_accounts VALUES (485, 3, '2-01-03-03-0001', 'WHT Payable', 'liability', 398, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.990501');
INSERT INTO public.chart_of_accounts VALUES (486, 3, '2-01-03-04-0001', 'Further Tax Payable', 'liability', 399, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:54.99699');
INSERT INTO public.chart_of_accounts VALUES (487, 3, '2-01-04-01-0001', 'Customer Advances — General', 'liability', 401, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.003284');
INSERT INTO public.chart_of_accounts VALUES (488, 3, '2-02-01-01-0001', 'Long-term Loans — General', 'liability', 404, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.009697');
INSERT INTO public.chart_of_accounts VALUES (489, 3, '2-02-02-01-0001', 'EOSB Provision — General', 'liability', 406, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.016195');
INSERT INTO public.chart_of_accounts VALUES (490, 3, '3-01-01-01-0001', 'Share Capital', 'equity', 410, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.022813');
INSERT INTO public.chart_of_accounts VALUES (491, 3, '3-01-01-01-0002', 'Suspense Equity', 'equity', 410, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.029196');
INSERT INTO public.chart_of_accounts VALUES (492, 3, '3-02-01-01-0001', 'Retained Earnings — Opening', 'equity', 413, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.035638');
INSERT INTO public.chart_of_accounts VALUES (493, 3, '3-02-01-02-0001', 'Retained Earnings — Closing', 'equity', 414, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.042175');
INSERT INTO public.chart_of_accounts VALUES (494, 3, '3-02-02-01-0001', 'Dividends', 'equity', 416, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.048567');
INSERT INTO public.chart_of_accounts VALUES (495, 3, '3-02-03-01-0001', 'Other Comprehensive Income', 'equity', 418, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.054841');
INSERT INTO public.chart_of_accounts VALUES (496, 3, '4-01-01-01-0001', 'Sales — General', 'revenue', 422, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.061121');
INSERT INTO public.chart_of_accounts VALUES (497, 3, '4-01-02-01-0001', 'Service Income — General', 'revenue', 424, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.067572');
INSERT INTO public.chart_of_accounts VALUES (498, 3, '4-02-01-01-0001', 'Sales Returns — General', 'revenue', 427, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.073851');
INSERT INTO public.chart_of_accounts VALUES (499, 3, '4-02-02-01-0001', 'Discounts Allowed — General', 'revenue', 429, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.080152');
INSERT INTO public.chart_of_accounts VALUES (500, 3, '4-03-01-01-0001', 'Other Income — General', 'revenue', 432, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.086613');
INSERT INTO public.chart_of_accounts VALUES (501, 3, '5-01-01-01-0001', 'Cost of Goods Sold', 'expense', 436, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.092895');
INSERT INTO public.chart_of_accounts VALUES (502, 3, '5-01-02-01-0001', 'Scrap / Write-off', 'expense', 438, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.099205');
INSERT INTO public.chart_of_accounts VALUES (503, 3, '5-01-02-01-0002', 'Inventory Adjustment', 'expense', 438, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.105907');
INSERT INTO public.chart_of_accounts VALUES (504, 3, '5-01-02-01-0003', 'Consumption Expense', 'expense', 438, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.112862');
INSERT INTO public.chart_of_accounts VALUES (505, 3, '5-01-02-01-0004', 'Inventory Cost Variance', 'expense', 438, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.119419');
INSERT INTO public.chart_of_accounts VALUES (506, 3, '5-02-01-01-0001', 'Salary Expense', 'expense', 441, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.125905');
INSERT INTO public.chart_of_accounts VALUES (507, 3, '5-02-01-01-0002', 'PF Employer Expense', 'expense', 441, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.132646');
INSERT INTO public.chart_of_accounts VALUES (508, 3, '5-02-02-01-0001', 'Rent Expense', 'expense', 443, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.139088');
INSERT INTO public.chart_of_accounts VALUES (509, 3, '5-02-02-01-0002', 'Utilities Expense', 'expense', 443, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.145555');
INSERT INTO public.chart_of_accounts VALUES (510, 3, '5-02-03-01-0001', 'Office Supplies', 'expense', 445, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.152057');
INSERT INTO public.chart_of_accounts VALUES (511, 3, '5-02-04-01-0001', 'Depreciation Expense', 'expense', 447, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.158902');
INSERT INTO public.chart_of_accounts VALUES (512, 3, '5-02-05-01-0001', 'Fees, Taxes & Licenses — General', 'expense', 449, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.165183');
INSERT INTO public.chart_of_accounts VALUES (513, 3, '5-03-01-01-0001', 'Freight & Transportation — General', 'expense', 452, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.171486');
INSERT INTO public.chart_of_accounts VALUES (514, 3, '5-03-02-01-0001', 'Commissions — General', 'expense', 454, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.177968');
INSERT INTO public.chart_of_accounts VALUES (515, 3, '5-03-03-01-0001', 'Marketing & Advertising — General', 'expense', 456, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.184242');
INSERT INTO public.chart_of_accounts VALUES (516, 3, '5-04-01-01-0001', 'Other Expenses — General', 'expense', 459, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.190532');
INSERT INTO public.chart_of_accounts VALUES (517, 3, '5-04-01-01-0002', 'Loss/(Gain) on Disposal of Fixed Assets', 'expense', 459, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.196823');
INSERT INTO public.chart_of_accounts VALUES (518, 3, '5-05-01-01-0001', 'Bank Charges', 'expense', 462, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.203397');
INSERT INTO public.chart_of_accounts VALUES (519, 3, '5-05-01-01-0002', 'Interest Expense', 'expense', 462, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.209704');
INSERT INTO public.chart_of_accounts VALUES (520, 3, '5-06-01-01-0001', 'Income Tax Expense', 'expense', 465, 5, false, true, NULL, NULL, NULL, '2026-10-29 05:44:55.216035');


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.companies VALUES (1, 'Default Company', 'default', true, 'free', NULL, 1, true, true, true, true, true, true, true, true, NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 05:44:48.497777', '2026-10-29 05:44:52.552651');
INSERT INTO public.companies VALUES (2, 'Ref ref-a5eb8c', 'ref-a5eb8c', true, 'free', NULL, 6, true, true, true, true, true, true, true, true, NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 05:44:52.869758', '2026-10-29 05:44:52.869762');
INSERT INTO public.companies VALUES (3, 'Ref ref-3f6f66', 'ref-3f6f66', true, 'free', NULL, 7, true, true, true, true, true, true, true, true, NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 05:44:54.173167', '2026-10-29 05:44:54.173171');


--
-- Data for Name: company_holidays; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: company_info; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.company_info VALUES (1, 1, 'SolarKon Energy Solutions', NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 05:44:50.815974', '2026-10-29 05:44:50.815979');
INSERT INTO public.company_info VALUES (2, 2, 'SolarKon Energy Solutions', NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 05:44:53.974158', '2026-10-29 05:44:53.974162');
INSERT INTO public.company_info VALUES (3, 3, 'SolarKon Energy Solutions', NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 05:44:55.272145', '2026-10-29 05:44:55.272148');


--
-- Data for Name: company_invitations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.company_invitations VALUES (1, 3, 'owner.a.db6e12@ref.test', 3, 7, 'accepted', '2026-10-29 05:44:55.551739');
INSERT INTO public.company_invitations VALUES (2, 3, 'restricted.a194de@ref.test', 2, 7, 'accepted', '2026-10-29 05:44:55.910313');
INSERT INTO public.company_invitations VALUES (3, 3, 'blocked.8a31c1@ref.test', 3, 7, 'accepted', '2026-10-29 05:44:56.300506');


--
-- Data for Name: company_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.company_memberships VALUES (1, 1, 1, 1, 'active', 'SYSADMIN', '2026-10-29 05:44:52.528494', NULL, '{"accounting": false, "executive": false, "fbr": false, "finance": false, "fixed_assets": false, "hr": true, "inventory": true, "invoicing": false}', NULL, 'System Administrator', NULL);
INSERT INTO public.company_memberships VALUES (2, 1, 3, 2, 'active', 'MGR002', '2026-10-29 05:44:52.534382', NULL, '{"accounting": false, "executive": false, "fbr": false, "finance": false, "fixed_assets": false, "hr": true, "inventory": true, "invoicing": false}', NULL, 'Manager', NULL);
INSERT INTO public.company_memberships VALUES (3, 1, 4, 3, 'active', 'EMP001', '2026-10-29 05:44:52.539421', NULL, '{"accounting": false, "executive": false, "fbr": false, "finance": false, "fixed_assets": false, "hr": true, "inventory": false, "invoicing": false}', NULL, 'Employee', NULL);
INSERT INTO public.company_memberships VALUES (4, 1, 5, 3, 'active', 'EMP002', '2026-10-29 05:44:52.54621', NULL, '{"accounting": false, "executive": false, "fbr": false, "finance": false, "fixed_assets": false, "hr": true, "inventory": false, "invoicing": false}', NULL, 'Employee', NULL);
INSERT INTO public.company_memberships VALUES (5, 2, 6, 1, 'active', 'SA0006', '2026-10-29 05:44:52.874173', NULL, '{"accounting": true, "executive": true, "fbr": true, "finance": true, "fixed_assets": true, "hr": true, "inventory": true, "invoicing": true}', NULL, NULL, NULL);
INSERT INTO public.company_memberships VALUES (6, 3, 7, 1, 'active', 'SA0007', '2026-10-29 05:44:54.177431', NULL, '{"accounting": true, "executive": true, "fbr": true, "finance": true, "fixed_assets": true, "hr": true, "inventory": true, "invoicing": true}', NULL, NULL, NULL);
INSERT INTO public.company_memberships VALUES (7, 3, 6, 3, 'active', NULL, '2026-10-29 05:44:55.711295', NULL, '{"accounting": false, "executive": false, "fbr": false, "finance": false, "fixed_assets": false, "hr": true, "inventory": false, "invoicing": false}', NULL, NULL, NULL);
INSERT INTO public.company_memberships VALUES (8, 3, 8, 2, 'active', NULL, '2026-10-29 05:44:56.068271', NULL, '{"accounting": true, "executive": false, "fbr": false, "finance": false, "fixed_assets": false, "hr": true, "inventory": false, "invoicing": false}', NULL, NULL, NULL);
INSERT INTO public.company_memberships VALUES (9, 3, 9, 3, 'blocked', NULL, '2026-10-29 05:44:56.457175', NULL, '{"accounting": false, "executive": false, "fbr": false, "finance": false, "fixed_assets": false, "hr": true, "inventory": false, "invoicing": false}', NULL, NULL, NULL);


--
-- Data for Name: consumption_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: consumption_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: digital_files; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: exec_account_selections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: fa_categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fa_categories VALUES (1, 1, 'Computers & IT Equipment', 'Desktop computers, laptops, servers, printers', 5, 'straight_line', 0.000000, true, '2026-10-29 05:44:48.811499');
INSERT INTO public.fa_categories VALUES (2, 1, 'Office Furniture', 'Desks, chairs, cabinets, shelving', 10, 'straight_line', 5.000000, true, '2026-10-29 05:44:48.815035');
INSERT INTO public.fa_categories VALUES (3, 1, 'Vehicles', 'Cars, trucks, forklifts', 8, 'declining_balance', 10.000000, true, '2026-10-29 05:44:48.818012');
INSERT INTO public.fa_categories VALUES (4, 1, 'Machinery & Equipment', 'Production machines, tools, heavy equipment', 15, 'straight_line', 5.000000, true, '2026-10-29 05:44:48.820775');
INSERT INTO public.fa_categories VALUES (5, 1, 'Buildings & Leasehold Improvements', 'Office buildings, warehouse, renovations', 30, 'straight_line', 10.000000, true, '2026-10-29 05:44:48.82351');
INSERT INTO public.fa_categories VALUES (6, 1, 'Software & Licenses', 'ERP licenses, development tools', 3, 'straight_line', 0.000000, true, '2026-10-29 05:44:48.826584');
INSERT INTO public.fa_categories VALUES (7, 2, 'Computers & IT Equipment', 'Desktop computers, laptops, servers, printers', 5, 'straight_line', 0.000000, true, '2026-10-29 05:44:53.954717');
INSERT INTO public.fa_categories VALUES (8, 2, 'Office Furniture', 'Desks, chairs, cabinets, shelving', 10, 'straight_line', 5.000000, true, '2026-10-29 05:44:53.957617');
INSERT INTO public.fa_categories VALUES (9, 2, 'Vehicles', 'Cars, trucks, forklifts', 8, 'declining_balance', 10.000000, true, '2026-10-29 05:44:53.9604');
INSERT INTO public.fa_categories VALUES (10, 2, 'Machinery & Equipment', 'Production machines, tools, heavy equipment', 15, 'straight_line', 5.000000, true, '2026-10-29 05:44:53.963165');
INSERT INTO public.fa_categories VALUES (11, 2, 'Buildings & Leasehold Improvements', 'Office buildings, warehouse, renovations', 30, 'straight_line', 10.000000, true, '2026-10-29 05:44:53.965953');
INSERT INTO public.fa_categories VALUES (12, 2, 'Software & Licenses', 'ERP licenses, development tools', 3, 'straight_line', 0.000000, true, '2026-10-29 05:44:53.969605');
INSERT INTO public.fa_categories VALUES (13, 3, 'Computers & IT Equipment', 'Desktop computers, laptops, servers, printers', 5, 'straight_line', 0.000000, true, '2026-10-29 05:44:55.252882');
INSERT INTO public.fa_categories VALUES (14, 3, 'Office Furniture', 'Desks, chairs, cabinets, shelving', 10, 'straight_line', 5.000000, true, '2026-10-29 05:44:55.25569');
INSERT INTO public.fa_categories VALUES (15, 3, 'Vehicles', 'Cars, trucks, forklifts', 8, 'declining_balance', 10.000000, true, '2026-10-29 05:44:55.258541');
INSERT INTO public.fa_categories VALUES (16, 3, 'Machinery & Equipment', 'Production machines, tools, heavy equipment', 15, 'straight_line', 5.000000, true, '2026-10-29 05:44:55.261316');
INSERT INTO public.fa_categories VALUES (17, 3, 'Buildings & Leasehold Improvements', 'Office buildings, warehouse, renovations', 30, 'straight_line', 10.000000, true, '2026-10-29 05:44:55.264076');
INSERT INTO public.fa_categories VALUES (18, 3, 'Software & Licenses', 'ERP licenses, development tools', 3, 'straight_line', 0.000000, true, '2026-10-29 05:44:55.267684');


--
-- Data for Name: fbr_config; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: fbr_invoice_records; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: fiscal_year_rule; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fiscal_year_rule VALUES (1, 1, 1, 1, '2026-10-29 05:44:50.824007', '2026-10-29 05:44:50.824012');
INSERT INTO public.fiscal_year_rule VALUES (2, 2, 1, 1, '2026-10-29 05:44:53.979955', '2026-10-29 05:44:53.97996');
INSERT INTO public.fiscal_year_rule VALUES (3, 3, 1, 1, '2026-10-29 05:44:55.277852', '2026-10-29 05:44:55.277856');


--
-- Data for Name: fixed_assets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: gl_daily_balances; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.gl_daily_balances VALUES (2, 1, 172, 0, '2026-10-29', 1400000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (4, 1, 173, 0, '2026-10-29', 1110000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (6, 1, 174, 0, '2026-10-29', 740000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (8, 1, 175, 0, '2026-10-29', 1080000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (10, 1, 176, 0, '2026-10-29', 1250000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (12, 1, 177, 0, '2026-10-29', 920000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (14, 1, 178, 0, '2026-10-29', 3875000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (16, 1, 179, 0, '2026-10-29', 4200000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (18, 1, 180, 0, '2026-10-29', 1140000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (20, 1, 181, 0, '2026-10-29', 60000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (22, 1, 182, 0, '2026-10-29', 80000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (24, 1, 183, 0, '2026-10-29', 50000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (26, 1, 184, 0, '2026-10-29', 130000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (28, 1, 185, 0, '2026-10-29', 80000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (30, 1, 186, 0, '2026-10-29', 96000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (32, 1, 187, 0, '2026-10-29', 80000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (34, 1, 188, 0, '2026-10-29', 22000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (36, 1, 189, 0, '2026-10-29', 42000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (38, 1, 190, 0, '2026-10-29', 37500.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (40, 1, 191, 0, '2026-10-29', 25000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (42, 1, 192, 0, '2026-10-29', 32000.0000, 0.0000, 1);
INSERT INTO public.gl_daily_balances VALUES (1, 1, 132, 0, '2026-10-29', 0.0000, 16497500.0000, 22);
INSERT INTO public.gl_daily_balances VALUES (44, 1, 193, 0, '2026-10-29', 48000.0000, 0.0000, 1);


--
-- Data for Name: global_limits; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.global_limits VALUES (1, 3, 25, NULL, '2026-10-29 05:44:48.643186');


--
-- Data for Name: income_tax_slabs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.inv_categories VALUES (1, 1, 'Solar Panels', 'Solar Panels category', NULL, true, '2026-10-29 05:44:50.588399');
INSERT INTO public.inv_categories VALUES (2, 1, 'Inverters', 'Inverters category', NULL, true, '2026-10-29 05:44:50.592256');
INSERT INTO public.inv_categories VALUES (3, 1, 'Batteries', 'Batteries category', NULL, true, '2026-10-29 05:44:50.594967');
INSERT INTO public.inv_categories VALUES (4, 1, 'Cables & Wiring', 'Cables & Wiring category', NULL, true, '2026-10-29 05:44:50.597651');
INSERT INTO public.inv_categories VALUES (5, 1, 'Mounting Structures', 'Mounting Structures category', NULL, true, '2026-10-29 05:44:50.600331');
INSERT INTO public.inv_categories VALUES (6, 1, 'Electrical Components', 'Electrical Components category', NULL, true, '2026-10-29 05:44:50.602997');
INSERT INTO public.inv_categories VALUES (7, 1, 'Tools & Equipment', 'Tools & Equipment category', NULL, true, '2026-10-29 05:44:50.605676');
INSERT INTO public.inv_categories VALUES (8, 1, 'Safety Gear', 'Safety Gear category', NULL, true, '2026-10-29 05:44:50.608609');


--
-- Data for Name: inv_customers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.inv_customers VALUES (1, 1, 'SolarTech Solutions', NULL, 'imran@solartech.com', '0300-1111111', NULL, '7-A, Johar Town', 'Lahore', NULL, NULL, 1000000.000000, NULL, NULL, true, '2026-10-29 05:44:50.781921');
INSERT INTO public.inv_customers VALUES (2, 1, 'Green Energy Pakistan', NULL, 'fatima@greenenergy.com', '0300-2222222', NULL, '15-B, Phase 2, DHA', 'Karachi', NULL, NULL, 2000000.000000, NULL, NULL, true, '2026-10-29 05:44:50.786855');
INSERT INTO public.inv_customers VALUES (3, 1, 'BuildRight Construction', NULL, 'ali@buildright.com', '0300-3333333', NULL, '3rd Floor, Al-Falah Plaza', 'Islamabad', NULL, NULL, 1500000.000000, NULL, NULL, true, '2026-10-29 05:44:50.791091');
INSERT INTO public.inv_customers VALUES (4, 1, 'Home Solutions Ltd.', NULL, 'zafar@homesol.com', '0300-4444444', NULL, '88, Garden Town', 'Lahore', NULL, NULL, 500000.000000, NULL, NULL, true, '2026-10-29 05:44:50.795731');


--
-- Data for Name: inv_invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_invoices; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_products; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.inv_products VALUES (1, 1, 'SOL-MONO-450', 'Monocrystalline Solar Panel 450W', NULL, 1, 32000.000000, 28000.000000, 10, 50.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.656008', '2026-10-29 05:44:50.656012');
INSERT INTO public.inv_products VALUES (2, 1, 'SOL-MONO-550', 'Monocrystalline Solar Panel 550W', NULL, 1, 42000.000000, 37000.000000, 5, 30.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.660689', '2026-10-29 05:44:50.660693');
INSERT INTO public.inv_products VALUES (3, 1, 'SOL-POLY-330', 'Polycrystalline Solar Panel 330W', NULL, 1, 22000.000000, 18500.000000, 8, 40.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.665025', '2026-10-29 05:44:50.665029');
INSERT INTO public.inv_products VALUES (4, 1, 'INV-5KW', '5kW Hybrid Inverter', NULL, 2, 85000.000000, 72000.000000, 3, 15.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.669347', '2026-10-29 05:44:50.669351');
INSERT INTO public.inv_products VALUES (5, 1, 'INV-10KW', '10kW Hybrid Inverter', NULL, 2, 145000.000000, 125000.000000, 2, 10.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.673662', '2026-10-29 05:44:50.673666');
INSERT INTO public.inv_products VALUES (6, 1, 'INV-3KW', '3kW String Inverter', NULL, 2, 55000.000000, 46000.000000, 4, 20.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.67799', '2026-10-29 05:44:50.677994');
INSERT INTO public.inv_products VALUES (7, 1, 'BAT-LFP-5KWH', '5kWh LiFePO4 Battery', NULL, 3, 180000.000000, 155000.000000, 5, 25.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.682331', '2026-10-29 05:44:50.682335');
INSERT INTO public.inv_products VALUES (8, 1, 'BAT-LFP-10KWH', '10kWh LiFePO4 Battery', NULL, 3, 320000.000000, 280000.000000, 3, 15.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.686808', '2026-10-29 05:44:50.686812');
INSERT INTO public.inv_products VALUES (9, 1, 'BAT-TUB-200', '200Ah Tubular Battery', NULL, 3, 45000.000000, 38000.000000, 5, 30.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.691092', '2026-10-29 05:44:50.691096');
INSERT INTO public.inv_products VALUES (10, 1, 'CBL-SOL-4MM', 'Solar DC Cable 4mm (per meter)', NULL, 4, 180.000000, 120.000000, 100, 500.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.695373', '2026-10-29 05:44:50.695377');
INSERT INTO public.inv_products VALUES (11, 1, 'CBL-AC-2.5MM', 'AC Cable 2.5mm (per meter)', NULL, 4, 120.000000, 80.000000, 200, 1000.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.699658', '2026-10-29 05:44:50.699662');
INSERT INTO public.inv_products VALUES (12, 1, 'CBL-MC4', 'MC4 Connector Pair', NULL, 4, 350.000000, 250.000000, 50, 200.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.703921', '2026-10-29 05:44:50.703926');
INSERT INTO public.inv_products VALUES (13, 1, 'MNT-ALU-RACK', 'Aluminum Mounting Rack (set)', NULL, 5, 8500.000000, 6500.000000, 5, 20.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.708281', '2026-10-29 05:44:50.708286');
INSERT INTO public.inv_products VALUES (14, 1, 'MNT-RAIL-2M', 'Mounting Rail 2m', NULL, 5, 2200.000000, 1600.000000, 10, 50.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.712875', '2026-10-29 05:44:50.712879');
INSERT INTO public.inv_products VALUES (15, 1, 'ELEC-DB', 'Distribution Board 16-way', NULL, 6, 4500.000000, 3200.000000, 5, 30.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.71717', '2026-10-29 05:44:50.717174');
INSERT INTO public.inv_products VALUES (16, 1, 'ELEC-SPD', 'Surge Protection Device', NULL, 6, 2800.000000, 2000.000000, 8, 40.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.721472', '2026-10-29 05:44:50.721476');
INSERT INTO public.inv_products VALUES (17, 1, 'ELEC-MCB-16A', 'MCB 16A Single Pole', NULL, 6, 350.000000, 220.000000, 20, 100.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.725796', '2026-10-29 05:44:50.725801');
INSERT INTO public.inv_products VALUES (18, 1, 'TOOL-CRIMP', 'Solar Crimping Tool', NULL, 7, 5500.000000, 4200.000000, 2, 10.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.730088', '2026-10-29 05:44:50.730092');
INSERT INTO public.inv_products VALUES (19, 1, 'TOOL-MULTI', 'Digital Multimeter', NULL, 7, 3500.000000, 2500.000000, 3, 15.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.734387', '2026-10-29 05:44:50.734391');
INSERT INTO public.inv_products VALUES (20, 1, 'SAFE-HLMT', 'Safety Helmet', NULL, 8, 800.000000, 500.000000, 10, 50.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.738863', '2026-10-29 05:44:50.738867');
INSERT INTO public.inv_products VALUES (21, 1, 'SAFE-GLOVES', 'Insulated Gloves (pair)', NULL, 8, 1200.000000, 800.000000, 10, 40.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.743249', '2026-10-29 05:44:50.743253');
INSERT INTO public.inv_products VALUES (22, 1, 'SAFE-HARNESS', 'Safety Harness', NULL, 8, 4500.000000, 3200.000000, 3, 15.0000, 'pcs', '', 0.000000, true, '2026-10-29 05:44:50.748027', '2026-10-29 05:44:50.748031');


--
-- Data for Name: inv_purchase_invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_purchase_invoices; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_purchase_order_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_purchase_return_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_purchase_returns; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_sales_order_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_sales_orders; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_sales_return_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_sales_returns; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inv_suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.inv_suppliers VALUES (1, 1, 'Longi Solar Pakistan', 'Mr. Ahmed', 'ahmed@longi.pk', '021-34567890', NULL, 'PLOT 12, SITE AREA', 'Karachi', NULL, NULL, NULL, NULL, true, '2026-10-29 05:44:50.754515');
INSERT INTO public.inv_suppliers VALUES (2, 1, 'JA Solar Technologies', 'Mr. Usman', 'usman@jasolar.com', '042-35678901', NULL, '23-G, Gulberg III', 'Lahore', NULL, NULL, NULL, NULL, true, '2026-10-29 05:44:50.758958');
INSERT INTO public.inv_suppliers VALUES (3, 1, 'BYD Energy Solutions', 'Mr. Kamran', 'kamran@byd.com', '021-36789012', NULL, 'Business Bay, Clifton', 'Karachi', NULL, NULL, NULL, NULL, true, '2026-10-29 05:44:50.762895');
INSERT INTO public.inv_suppliers VALUES (4, 1, 'Growatt Inverters', 'Mr. Hassan', 'hassan@growatt.com', '042-37890123', NULL, '55 Main Boulevard', 'Lahore', NULL, NULL, NULL, NULL, true, '2026-10-29 05:44:50.766825');
INSERT INTO public.inv_suppliers VALUES (5, 1, 'Al-Rashid Traders', 'Mr. Rashid', 'rashid@alrashid.com', '0315-1234567', NULL, 'Steel Market, Bolton Market', 'Karachi', NULL, NULL, NULL, NULL, true, '2026-10-29 05:44:50.770757');
INSERT INTO public.inv_suppliers VALUES (6, 1, 'Pakistan Cable Co.', 'Mr. Faisal', 'faisal@pakcable.com', '021-38901234', NULL, 'Industrial Area, Kot Lakhpat', 'Lahore', NULL, NULL, NULL, NULL, true, '2026-10-29 05:44:50.775607');


--
-- Data for Name: inv_units; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.inv_units VALUES (1, 1, 'Piece', 'pcs', 'Individual unit count', true, '2026-10-29 05:44:50.614487');
INSERT INTO public.inv_units VALUES (2, 1, 'Kilogram', 'kg', 'Weight in kilograms', true, '2026-10-29 05:44:50.617652');
INSERT INTO public.inv_units VALUES (3, 1, 'Gram', 'g', 'Weight in grams', true, '2026-10-29 05:44:50.620159');
INSERT INTO public.inv_units VALUES (4, 1, 'Meter', 'm', 'Length in meters', true, '2026-10-29 05:44:50.62267');
INSERT INTO public.inv_units VALUES (5, 1, 'Liter', 'l', 'Volume in liters', true, '2026-10-29 05:44:50.62619');
INSERT INTO public.inv_units VALUES (6, 1, 'Box', 'box', 'Box or carton', true, '2026-10-29 05:44:50.628668');
INSERT INTO public.inv_units VALUES (7, 1, 'Set', 'set', 'Complete set', true, '2026-10-29 05:44:50.631135');
INSERT INTO public.inv_units VALUES (8, 1, 'Pair', 'pair', 'Two units', true, '2026-10-29 05:44:50.63362');
INSERT INTO public.inv_units VALUES (9, 1, 'Dozen', 'doz', '12 units', true, '2026-10-29 05:44:50.63611');
INSERT INTO public.inv_units VALUES (10, 1, 'Square Meter', 'sqm', 'Area measurement', true, '2026-10-29 05:44:50.638599');
INSERT INTO public.inv_units VALUES (11, 1, 'Kilowatt', 'kW', 'Power rating', true, '2026-10-29 05:44:50.641105');
INSERT INTO public.inv_units VALUES (12, 1, 'Watt', 'W', 'Power rating', true, '2026-10-29 05:44:50.643621');
INSERT INTO public.inv_units VALUES (13, 1, 'Ampere', 'A', 'Current measurement', true, '2026-10-29 05:44:50.646126');
INSERT INTO public.inv_units VALUES (14, 1, 'Volt', 'V', 'Voltage measurement', true, '2026-10-29 05:44:50.647404');


--
-- Data for Name: inventory_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.inventory_settings VALUES (1, 1, 'weighted_average', false, 4, true, 'with_po', 'with_so', NULL, NULL, NULL, false, false, NULL, NULL);
INSERT INTO public.inventory_settings VALUES (2, 2, 'weighted_average', false, 4, true, 'with_po', 'with_so', NULL, NULL, NULL, false, false, NULL, NULL);
INSERT INTO public.inventory_settings VALUES (3, 3, 'weighted_average', false, 4, true, 'with_po', 'with_so', NULL, NULL, NULL, false, false, NULL, NULL);


--
-- Data for Name: invoice_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: invoice_templates; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.invoice_templates VALUES (1, 1, 'Standard Sales Invoice', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:51.139482', '2026-10-29 05:44:51.139487');
INSERT INTO public.invoice_templates VALUES (2, 1, 'Sales Invoice (Item Wise)', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:51.139489', '2026-10-29 05:44:51.139491');
INSERT INTO public.invoice_templates VALUES (3, 1, 'Standard Purchase Invoice', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:51.145648', '2026-10-29 05:44:51.145653');
INSERT INTO public.invoice_templates VALUES (4, 1, 'Purchase Invoice (Item Wise)', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:51.145656', '2026-10-29 05:44:51.145657');
INSERT INTO public.invoice_templates VALUES (5, 2, 'Standard Sales Invoice', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:54.015363', '2026-10-29 05:44:54.015368');
INSERT INTO public.invoice_templates VALUES (6, 2, 'Sales Invoice (Item Wise)', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:54.01537', '2026-10-29 05:44:54.015372');
INSERT INTO public.invoice_templates VALUES (7, 2, 'Standard Purchase Invoice', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:54.018911', '2026-10-29 05:44:54.018915');
INSERT INTO public.invoice_templates VALUES (8, 2, 'Purchase Invoice (Item Wise)', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:54.018917', '2026-10-29 05:44:54.018919');
INSERT INTO public.invoice_templates VALUES (9, 3, 'Standard Sales Invoice', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:55.312211', '2026-10-29 05:44:55.312216');
INSERT INTO public.invoice_templates VALUES (10, 3, 'Sales Invoice (Item Wise)', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:55.312218', '2026-10-29 05:44:55.31222');
INSERT INTO public.invoice_templates VALUES (11, 3, 'Standard Purchase Invoice', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:55.315562', '2026-10-29 05:44:55.315567');
INSERT INTO public.invoice_templates VALUES (12, 3, 'Purchase Invoice (Item Wise)', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 05:44:55.315569', '2026-10-29 05:44:55.315571');


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.journal_entries VALUES (1, 1, 'OPENING', 1, 'OPEN-00001', 'Opening stock — Monocrystalline Solar Panel 450W', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.224387', true);
INSERT INTO public.journal_entries VALUES (2, 1, 'OPENING', 2, 'OPEN-00002', 'Opening stock — Monocrystalline Solar Panel 550W', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.285638', true);
INSERT INTO public.journal_entries VALUES (3, 1, 'OPENING', 3, 'OPEN-00003', 'Opening stock — Polycrystalline Solar Panel 330W', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.341058', true);
INSERT INTO public.journal_entries VALUES (4, 1, 'OPENING', 4, 'OPEN-00004', 'Opening stock — 5kW Hybrid Inverter', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.395826', true);
INSERT INTO public.journal_entries VALUES (5, 1, 'OPENING', 5, 'OPEN-00005', 'Opening stock — 10kW Hybrid Inverter', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.451201', true);
INSERT INTO public.journal_entries VALUES (6, 1, 'OPENING', 6, 'OPEN-00006', 'Opening stock — 3kW String Inverter', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.505569', true);
INSERT INTO public.journal_entries VALUES (7, 1, 'OPENING', 7, 'OPEN-00007', 'Opening stock — 5kWh LiFePO4 Battery', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.560728', true);
INSERT INTO public.journal_entries VALUES (8, 1, 'OPENING', 8, 'OPEN-00008', 'Opening stock — 10kWh LiFePO4 Battery', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.615548', true);
INSERT INTO public.journal_entries VALUES (9, 1, 'OPENING', 9, 'OPEN-00009', 'Opening stock — 200Ah Tubular Battery', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.670847', true);
INSERT INTO public.journal_entries VALUES (10, 1, 'OPENING', 10, 'OPEN-00010', 'Opening stock — Solar DC Cable 4mm (per meter)', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.72492', true);
INSERT INTO public.journal_entries VALUES (11, 1, 'OPENING', 11, 'OPEN-00011', 'Opening stock — AC Cable 2.5mm (per meter)', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.780455', true);
INSERT INTO public.journal_entries VALUES (12, 1, 'OPENING', 12, 'OPEN-00012', 'Opening stock — MC4 Connector Pair', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.835529', true);
INSERT INTO public.journal_entries VALUES (13, 1, 'OPENING', 13, 'OPEN-00013', 'Opening stock — Aluminum Mounting Rack (set)', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.890181', true);
INSERT INTO public.journal_entries VALUES (14, 1, 'OPENING', 14, 'OPEN-00014', 'Opening stock — Mounting Rail 2m', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:51.945516', true);
INSERT INTO public.journal_entries VALUES (15, 1, 'OPENING', 15, 'OPEN-00015', 'Opening stock — Distribution Board 16-way', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:52.000511', true);
INSERT INTO public.journal_entries VALUES (16, 1, 'OPENING', 16, 'OPEN-00016', 'Opening stock — Surge Protection Device', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:52.056266', true);
INSERT INTO public.journal_entries VALUES (17, 1, 'OPENING', 17, 'OPEN-00017', 'Opening stock — MCB 16A Single Pole', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:52.111418', true);
INSERT INTO public.journal_entries VALUES (18, 1, 'OPENING', 18, 'OPEN-00018', 'Opening stock — Solar Crimping Tool', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:52.166318', true);
INSERT INTO public.journal_entries VALUES (19, 1, 'OPENING', 19, 'OPEN-00019', 'Opening stock — Digital Multimeter', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:52.220366', true);
INSERT INTO public.journal_entries VALUES (20, 1, 'OPENING', 20, 'OPEN-00020', 'Opening stock — Safety Helmet', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:52.276446', true);
INSERT INTO public.journal_entries VALUES (21, 1, 'OPENING', 21, 'OPEN-00021', 'Opening stock — Insulated Gloves (pair)', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:52.330595', true);
INSERT INTO public.journal_entries VALUES (22, 1, 'OPENING', 22, 'OPEN-00022', 'Opening stock — Safety Harness', '2026-10-29 00:00:00', 1, '2026-10-29 05:44:52.385817', true);


--
-- Data for Name: journal_lines; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.journal_lines VALUES (1, 1, 1, 172, 1400000.0000, 0.0000, 'Opening stock Monocrystalline Solar Panel 450W', NULL);
INSERT INTO public.journal_lines VALUES (2, 1, 1, 132, 0.0000, 1400000.0000, 'Opening balance — Monocrystalline Solar Panel 450W', NULL);
INSERT INTO public.journal_lines VALUES (3, 1, 2, 173, 1110000.0000, 0.0000, 'Opening stock Monocrystalline Solar Panel 550W', NULL);
INSERT INTO public.journal_lines VALUES (4, 1, 2, 132, 0.0000, 1110000.0000, 'Opening balance — Monocrystalline Solar Panel 550W', NULL);
INSERT INTO public.journal_lines VALUES (5, 1, 3, 174, 740000.0000, 0.0000, 'Opening stock Polycrystalline Solar Panel 330W', NULL);
INSERT INTO public.journal_lines VALUES (6, 1, 3, 132, 0.0000, 740000.0000, 'Opening balance — Polycrystalline Solar Panel 330W', NULL);
INSERT INTO public.journal_lines VALUES (7, 1, 4, 175, 1080000.0000, 0.0000, 'Opening stock 5kW Hybrid Inverter', NULL);
INSERT INTO public.journal_lines VALUES (8, 1, 4, 132, 0.0000, 1080000.0000, 'Opening balance — 5kW Hybrid Inverter', NULL);
INSERT INTO public.journal_lines VALUES (9, 1, 5, 176, 1250000.0000, 0.0000, 'Opening stock 10kW Hybrid Inverter', NULL);
INSERT INTO public.journal_lines VALUES (10, 1, 5, 132, 0.0000, 1250000.0000, 'Opening balance — 10kW Hybrid Inverter', NULL);
INSERT INTO public.journal_lines VALUES (11, 1, 6, 177, 920000.0000, 0.0000, 'Opening stock 3kW String Inverter', NULL);
INSERT INTO public.journal_lines VALUES (12, 1, 6, 132, 0.0000, 920000.0000, 'Opening balance — 3kW String Inverter', NULL);
INSERT INTO public.journal_lines VALUES (13, 1, 7, 178, 3875000.0000, 0.0000, 'Opening stock 5kWh LiFePO4 Battery', NULL);
INSERT INTO public.journal_lines VALUES (14, 1, 7, 132, 0.0000, 3875000.0000, 'Opening balance — 5kWh LiFePO4 Battery', NULL);
INSERT INTO public.journal_lines VALUES (15, 1, 8, 179, 4200000.0000, 0.0000, 'Opening stock 10kWh LiFePO4 Battery', NULL);
INSERT INTO public.journal_lines VALUES (16, 1, 8, 132, 0.0000, 4200000.0000, 'Opening balance — 10kWh LiFePO4 Battery', NULL);
INSERT INTO public.journal_lines VALUES (17, 1, 9, 180, 1140000.0000, 0.0000, 'Opening stock 200Ah Tubular Battery', NULL);
INSERT INTO public.journal_lines VALUES (18, 1, 9, 132, 0.0000, 1140000.0000, 'Opening balance — 200Ah Tubular Battery', NULL);
INSERT INTO public.journal_lines VALUES (19, 1, 10, 181, 60000.0000, 0.0000, 'Opening stock Solar DC Cable 4mm (per meter)', NULL);
INSERT INTO public.journal_lines VALUES (20, 1, 10, 132, 0.0000, 60000.0000, 'Opening balance — Solar DC Cable 4mm (per meter)', NULL);
INSERT INTO public.journal_lines VALUES (21, 1, 11, 182, 80000.0000, 0.0000, 'Opening stock AC Cable 2.5mm (per meter)', NULL);
INSERT INTO public.journal_lines VALUES (22, 1, 11, 132, 0.0000, 80000.0000, 'Opening balance — AC Cable 2.5mm (per meter)', NULL);
INSERT INTO public.journal_lines VALUES (23, 1, 12, 183, 50000.0000, 0.0000, 'Opening stock MC4 Connector Pair', NULL);
INSERT INTO public.journal_lines VALUES (24, 1, 12, 132, 0.0000, 50000.0000, 'Opening balance — MC4 Connector Pair', NULL);
INSERT INTO public.journal_lines VALUES (25, 1, 13, 184, 130000.0000, 0.0000, 'Opening stock Aluminum Mounting Rack (set)', NULL);
INSERT INTO public.journal_lines VALUES (26, 1, 13, 132, 0.0000, 130000.0000, 'Opening balance — Aluminum Mounting Rack (set)', NULL);
INSERT INTO public.journal_lines VALUES (27, 1, 14, 185, 80000.0000, 0.0000, 'Opening stock Mounting Rail 2m', NULL);
INSERT INTO public.journal_lines VALUES (28, 1, 14, 132, 0.0000, 80000.0000, 'Opening balance — Mounting Rail 2m', NULL);
INSERT INTO public.journal_lines VALUES (29, 1, 15, 186, 96000.0000, 0.0000, 'Opening stock Distribution Board 16-way', NULL);
INSERT INTO public.journal_lines VALUES (30, 1, 15, 132, 0.0000, 96000.0000, 'Opening balance — Distribution Board 16-way', NULL);
INSERT INTO public.journal_lines VALUES (31, 1, 16, 187, 80000.0000, 0.0000, 'Opening stock Surge Protection Device', NULL);
INSERT INTO public.journal_lines VALUES (32, 1, 16, 132, 0.0000, 80000.0000, 'Opening balance — Surge Protection Device', NULL);
INSERT INTO public.journal_lines VALUES (33, 1, 17, 188, 22000.0000, 0.0000, 'Opening stock MCB 16A Single Pole', NULL);
INSERT INTO public.journal_lines VALUES (34, 1, 17, 132, 0.0000, 22000.0000, 'Opening balance — MCB 16A Single Pole', NULL);
INSERT INTO public.journal_lines VALUES (35, 1, 18, 189, 42000.0000, 0.0000, 'Opening stock Solar Crimping Tool', NULL);
INSERT INTO public.journal_lines VALUES (36, 1, 18, 132, 0.0000, 42000.0000, 'Opening balance — Solar Crimping Tool', NULL);
INSERT INTO public.journal_lines VALUES (37, 1, 19, 190, 37500.0000, 0.0000, 'Opening stock Digital Multimeter', NULL);
INSERT INTO public.journal_lines VALUES (38, 1, 19, 132, 0.0000, 37500.0000, 'Opening balance — Digital Multimeter', NULL);
INSERT INTO public.journal_lines VALUES (39, 1, 20, 191, 25000.0000, 0.0000, 'Opening stock Safety Helmet', NULL);
INSERT INTO public.journal_lines VALUES (40, 1, 20, 132, 0.0000, 25000.0000, 'Opening balance — Safety Helmet', NULL);
INSERT INTO public.journal_lines VALUES (41, 1, 21, 192, 32000.0000, 0.0000, 'Opening stock Insulated Gloves (pair)', NULL);
INSERT INTO public.journal_lines VALUES (42, 1, 21, 132, 0.0000, 32000.0000, 'Opening balance — Insulated Gloves (pair)', NULL);
INSERT INTO public.journal_lines VALUES (43, 1, 22, 193, 48000.0000, 0.0000, 'Opening stock Safety Harness', NULL);
INSERT INTO public.journal_lines VALUES (44, 1, 22, 132, 0.0000, 48000.0000, 'Opening balance — Safety Harness', NULL);


--
-- Data for Name: kanban_boards; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: kanban_tasks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: layer_consumptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: leave_approvals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: leave_quotas; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: leave_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: leave_types; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: loan_advance_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: loan_repayments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_recipients; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: overtime_accounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: payment_allocations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: payroll_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: payroll_components; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: payroll_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: payroll_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: payroll_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: payroll_slips; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: performance_goals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: performance_reviews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.permissions VALUES (1, 1, 'attendance', true, true, true);
INSERT INTO public.permissions VALUES (2, 1, 'leaves', true, true, true);
INSERT INTO public.permissions VALUES (3, 1, 'ess', true, true, true);
INSERT INTO public.permissions VALUES (4, 1, 'reports', true, true, true);
INSERT INTO public.permissions VALUES (5, 1, 'mss', true, true, true);
INSERT INTO public.permissions VALUES (6, 1, 'workplace', true, true, true);
INSERT INTO public.permissions VALUES (7, 1, 'timesheets', true, true, true);
INSERT INTO public.permissions VALUES (8, 1, 'digital_files', true, true, true);
INSERT INTO public.permissions VALUES (9, 1, 'compensation', true, true, true);
INSERT INTO public.permissions VALUES (10, 1, 'communications', true, true, true);
INSERT INTO public.permissions VALUES (11, 1, 'pf', true, true, true);
INSERT INTO public.permissions VALUES (12, 1, 'users', true, true, true);
INSERT INTO public.permissions VALUES (13, 1, 'products', true, true, true);
INSERT INTO public.permissions VALUES (14, 1, 'suppliers', true, true, true);
INSERT INTO public.permissions VALUES (15, 1, 'purchase_invoice', true, true, true);
INSERT INTO public.permissions VALUES (16, 1, 'purchase_return', true, true, true);
INSERT INTO public.permissions VALUES (17, 1, 'sales', true, true, true);
INSERT INTO public.permissions VALUES (18, 1, 'inventory', true, true, true);
INSERT INTO public.permissions VALUES (19, 2, 'attendance', true, true, false);
INSERT INTO public.permissions VALUES (20, 2, 'leaves', true, true, false);
INSERT INTO public.permissions VALUES (21, 2, 'ess', true, true, false);
INSERT INTO public.permissions VALUES (22, 2, 'reports', true, false, false);
INSERT INTO public.permissions VALUES (23, 2, 'mss', true, true, false);
INSERT INTO public.permissions VALUES (24, 2, 'workplace', true, true, false);
INSERT INTO public.permissions VALUES (25, 2, 'timesheets', true, true, false);
INSERT INTO public.permissions VALUES (26, 2, 'digital_files', true, false, false);
INSERT INTO public.permissions VALUES (27, 2, 'compensation', true, false, false);
INSERT INTO public.permissions VALUES (28, 2, 'communications', true, false, false);
INSERT INTO public.permissions VALUES (29, 2, 'pf', true, false, false);
INSERT INTO public.permissions VALUES (30, 2, 'users', false, false, false);
INSERT INTO public.permissions VALUES (31, 2, 'products', true, true, false);
INSERT INTO public.permissions VALUES (32, 2, 'suppliers', true, true, false);
INSERT INTO public.permissions VALUES (33, 2, 'purchase_invoice', true, true, false);
INSERT INTO public.permissions VALUES (34, 2, 'purchase_return', true, true, false);
INSERT INTO public.permissions VALUES (35, 2, 'sales', true, true, false);
INSERT INTO public.permissions VALUES (36, 2, 'inventory', true, false, false);
INSERT INTO public.permissions VALUES (37, 3, 'attendance', true, true, false);
INSERT INTO public.permissions VALUES (38, 3, 'leaves', true, true, false);
INSERT INTO public.permissions VALUES (39, 3, 'ess', true, true, false);
INSERT INTO public.permissions VALUES (40, 3, 'reports', false, false, false);
INSERT INTO public.permissions VALUES (41, 3, 'mss', false, false, false);
INSERT INTO public.permissions VALUES (42, 3, 'workplace', true, false, false);
INSERT INTO public.permissions VALUES (43, 3, 'timesheets', true, true, false);
INSERT INTO public.permissions VALUES (44, 3, 'digital_files', true, false, false);
INSERT INTO public.permissions VALUES (45, 3, 'compensation', false, false, false);
INSERT INTO public.permissions VALUES (46, 3, 'communications', true, false, false);
INSERT INTO public.permissions VALUES (47, 3, 'pf', true, false, false);
INSERT INTO public.permissions VALUES (48, 3, 'users', false, false, false);
INSERT INTO public.permissions VALUES (49, 3, 'products', false, false, false);
INSERT INTO public.permissions VALUES (50, 3, 'suppliers', false, false, false);
INSERT INTO public.permissions VALUES (51, 3, 'purchase_invoice', false, false, false);
INSERT INTO public.permissions VALUES (52, 3, 'purchase_return', false, false, false);
INSERT INTO public.permissions VALUES (53, 3, 'sales', false, false, false);
INSERT INTO public.permissions VALUES (54, 3, 'inventory', false, false, false);


--
-- Data for Name: pf_config; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pf_contributions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pf_ledger; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pf_loan_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pf_profit_distributions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pf_settlements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pf_withdrawal_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_labels; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_tasks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: registration_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: report_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.report_settings VALUES (1, 1, NULL, 10, 'relevant', 'relevant', 'relevant', NULL, NULL, NULL, NULL, 'indirect', NULL, '2026-10-29 05:44:50.856224');
INSERT INTO public.report_settings VALUES (2, 2, NULL, 10, 'relevant', 'relevant', 'relevant', NULL, NULL, NULL, NULL, 'indirect', NULL, '2026-10-29 05:44:53.998228');
INSERT INTO public.report_settings VALUES (3, 3, NULL, 10, 'relevant', 'relevant', 'relevant', NULL, NULL, NULL, NULL, 'indirect', NULL, '2026-10-29 05:44:55.295876');


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.roles VALUES (1, 'admin', 'Admin role');
INSERT INTO public.roles VALUES (2, 'manager', 'Manager role');
INSERT INTO public.roles VALUES (3, 'employee', 'Employee role');


--
-- Data for Name: salary_revisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scrap_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: scrap_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_adjustment_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_adjustment_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_cost_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_layers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_layers VALUES (1, 1, 1, 1, 28000.0000, 50.0000, 50.0000, 1400000.0000, 'weighted_average', false, '2026-10-29 05:44:51.188121', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (2, 1, 2, 2, 37000.0000, 30.0000, 30.0000, 1110000.0000, 'weighted_average', false, '2026-10-29 05:44:51.256167', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (3, 1, 3, 3, 18500.0000, 40.0000, 40.0000, 740000.0000, 'weighted_average', false, '2026-10-29 05:44:51.312534', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (4, 1, 4, 4, 72000.0000, 15.0000, 15.0000, 1080000.0000, 'weighted_average', false, '2026-10-29 05:44:51.367511', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (5, 1, 5, 5, 125000.0000, 10.0000, 10.0000, 1250000.0000, 'weighted_average', false, '2026-10-29 05:44:51.422028', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (6, 1, 6, 6, 46000.0000, 20.0000, 20.0000, 920000.0000, 'weighted_average', false, '2026-10-29 05:44:51.477115', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (7, 1, 7, 7, 155000.0000, 25.0000, 25.0000, 3875000.0000, 'weighted_average', false, '2026-10-29 05:44:51.532047', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (8, 1, 8, 8, 280000.0000, 15.0000, 15.0000, 4200000.0000, 'weighted_average', false, '2026-10-29 05:44:51.587214', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (9, 1, 9, 9, 38000.0000, 30.0000, 30.0000, 1140000.0000, 'weighted_average', false, '2026-10-29 05:44:51.642021', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (10, 1, 10, 10, 120.0000, 500.0000, 500.0000, 60000.0000, 'weighted_average', false, '2026-10-29 05:44:51.696747', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (11, 1, 11, 11, 80.0000, 1000.0000, 1000.0000, 80000.0000, 'weighted_average', false, '2026-10-29 05:44:51.751391', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (12, 1, 12, 12, 250.0000, 200.0000, 200.0000, 50000.0000, 'weighted_average', false, '2026-10-29 05:44:51.807104', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (13, 1, 13, 13, 6500.0000, 20.0000, 20.0000, 130000.0000, 'weighted_average', false, '2026-10-29 05:44:51.861217', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (14, 1, 14, 14, 1600.0000, 50.0000, 50.0000, 80000.0000, 'weighted_average', false, '2026-10-29 05:44:51.916872', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (15, 1, 15, 15, 3200.0000, 30.0000, 30.0000, 96000.0000, 'weighted_average', false, '2026-10-29 05:44:51.971778', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (16, 1, 16, 16, 2000.0000, 40.0000, 40.0000, 80000.0000, 'weighted_average', false, '2026-10-29 05:44:52.027516', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (17, 1, 17, 17, 220.0000, 100.0000, 100.0000, 22000.0000, 'weighted_average', false, '2026-10-29 05:44:52.082675', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (18, 1, 18, 18, 4200.0000, 10.0000, 10.0000, 42000.0000, 'weighted_average', false, '2026-10-29 05:44:52.137591', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (19, 1, 19, 19, 2500.0000, 15.0000, 15.0000, 37500.0000, 'weighted_average', false, '2026-10-29 05:44:52.192252', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (20, 1, 20, 20, 500.0000, 50.0000, 50.0000, 25000.0000, 'weighted_average', false, '2026-10-29 05:44:52.247593', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (21, 1, 21, 21, 800.0000, 40.0000, 40.0000, 32000.0000, 'weighted_average', false, '2026-10-29 05:44:52.302386', 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_layers VALUES (22, 1, 22, 22, 3200.0000, 15.0000, 15.0000, 48000.0000, 'weighted_average', false, '2026-10-29 05:44:52.356891', 'Opening balance (pre-costing-engine stock)');


--
-- Data for Name: stock_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.stock_ledger VALUES (1, 1, 1, 'OPENING', 1, 'OPEN-00001', 'IN', 50.0000, 28000.0000, 1400000.0000, 50.0000, 1400000.0000, 28000.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.175031', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (2, 1, 2, 'OPENING', 2, 'OPEN-00002', 'IN', 30.0000, 37000.0000, 1110000.0000, 30.0000, 1110000.0000, 37000.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.248148', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (3, 1, 3, 'OPENING', 3, 'OPEN-00003', 'IN', 40.0000, 18500.0000, 740000.0000, 40.0000, 740000.0000, 18500.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.304324', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (4, 1, 4, 'OPENING', 4, 'OPEN-00004', 'IN', 15.0000, 72000.0000, 1080000.0000, 15.0000, 1080000.0000, 72000.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.359452', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (5, 1, 5, 'OPENING', 5, 'OPEN-00005', 'IN', 10.0000, 125000.0000, 1250000.0000, 10.0000, 1250000.0000, 125000.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.414123', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (6, 1, 6, 'OPENING', 6, 'OPEN-00006', 'IN', 20.0000, 46000.0000, 920000.0000, 20.0000, 920000.0000, 46000.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.469314', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (7, 1, 7, 'OPENING', 7, 'OPEN-00007', 'IN', 25.0000, 155000.0000, 3875000.0000, 25.0000, 3875000.0000, 155000.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.523823', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (8, 1, 8, 'OPENING', 8, 'OPEN-00008', 'IN', 15.0000, 280000.0000, 4200000.0000, 15.0000, 4200000.0000, 280000.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.579192', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (9, 1, 9, 'OPENING', 9, 'OPEN-00009', 'IN', 30.0000, 38000.0000, 1140000.0000, 30.0000, 1140000.0000, 38000.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.634071', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (10, 1, 10, 'OPENING', 10, 'OPEN-00010', 'IN', 500.0000, 120.0000, 60000.0000, 500.0000, 60000.0000, 120.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.689007', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (11, 1, 11, 'OPENING', 11, 'OPEN-00011', 'IN', 1000.0000, 80.0000, 80000.0000, 1000.0000, 80000.0000, 80.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.742867', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (12, 1, 12, 'OPENING', 12, 'OPEN-00012', 'IN', 200.0000, 250.0000, 50000.0000, 200.0000, 50000.0000, 250.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.799039', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (13, 1, 13, 'OPENING', 13, 'OPEN-00013', 'IN', 20.0000, 6500.0000, 130000.0000, 20.0000, 130000.0000, 6500.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.853485', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (14, 1, 14, 'OPENING', 14, 'OPEN-00014', 'IN', 50.0000, 1600.0000, 80000.0000, 50.0000, 80000.0000, 1600.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.908991', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (15, 1, 15, 'OPENING', 15, 'OPEN-00015', 'IN', 30.0000, 3200.0000, 96000.0000, 30.0000, 96000.0000, 3200.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:51.963587', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (16, 1, 16, 'OPENING', 16, 'OPEN-00016', 'IN', 40.0000, 2000.0000, 80000.0000, 40.0000, 80000.0000, 2000.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:52.019386', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (17, 1, 17, 'OPENING', 17, 'OPEN-00017', 'IN', 100.0000, 220.0000, 22000.0000, 100.0000, 22000.0000, 220.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:52.074757', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (18, 1, 18, 'OPENING', 18, 'OPEN-00018', 'IN', 10.0000, 4200.0000, 42000.0000, 10.0000, 42000.0000, 4200.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:52.129805', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (19, 1, 19, 'OPENING', 19, 'OPEN-00019', 'IN', 15.0000, 2500.0000, 37500.0000, 15.0000, 37500.0000, 2500.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:52.18423', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (20, 1, 20, 'OPENING', 20, 'OPEN-00020', 'IN', 50.0000, 500.0000, 25000.0000, 50.0000, 25000.0000, 500.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:52.239286', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (21, 1, 21, 'OPENING', 21, 'OPEN-00021', 'IN', 40.0000, 800.0000, 32000.0000, 40.0000, 32000.0000, 800.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:52.294632', 1, 'Opening balance (pre-costing-engine stock)');
INSERT INTO public.stock_ledger VALUES (22, 1, 22, 'OPENING', 22, 'OPEN-00022', 'IN', 15.0000, 3200.0000, 48000.0000, 15.0000, 48000.0000, 3200.0000, 'weighted_average', '2026-10-29', '2026-10-29 05:44:52.348817', 1, 'Opening balance (pre-costing-engine stock)');


--
-- Data for Name: stock_take_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stock_takes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: stored_files; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tax_rate_accounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: time_policies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: timesheet_approvals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: timesheet_entries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: timesheet_merged_reports; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: timesheet_weeks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: twcf_lines; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.user_permissions VALUES (1, 3, 6, 'employees', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (2, 3, 6, 'attendance', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (3, 3, 6, 'leaves', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (4, 3, 6, 'payroll', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (5, 3, 6, 'loans', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (6, 3, 6, 'pf', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (7, 3, 6, 'products', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (8, 3, 6, 'categories', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (9, 3, 6, 'stock', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (10, 3, 6, 'consumption_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (11, 3, 6, 'scrap_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (12, 3, 6, 'adjustment_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (13, 3, 6, 'stock_take_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (14, 3, 6, 'inventory_reports', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (15, 3, 6, 'suppliers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (16, 3, 6, 'customers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (17, 3, 6, 'purchase_orders', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (18, 3, 6, 'sales_orders', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (19, 3, 6, 'purchase_invoices', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (20, 3, 6, 'purchase_returns', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (21, 3, 6, 'sales_invoices', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (22, 3, 6, 'sales_returns', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (23, 3, 6, 'payment_tracking', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (24, 3, 6, 'financial_reports', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (25, 3, 6, 'cash_payment_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (26, 3, 6, 'cash_receipt_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (27, 3, 6, 'bank_payment_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (28, 3, 6, 'bank_receipt_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (29, 3, 6, 'journal_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (30, 3, 6, 'chart_of_accounts', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (31, 3, 6, 'bank_reconciliation', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (32, 3, 6, 'fbr_dashboard', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (33, 3, 6, 'fbr_settings', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (34, 3, 6, 'fixed_assets_dashboard', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (35, 3, 6, 'fixed_assets_assets', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (36, 3, 6, 'fixed_assets_categories', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (37, 3, 6, 'fixed_assets_reports', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (38, 3, 6, 'executive_reports', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (39, 3, 8, 'employees', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (40, 3, 8, 'attendance', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (41, 3, 8, 'leaves', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (42, 3, 8, 'payroll', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (43, 3, 8, 'loans', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (44, 3, 8, 'pf', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (45, 3, 8, 'products', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (46, 3, 8, 'categories', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (47, 3, 8, 'stock', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (48, 3, 8, 'consumption_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (49, 3, 8, 'scrap_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (50, 3, 8, 'adjustment_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (51, 3, 8, 'stock_take_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (52, 3, 8, 'inventory_reports', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (53, 3, 8, 'suppliers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (54, 3, 8, 'customers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (55, 3, 8, 'purchase_orders', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (56, 3, 8, 'sales_orders', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (57, 3, 8, 'purchase_invoices', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (58, 3, 8, 'purchase_returns', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (59, 3, 8, 'sales_invoices', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (60, 3, 8, 'sales_returns', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (61, 3, 8, 'payment_tracking', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (62, 3, 8, 'financial_reports', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (63, 3, 8, 'cash_payment_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (64, 3, 8, 'cash_receipt_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (65, 3, 8, 'bank_payment_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (66, 3, 8, 'bank_receipt_vouchers', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (67, 3, 8, 'journal_vouchers', true, true, false, false, false);
INSERT INTO public.user_permissions VALUES (68, 3, 8, 'chart_of_accounts', true, false, false, false, false);
INSERT INTO public.user_permissions VALUES (69, 3, 8, 'bank_reconciliation', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (70, 3, 8, 'fbr_dashboard', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (71, 3, 8, 'fbr_settings', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (72, 3, 8, 'fixed_assets_dashboard', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (73, 3, 8, 'fixed_assets_assets', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (74, 3, 8, 'fixed_assets_categories', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (75, 3, 8, 'fixed_assets_reports', false, false, false, false, false);
INSERT INTO public.user_permissions VALUES (76, 3, 8, 'executive_reports', false, false, false, false, false);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users VALUES (2, 'ADM001', 'admin@solarkon.com', 'admin@solarkon.com', 'scrypt:32768:8:1$9Wti4Zw6atMcwbM3$2676aebea86c0190f25e3e2063d79ca3ebad45b6ee1e8f1103f49a5f85e982795ff225f9632652ea3d5227dfa8a88f7f3fba83919ff1c30753e6c70fc5004c18', 'System Admin', 3, NULL, 'Employee', NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, false, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 05:44:50.243344', '2026-10-29 05:44:51.101627');
INSERT INTO public.users VALUES (3, 'MGR002', 'manager@solarkon.com', 'manager@solarkon.com', 'scrypt:32768:8:1$8aiKHbStGloJXPnk$974a60685792df9aff4145ada2f71aa76e642dc970c1ab1e5d626bdd1d2b302c14e49a24f469b1ccb8f11551d74d2e1cdac8109c5b0d07ebc79bcb80f06c3076', 'Manager User', 2, NULL, 'Manager', NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, true, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 05:44:50.355298', '2026-10-29 05:44:51.110309');
INSERT INTO public.users VALUES (4, 'EMP001', 'emp@solarkon.com', 'emp@solarkon.com', 'scrypt:32768:8:1$kmCYJROZdXX6INYc$66713c1b59151f6e403a55e32ad66925b9497f483aea726ef04e8783719d3805d0f418907272a7597fde5a08c34d579f64955b3fde1f967a794bceae54dcd084', 'Employee User', 3, NULL, 'Employee', NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, false, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 05:44:50.467227', '2026-10-29 05:44:51.119196');
INSERT INTO public.users VALUES (5, 'EMP002', 'john.doe@solarkon.com', 'john.doe@solarkon.com', 'scrypt:32768:8:1$DS8oSQMhFQIrV3Bn$162c001ad00eaace6d0e42098f737558751bd7df2f4d22d6e4a3209bd0a35d576fbf36211e73f878e3bd17d7003d6f6827df7566edf6dc55f775fea23407a603', 'John Doe', 3, NULL, 'Employee', NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, false, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 05:44:50.577822', '2026-10-29 05:44:51.128793');
INSERT INTO public.users VALUES (1, 'SYSADMIN', 'admin@gmail.com', 'admin@gmail.com', 'scrypt:32768:8:1$rE9rSwbfFYjMyXh4$c515db21be1d97750b4bfa8e053bec4912c7670e7663b19760c5da71b4dec7ec03fe96e3f625e9a039b1c51537b8abbdfcc90c3a26b9dd7a731b825e9816109b', 'Administrator', 1, NULL, 'System Administrator', NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, true, false, false, false, false, false, false, true, NULL, NULL, '2026-10-29 05:44:50.128405', '2026-10-29 05:44:52.551216');
INSERT INTO public.users VALUES (7, 'SA0007', 'owner.b.6603bc@ref.test', 'owner.b.6603bc@ref.test', 'scrypt:32768:8:1$UEEzMvH1xRlecjDT$0b614a35d1ed81dd5d65dcc7c36fc02db8ea8dd08cc7fd69d75db6cbfc019bbae4992c39c4af6c82e7349e20ae13cbac6f2a207f5b57b9532edc0821fe93c577', 'Owner.B.6603Bc', 1, NULL, NULL, NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, true, true, true, true, true, true, true, false, NULL, NULL, '2026-10-29 05:44:54.164595', '2026-10-29 05:44:54.164598');
INSERT INTO public.users VALUES (8, 'SA0008', 'restricted.a194de@ref.test', 'restricted.a194de@ref.test', 'scrypt:32768:8:1$k7GU2tyy81m7RSUf$1f30445f0ffd5f196c863da79e21ded55441c67a89d1419c38d66d32a869494f208bce15c3e965ae9f7c0e3403d77c4a4e1b9a474add62d8622a1f0874af02cf', 'Restricted Person', 3, NULL, NULL, NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, false, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 05:44:55.861961', '2026-10-29 05:44:55.861964');
INSERT INTO public.users VALUES (9, 'SA0009', 'blocked.8a31c1@ref.test', 'blocked.8a31c1@ref.test', 'scrypt:32768:8:1$TUCu6xk5pCICmB19$3815008a52fc51735b19168d350b3d58885124f72d5afd7d5a34c9888b20e18987fb5d6284660e71301a6b0d8d7d9ef3ca3e8a4b3e7e8edd9f4355850a44af35', 'Blocked Person', 3, NULL, NULL, NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, false, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 05:44:56.252754', '2026-10-29 05:44:56.252757');
INSERT INTO public.users VALUES (6, 'SA0006', 'owner.a.db6e12@ref.test', 'owner.a.db6e12@ref.test', 'scrypt:32768:8:1$A49dkImTTPaGJ6bs$9fb86843d421e58bc874b948d3cf7e78ef27a73029a9ba4a86d91795474b25954d0c892c1433c7e7b2d5f29df3ba624d47efe722ba082318bf9971a422601481', 'Owner.A.Db6E12', 1, NULL, NULL, NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, true, true, true, true, true, true, true, false, NULL, NULL, '2026-10-29 05:44:52.861124', '2026-10-29 05:45:01.507416');


--
-- Data for Name: voucher_numbers; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.voucher_numbers VALUES (1, 1, 'PI', 1);
INSERT INTO public.voucher_numbers VALUES (2, 1, 'PR', 1);
INSERT INTO public.voucher_numbers VALUES (3, 1, 'CONS', 1);
INSERT INTO public.voucher_numbers VALUES (4, 1, 'SCRAP', 1);
INSERT INTO public.voucher_numbers VALUES (5, 1, 'ADJ', 1);
INSERT INTO public.voucher_numbers VALUES (6, 1, 'ST', 1);
INSERT INTO public.voucher_numbers VALUES (7, 1, 'CPV', 1);
INSERT INTO public.voucher_numbers VALUES (8, 1, 'CRV', 1);
INSERT INTO public.voucher_numbers VALUES (9, 1, 'BPV', 1);
INSERT INTO public.voucher_numbers VALUES (10, 1, 'BRV', 1);
INSERT INTO public.voucher_numbers VALUES (11, 1, 'JV', 1);
INSERT INTO public.voucher_numbers VALUES (12, 1, 'PRL', 1);
INSERT INTO public.voucher_numbers VALUES (13, 1, 'FA-TRF', 1);
INSERT INTO public.voucher_numbers VALUES (14, 1, 'INV-FA', 1);
INSERT INTO public.voucher_numbers VALUES (15, 2, 'PI', 1);
INSERT INTO public.voucher_numbers VALUES (16, 2, 'PR', 1);
INSERT INTO public.voucher_numbers VALUES (17, 2, 'CONS', 1);
INSERT INTO public.voucher_numbers VALUES (18, 2, 'SCRAP', 1);
INSERT INTO public.voucher_numbers VALUES (19, 2, 'ADJ', 1);
INSERT INTO public.voucher_numbers VALUES (20, 2, 'ST', 1);
INSERT INTO public.voucher_numbers VALUES (21, 2, 'CPV', 1);
INSERT INTO public.voucher_numbers VALUES (22, 2, 'CRV', 1);
INSERT INTO public.voucher_numbers VALUES (23, 2, 'BPV', 1);
INSERT INTO public.voucher_numbers VALUES (24, 2, 'BRV', 1);
INSERT INTO public.voucher_numbers VALUES (25, 2, 'JV', 1);
INSERT INTO public.voucher_numbers VALUES (26, 2, 'PRL', 1);
INSERT INTO public.voucher_numbers VALUES (27, 2, 'FA-TRF', 1);
INSERT INTO public.voucher_numbers VALUES (28, 2, 'INV-FA', 1);
INSERT INTO public.voucher_numbers VALUES (29, 3, 'PI', 1);
INSERT INTO public.voucher_numbers VALUES (30, 3, 'PR', 1);
INSERT INTO public.voucher_numbers VALUES (31, 3, 'CONS', 1);
INSERT INTO public.voucher_numbers VALUES (32, 3, 'SCRAP', 1);
INSERT INTO public.voucher_numbers VALUES (33, 3, 'ADJ', 1);
INSERT INTO public.voucher_numbers VALUES (34, 3, 'ST', 1);
INSERT INTO public.voucher_numbers VALUES (35, 3, 'CPV', 1);
INSERT INTO public.voucher_numbers VALUES (36, 3, 'CRV', 1);
INSERT INTO public.voucher_numbers VALUES (37, 3, 'BPV', 1);
INSERT INTO public.voucher_numbers VALUES (38, 3, 'BRV', 1);
INSERT INTO public.voucher_numbers VALUES (39, 3, 'JV', 1);
INSERT INTO public.voucher_numbers VALUES (40, 3, 'PRL', 1);
INSERT INTO public.voucher_numbers VALUES (41, 3, 'FA-TRF', 1);
INSERT INTO public.voucher_numbers VALUES (42, 3, 'INV-FA', 1);


--
-- Data for Name: work_packages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: accounting_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounting_periods_id_seq', 24, true);


--
-- Name: accounting_voucher_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounting_voucher_lines_id_seq', 1, false);


--
-- Name: accounting_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounting_vouchers_id_seq', 1, false);


--
-- Name: additional_charges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.additional_charges_id_seq', 1, false);


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.announcements_id_seq', 1, false);


--
-- Name: approval_workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.approval_workflows_id_seq', 1, false);


--
-- Name: asset_depreciation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.asset_depreciation_id_seq', 1, false);


--
-- Name: asset_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.asset_transfers_id_seq', 1, false);


--
-- Name: attendance_corrections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_corrections_id_seq', 1, false);


--
-- Name: attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_id_seq', 1, false);


--
-- Name: attendance_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_logs_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 645, true);


--
-- Name: bank_rec_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_rec_items_id_seq', 1, false);


--
-- Name: bank_reconciliations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_reconciliations_id_seq', 1, false);


--
-- Name: break_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.break_logs_id_seq', 1, false);


--
-- Name: button_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.button_permissions_id_seq', 1, false);


--
-- Name: category_revenue_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.category_revenue_accounts_id_seq', 1, false);


--
-- Name: change_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.change_requests_id_seq', 1, false);


--
-- Name: charge_ledger_defaults_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.charge_ledger_defaults_id_seq', 1, false);


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chart_of_accounts_id_seq', 520, true);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.companies_id_seq', 3, true);


--
-- Name: company_holidays_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.company_holidays_id_seq', 1, false);


--
-- Name: company_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.company_info_id_seq', 3, true);


--
-- Name: company_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.company_invitations_id_seq', 3, true);


--
-- Name: company_memberships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.company_memberships_id_seq', 9, true);


--
-- Name: consumption_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.consumption_items_id_seq', 1, false);


--
-- Name: consumption_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.consumption_vouchers_id_seq', 1, false);


--
-- Name: digital_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.digital_files_id_seq', 1, false);


--
-- Name: dotnet_data_protection_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dotnet_data_protection_keys_id_seq', 1, true);


--
-- Name: email_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_logs_id_seq', 1, false);


--
-- Name: exec_account_selections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.exec_account_selections_id_seq', 1, false);


--
-- Name: fa_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fa_categories_id_seq', 18, true);


--
-- Name: fbr_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fbr_config_id_seq', 1, false);


--
-- Name: fbr_invoice_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fbr_invoice_records_id_seq', 1, false);


--
-- Name: file_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.file_categories_id_seq', 1, false);


--
-- Name: fiscal_year_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fiscal_year_rule_id_seq', 3, true);


--
-- Name: fixed_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fixed_assets_id_seq', 1, false);


--
-- Name: gl_daily_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gl_daily_balances_id_seq', 44, true);


--
-- Name: global_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.global_limits_id_seq', 1, true);


--
-- Name: income_tax_slabs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.income_tax_slabs_id_seq', 1, false);


--
-- Name: inv_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_categories_id_seq', 8, true);


--
-- Name: inv_customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_customers_id_seq', 4, true);


--
-- Name: inv_invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_invoice_items_id_seq', 1, false);


--
-- Name: inv_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_invoices_id_seq', 1, false);


--
-- Name: inv_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_products_id_seq', 22, true);


--
-- Name: inv_purchase_invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_purchase_invoice_items_id_seq', 1, false);


--
-- Name: inv_purchase_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_purchase_invoices_id_seq', 1, false);


--
-- Name: inv_purchase_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_purchase_order_items_id_seq', 1, false);


--
-- Name: inv_purchase_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_purchase_orders_id_seq', 1, false);


--
-- Name: inv_purchase_return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_purchase_return_items_id_seq', 1, false);


--
-- Name: inv_purchase_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_purchase_returns_id_seq', 1, false);


--
-- Name: inv_sales_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_sales_order_items_id_seq', 1, false);


--
-- Name: inv_sales_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_sales_orders_id_seq', 1, false);


--
-- Name: inv_sales_return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_sales_return_items_id_seq', 1, false);


--
-- Name: inv_sales_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_sales_returns_id_seq', 1, false);


--
-- Name: inv_stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_stock_movements_id_seq', 1, false);


--
-- Name: inv_suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_suppliers_id_seq', 6, true);


--
-- Name: inv_units_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inv_units_id_seq', 14, true);


--
-- Name: inventory_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_settings_id_seq', 3, true);


--
-- Name: invoice_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_settings_id_seq', 1, false);


--
-- Name: invoice_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_templates_id_seq', 12, true);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journal_entries_id_seq', 22, true);


--
-- Name: journal_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journal_lines_id_seq', 44, true);


--
-- Name: kanban_boards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kanban_boards_id_seq', 1, false);


--
-- Name: kanban_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kanban_tasks_id_seq', 1, false);


--
-- Name: layer_consumptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.layer_consumptions_id_seq', 1, false);


--
-- Name: leave_approvals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_approvals_id_seq', 1, false);


--
-- Name: leave_quotas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_quotas_id_seq', 1, false);


--
-- Name: leave_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_requests_id_seq', 1, false);


--
-- Name: leave_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_types_id_seq', 1, false);


--
-- Name: loan_advance_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.loan_advance_requests_id_seq', 1, false);


--
-- Name: loan_repayments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.loan_repayments_id_seq', 1, false);


--
-- Name: notification_recipients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_recipients_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: overtime_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.overtime_accounts_id_seq', 1, false);


--
-- Name: payment_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_allocations_id_seq', 1, false);


--
-- Name: payroll_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_audit_logs_id_seq', 1, false);


--
-- Name: payroll_components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_components_id_seq', 1, false);


--
-- Name: payroll_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_profiles_id_seq', 1, false);


--
-- Name: payroll_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_runs_id_seq', 1, false);


--
-- Name: payroll_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_settings_id_seq', 1, false);


--
-- Name: payroll_slips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_slips_id_seq', 1, false);


--
-- Name: performance_goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.performance_goals_id_seq', 1, false);


--
-- Name: performance_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.performance_reviews_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 54, true);


--
-- Name: pf_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pf_config_id_seq', 1, false);


--
-- Name: pf_contributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pf_contributions_id_seq', 1, false);


--
-- Name: pf_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pf_ledger_id_seq', 1, false);


--
-- Name: pf_loan_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pf_loan_requests_id_seq', 1, false);


--
-- Name: pf_profit_distributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pf_profit_distributions_id_seq', 1, false);


--
-- Name: pf_settlements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pf_settlements_id_seq', 1, false);


--
-- Name: pf_withdrawal_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pf_withdrawal_requests_id_seq', 1, false);


--
-- Name: project_labels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_labels_id_seq', 1, false);


--
-- Name: project_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_tasks_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);


--
-- Name: registration_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.registration_requests_id_seq', 1, false);


--
-- Name: report_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.report_settings_id_seq', 3, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 3, true);


--
-- Name: salary_revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_revisions_id_seq', 1, false);


--
-- Name: scrap_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scrap_items_id_seq', 1, false);


--
-- Name: scrap_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scrap_vouchers_id_seq', 1, false);


--
-- Name: stock_adjustment_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_adjustment_items_id_seq', 1, false);


--
-- Name: stock_adjustment_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_adjustment_vouchers_id_seq', 1, false);


--
-- Name: stock_cost_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_cost_adjustments_id_seq', 1, false);


--
-- Name: stock_layers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_layers_id_seq', 22, true);


--
-- Name: stock_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_ledger_id_seq', 22, true);


--
-- Name: stock_take_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_take_items_id_seq', 1, false);


--
-- Name: stock_takes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_takes_id_seq', 1, false);


--
-- Name: stored_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stored_files_id_seq', 1, false);


--
-- Name: tax_rate_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tax_rate_accounts_id_seq', 1, false);


--
-- Name: team_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.team_events_id_seq', 1, false);


--
-- Name: time_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.time_policies_id_seq', 1, false);


--
-- Name: timesheet_approvals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.timesheet_approvals_id_seq', 1, false);


--
-- Name: timesheet_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.timesheet_entries_id_seq', 1, false);


--
-- Name: timesheet_merged_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.timesheet_merged_reports_id_seq', 1, false);


--
-- Name: timesheet_weeks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.timesheet_weeks_id_seq', 1, false);


--
-- Name: twcf_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.twcf_lines_id_seq', 1, false);


--
-- Name: user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_permissions_id_seq', 76, true);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 105, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 9, true);


--
-- Name: voucher_numbers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.voucher_numbers_id_seq', 42, true);


--
-- Name: work_packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.work_packages_id_seq', 1, false);


--
-- Name: accounting_periods accounting_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_periods
    ADD CONSTRAINT accounting_periods_pkey PRIMARY KEY (id);


--
-- Name: accounting_voucher_lines accounting_voucher_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_voucher_lines
    ADD CONSTRAINT accounting_voucher_lines_pkey PRIMARY KEY (id);


--
-- Name: accounting_vouchers accounting_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT accounting_vouchers_pkey PRIMARY KEY (id);


--
-- Name: additional_charges additional_charges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.additional_charges
    ADD CONSTRAINT additional_charges_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: approval_workflows approval_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_pkey PRIMARY KEY (id);


--
-- Name: asset_depreciation asset_depreciation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_depreciation
    ADD CONSTRAINT asset_depreciation_pkey PRIMARY KEY (id);


--
-- Name: asset_transfers asset_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_transfers
    ADD CONSTRAINT asset_transfers_pkey PRIMARY KEY (id);


--
-- Name: attendance_corrections attendance_corrections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_corrections
    ADD CONSTRAINT attendance_corrections_pkey PRIMARY KEY (id);


--
-- Name: attendance_logs attendance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_logs
    ADD CONSTRAINT attendance_logs_pkey PRIMARY KEY (id);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_rec_items bank_rec_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_rec_items
    ADD CONSTRAINT bank_rec_items_pkey PRIMARY KEY (id);


--
-- Name: bank_reconciliations bank_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: break_logs break_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.break_logs
    ADD CONSTRAINT break_logs_pkey PRIMARY KEY (id);


--
-- Name: button_permissions button_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.button_permissions
    ADD CONSTRAINT button_permissions_pkey PRIMARY KEY (id);


--
-- Name: category_revenue_accounts category_revenue_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_revenue_accounts
    ADD CONSTRAINT category_revenue_accounts_pkey PRIMARY KEY (id);


--
-- Name: change_requests change_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_requests
    ADD CONSTRAINT change_requests_pkey PRIMARY KEY (id);


--
-- Name: charge_ledger_defaults charge_ledger_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.charge_ledger_defaults
    ADD CONSTRAINT charge_ledger_defaults_pkey PRIMARY KEY (id);


--
-- Name: chart_of_accounts chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: companies companies_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_slug_key UNIQUE (slug);


--
-- Name: company_holidays company_holidays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_holidays
    ADD CONSTRAINT company_holidays_pkey PRIMARY KEY (id);


--
-- Name: company_info company_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_info
    ADD CONSTRAINT company_info_pkey PRIMARY KEY (id);


--
-- Name: company_invitations company_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_invitations
    ADD CONSTRAINT company_invitations_pkey PRIMARY KEY (id);


--
-- Name: company_memberships company_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT company_memberships_pkey PRIMARY KEY (id);


--
-- Name: consumption_items consumption_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consumption_items
    ADD CONSTRAINT consumption_items_pkey PRIMARY KEY (id);


--
-- Name: consumption_vouchers consumption_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT consumption_vouchers_pkey PRIMARY KEY (id);


--
-- Name: digital_files digital_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digital_files
    ADD CONSTRAINT digital_files_pkey PRIMARY KEY (id);


--
-- Name: dotnet_data_protection_keys dotnet_data_protection_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dotnet_data_protection_keys
    ADD CONSTRAINT dotnet_data_protection_keys_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: exec_account_selections exec_account_selections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exec_account_selections
    ADD CONSTRAINT exec_account_selections_pkey PRIMARY KEY (id);


--
-- Name: fa_categories fa_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fa_categories
    ADD CONSTRAINT fa_categories_pkey PRIMARY KEY (id);


--
-- Name: fbr_config fbr_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fbr_config
    ADD CONSTRAINT fbr_config_pkey PRIMARY KEY (id);


--
-- Name: fbr_invoice_records fbr_invoice_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fbr_invoice_records
    ADD CONSTRAINT fbr_invoice_records_pkey PRIMARY KEY (id);


--
-- Name: file_categories file_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_categories
    ADD CONSTRAINT file_categories_pkey PRIMARY KEY (id);


--
-- Name: fiscal_year_rule fiscal_year_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_year_rule
    ADD CONSTRAINT fiscal_year_rule_pkey PRIMARY KEY (id);


--
-- Name: fixed_assets fixed_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_pkey PRIMARY KEY (id);


--
-- Name: gl_daily_balances gl_daily_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gl_daily_balances
    ADD CONSTRAINT gl_daily_balances_pkey PRIMARY KEY (id);


--
-- Name: global_limits global_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_limits
    ADD CONSTRAINT global_limits_pkey PRIMARY KEY (id);


--
-- Name: income_tax_slabs income_tax_slabs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income_tax_slabs
    ADD CONSTRAINT income_tax_slabs_pkey PRIMARY KEY (id);


--
-- Name: inv_categories inv_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_categories
    ADD CONSTRAINT inv_categories_pkey PRIMARY KEY (id);


--
-- Name: inv_customers inv_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_customers
    ADD CONSTRAINT inv_customers_pkey PRIMARY KEY (id);


--
-- Name: inv_invoice_items inv_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: inv_invoices inv_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_pkey PRIMARY KEY (id);


--
-- Name: inv_products inv_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_products
    ADD CONSTRAINT inv_products_pkey PRIMARY KEY (id);


--
-- Name: inv_purchase_invoice_items inv_purchase_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: inv_purchase_invoices inv_purchase_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_pkey PRIMARY KEY (id);


--
-- Name: inv_purchase_order_items inv_purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_order_items
    ADD CONSTRAINT inv_purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: inv_purchase_orders inv_purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT inv_purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: inv_purchase_return_items inv_purchase_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_return_items
    ADD CONSTRAINT inv_purchase_return_items_pkey PRIMARY KEY (id);


--
-- Name: inv_purchase_returns inv_purchase_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT inv_purchase_returns_pkey PRIMARY KEY (id);


--
-- Name: inv_sales_order_items inv_sales_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_order_items
    ADD CONSTRAINT inv_sales_order_items_pkey PRIMARY KEY (id);


--
-- Name: inv_sales_orders inv_sales_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT inv_sales_orders_pkey PRIMARY KEY (id);


--
-- Name: inv_sales_return_items inv_sales_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_return_items
    ADD CONSTRAINT inv_sales_return_items_pkey PRIMARY KEY (id);


--
-- Name: inv_sales_returns inv_sales_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_pkey PRIMARY KEY (id);


--
-- Name: inv_stock_movements inv_stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_stock_movements
    ADD CONSTRAINT inv_stock_movements_pkey PRIMARY KEY (id);


--
-- Name: inv_suppliers inv_suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_suppliers
    ADD CONSTRAINT inv_suppliers_pkey PRIMARY KEY (id);


--
-- Name: inv_units inv_units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_units
    ADD CONSTRAINT inv_units_pkey PRIMARY KEY (id);


--
-- Name: inventory_settings inventory_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_pkey PRIMARY KEY (id);


--
-- Name: invoice_settings invoice_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_settings
    ADD CONSTRAINT invoice_settings_pkey PRIMARY KEY (id);


--
-- Name: invoice_templates invoice_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_templates
    ADD CONSTRAINT invoice_templates_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_lines journal_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_pkey PRIMARY KEY (id);


--
-- Name: kanban_boards kanban_boards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kanban_boards
    ADD CONSTRAINT kanban_boards_pkey PRIMARY KEY (id);


--
-- Name: kanban_tasks kanban_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kanban_tasks
    ADD CONSTRAINT kanban_tasks_pkey PRIMARY KEY (id);


--
-- Name: layer_consumptions layer_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.layer_consumptions
    ADD CONSTRAINT layer_consumptions_pkey PRIMARY KEY (id);


--
-- Name: leave_approvals leave_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_approvals
    ADD CONSTRAINT leave_approvals_pkey PRIMARY KEY (id);


--
-- Name: leave_quotas leave_quotas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_quotas
    ADD CONSTRAINT leave_quotas_pkey PRIMARY KEY (id);


--
-- Name: leave_requests leave_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_pkey PRIMARY KEY (id);


--
-- Name: leave_types leave_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT leave_types_pkey PRIMARY KEY (id);


--
-- Name: loan_advance_requests loan_advance_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_advance_requests
    ADD CONSTRAINT loan_advance_requests_pkey PRIMARY KEY (id);


--
-- Name: loan_repayments loan_repayments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_repayments
    ADD CONSTRAINT loan_repayments_pkey PRIMARY KEY (id);


--
-- Name: notification_recipients notification_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_recipients
    ADD CONSTRAINT notification_recipients_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: overtime_accounts overtime_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.overtime_accounts
    ADD CONSTRAINT overtime_accounts_pkey PRIMARY KEY (id);


--
-- Name: payment_allocations payment_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_pkey PRIMARY KEY (id);


--
-- Name: payroll_audit_logs payroll_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_audit_logs
    ADD CONSTRAINT payroll_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: payroll_components payroll_components_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_components
    ADD CONSTRAINT payroll_components_pkey PRIMARY KEY (id);


--
-- Name: payroll_profiles payroll_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_profiles
    ADD CONSTRAINT payroll_profiles_pkey PRIMARY KEY (id);


--
-- Name: payroll_runs payroll_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_pkey PRIMARY KEY (id);


--
-- Name: payroll_settings payroll_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_settings
    ADD CONSTRAINT payroll_settings_pkey PRIMARY KEY (id);


--
-- Name: payroll_slips payroll_slips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_slips
    ADD CONSTRAINT payroll_slips_pkey PRIMARY KEY (id);


--
-- Name: performance_goals performance_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_goals
    ADD CONSTRAINT performance_goals_pkey PRIMARY KEY (id);


--
-- Name: performance_reviews performance_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: pf_config pf_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_config
    ADD CONSTRAINT pf_config_pkey PRIMARY KEY (id);


--
-- Name: pf_contributions pf_contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_contributions
    ADD CONSTRAINT pf_contributions_pkey PRIMARY KEY (id);


--
-- Name: pf_ledger pf_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_ledger
    ADD CONSTRAINT pf_ledger_pkey PRIMARY KEY (id);


--
-- Name: pf_loan_requests pf_loan_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_loan_requests
    ADD CONSTRAINT pf_loan_requests_pkey PRIMARY KEY (id);


--
-- Name: pf_profit_distributions pf_profit_distributions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_profit_distributions
    ADD CONSTRAINT pf_profit_distributions_pkey PRIMARY KEY (id);


--
-- Name: pf_settlements pf_settlements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_settlements
    ADD CONSTRAINT pf_settlements_pkey PRIMARY KEY (id);


--
-- Name: pf_withdrawal_requests pf_withdrawal_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_withdrawal_requests
    ADD CONSTRAINT pf_withdrawal_requests_pkey PRIMARY KEY (id);


--
-- Name: project_labels project_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_labels
    ADD CONSTRAINT project_labels_pkey PRIMARY KEY (id);


--
-- Name: project_tasks project_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: registration_requests registration_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_pkey PRIMARY KEY (id);


--
-- Name: report_settings report_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_settings
    ADD CONSTRAINT report_settings_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: salary_revisions salary_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_revisions
    ADD CONSTRAINT salary_revisions_pkey PRIMARY KEY (id);


--
-- Name: scrap_items scrap_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_items
    ADD CONSTRAINT scrap_items_pkey PRIMARY KEY (id);


--
-- Name: scrap_vouchers scrap_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT scrap_vouchers_pkey PRIMARY KEY (id);


--
-- Name: stock_adjustment_items stock_adjustment_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustment_items
    ADD CONSTRAINT stock_adjustment_items_pkey PRIMARY KEY (id);


--
-- Name: stock_adjustment_vouchers stock_adjustment_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustment_vouchers
    ADD CONSTRAINT stock_adjustment_vouchers_pkey PRIMARY KEY (id);


--
-- Name: stock_cost_adjustments stock_cost_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_cost_adjustments
    ADD CONSTRAINT stock_cost_adjustments_pkey PRIMARY KEY (id);


--
-- Name: stock_layers stock_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_layers
    ADD CONSTRAINT stock_layers_pkey PRIMARY KEY (id);


--
-- Name: stock_ledger stock_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_pkey PRIMARY KEY (id);


--
-- Name: stock_take_items stock_take_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_pkey PRIMARY KEY (id);


--
-- Name: stock_takes stock_takes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_pkey PRIMARY KEY (id);


--
-- Name: stored_files stored_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_files
    ADD CONSTRAINT stored_files_pkey PRIMARY KEY (id);


--
-- Name: tax_rate_accounts tax_rate_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_accounts
    ADD CONSTRAINT tax_rate_accounts_pkey PRIMARY KEY (id);


--
-- Name: team_events team_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_events
    ADD CONSTRAINT team_events_pkey PRIMARY KEY (id);


--
-- Name: time_policies time_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_policies
    ADD CONSTRAINT time_policies_pkey PRIMARY KEY (id);


--
-- Name: timesheet_approvals timesheet_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_approvals
    ADD CONSTRAINT timesheet_approvals_pkey PRIMARY KEY (id);


--
-- Name: timesheet_entries timesheet_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_entries
    ADD CONSTRAINT timesheet_entries_pkey PRIMARY KEY (id);


--
-- Name: timesheet_merged_reports timesheet_merged_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_merged_reports
    ADD CONSTRAINT timesheet_merged_reports_pkey PRIMARY KEY (id);


--
-- Name: timesheet_weeks timesheet_weeks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_weeks
    ADD CONSTRAINT timesheet_weeks_pkey PRIMARY KEY (id);


--
-- Name: twcf_lines twcf_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.twcf_lines
    ADD CONSTRAINT twcf_lines_pkey PRIMARY KEY (id);


--
-- Name: accounting_vouchers uq_accounting_vouchers_voucher_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT uq_accounting_vouchers_voucher_number UNIQUE (company_id, voucher_number);


--
-- Name: asset_transfers uq_asset_transfers_voucher_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_transfers
    ADD CONSTRAINT uq_asset_transfers_voucher_number UNIQUE (company_id, voucher_number);


--
-- Name: attendance uq_attendance_company_date; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT uq_attendance_company_date UNIQUE (company_id, user_id, date);


--
-- Name: bank_rec_items uq_bank_rec_item; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_rec_items
    ADD CONSTRAINT uq_bank_rec_item UNIQUE (reconciliation_id, journal_line_id);


--
-- Name: button_permissions uq_button_perm_company; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.button_permissions
    ADD CONSTRAINT uq_button_perm_company UNIQUE (company_id, role_id, button_code);


--
-- Name: category_revenue_accounts uq_category_revenue_accounts_category_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_revenue_accounts
    ADD CONSTRAINT uq_category_revenue_accounts_category_id UNIQUE (company_id, category_id);


--
-- Name: charge_ledger_defaults uq_charge_ledger_defaults_account_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.charge_ledger_defaults
    ADD CONSTRAINT uq_charge_ledger_defaults_account_id UNIQUE (company_id, account_id);


--
-- Name: chart_of_accounts uq_chart_of_accounts_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT uq_chart_of_accounts_code UNIQUE (company_id, code);


--
-- Name: consumption_vouchers uq_consumption_vouchers_voucher_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT uq_consumption_vouchers_voucher_number UNIQUE (company_id, voucher_number);


--
-- Name: dotnet_data_protection_keys uq_dotnet_dp_keys_friendly_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dotnet_data_protection_keys
    ADD CONSTRAINT uq_dotnet_dp_keys_friendly_name UNIQUE (friendly_name);


--
-- Name: exec_account_selections uq_exec_selection_company_account; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exec_account_selections
    ADD CONSTRAINT uq_exec_selection_company_account UNIQUE (company_id, account_id);


--
-- Name: fa_categories uq_fa_categories_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fa_categories
    ADD CONSTRAINT uq_fa_categories_name UNIQUE (company_id, name);


--
-- Name: file_categories uq_file_categories_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_categories
    ADD CONSTRAINT uq_file_categories_name UNIQUE (company_id, name);


--
-- Name: fixed_assets uq_fixed_assets_asset_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT uq_fixed_assets_asset_code UNIQUE (company_id, asset_code);


--
-- Name: gl_daily_balances uq_gl_daily_balances_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gl_daily_balances
    ADD CONSTRAINT uq_gl_daily_balances_key UNIQUE (company_id, account_id, label_id, day);


--
-- Name: company_holidays uq_holiday_date_dept_company; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_holidays
    ADD CONSTRAINT uq_holiday_date_dept_company UNIQUE (company_id, holiday_date, department);


--
-- Name: inv_invoices uq_inv_invoices_invoice_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT uq_inv_invoices_invoice_number UNIQUE (company_id, invoice_number);


--
-- Name: inv_invoices uq_inv_invoices_voucher_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT uq_inv_invoices_voucher_number UNIQUE (company_id, voucher_number);


--
-- Name: inv_products uq_inv_products_sku; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_products
    ADD CONSTRAINT uq_inv_products_sku UNIQUE (company_id, sku);


--
-- Name: inv_purchase_invoices uq_inv_purchase_invoices_invoice_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT uq_inv_purchase_invoices_invoice_number UNIQUE (company_id, invoice_number);


--
-- Name: inv_purchase_invoices uq_inv_purchase_invoices_voucher_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT uq_inv_purchase_invoices_voucher_number UNIQUE (company_id, voucher_number);


--
-- Name: inv_purchase_orders uq_inv_purchase_orders_po_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT uq_inv_purchase_orders_po_number UNIQUE (company_id, po_number);


--
-- Name: inv_purchase_returns uq_inv_purchase_returns_return_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT uq_inv_purchase_returns_return_number UNIQUE (company_id, return_number);


--
-- Name: inv_sales_orders uq_inv_sales_orders_so_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT uq_inv_sales_orders_so_number UNIQUE (company_id, so_number);


--
-- Name: inv_sales_returns uq_inv_sales_returns_return_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT uq_inv_sales_returns_return_number UNIQUE (company_id, return_number);


--
-- Name: inv_units uq_inv_units_abbreviation; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_units
    ADD CONSTRAINT uq_inv_units_abbreviation UNIQUE (company_id, abbreviation);


--
-- Name: inv_units uq_inv_units_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_units
    ADD CONSTRAINT uq_inv_units_name UNIQUE (company_id, name);


--
-- Name: leave_quotas uq_leave_quota_company; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_quotas
    ADD CONSTRAINT uq_leave_quota_company UNIQUE (company_id, user_id, leave_type_id, year);


--
-- Name: leave_types uq_leave_types_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT uq_leave_types_code UNIQUE (company_id, code);


--
-- Name: leave_types uq_leave_types_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT uq_leave_types_name UNIQUE (company_id, name);


--
-- Name: company_memberships uq_membership_company_emp_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT uq_membership_company_emp_code UNIQUE (company_id, employee_code);


--
-- Name: company_memberships uq_membership_company_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT uq_membership_company_user UNIQUE (company_id, user_id);


--
-- Name: overtime_accounts uq_overtime_date_company; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.overtime_accounts
    ADD CONSTRAINT uq_overtime_date_company UNIQUE (company_id, user_id, date);


--
-- Name: payment_allocations uq_payment_allocations_line_doc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT uq_payment_allocations_line_doc UNIQUE (company_id, voucher_line_id, doc_type, doc_id);


--
-- Name: payroll_profiles uq_payroll_profiles_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_profiles
    ADD CONSTRAINT uq_payroll_profiles_user_id UNIQUE (company_id, user_id);


--
-- Name: payroll_runs uq_payroll_run_company; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT uq_payroll_run_company UNIQUE (company_id, month, year);


--
-- Name: payroll_slips uq_payroll_slip_company; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_slips
    ADD CONSTRAINT uq_payroll_slip_company UNIQUE (company_id, payroll_run_id, user_id);


--
-- Name: pf_contributions uq_pf_contribution_company; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_contributions
    ADD CONSTRAINT uq_pf_contribution_company UNIQUE (company_id, user_id, month, year);


--
-- Name: project_labels uq_project_labels_company_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_labels
    ADD CONSTRAINT uq_project_labels_company_name UNIQUE (company_id, name);


--
-- Name: projects uq_projects_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT uq_projects_code UNIQUE (company_id, code);


--
-- Name: scrap_vouchers uq_scrap_vouchers_voucher_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT uq_scrap_vouchers_voucher_number UNIQUE (company_id, voucher_number);


--
-- Name: stock_adjustment_vouchers uq_stock_adjustment_vouchers_voucher_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustment_vouchers
    ADD CONSTRAINT uq_stock_adjustment_vouchers_voucher_number UNIQUE (company_id, voucher_number);


--
-- Name: stock_takes uq_stock_takes_reference; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT uq_stock_takes_reference UNIQUE (company_id, reference);


--
-- Name: stored_files uq_stored_files_company_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_files
    ADD CONSTRAINT uq_stored_files_company_key UNIQUE (company_id, key);


--
-- Name: tax_rate_accounts uq_tax_rate_accounts_rate_pct; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_accounts
    ADD CONSTRAINT uq_tax_rate_accounts_rate_pct UNIQUE (company_id, rate_pct);


--
-- Name: timesheet_weeks uq_ts_week_company; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_weeks
    ADD CONSTRAINT uq_ts_week_company UNIQUE (company_id, user_id, week_start);


--
-- Name: user_permissions uq_user_perm_company; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT uq_user_perm_company UNIQUE (company_id, user_id, resource);


--
-- Name: voucher_numbers uq_voucher_numbers_prefix; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voucher_numbers
    ADD CONSTRAINT uq_voucher_numbers_prefix UNIQUE (company_id, prefix);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_token_hash_key UNIQUE (token_hash);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_employee_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_employee_code_key UNIQUE (employee_code);


--
-- Name: users users_login_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_login_id_key UNIQUE (login_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: voucher_numbers voucher_numbers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voucher_numbers
    ADD CONSTRAINT voucher_numbers_pkey PRIMARY KEY (id);


--
-- Name: work_packages work_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT work_packages_pkey PRIMARY KEY (id);


--
-- Name: ix_accounting_periods_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_accounting_periods_company_id ON public.accounting_periods USING btree (company_id);


--
-- Name: ix_accounting_periods_fiscal_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_accounting_periods_fiscal_year ON public.accounting_periods USING btree (fiscal_year);


--
-- Name: ix_accounting_voucher_lines_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_accounting_voucher_lines_company_id ON public.accounting_voucher_lines USING btree (company_id);


--
-- Name: ix_accounting_vouchers_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_accounting_vouchers_company_id ON public.accounting_vouchers USING btree (company_id);


--
-- Name: ix_additional_charges_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_additional_charges_company_id ON public.additional_charges USING btree (company_id);


--
-- Name: ix_additional_charges_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_additional_charges_doc ON public.additional_charges USING btree (company_id, doc_type, doc_id);


--
-- Name: ix_announcements_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_company_id ON public.announcements USING btree (company_id);


--
-- Name: ix_approval_workflows_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approval_workflows_company_id ON public.approval_workflows USING btree (company_id);


--
-- Name: ix_asset_depreciation_asset; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asset_depreciation_asset ON public.asset_depreciation USING btree (asset_id, entry_date);


--
-- Name: ix_asset_depreciation_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asset_depreciation_company_id ON public.asset_depreciation USING btree (company_id);


--
-- Name: ix_asset_transfers_asset; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asset_transfers_asset ON public.asset_transfers USING btree (asset_id);


--
-- Name: ix_asset_transfers_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asset_transfers_company_id ON public.asset_transfers USING btree (company_id);


--
-- Name: ix_attendance_company_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_attendance_company_date ON public.attendance USING btree (company_id, date);


--
-- Name: ix_attendance_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_attendance_company_id ON public.attendance USING btree (company_id);


--
-- Name: ix_attendance_corrections_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_attendance_corrections_company_id ON public.attendance_corrections USING btree (company_id);


--
-- Name: ix_attendance_logs_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_attendance_logs_company_id ON public.attendance_logs USING btree (company_id);


--
-- Name: ix_audit_logs_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: ix_audit_logs_action_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_action_created_at ON public.audit_logs USING btree (action, created_at);


--
-- Name: ix_audit_logs_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_company_id ON public.audit_logs USING btree (company_id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_entity_id ON public.audit_logs USING btree (entity_id);


--
-- Name: ix_audit_logs_entity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_entity_type ON public.audit_logs USING btree (entity_type);


--
-- Name: ix_audit_logs_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_module ON public.audit_logs USING btree (module);


--
-- Name: ix_audit_logs_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_reference ON public.audit_logs USING btree (reference);


--
-- Name: ix_audit_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: ix_bank_rec_items_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bank_rec_items_company_id ON public.bank_rec_items USING btree (company_id);


--
-- Name: ix_bank_rec_items_journal_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bank_rec_items_journal_line_id ON public.bank_rec_items USING btree (journal_line_id);


--
-- Name: ix_bank_rec_items_reconciliation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bank_rec_items_reconciliation_id ON public.bank_rec_items USING btree (reconciliation_id);


--
-- Name: ix_bank_reconciliations_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_bank_reconciliations_company_id ON public.bank_reconciliations USING btree (company_id);


--
-- Name: ix_break_logs_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_break_logs_company_id ON public.break_logs USING btree (company_id);


--
-- Name: ix_button_permissions_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_button_permissions_company_id ON public.button_permissions USING btree (company_id);


--
-- Name: ix_category_revenue_accounts_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_category_revenue_accounts_company_id ON public.category_revenue_accounts USING btree (company_id);


--
-- Name: ix_change_requests_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_change_requests_company_id ON public.change_requests USING btree (company_id);


--
-- Name: ix_charge_ledger_defaults_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_charge_ledger_defaults_company_id ON public.charge_ledger_defaults USING btree (company_id);


--
-- Name: ix_chart_of_accounts_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chart_of_accounts_company_id ON public.chart_of_accounts USING btree (company_id);


--
-- Name: ix_company_holidays_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_holidays_company_id ON public.company_holidays USING btree (company_id);


--
-- Name: ix_company_info_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_info_company_id ON public.company_info USING btree (company_id);


--
-- Name: ix_company_invitations_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_invitations_company_id ON public.company_invitations USING btree (company_id);


--
-- Name: ix_company_memberships_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_memberships_company_id ON public.company_memberships USING btree (company_id);


--
-- Name: ix_company_memberships_manager_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_memberships_manager_id ON public.company_memberships USING btree (manager_id);


--
-- Name: ix_company_memberships_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_company_memberships_user_id ON public.company_memberships USING btree (user_id);


--
-- Name: ix_consumption_items_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_consumption_items_company_id ON public.consumption_items USING btree (company_id);


--
-- Name: ix_consumption_vouchers_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_consumption_vouchers_company_id ON public.consumption_vouchers USING btree (company_id);


--
-- Name: ix_digital_files_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_digital_files_company_id ON public.digital_files USING btree (company_id);


--
-- Name: ix_email_logs_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_logs_company_id ON public.email_logs USING btree (company_id);


--
-- Name: ix_exec_account_selections_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exec_account_selections_account_id ON public.exec_account_selections USING btree (account_id);


--
-- Name: ix_exec_account_selections_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exec_account_selections_company_id ON public.exec_account_selections USING btree (company_id);


--
-- Name: ix_fa_categories_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fa_categories_company_id ON public.fa_categories USING btree (company_id);


--
-- Name: ix_fbr_config_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fbr_config_company_id ON public.fbr_config USING btree (company_id);


--
-- Name: ix_fbr_invoice_records_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fbr_invoice_records_company_id ON public.fbr_invoice_records USING btree (company_id);


--
-- Name: ix_fbr_invoice_records_invoice_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fbr_invoice_records_invoice_status ON public.fbr_invoice_records USING btree (inv_invoice_id, status);


--
-- Name: ix_file_categories_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_file_categories_company_id ON public.file_categories USING btree (company_id);


--
-- Name: ix_fiscal_year_rule_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fiscal_year_rule_company_id ON public.fiscal_year_rule USING btree (company_id);


--
-- Name: ix_fixed_assets_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fixed_assets_company_id ON public.fixed_assets USING btree (company_id);


--
-- Name: ix_gl_daily_balances_account_day; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gl_daily_balances_account_day ON public.gl_daily_balances USING btree (account_id, day);


--
-- Name: ix_gl_daily_balances_company_day; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gl_daily_balances_company_day ON public.gl_daily_balances USING btree (company_id, day);


--
-- Name: ix_gl_daily_balances_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gl_daily_balances_company_id ON public.gl_daily_balances USING btree (company_id);


--
-- Name: ix_income_tax_slabs_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_income_tax_slabs_company_id ON public.income_tax_slabs USING btree (company_id);


--
-- Name: ix_inv_categories_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_categories_company_id ON public.inv_categories USING btree (company_id);


--
-- Name: ix_inv_customers_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_customers_company_id ON public.inv_customers USING btree (company_id);


--
-- Name: ix_inv_invoice_items_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_invoice_items_company_id ON public.inv_invoice_items USING btree (company_id);


--
-- Name: ix_inv_invoice_items_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_invoice_items_invoice_id ON public.inv_invoice_items USING btree (invoice_id);


--
-- Name: ix_inv_invoices_company_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_invoices_company_date ON public.inv_invoices USING btree (company_id, invoice_date);


--
-- Name: ix_inv_invoices_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_invoices_company_id ON public.inv_invoices USING btree (company_id);


--
-- Name: ix_inv_products_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_products_company_id ON public.inv_products USING btree (company_id);


--
-- Name: ix_inv_purchase_invoice_items_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_purchase_invoice_items_company_id ON public.inv_purchase_invoice_items USING btree (company_id);


--
-- Name: ix_inv_purchase_invoice_items_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_purchase_invoice_items_invoice_id ON public.inv_purchase_invoice_items USING btree (invoice_id);


--
-- Name: ix_inv_purchase_invoices_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_purchase_invoices_company_id ON public.inv_purchase_invoices USING btree (company_id);


--
-- Name: ix_inv_purchase_order_items_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_purchase_order_items_company_id ON public.inv_purchase_order_items USING btree (company_id);


--
-- Name: ix_inv_purchase_orders_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_purchase_orders_company_id ON public.inv_purchase_orders USING btree (company_id);


--
-- Name: ix_inv_purchase_return_items_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_purchase_return_items_company_id ON public.inv_purchase_return_items USING btree (company_id);


--
-- Name: ix_inv_purchase_returns_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_purchase_returns_company_id ON public.inv_purchase_returns USING btree (company_id);


--
-- Name: ix_inv_sales_order_items_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_sales_order_items_company_id ON public.inv_sales_order_items USING btree (company_id);


--
-- Name: ix_inv_sales_orders_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_sales_orders_company_id ON public.inv_sales_orders USING btree (company_id);


--
-- Name: ix_inv_sales_return_items_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_sales_return_items_company_id ON public.inv_sales_return_items USING btree (company_id);


--
-- Name: ix_inv_sales_returns_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_sales_returns_company_id ON public.inv_sales_returns USING btree (company_id);


--
-- Name: ix_inv_stock_movements_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_stock_movements_company_id ON public.inv_stock_movements USING btree (company_id);


--
-- Name: ix_inv_stock_movements_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_stock_movements_product ON public.inv_stock_movements USING btree (product_id, id);


--
-- Name: ix_inv_suppliers_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_suppliers_company_id ON public.inv_suppliers USING btree (company_id);


--
-- Name: ix_inv_units_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inv_units_company_id ON public.inv_units USING btree (company_id);


--
-- Name: ix_inventory_settings_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_settings_company_id ON public.inventory_settings USING btree (company_id);


--
-- Name: ix_invoice_settings_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invoice_settings_company_id ON public.invoice_settings USING btree (company_id);


--
-- Name: ix_invoice_templates_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invoice_templates_company_id ON public.invoice_templates USING btree (company_id);


--
-- Name: ix_journal_entries_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_journal_entries_company_id ON public.journal_entries USING btree (company_id);


--
-- Name: ix_journal_entries_company_posted_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_journal_entries_company_posted_date ON public.journal_entries USING btree (company_id, is_posted, entry_date);


--
-- Name: ix_journal_entries_voucher; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_journal_entries_voucher ON public.journal_entries USING btree (voucher_type, voucher_id);


--
-- Name: ix_journal_entries_voucher_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_journal_entries_voucher_number ON public.journal_entries USING btree (voucher_number);


--
-- Name: ix_journal_lines_account_entry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_journal_lines_account_entry ON public.journal_lines USING btree (account_id, journal_entry_id);


--
-- Name: ix_journal_lines_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_journal_lines_company_id ON public.journal_lines USING btree (company_id);


--
-- Name: ix_journal_lines_entry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_journal_lines_entry ON public.journal_lines USING btree (journal_entry_id);


--
-- Name: ix_kanban_boards_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kanban_boards_company_id ON public.kanban_boards USING btree (company_id);


--
-- Name: ix_kanban_tasks_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kanban_tasks_company_id ON public.kanban_tasks USING btree (company_id);


--
-- Name: ix_layer_consumptions_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_layer_consumptions_company_id ON public.layer_consumptions USING btree (company_id);


--
-- Name: ix_layer_consumptions_layer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_layer_consumptions_layer_id ON public.layer_consumptions USING btree (layer_id);


--
-- Name: ix_layer_consumptions_out_ledger_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_layer_consumptions_out_ledger_id ON public.layer_consumptions USING btree (out_ledger_id);


--
-- Name: ix_layer_consumptions_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_layer_consumptions_product_id ON public.layer_consumptions USING btree (product_id);


--
-- Name: ix_leave_approvals_approver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_leave_approvals_approver ON public.leave_approvals USING btree (company_id, approver_id, status);


--
-- Name: ix_leave_approvals_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_leave_approvals_company_id ON public.leave_approvals USING btree (company_id);


--
-- Name: ix_leave_quotas_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_leave_quotas_company_id ON public.leave_quotas USING btree (company_id);


--
-- Name: ix_leave_requests_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_leave_requests_company_id ON public.leave_requests USING btree (company_id);


--
-- Name: ix_leave_requests_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_leave_requests_user ON public.leave_requests USING btree (company_id, user_id, status);


--
-- Name: ix_leave_types_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_leave_types_company_id ON public.leave_types USING btree (company_id);


--
-- Name: ix_loan_advance_requests_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_loan_advance_requests_company_id ON public.loan_advance_requests USING btree (company_id);


--
-- Name: ix_loan_repayments_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_loan_repayments_company_id ON public.loan_repayments USING btree (company_id);


--
-- Name: ix_loan_requests_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_loan_requests_user ON public.loan_advance_requests USING btree (company_id, user_id, status);


--
-- Name: ix_notification_recipients_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_recipients_company_id ON public.notification_recipients USING btree (company_id);


--
-- Name: ix_notification_recipients_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_recipients_unread ON public.notification_recipients USING btree (company_id, user_id, id) WHERE (is_read = false);


--
-- Name: ix_notifications_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_company_id ON public.notifications USING btree (company_id);


--
-- Name: ix_overtime_accounts_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_overtime_accounts_company_id ON public.overtime_accounts USING btree (company_id);


--
-- Name: ix_payment_allocations_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payment_allocations_company_id ON public.payment_allocations USING btree (company_id);


--
-- Name: ix_payment_allocations_doc_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payment_allocations_doc_id ON public.payment_allocations USING btree (doc_id);


--
-- Name: ix_payment_allocations_party_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payment_allocations_party_id ON public.payment_allocations USING btree (party_id);


--
-- Name: ix_payment_allocations_voucher_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payment_allocations_voucher_id ON public.payment_allocations USING btree (voucher_id);


--
-- Name: ix_payment_allocations_voucher_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payment_allocations_voucher_line_id ON public.payment_allocations USING btree (voucher_line_id);


--
-- Name: ix_payroll_audit_logs_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payroll_audit_logs_company_id ON public.payroll_audit_logs USING btree (company_id);


--
-- Name: ix_payroll_components_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payroll_components_company_id ON public.payroll_components USING btree (company_id);


--
-- Name: ix_payroll_profiles_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payroll_profiles_company_id ON public.payroll_profiles USING btree (company_id);


--
-- Name: ix_payroll_runs_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payroll_runs_company_id ON public.payroll_runs USING btree (company_id);


--
-- Name: ix_payroll_settings_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payroll_settings_company_id ON public.payroll_settings USING btree (company_id);


--
-- Name: ix_payroll_slips_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payroll_slips_company_id ON public.payroll_slips USING btree (company_id);


--
-- Name: ix_performance_goals_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_performance_goals_company_id ON public.performance_goals USING btree (company_id);


--
-- Name: ix_performance_reviews_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_performance_reviews_company_id ON public.performance_reviews USING btree (company_id);


--
-- Name: ix_pf_config_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pf_config_company_id ON public.pf_config USING btree (company_id);


--
-- Name: ix_pf_contributions_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pf_contributions_company_id ON public.pf_contributions USING btree (company_id);


--
-- Name: ix_pf_ledger_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pf_ledger_company_id ON public.pf_ledger USING btree (company_id);


--
-- Name: ix_pf_loan_requests_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pf_loan_requests_company_id ON public.pf_loan_requests USING btree (company_id);


--
-- Name: ix_pf_profit_distributions_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pf_profit_distributions_company_id ON public.pf_profit_distributions USING btree (company_id);


--
-- Name: ix_pf_settlements_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pf_settlements_company_id ON public.pf_settlements USING btree (company_id);


--
-- Name: ix_pf_withdrawal_requests_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pf_withdrawal_requests_company_id ON public.pf_withdrawal_requests USING btree (company_id);


--
-- Name: ix_project_labels_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_labels_company_id ON public.project_labels USING btree (company_id);


--
-- Name: ix_project_tasks_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_tasks_company_id ON public.project_tasks USING btree (company_id);


--
-- Name: ix_projects_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_projects_company_id ON public.projects USING btree (company_id);


--
-- Name: ix_registration_requests_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_registration_requests_email ON public.registration_requests USING btree (email);


--
-- Name: ix_registration_requests_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_registration_requests_phone ON public.registration_requests USING btree (phone);


--
-- Name: ix_registration_requests_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_registration_requests_status ON public.registration_requests USING btree (status);


--
-- Name: ix_report_settings_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_report_settings_company_id ON public.report_settings USING btree (company_id);


--
-- Name: ix_salary_revisions_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_salary_revisions_company_id ON public.salary_revisions USING btree (company_id);


--
-- Name: ix_scrap_items_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_scrap_items_company_id ON public.scrap_items USING btree (company_id);


--
-- Name: ix_scrap_vouchers_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_scrap_vouchers_company_id ON public.scrap_vouchers USING btree (company_id);


--
-- Name: ix_stock_adjustment_items_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_adjustment_items_company_id ON public.stock_adjustment_items USING btree (company_id);


--
-- Name: ix_stock_adjustment_vouchers_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_adjustment_vouchers_company_id ON public.stock_adjustment_vouchers USING btree (company_id);


--
-- Name: ix_stock_cost_adjustments_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_cost_adjustments_company_id ON public.stock_cost_adjustments USING btree (company_id);


--
-- Name: ix_stock_cost_adjustments_ledger_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_cost_adjustments_ledger_id ON public.stock_cost_adjustments USING btree (ledger_id);


--
-- Name: ix_stock_cost_adjustments_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_cost_adjustments_product_id ON public.stock_cost_adjustments USING btree (product_id);


--
-- Name: ix_stock_layers_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_layers_company_id ON public.stock_layers USING btree (company_id);


--
-- Name: ix_stock_layers_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_layers_product_id ON public.stock_layers USING btree (product_id);


--
-- Name: ix_stock_layers_qty_remaining; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_layers_qty_remaining ON public.stock_layers USING btree (qty_remaining);


--
-- Name: ix_stock_ledger_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_company_id ON public.stock_ledger USING btree (company_id);


--
-- Name: ix_stock_ledger_product_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_product_date ON public.stock_ledger USING btree (company_id, product_id, txn_date, id);


--
-- Name: ix_stock_ledger_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_product_id ON public.stock_ledger USING btree (product_id);


--
-- Name: ix_stock_ledger_txn_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_txn_date ON public.stock_ledger USING btree (txn_date);


--
-- Name: ix_stock_ledger_voucher_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_ledger_voucher_number ON public.stock_ledger USING btree (voucher_number);


--
-- Name: ix_stock_take_items_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_take_items_company_id ON public.stock_take_items USING btree (company_id);


--
-- Name: ix_stock_takes_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_takes_company_id ON public.stock_takes USING btree (company_id);


--
-- Name: ix_stored_files_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stored_files_company_id ON public.stored_files USING btree (company_id);


--
-- Name: ix_tax_rate_accounts_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tax_rate_accounts_company_id ON public.tax_rate_accounts USING btree (company_id);


--
-- Name: ix_team_events_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_team_events_company_id ON public.team_events USING btree (company_id);


--
-- Name: ix_time_policies_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_time_policies_company_id ON public.time_policies USING btree (company_id);


--
-- Name: ix_timesheet_approvals_approver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timesheet_approvals_approver ON public.timesheet_approvals USING btree (company_id, approver_id, status);


--
-- Name: ix_timesheet_approvals_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timesheet_approvals_company_id ON public.timesheet_approvals USING btree (company_id);


--
-- Name: ix_timesheet_entries_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timesheet_entries_company_id ON public.timesheet_entries USING btree (company_id);


--
-- Name: ix_timesheet_merged_reports_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timesheet_merged_reports_company_id ON public.timesheet_merged_reports USING btree (company_id);


--
-- Name: ix_timesheet_weeks_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timesheet_weeks_company_id ON public.timesheet_weeks USING btree (company_id);


--
-- Name: ix_twcf_lines_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_twcf_lines_company_id ON public.twcf_lines USING btree (company_id);


--
-- Name: ix_user_permissions_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_permissions_company_id ON public.user_permissions USING btree (company_id);


--
-- Name: ix_user_permissions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_permissions_user_id ON public.user_permissions USING btree (user_id);


--
-- Name: ix_user_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: ix_voucher_numbers_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_voucher_numbers_company_id ON public.voucher_numbers USING btree (company_id);


--
-- Name: ix_work_packages_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_packages_company_id ON public.work_packages USING btree (company_id);


--
-- Name: uq_users_email_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_users_email_lower ON public.users USING btree (lower((email)::text));


--
-- Name: accounting_voucher_lines accounting_voucher_lines_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_voucher_lines
    ADD CONSTRAINT accounting_voucher_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: accounting_voucher_lines accounting_voucher_lines_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_voucher_lines
    ADD CONSTRAINT accounting_voucher_lines_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);


--
-- Name: accounting_voucher_lines accounting_voucher_lines_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_voucher_lines
    ADD CONSTRAINT accounting_voucher_lines_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.accounting_vouchers(id);


--
-- Name: accounting_vouchers accounting_vouchers_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT accounting_vouchers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: accounting_vouchers accounting_vouchers_cash_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT accounting_vouchers_cash_bank_account_id_fkey FOREIGN KEY (cash_bank_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: accounting_vouchers accounting_vouchers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT accounting_vouchers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: accounting_vouchers accounting_vouchers_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT accounting_vouchers_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);


--
-- Name: additional_charges additional_charges_charge_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.additional_charges
    ADD CONSTRAINT additional_charges_charge_account_id_fkey FOREIGN KEY (charge_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: announcements announcements_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: approval_workflows approval_workflows_leave_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_leave_type_id_fkey FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);


--
-- Name: asset_depreciation asset_depreciation_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_depreciation
    ADD CONSTRAINT asset_depreciation_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.fixed_assets(id);


--
-- Name: asset_depreciation asset_depreciation_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_depreciation
    ADD CONSTRAINT asset_depreciation_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id);


--
-- Name: asset_transfers asset_transfers_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_transfers
    ADD CONSTRAINT asset_transfers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: asset_transfers asset_transfers_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_transfers
    ADD CONSTRAINT asset_transfers_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.fixed_assets(id);


--
-- Name: asset_transfers asset_transfers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_transfers
    ADD CONSTRAINT asset_transfers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: attendance_corrections attendance_corrections_attendance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_corrections
    ADD CONSTRAINT attendance_corrections_attendance_id_fkey FOREIGN KEY (attendance_id) REFERENCES public.attendance(id);


--
-- Name: attendance_corrections attendance_corrections_corrected_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_corrections
    ADD CONSTRAINT attendance_corrections_corrected_by_fkey FOREIGN KEY (corrected_by) REFERENCES public.users(id);


--
-- Name: attendance_logs attendance_logs_attendance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_logs
    ADD CONSTRAINT attendance_logs_attendance_id_fkey FOREIGN KEY (attendance_id) REFERENCES public.attendance(id);


--
-- Name: attendance attendance_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: bank_rec_items bank_rec_items_journal_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_rec_items
    ADD CONSTRAINT bank_rec_items_journal_line_id_fkey FOREIGN KEY (journal_line_id) REFERENCES public.journal_lines(id);


--
-- Name: bank_rec_items bank_rec_items_reconciliation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_rec_items
    ADD CONSTRAINT bank_rec_items_reconciliation_id_fkey FOREIGN KEY (reconciliation_id) REFERENCES public.bank_reconciliations(id);


--
-- Name: bank_reconciliations bank_reconciliations_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: bank_reconciliations bank_reconciliations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: break_logs break_logs_attendance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.break_logs
    ADD CONSTRAINT break_logs_attendance_id_fkey FOREIGN KEY (attendance_id) REFERENCES public.attendance(id);


--
-- Name: button_permissions button_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.button_permissions
    ADD CONSTRAINT button_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: category_revenue_accounts category_revenue_accounts_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_revenue_accounts
    ADD CONSTRAINT category_revenue_accounts_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: category_revenue_accounts category_revenue_accounts_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_revenue_accounts
    ADD CONSTRAINT category_revenue_accounts_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.inv_categories(id);


--
-- Name: change_requests change_requests_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_requests
    ADD CONSTRAINT change_requests_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: change_requests change_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_requests
    ADD CONSTRAINT change_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: charge_ledger_defaults charge_ledger_defaults_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.charge_ledger_defaults
    ADD CONSTRAINT charge_ledger_defaults_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: chart_of_accounts chart_of_accounts_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: companies companies_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: company_invitations company_invitations_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_invitations
    ADD CONSTRAINT company_invitations_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: company_invitations company_invitations_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_invitations
    ADD CONSTRAINT company_invitations_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- Name: company_invitations company_invitations_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_invitations
    ADD CONSTRAINT company_invitations_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: company_memberships company_memberships_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT company_memberships_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: company_memberships company_memberships_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT company_memberships_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: company_memberships company_memberships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT company_memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: consumption_items consumption_items_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consumption_items
    ADD CONSTRAINT consumption_items_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.consumption_vouchers(id);


--
-- Name: consumption_vouchers consumption_vouchers_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT consumption_vouchers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: consumption_vouchers consumption_vouchers_charge_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT consumption_vouchers_charge_account_id_fkey FOREIGN KEY (charge_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: consumption_vouchers consumption_vouchers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT consumption_vouchers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: consumption_vouchers consumption_vouchers_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT consumption_vouchers_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);


--
-- Name: digital_files digital_files_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digital_files
    ADD CONSTRAINT digital_files_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.file_categories(id);


--
-- Name: digital_files digital_files_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digital_files
    ADD CONSTRAINT digital_files_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: digital_files digital_files_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digital_files
    ADD CONSTRAINT digital_files_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: exec_account_selections exec_account_selections_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exec_account_selections
    ADD CONSTRAINT exec_account_selections_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: exec_account_selections exec_account_selections_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exec_account_selections
    ADD CONSTRAINT exec_account_selections_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: fbr_invoice_records fbr_invoice_records_inv_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fbr_invoice_records
    ADD CONSTRAINT fbr_invoice_records_inv_invoice_id_fkey FOREIGN KEY (inv_invoice_id) REFERENCES public.inv_invoices(id);


--
-- Name: fbr_invoice_records fbr_invoice_records_submitted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fbr_invoice_records
    ADD CONSTRAINT fbr_invoice_records_submitted_by_fkey FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: fixed_assets fixed_assets_accum_dep_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_accum_dep_account_id_fkey FOREIGN KEY (accum_dep_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: fixed_assets fixed_assets_acquisition_credit_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_acquisition_credit_account_id_fkey FOREIGN KEY (acquisition_credit_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: fixed_assets fixed_assets_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.fa_categories(id);


--
-- Name: fixed_assets fixed_assets_dep_expense_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_dep_expense_account_id_fkey FOREIGN KEY (dep_expense_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: fixed_assets fixed_assets_fixed_asset_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_fixed_asset_account_id_fkey FOREIGN KEY (fixed_asset_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: fixed_assets fixed_assets_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);


--
-- Name: global_limits global_limits_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_limits
    ADD CONSTRAINT global_limits_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: inv_categories inv_categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_categories
    ADD CONSTRAINT inv_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.inv_categories(id);


--
-- Name: inv_invoice_items inv_invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.inv_invoices(id);


--
-- Name: inv_invoice_items inv_invoice_items_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);


--
-- Name: inv_invoice_items inv_invoice_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);


--
-- Name: inv_invoice_items inv_invoice_items_source_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_source_order_id_fkey FOREIGN KEY (source_order_id) REFERENCES public.inv_sales_orders(id);


--
-- Name: inv_invoice_items inv_invoice_items_source_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_source_order_item_id_fkey FOREIGN KEY (source_order_item_id) REFERENCES public.inv_sales_order_items(id);


--
-- Name: inv_invoices inv_invoices_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: inv_invoices inv_invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inv_invoices inv_invoices_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.inv_customers(id);


--
-- Name: inv_invoices inv_invoices_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);


--
-- Name: inv_invoices inv_invoices_party_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_party_account_id_fkey FOREIGN KEY (party_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: inv_invoices inv_invoices_sales_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.inv_sales_orders(id);


--
-- Name: inv_products inv_products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_products
    ADD CONSTRAINT inv_products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.inv_categories(id);


--
-- Name: inv_purchase_invoice_items inv_purchase_invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.inv_purchase_invoices(id);


--
-- Name: inv_purchase_invoice_items inv_purchase_invoice_items_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);


--
-- Name: inv_purchase_invoice_items inv_purchase_invoice_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);


--
-- Name: inv_purchase_invoice_items inv_purchase_invoice_items_source_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_source_order_id_fkey FOREIGN KEY (source_order_id) REFERENCES public.inv_purchase_orders(id);


--
-- Name: inv_purchase_invoice_items inv_purchase_invoice_items_source_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_source_order_item_id_fkey FOREIGN KEY (source_order_item_id) REFERENCES public.inv_purchase_order_items(id);


--
-- Name: inv_purchase_invoices inv_purchase_invoices_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: inv_purchase_invoices inv_purchase_invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inv_purchase_invoices inv_purchase_invoices_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);


--
-- Name: inv_purchase_invoices inv_purchase_invoices_party_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_party_account_id_fkey FOREIGN KEY (party_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: inv_purchase_invoices inv_purchase_invoices_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.inv_purchase_orders(id);


--
-- Name: inv_purchase_invoices inv_purchase_invoices_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.inv_suppliers(id);


--
-- Name: inv_purchase_order_items inv_purchase_order_items_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_order_items
    ADD CONSTRAINT inv_purchase_order_items_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.inv_purchase_orders(id);


--
-- Name: inv_purchase_order_items inv_purchase_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_order_items
    ADD CONSTRAINT inv_purchase_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);


--
-- Name: inv_purchase_orders inv_purchase_orders_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT inv_purchase_orders_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: inv_purchase_orders inv_purchase_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT inv_purchase_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inv_purchase_orders inv_purchase_orders_party_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT inv_purchase_orders_party_account_id_fkey FOREIGN KEY (party_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: inv_purchase_orders inv_purchase_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT inv_purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.inv_suppliers(id);


--
-- Name: inv_purchase_return_items inv_purchase_return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_return_items
    ADD CONSTRAINT inv_purchase_return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);


--
-- Name: inv_purchase_return_items inv_purchase_return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_return_items
    ADD CONSTRAINT inv_purchase_return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.inv_purchase_returns(id);


--
-- Name: inv_purchase_returns inv_purchase_returns_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT inv_purchase_returns_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: inv_purchase_returns inv_purchase_returns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT inv_purchase_returns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inv_purchase_returns inv_purchase_returns_original_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT inv_purchase_returns_original_invoice_id_fkey FOREIGN KEY (original_invoice_id) REFERENCES public.inv_purchase_invoices(id);


--
-- Name: inv_purchase_returns inv_purchase_returns_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT inv_purchase_returns_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.inv_suppliers(id);


--
-- Name: inv_sales_order_items inv_sales_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_order_items
    ADD CONSTRAINT inv_sales_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);


--
-- Name: inv_sales_order_items inv_sales_order_items_so_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_order_items
    ADD CONSTRAINT inv_sales_order_items_so_id_fkey FOREIGN KEY (so_id) REFERENCES public.inv_sales_orders(id);


--
-- Name: inv_sales_orders inv_sales_orders_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT inv_sales_orders_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: inv_sales_orders inv_sales_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT inv_sales_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inv_sales_orders inv_sales_orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT inv_sales_orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.inv_customers(id);


--
-- Name: inv_sales_orders inv_sales_orders_party_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT inv_sales_orders_party_account_id_fkey FOREIGN KEY (party_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: inv_sales_return_items inv_sales_return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_return_items
    ADD CONSTRAINT inv_sales_return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);


--
-- Name: inv_sales_return_items inv_sales_return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_return_items
    ADD CONSTRAINT inv_sales_return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.inv_sales_returns(id);


--
-- Name: inv_sales_returns inv_sales_returns_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: inv_sales_returns inv_sales_returns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inv_sales_returns inv_sales_returns_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.inv_customers(id);


--
-- Name: inv_sales_returns inv_sales_returns_original_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_original_invoice_id_fkey FOREIGN KEY (original_invoice_id) REFERENCES public.inv_invoices(id);


--
-- Name: inv_sales_returns inv_sales_returns_party_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_party_account_id_fkey FOREIGN KEY (party_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: inv_stock_movements inv_stock_movements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_stock_movements
    ADD CONSTRAINT inv_stock_movements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inv_stock_movements inv_stock_movements_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inv_stock_movements
    ADD CONSTRAINT inv_stock_movements_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);


--
-- Name: inventory_settings inventory_settings_default_cogs_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_default_cogs_account_id_fkey FOREIGN KEY (default_cogs_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: inventory_settings inventory_settings_default_inventory_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_default_inventory_account_id_fkey FOREIGN KEY (default_inventory_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: inventory_settings inventory_settings_default_invoice_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_default_invoice_label_id_fkey FOREIGN KEY (default_invoice_label_id) REFERENCES public.project_labels(id);


--
-- Name: inventory_settings inventory_settings_default_return_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_default_return_account_id_fkey FOREIGN KEY (default_return_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: inventory_settings inventory_settings_default_voucher_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_default_voucher_label_id_fkey FOREIGN KEY (default_voucher_label_id) REFERENCES public.project_labels(id);


--
-- Name: journal_entries journal_entries_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: journal_lines journal_lines_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: journal_lines journal_lines_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id);


--
-- Name: journal_lines journal_lines_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);


--
-- Name: kanban_boards kanban_boards_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kanban_boards
    ADD CONSTRAINT kanban_boards_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: kanban_tasks kanban_tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kanban_tasks
    ADD CONSTRAINT kanban_tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: kanban_tasks kanban_tasks_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kanban_tasks
    ADD CONSTRAINT kanban_tasks_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.kanban_boards(id);


--
-- Name: layer_consumptions layer_consumptions_layer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.layer_consumptions
    ADD CONSTRAINT layer_consumptions_layer_id_fkey FOREIGN KEY (layer_id) REFERENCES public.stock_layers(id);


--
-- Name: layer_consumptions layer_consumptions_out_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.layer_consumptions
    ADD CONSTRAINT layer_consumptions_out_ledger_id_fkey FOREIGN KEY (out_ledger_id) REFERENCES public.stock_ledger(id);


--
-- Name: leave_approvals leave_approvals_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_approvals
    ADD CONSTRAINT leave_approvals_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id);


--
-- Name: leave_approvals leave_approvals_leave_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_approvals
    ADD CONSTRAINT leave_approvals_leave_request_id_fkey FOREIGN KEY (leave_request_id) REFERENCES public.leave_requests(id);


--
-- Name: leave_quotas leave_quotas_leave_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_quotas
    ADD CONSTRAINT leave_quotas_leave_type_id_fkey FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);


--
-- Name: leave_quotas leave_quotas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_quotas
    ADD CONSTRAINT leave_quotas_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: leave_requests leave_requests_leave_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_leave_type_id_fkey FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);


--
-- Name: leave_requests leave_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: loan_advance_requests loan_advance_requests_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_advance_requests
    ADD CONSTRAINT loan_advance_requests_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: loan_advance_requests loan_advance_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_advance_requests
    ADD CONSTRAINT loan_advance_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: loan_repayments loan_repayments_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_repayments
    ADD CONSTRAINT loan_repayments_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.loan_advance_requests(id);


--
-- Name: loan_repayments loan_repayments_payroll_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_repayments
    ADD CONSTRAINT loan_repayments_payroll_run_id_fkey FOREIGN KEY (payroll_run_id) REFERENCES public.payroll_runs(id);


--
-- Name: notification_recipients notification_recipients_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_recipients
    ADD CONSTRAINT notification_recipients_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notifications(id);


--
-- Name: notification_recipients notification_recipients_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_recipients
    ADD CONSTRAINT notification_recipients_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: overtime_accounts overtime_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.overtime_accounts
    ADD CONSTRAINT overtime_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payment_allocations payment_allocations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: payment_allocations payment_allocations_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.accounting_vouchers(id);


--
-- Name: payment_allocations payment_allocations_voucher_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_voucher_line_id_fkey FOREIGN KEY (voucher_line_id) REFERENCES public.accounting_voucher_lines(id);


--
-- Name: payroll_audit_logs payroll_audit_logs_payroll_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_audit_logs
    ADD CONSTRAINT payroll_audit_logs_payroll_run_id_fkey FOREIGN KEY (payroll_run_id) REFERENCES public.payroll_runs(id);


--
-- Name: payroll_audit_logs payroll_audit_logs_performed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_audit_logs
    ADD CONSTRAINT payroll_audit_logs_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.users(id);


--
-- Name: payroll_components payroll_components_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_components
    ADD CONSTRAINT payroll_components_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.payroll_profiles(id);


--
-- Name: payroll_profiles payroll_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_profiles
    ADD CONSTRAINT payroll_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payroll_runs payroll_runs_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: payroll_runs payroll_runs_processed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_processed_by_fkey FOREIGN KEY (processed_by) REFERENCES public.users(id);


--
-- Name: payroll_slips payroll_slips_payroll_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_slips
    ADD CONSTRAINT payroll_slips_payroll_run_id_fkey FOREIGN KEY (payroll_run_id) REFERENCES public.payroll_runs(id);


--
-- Name: payroll_slips payroll_slips_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_slips
    ADD CONSTRAINT payroll_slips_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: performance_goals performance_goals_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_goals
    ADD CONSTRAINT performance_goals_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: performance_goals performance_goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_goals
    ADD CONSTRAINT performance_goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: performance_reviews performance_reviews_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: performance_reviews performance_reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: permissions permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: pf_contributions pf_contributions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_contributions
    ADD CONSTRAINT pf_contributions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: pf_ledger pf_ledger_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_ledger
    ADD CONSTRAINT pf_ledger_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: pf_loan_requests pf_loan_requests_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_loan_requests
    ADD CONSTRAINT pf_loan_requests_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: pf_loan_requests pf_loan_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_loan_requests
    ADD CONSTRAINT pf_loan_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: pf_profit_distributions pf_profit_distributions_distributed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_profit_distributions
    ADD CONSTRAINT pf_profit_distributions_distributed_by_fkey FOREIGN KEY (distributed_by) REFERENCES public.users(id);


--
-- Name: pf_settlements pf_settlements_settled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_settlements
    ADD CONSTRAINT pf_settlements_settled_by_fkey FOREIGN KEY (settled_by) REFERENCES public.users(id);


--
-- Name: pf_settlements pf_settlements_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_settlements
    ADD CONSTRAINT pf_settlements_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: pf_withdrawal_requests pf_withdrawal_requests_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_withdrawal_requests
    ADD CONSTRAINT pf_withdrawal_requests_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: pf_withdrawal_requests pf_withdrawal_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pf_withdrawal_requests
    ADD CONSTRAINT pf_withdrawal_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: project_tasks project_tasks_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: project_tasks project_tasks_work_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_work_package_id_fkey FOREIGN KEY (work_package_id) REFERENCES public.work_packages(id);


--
-- Name: projects projects_project_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_project_manager_id_fkey FOREIGN KEY (project_manager_id) REFERENCES public.users(id);


--
-- Name: registration_requests registration_requests_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: report_settings report_settings_purchase_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_settings
    ADD CONSTRAINT report_settings_purchase_template_id_fkey FOREIGN KEY (purchase_template_id) REFERENCES public.invoice_templates(id);


--
-- Name: report_settings report_settings_sales_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_settings
    ADD CONSTRAINT report_settings_sales_template_id_fkey FOREIGN KEY (sales_template_id) REFERENCES public.invoice_templates(id);


--
-- Name: salary_revisions salary_revisions_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_revisions
    ADD CONSTRAINT salary_revisions_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: salary_revisions salary_revisions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_revisions
    ADD CONSTRAINT salary_revisions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: scrap_items scrap_items_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_items
    ADD CONSTRAINT scrap_items_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.scrap_vouchers(id);


--
-- Name: scrap_vouchers scrap_vouchers_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT scrap_vouchers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: scrap_vouchers scrap_vouchers_charge_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT scrap_vouchers_charge_account_id_fkey FOREIGN KEY (charge_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: scrap_vouchers scrap_vouchers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT scrap_vouchers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: scrap_vouchers scrap_vouchers_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT scrap_vouchers_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);


--
-- Name: stock_adjustment_items stock_adjustment_items_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustment_items
    ADD CONSTRAINT stock_adjustment_items_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.stock_adjustment_vouchers(id);


--
-- Name: stock_adjustment_vouchers stock_adjustment_vouchers_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustment_vouchers
    ADD CONSTRAINT stock_adjustment_vouchers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: stock_adjustment_vouchers stock_adjustment_vouchers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustment_vouchers
    ADD CONSTRAINT stock_adjustment_vouchers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stock_adjustment_vouchers stock_adjustment_vouchers_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustment_vouchers
    ADD CONSTRAINT stock_adjustment_vouchers_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);


--
-- Name: stock_cost_adjustments stock_cost_adjustments_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_cost_adjustments
    ADD CONSTRAINT stock_cost_adjustments_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id);


--
-- Name: stock_layers stock_layers_source_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_layers
    ADD CONSTRAINT stock_layers_source_ledger_id_fkey FOREIGN KEY (source_ledger_id) REFERENCES public.stock_ledger(id);


--
-- Name: stock_ledger stock_ledger_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stock_take_items stock_take_items_stock_take_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id);


--
-- Name: stock_takes stock_takes_adjustment_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_adjustment_voucher_id_fkey FOREIGN KEY (adjustment_voucher_id) REFERENCES public.stock_adjustment_vouchers(id);


--
-- Name: stock_takes stock_takes_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: stock_takes stock_takes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: tax_rate_accounts tax_rate_accounts_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_accounts
    ADD CONSTRAINT tax_rate_accounts_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: team_events team_events_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_events
    ADD CONSTRAINT team_events_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: timesheet_approvals timesheet_approvals_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_approvals
    ADD CONSTRAINT timesheet_approvals_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id);


--
-- Name: timesheet_approvals timesheet_approvals_week_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_approvals
    ADD CONSTRAINT timesheet_approvals_week_id_fkey FOREIGN KEY (week_id) REFERENCES public.timesheet_weeks(id);


--
-- Name: timesheet_entries timesheet_entries_week_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_entries
    ADD CONSTRAINT timesheet_entries_week_id_fkey FOREIGN KEY (week_id) REFERENCES public.timesheet_weeks(id);


--
-- Name: timesheet_merged_reports timesheet_merged_reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_merged_reports
    ADD CONSTRAINT timesheet_merged_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: timesheet_weeks timesheet_weeks_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_weeks
    ADD CONSTRAINT timesheet_weeks_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: timesheet_weeks timesheet_weeks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_weeks
    ADD CONSTRAINT timesheet_weeks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_permissions user_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id);


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: work_packages work_packages_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT work_packages_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- PostgreSQL database dump complete
--

