-- A database the Python app at Alembic 0015 built and seeded, plus companies and
-- logins in the shapes 0016 rewrites. dotnet/tools/make_migration_fixtures.py.

CREATE TABLE public.accounting_periods (
    id integer NOT NULL,
    company_id integer,
    fiscal_year character varying(10) NOT NULL,
    period_name character varying(50) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_open boolean,
    is_closed boolean,
    is_active boolean,
    created_at timestamp without time zone,
    closed_at timestamp without time zone
);

CREATE SEQUENCE public.accounting_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.accounting_periods_id_seq OWNED BY public.accounting_periods.id;

CREATE TABLE public.accounting_voucher_lines (
    id integer NOT NULL,
    company_id integer,
    voucher_id integer NOT NULL,
    line_no integer NOT NULL,
    account_id integer NOT NULL,
    description character varying(300),
    debit numeric(16,4),
    credit numeric(16,4),
    label_id integer
);

CREATE SEQUENCE public.accounting_voucher_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.accounting_voucher_lines_id_seq OWNED BY public.accounting_voucher_lines.id;

CREATE TABLE public.accounting_vouchers (
    id integer NOT NULL,
    company_id integer,
    voucher_type character varying(10) NOT NULL,
    voucher_number character varying(50) NOT NULL,
    voucher_date timestamp without time zone NOT NULL,
    cash_bank_account_id integer,
    label_id integer,
    notes text,
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone
);

CREATE SEQUENCE public.accounting_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.accounting_vouchers_id_seq OWNED BY public.accounting_vouchers.id;

CREATE TABLE public.additional_charges (
    id integer NOT NULL,
    company_id integer,
    doc_type character varying(10) NOT NULL,
    doc_id integer NOT NULL,
    charge_account_id integer NOT NULL,
    description character varying(200),
    amount numeric(20,6),
    scope character varying(20),
    distribution character varying(20),
    manual_allocations text,
    treatment character varying(10),
    st_taxable boolean,
    wht_taxable boolean,
    extra_taxable boolean,
    taxable boolean,
    tax_base character varying(30),
    created_at timestamp without time zone
);

CREATE SEQUENCE public.additional_charges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.additional_charges_id_seq OWNED BY public.additional_charges.id;

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);

CREATE TABLE public.announcements (
    id integer NOT NULL,
    company_id integer,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    priority character varying(20),
    author_id integer NOT NULL,
    pinned boolean,
    expires_at date,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.announcements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;

CREATE TABLE public.approval_workflows (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    module character varying(50) NOT NULL,
    leave_type_id integer,
    requires_approval boolean,
    approval_levels integer,
    auto_approve boolean,
    auto_approve_role character varying(50),
    notify_admins boolean,
    is_active boolean,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.approval_workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.approval_workflows_id_seq OWNED BY public.approval_workflows.id;

CREATE TABLE public.asset_depreciation (
    id integer NOT NULL,
    company_id integer,
    asset_id integer NOT NULL,
    entry_date date NOT NULL,
    amount numeric(20,6) NOT NULL,
    accumulated_after numeric(20,6) NOT NULL,
    net_book_value_after numeric(20,6) NOT NULL,
    journal_entry_id integer,
    notes character varying(200),
    created_at timestamp without time zone
);

CREATE SEQUENCE public.asset_depreciation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.asset_depreciation_id_seq OWNED BY public.asset_depreciation.id;

CREATE TABLE public.asset_transfers (
    id integer NOT NULL,
    company_id integer,
    voucher_number character varying(50) NOT NULL,
    direction character varying(20) NOT NULL,
    asset_id integer NOT NULL,
    product_id integer,
    new_product_name character varying(200),
    source_product_id integer,
    transfer_amount numeric(20,6),
    quantity numeric(20,6),
    description text,
    transfer_date date,
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone
);

CREATE SEQUENCE public.asset_transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.asset_transfers_id_seq OWNED BY public.asset_transfers.id;

CREATE TABLE public.attendance (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    date date NOT NULL,
    clock_in timestamp without time zone,
    clock_out timestamp without time zone,
    ip_address character varying(50),
    geo_lat double precision,
    geo_lng double precision,
    status character varying(20),
    is_late boolean,
    is_half_day boolean,
    notes text,
    created_at timestamp without time zone
);

CREATE TABLE public.attendance_corrections (
    id integer NOT NULL,
    company_id integer,
    attendance_id integer NOT NULL,
    corrected_by integer NOT NULL,
    field character varying(50) NOT NULL,
    old_value character varying(255),
    new_value character varying(255) NOT NULL,
    reason text NOT NULL,
    corrected_at timestamp without time zone
);

CREATE SEQUENCE public.attendance_corrections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.attendance_corrections_id_seq OWNED BY public.attendance_corrections.id;

CREATE SEQUENCE public.attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.attendance_id_seq OWNED BY public.attendance.id;

CREATE TABLE public.attendance_logs (
    id integer NOT NULL,
    company_id integer,
    attendance_id integer NOT NULL,
    event character varying(20) NOT NULL,
    "timestamp" timestamp without time zone,
    ip_address character varying(50),
    geo_lat double precision,
    geo_lng double precision
);

CREATE SEQUENCE public.attendance_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.attendance_logs_id_seq OWNED BY public.attendance_logs.id;

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    company_id integer,
    created_at timestamp without time zone NOT NULL,
    user_id integer,
    user_name character varying(200),
    action character varying(30) NOT NULL,
    module character varying(30),
    entity_type character varying(60),
    entity_id integer,
    reference character varying(120),
    summary character varying(500),
    changes text,
    ip_address character varying(64),
    path character varying(300)
);

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;

CREATE TABLE public.bank_rec_items (
    id integer NOT NULL,
    company_id integer,
    reconciliation_id integer NOT NULL,
    journal_line_id integer NOT NULL
);

CREATE SEQUENCE public.bank_rec_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.bank_rec_items_id_seq OWNED BY public.bank_rec_items.id;

CREATE TABLE public.bank_reconciliations (
    id integer NOT NULL,
    company_id integer,
    account_id integer NOT NULL,
    statement_date date NOT NULL,
    statement_balance numeric(20,6) NOT NULL,
    status character varying(20),
    notes text,
    created_by integer,
    created_at timestamp without time zone,
    completed_at timestamp without time zone
);

CREATE SEQUENCE public.bank_reconciliations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.bank_reconciliations_id_seq OWNED BY public.bank_reconciliations.id;

CREATE TABLE public.break_logs (
    id integer NOT NULL,
    company_id integer,
    attendance_id integer NOT NULL,
    break_start timestamp without time zone NOT NULL,
    break_end timestamp without time zone,
    break_type character varying(30),
    duration_minutes integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.break_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.break_logs_id_seq OWNED BY public.break_logs.id;

CREATE TABLE public.button_permissions (
    id integer NOT NULL,
    company_id integer,
    role_id integer NOT NULL,
    button_code character varying(100) NOT NULL,
    is_granted boolean,
    module character varying(50) NOT NULL,
    description character varying(200)
);

CREATE SEQUENCE public.button_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.button_permissions_id_seq OWNED BY public.button_permissions.id;

CREATE TABLE public.category_revenue_accounts (
    id integer NOT NULL,
    company_id integer,
    category_id integer NOT NULL,
    account_id integer NOT NULL
);

CREATE SEQUENCE public.category_revenue_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.category_revenue_accounts_id_seq OWNED BY public.category_revenue_accounts.id;

CREATE TABLE public.change_requests (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    field_name character varying(100) NOT NULL,
    old_value text,
    new_value text NOT NULL,
    status character varying(20),
    reviewed_by integer,
    review_notes text,
    created_at timestamp without time zone,
    reviewed_at timestamp without time zone
);

CREATE SEQUENCE public.change_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.change_requests_id_seq OWNED BY public.change_requests.id;

CREATE TABLE public.charge_ledger_defaults (
    id integer NOT NULL,
    company_id integer,
    account_id integer NOT NULL,
    treatment character varying(10),
    st_taxable boolean,
    wht_taxable boolean,
    extra_taxable boolean,
    applies_to character varying(10)
);

CREATE SEQUENCE public.charge_ledger_defaults_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.charge_ledger_defaults_id_seq OWNED BY public.charge_ledger_defaults.id;

CREATE TABLE public.chart_of_accounts (
    id integer NOT NULL,
    company_id integer,
    code character varying(30) NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(50) NOT NULL,
    parent_id integer,
    level integer NOT NULL,
    is_fixed boolean,
    is_active boolean,
    description text,
    cash_flow_activity character varying(20),
    pl_section character varying(30),
    created_at timestamp without time zone
);

CREATE SEQUENCE public.chart_of_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.chart_of_accounts_id_seq OWNED BY public.chart_of_accounts.id;

CREATE TABLE public.companies (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(120) NOT NULL,
    is_active boolean,
    plan_name character varying(50),
    max_members integer,
    created_by integer,
    mod_hr_enabled boolean,
    mod_inventory_enabled boolean,
    mod_invoicing_enabled boolean,
    mod_finance_enabled boolean,
    mod_accounting_enabled boolean,
    mod_fbr_enabled boolean,
    mod_fixed_assets_enabled boolean,
    mod_executive_enabled boolean,
    address text,
    city character varying(100),
    state character varying(100),
    country character varying(100),
    phone character varying(50),
    email character varying(200),
    website character varying(200),
    tax_id character varying(100),
    registration_number character varying(100),
    logo_url character varying(500),
    bank_name character varying(200),
    bank_account_title character varying(200),
    bank_account_number character varying(100),
    fiscal_year_start_month integer,
    currency character varying(10),
    currency_symbol character varying(10),
    date_format character varying(20),
    number_format character varying(10),
    timezone character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;

CREATE TABLE public.company_holidays (
    id integer NOT NULL,
    company_id integer,
    name character varying(200) NOT NULL,
    holiday_date date NOT NULL,
    is_recurring boolean,
    department character varying(100),
    location character varying(100),
    is_active boolean,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.company_holidays_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.company_holidays_id_seq OWNED BY public.company_holidays.id;

CREATE TABLE public.company_info (
    id integer NOT NULL,
    company_id integer,
    company_name character varying(200),
    address text,
    city character varying(100),
    state character varying(100),
    country character varying(100),
    phone character varying(50),
    email character varying(200),
    website character varying(200),
    tax_id character varying(100),
    registration_number character varying(100),
    logo_url character varying(500),
    bank_name character varying(200),
    bank_account_title character varying(200),
    bank_account_number character varying(100),
    fiscal_year_start_month integer,
    currency character varying(10),
    currency_symbol character varying(10),
    date_format character varying(20),
    number_format character varying(10),
    timezone character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.company_info_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.company_info_id_seq OWNED BY public.company_info.id;

CREATE TABLE public.company_invitations (
    id integer NOT NULL,
    company_id integer NOT NULL,
    email character varying(120) NOT NULL,
    role_id integer NOT NULL,
    invited_by integer,
    status character varying(10) NOT NULL,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.company_invitations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.company_invitations_id_seq OWNED BY public.company_invitations.id;

CREATE TABLE public.company_memberships (
    id integer NOT NULL,
    company_id integer NOT NULL,
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    status character varying(10) NOT NULL,
    employee_code character varying(20),
    joined_at timestamp without time zone,
    date_of_leaving date,
    module_flags text,
    manager_id integer,
    designation character varying(100),
    department character varying(100)
);

CREATE SEQUENCE public.company_memberships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.company_memberships_id_seq OWNED BY public.company_memberships.id;

CREATE TABLE public.consumption_items (
    id integer NOT NULL,
    company_id integer,
    voucher_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(200),
    quantity numeric(16,4) NOT NULL,
    unit_cost numeric(16,4),
    total_cost numeric(16,4)
);

CREATE SEQUENCE public.consumption_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.consumption_items_id_seq OWNED BY public.consumption_items.id;

CREATE TABLE public.consumption_vouchers (
    id integer NOT NULL,
    company_id integer,
    voucher_number character varying(50) NOT NULL,
    date timestamp without time zone,
    department character varying(100),
    reason text,
    charge_account_id integer,
    label_id integer,
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone
);

CREATE SEQUENCE public.consumption_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.consumption_vouchers_id_seq OWNED BY public.consumption_vouchers.id;

CREATE TABLE public.digital_files (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    category_id integer,
    title character varying(200) NOT NULL,
    filename character varying(255) NOT NULL,
    original_name character varying(255) NOT NULL,
    file_size integer,
    mime_type character varying(100),
    notes text,
    expiry_date date,
    is_verified boolean,
    verified_by integer,
    verified_at timestamp without time zone,
    uploaded_at timestamp without time zone
);

CREATE SEQUENCE public.digital_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.digital_files_id_seq OWNED BY public.digital_files.id;

CREATE TABLE public.email_logs (
    id integer NOT NULL,
    company_id integer,
    recipient character varying(120) NOT NULL,
    subject character varying(200) NOT NULL,
    body text,
    module character varying(50),
    status character varying(20),
    error_message text,
    sent_at timestamp without time zone
);

CREATE SEQUENCE public.email_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.email_logs_id_seq OWNED BY public.email_logs.id;

CREATE TABLE public.exec_account_selections (
    id integer NOT NULL,
    company_id integer,
    account_id integer NOT NULL,
    include_children boolean NOT NULL,
    created_by integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.exec_account_selections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.exec_account_selections_id_seq OWNED BY public.exec_account_selections.id;

CREATE TABLE public.fa_categories (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    description text,
    default_useful_life integer,
    default_depreciation_method character varying(20),
    default_salvage_value_pct numeric(20,6),
    is_active boolean,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.fa_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.fa_categories_id_seq OWNED BY public.fa_categories.id;

CREATE TABLE public.fbr_config (
    id integer NOT NULL,
    company_id integer,
    environment character varying(20),
    access_token character varying(500),
    token_expiry timestamp without time zone,
    seller_ntn character varying(50),
    seller_strn character varying(50),
    seller_cnic character varying(50),
    seller_name character varying(200),
    seller_business_name character varying(200),
    seller_address text,
    seller_phone character varying(50),
    seller_email character varying(200),
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.fbr_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.fbr_config_id_seq OWNED BY public.fbr_config.id;

CREATE TABLE public.fbr_invoice_records (
    id integer NOT NULL,
    company_id integer,
    inv_invoice_id integer NOT NULL,
    fbr_invoice_number character varying(100),
    fbr_submission_id character varying(100),
    status character varying(20),
    request_json text,
    response_json text,
    error_message text,
    invoice_type character varying(10),
    attempt_count integer,
    submitted_at timestamp without time zone,
    submitted_by integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.fbr_invoice_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.fbr_invoice_records_id_seq OWNED BY public.fbr_invoice_records.id;

CREATE TABLE public.file_categories (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    description text
);

CREATE SEQUENCE public.file_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.file_categories_id_seq OWNED BY public.file_categories.id;

CREATE TABLE public.fiscal_year_rule (
    id integer NOT NULL,
    company_id integer,
    start_month integer NOT NULL,
    start_day integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.fiscal_year_rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.fiscal_year_rule_id_seq OWNED BY public.fiscal_year_rule.id;

CREATE TABLE public.fixed_assets (
    id integer NOT NULL,
    company_id integer,
    asset_code character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    category_id integer NOT NULL,
    purchase_date date NOT NULL,
    purchase_cost numeric(20,6) NOT NULL,
    useful_life integer NOT NULL,
    depreciation_method character varying(20) NOT NULL,
    salvage_value numeric(20,6),
    accumulated_depreciation numeric(20,6),
    current_book_value numeric(20,6) NOT NULL,
    status character varying(20),
    location character varying(200),
    assigned_to character varying(100),
    vendor character varying(200),
    serial_number character varying(100),
    fixed_asset_account_id integer,
    accum_dep_account_id integer,
    dep_expense_account_id integer,
    acquisition_credit_account_id integer,
    notes text,
    label_id integer,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.fixed_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.fixed_assets_id_seq OWNED BY public.fixed_assets.id;

CREATE TABLE public.gl_daily_balances (
    id integer NOT NULL,
    company_id integer NOT NULL,
    account_id integer NOT NULL,
    label_id integer NOT NULL,
    day date NOT NULL,
    debit numeric(18,4) NOT NULL,
    credit numeric(18,4) NOT NULL,
    line_count integer NOT NULL
);

CREATE SEQUENCE public.gl_daily_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.gl_daily_balances_id_seq OWNED BY public.gl_daily_balances.id;

CREATE TABLE public.global_limits (
    id integer NOT NULL,
    max_companies_per_user integer NOT NULL,
    default_max_members integer NOT NULL,
    updated_by integer,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.global_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.global_limits_id_seq OWNED BY public.global_limits.id;

CREATE TABLE public.income_tax_slabs (
    id integer NOT NULL,
    company_id integer,
    min_income numeric(20,6) NOT NULL,
    max_income numeric(20,6) NOT NULL,
    rate_pct numeric(20,6) NOT NULL,
    fixed_amount numeric(20,6) NOT NULL,
    is_active boolean,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.income_tax_slabs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.income_tax_slabs_id_seq OWNED BY public.income_tax_slabs.id;

CREATE TABLE public.inv_categories (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    description text,
    parent_id integer,
    is_active boolean,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.inv_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_categories_id_seq OWNED BY public.inv_categories.id;

CREATE TABLE public.inv_customers (
    id integer NOT NULL,
    company_id integer,
    name character varying(200) NOT NULL,
    contact_person character varying(100),
    email character varying(120),
    phone character varying(20),
    mobile character varying(20),
    address text,
    city character varying(50),
    tax_id character varying(50),
    payment_terms character varying(100),
    credit_limit numeric(20,6),
    website character varying(200),
    notes text,
    is_active boolean,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.inv_customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_customers_id_seq OWNED BY public.inv_customers.id;

CREATE TABLE public.inv_invoice_items (
    id integer NOT NULL,
    company_id integer,
    invoice_id integer NOT NULL,
    product_id integer,
    description character varying(300),
    quantity numeric(20,6),
    unit character varying(20),
    unit_price numeric(20,6),
    label_id integer,
    source_order_id integer,
    source_order_item_id integer,
    source_order_number character varying(50),
    discount_pct numeric(20,6),
    discount_amount numeric(20,6),
    delivery numeric(20,6),
    installation numeric(20,6),
    sales_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    comments text
);

CREATE SEQUENCE public.inv_invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_invoice_items_id_seq OWNED BY public.inv_invoice_items.id;

CREATE TABLE public.inv_invoices (
    id integer NOT NULL,
    company_id integer,
    invoice_number character varying(50) NOT NULL,
    voucher_number character varying(50) NOT NULL,
    sales_order_id integer,
    customer_id integer NOT NULL,
    party_account_id integer,
    label_id integer,
    invoice_date timestamp without time zone,
    due_date timestamp without time zone,
    voucher_status character varying(20),
    payment_status character varying(20),
    discount_mode character varying(20),
    charges_mode character varying(20),
    tax_mode character varying(20),
    global_discount_pct numeric(20,6),
    global_discount_value numeric(20,6),
    global_delivery numeric(20,6),
    global_installation numeric(20,6),
    global_sales_tax_pct numeric(20,6),
    further_tax_pct numeric(20,6),
    apply_further_tax boolean,
    withholding_tax_pct numeric(20,6),
    apply_withholding_tax boolean,
    subtotal numeric(20,6),
    total_discount numeric(20,6),
    total_charges numeric(20,6),
    total_tax numeric(20,6),
    total_further_tax numeric(20,6),
    total_withholding_tax numeric(20,6),
    total_amount numeric(20,6),
    paid_amount numeric(20,6),
    notes text,
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.inv_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_invoices_id_seq OWNED BY public.inv_invoices.id;

CREATE TABLE public.inv_products (
    id integer NOT NULL,
    company_id integer,
    sku character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    category_id integer,
    unit_price numeric(20,6),
    cost_price numeric(20,6),
    reorder_level integer,
    current_stock numeric(16,4),
    unit character varying(20),
    hs_code character varying(50),
    weight numeric(20,6),
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.inv_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_products_id_seq OWNED BY public.inv_products.id;

CREATE TABLE public.inv_purchase_invoice_items (
    id integer NOT NULL,
    company_id integer,
    invoice_id integer NOT NULL,
    product_id integer,
    description character varying(300),
    quantity numeric(20,6),
    unit character varying(20),
    unit_price numeric(20,6),
    label_id integer,
    source_order_id integer,
    source_order_item_id integer,
    source_order_number character varying(50),
    discount_pct numeric(20,6),
    discount_amount numeric(20,6),
    commission numeric(20,6),
    freight numeric(20,6),
    loading_unloading numeric(20,6),
    sales_tax_pct numeric(20,6),
    withholding_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    comments text
);

CREATE SEQUENCE public.inv_purchase_invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_purchase_invoice_items_id_seq OWNED BY public.inv_purchase_invoice_items.id;

CREATE TABLE public.inv_purchase_invoices (
    id integer NOT NULL,
    company_id integer,
    invoice_number character varying(50) NOT NULL,
    voucher_number character varying(50) NOT NULL,
    invoice_date timestamp without time zone,
    supplier_id integer NOT NULL,
    party_account_id integer,
    label_id integer,
    driver_name character varying(100),
    driver_contact character varying(50),
    vehicle_number character varying(50),
    gate_pass character varying(50),
    discount_mode character varying(20),
    expenses_mode character varying(20),
    tax_mode character varying(20),
    global_discount_pct numeric(20,6),
    global_discount_value numeric(20,6),
    global_commission numeric(20,6),
    global_freight numeric(20,6),
    global_loading numeric(20,6),
    global_sales_tax_pct numeric(20,6),
    global_withholding_tax_pct numeric(20,6),
    further_tax_pct numeric(20,6),
    apply_further_tax boolean,
    apply_withholding_tax boolean,
    subtotal numeric(20,6),
    total_discount numeric(20,6),
    total_expenses numeric(20,6),
    total_tax numeric(20,6),
    total_further_tax numeric(20,6),
    total_withholding_tax numeric(20,6),
    net_payable numeric(20,6),
    total_amount numeric(20,6),
    paid_amount numeric(20,6),
    payment_status character varying(20),
    purchase_order_id integer,
    notes text,
    status character varying(20),
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.inv_purchase_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_purchase_invoices_id_seq OWNED BY public.inv_purchase_invoices.id;

CREATE TABLE public.inv_purchase_order_items (
    id integer NOT NULL,
    company_id integer,
    po_id integer NOT NULL,
    product_id integer NOT NULL,
    description character varying(200),
    unit character varying(20),
    quantity numeric(20,6),
    invoiced_qty numeric(20,6),
    unit_price numeric(20,6),
    sales_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    total_price numeric(20,6)
);

CREATE SEQUENCE public.inv_purchase_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_purchase_order_items_id_seq OWNED BY public.inv_purchase_order_items.id;

CREATE TABLE public.inv_purchase_orders (
    id integer NOT NULL,
    company_id integer,
    po_number character varying(50) NOT NULL,
    supplier_id integer NOT NULL,
    party_account_id integer,
    order_date date,
    expected_date date,
    status character varying(20),
    fulfilment_status character varying(20),
    tax_mode character varying(20),
    global_sales_tax_pct numeric(20,6),
    subtotal numeric(20,6),
    total_tax numeric(20,6),
    total_amount numeric(20,6),
    notes text,
    driver_name character varying(100),
    driver_contact character varying(50),
    vehicle_number character varying(50),
    gate_pass character varying(50),
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.inv_purchase_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_purchase_orders_id_seq OWNED BY public.inv_purchase_orders.id;

CREATE TABLE public.inv_purchase_return_items (
    id integer NOT NULL,
    company_id integer,
    return_id integer NOT NULL,
    product_id integer,
    description character varying(300),
    original_quantity numeric(20,6),
    previously_returned_qty numeric(20,6),
    max_returnable_qty numeric(20,6),
    current_return_qty numeric(20,6),
    unit character varying(20),
    unit_price numeric(20,6),
    discount_pct numeric(20,6),
    discount_amount numeric(20,6),
    commission numeric(20,6),
    freight numeric(20,6),
    loading_unloading numeric(20,6),
    sales_tax_pct numeric(20,6),
    withholding_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    proportional_discount numeric(20,6),
    proportional_sales_tax numeric(20,6),
    proportional_withholding_tax numeric(20,6),
    proportional_commission numeric(20,6),
    proportional_freight numeric(20,6),
    proportional_loading numeric(20,6),
    net_return_value numeric(20,6)
);

CREATE SEQUENCE public.inv_purchase_return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_purchase_return_items_id_seq OWNED BY public.inv_purchase_return_items.id;

CREATE TABLE public.inv_purchase_returns (
    id integer NOT NULL,
    company_id integer,
    return_number character varying(50) NOT NULL,
    original_invoice_id integer NOT NULL,
    supplier_id integer NOT NULL,
    return_date timestamp without time zone,
    notes text,
    gross_return_value numeric(20,6),
    total_discount numeric(20,6),
    total_expenses numeric(20,6),
    total_tax numeric(20,6),
    net_return_amount numeric(20,6),
    reverse_expenses boolean,
    status character varying(20),
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.inv_purchase_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_purchase_returns_id_seq OWNED BY public.inv_purchase_returns.id;

CREATE TABLE public.inv_sales_order_items (
    id integer NOT NULL,
    company_id integer,
    so_id integer NOT NULL,
    product_id integer NOT NULL,
    description character varying(200),
    unit character varying(20),
    quantity numeric(20,6),
    invoiced_qty numeric(20,6),
    unit_price numeric(20,6),
    sales_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    total_price numeric(20,6)
);

CREATE SEQUENCE public.inv_sales_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_sales_order_items_id_seq OWNED BY public.inv_sales_order_items.id;

CREATE TABLE public.inv_sales_orders (
    id integer NOT NULL,
    company_id integer,
    so_number character varying(50) NOT NULL,
    customer_id integer NOT NULL,
    party_account_id integer,
    order_date date,
    expected_date date,
    status character varying(20),
    fulfilment_status character varying(20),
    tax_mode character varying(20),
    global_sales_tax_pct numeric(20,6),
    subtotal numeric(20,6),
    total_tax numeric(20,6),
    total_amount numeric(20,6),
    notes text,
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.inv_sales_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_sales_orders_id_seq OWNED BY public.inv_sales_orders.id;

CREATE TABLE public.inv_sales_return_items (
    id integer NOT NULL,
    company_id integer,
    return_id integer NOT NULL,
    product_id integer,
    description character varying(300),
    original_quantity numeric(20,6),
    previously_returned_qty numeric(20,6),
    max_returnable_qty numeric(20,6),
    current_return_qty numeric(20,6),
    unit character varying(20),
    unit_price numeric(20,6),
    discount_pct numeric(20,6),
    discount_amount numeric(20,6),
    delivery numeric(20,6),
    installation numeric(20,6),
    sales_tax_pct numeric(20,6),
    total_before_discount numeric(20,6),
    total_after_discount numeric(20,6),
    proportional_discount numeric(20,6),
    proportional_sales_tax numeric(20,6),
    proportional_delivery numeric(20,6),
    proportional_installation numeric(20,6),
    net_return_value numeric(20,6),
    cost_basis numeric(20,6),
    total_cost_returned numeric(20,6)
);

CREATE SEQUENCE public.inv_sales_return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_sales_return_items_id_seq OWNED BY public.inv_sales_return_items.id;

CREATE TABLE public.inv_sales_returns (
    id integer NOT NULL,
    company_id integer,
    return_number character varying(50) NOT NULL,
    original_invoice_id integer NOT NULL,
    customer_id integer NOT NULL,
    party_account_id integer,
    return_date timestamp without time zone,
    notes text,
    gross_return_value numeric(20,6),
    total_discount numeric(20,6),
    total_charges numeric(20,6),
    total_tax numeric(20,6),
    net_return_amount numeric(20,6),
    total_cost_returned numeric(20,6),
    reverse_charges boolean,
    status character varying(20),
    created_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    edit_version integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.inv_sales_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_sales_returns_id_seq OWNED BY public.inv_sales_returns.id;

CREATE TABLE public.inv_stock_movements (
    id integer NOT NULL,
    company_id integer,
    product_id integer NOT NULL,
    type character varying(20) NOT NULL,
    quantity numeric(16,4) NOT NULL,
    reference_type character varying(50),
    reference_id integer,
    notes text,
    created_by integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.inv_stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_stock_movements_id_seq OWNED BY public.inv_stock_movements.id;

CREATE TABLE public.inv_suppliers (
    id integer NOT NULL,
    company_id integer,
    name character varying(200) NOT NULL,
    contact_person character varying(100),
    email character varying(120),
    phone character varying(20),
    mobile character varying(20),
    address text,
    city character varying(50),
    tax_id character varying(50),
    payment_terms character varying(100),
    website character varying(200),
    notes text,
    is_active boolean,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.inv_suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_suppliers_id_seq OWNED BY public.inv_suppliers.id;

CREATE TABLE public.inv_units (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    abbreviation character varying(20) NOT NULL,
    explanation text,
    is_active boolean,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.inv_units_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inv_units_id_seq OWNED BY public.inv_units.id;

CREATE TABLE public.inventory_settings (
    id integer NOT NULL,
    company_id integer,
    valuation_method character varying(20),
    allow_negative_stock boolean,
    decimal_places integer,
    auto_generate_vouchers boolean,
    purchase_flow character varying(20),
    sales_flow character varying(20),
    default_cogs_account_id integer,
    default_inventory_account_id integer,
    default_return_account_id integer,
    per_line_labeling_voucher boolean,
    per_line_labeling_invoice boolean,
    default_voucher_label_id integer,
    default_invoice_label_id integer
);

CREATE SEQUENCE public.inventory_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.inventory_settings_id_seq OWNED BY public.inventory_settings.id;

CREATE TABLE public.invoice_settings (
    id integer NOT NULL,
    company_id integer,
    default_sales_tax_pct numeric(20,6),
    default_further_tax_pct numeric(20,6),
    default_withholding_tax_pct numeric(20,6),
    default_discount_pct numeric(20,6),
    default_charges_mode character varying(20),
    default_discount_mode character varying(20),
    default_tax_mode character varying(20),
    show_discount_column boolean,
    show_charges_column boolean,
    show_tax_column boolean,
    auto_add_line boolean,
    require_approval boolean,
    allow_partial_payment boolean,
    default_party_mode character varying(10),
    over_invoice_tolerance_pct numeric(20,6),
    withholding_base character varying(10),
    show_further_tax boolean,
    show_withholding_tax boolean,
    show_transport_block boolean,
    create_from_orders_enabled boolean,
    per_line_discount_enabled boolean,
    per_line_tax_enabled boolean
);

CREATE SEQUENCE public.invoice_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.invoice_settings_id_seq OWNED BY public.invoice_settings.id;

CREATE TABLE public.invoice_templates (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    type character varying(10) NOT NULL,
    body_html text NOT NULL,
    is_default boolean,
    design character varying(20),
    accent_color character varying(20),
    options_json text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.invoice_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.invoice_templates_id_seq OWNED BY public.invoice_templates.id;

CREATE TABLE public.journal_entries (
    id integer NOT NULL,
    company_id integer,
    voucher_type character varying(50) NOT NULL,
    voucher_id integer NOT NULL,
    voucher_number character varying(50) NOT NULL,
    description text,
    entry_date timestamp without time zone NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp without time zone,
    is_posted boolean
);

CREATE SEQUENCE public.journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.journal_entries_id_seq OWNED BY public.journal_entries.id;

CREATE TABLE public.journal_lines (
    id integer NOT NULL,
    company_id integer,
    journal_entry_id integer NOT NULL,
    account_id integer NOT NULL,
    debit numeric(16,4),
    credit numeric(16,4),
    description text,
    label_id integer
);

CREATE SEQUENCE public.journal_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.journal_lines_id_seq OWNED BY public.journal_lines.id;

CREATE TABLE public.kanban_boards (
    id integer NOT NULL,
    company_id integer,
    title character varying(200) NOT NULL,
    description text,
    created_by integer NOT NULL,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.kanban_boards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.kanban_boards_id_seq OWNED BY public.kanban_boards.id;

CREATE TABLE public.kanban_tasks (
    id integer NOT NULL,
    company_id integer,
    board_id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    status character varying(30),
    priority character varying(20),
    assignee_id integer,
    due_date date,
    "position" integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.kanban_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.kanban_tasks_id_seq OWNED BY public.kanban_tasks.id;

CREATE TABLE public.layer_consumptions (
    id integer NOT NULL,
    company_id integer,
    layer_id integer NOT NULL,
    out_ledger_id integer NOT NULL,
    product_id integer NOT NULL,
    qty numeric(16,4) NOT NULL,
    unit_cost numeric(16,4) NOT NULL,
    total_cost numeric(16,4) NOT NULL,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.layer_consumptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.layer_consumptions_id_seq OWNED BY public.layer_consumptions.id;

CREATE TABLE public.leave_approvals (
    id integer NOT NULL,
    company_id integer,
    leave_request_id integer NOT NULL,
    approver_id integer NOT NULL,
    level integer,
    status character varying(20),
    comment text,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.leave_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.leave_approvals_id_seq OWNED BY public.leave_approvals.id;

CREATE TABLE public.leave_quotas (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    year integer NOT NULL,
    total numeric(20,6),
    used numeric(20,6),
    pending numeric(20,6),
    remaining numeric(20,6)
);

CREATE SEQUENCE public.leave_quotas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.leave_quotas_id_seq OWNED BY public.leave_quotas.id;

CREATE TABLE public.leave_requests (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    total_days numeric(20,6) NOT NULL,
    reason text NOT NULL,
    status character varying(20),
    is_half_day boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.leave_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.leave_requests_id_seq OWNED BY public.leave_requests.id;

CREATE TABLE public.leave_types (
    id integer NOT NULL,
    company_id integer,
    name character varying(50) NOT NULL,
    code character varying(10) NOT NULL,
    description text,
    default_quota integer,
    is_paid boolean,
    requires_approval boolean,
    carry_forward boolean,
    max_carry_forward integer
);

CREATE SEQUENCE public.leave_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.leave_types_id_seq OWNED BY public.leave_types.id;

CREATE TABLE public.loan_advance_requests (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    request_type character varying(20) NOT NULL,
    amount numeric(20,6) NOT NULL,
    purpose text NOT NULL,
    installment_months integer,
    monthly_installment numeric(20,6),
    remaining_amount numeric(20,6),
    status character varying(20),
    approved_by integer,
    approved_at timestamp without time zone,
    disbursed_at timestamp without time zone,
    queue_for_payroll boolean,
    notes text,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.loan_advance_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.loan_advance_requests_id_seq OWNED BY public.loan_advance_requests.id;

CREATE TABLE public.loan_repayments (
    id integer NOT NULL,
    company_id integer,
    loan_id integer NOT NULL,
    amount numeric(20,6) NOT NULL,
    paid_at timestamp without time zone,
    payroll_run_id integer,
    notes text
);

CREATE SEQUENCE public.loan_repayments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.loan_repayments_id_seq OWNED BY public.loan_repayments.id;

CREATE TABLE public.notification_recipients (
    id integer NOT NULL,
    company_id integer,
    notification_id integer NOT NULL,
    user_id integer NOT NULL,
    is_read boolean,
    read_at timestamp without time zone
);

CREATE SEQUENCE public.notification_recipients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.notification_recipients_id_seq OWNED BY public.notification_recipients.id;

CREATE TABLE public.notifications (
    id integer NOT NULL,
    company_id integer,
    title character varying(200) NOT NULL,
    message text NOT NULL,
    notification_type character varying(50),
    module character varying(50),
    reference_id integer,
    created_by integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;

CREATE TABLE public.overtime_accounts (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    date date NOT NULL,
    regular_hours double precision,
    overtime_hours double precision,
    double_overtime double precision,
    approved boolean,
    notes text,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.overtime_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.overtime_accounts_id_seq OWNED BY public.overtime_accounts.id;

CREATE TABLE public.payment_allocations (
    id integer NOT NULL,
    company_id integer,
    voucher_id integer NOT NULL,
    voucher_line_id integer NOT NULL,
    doc_type character varying(4) NOT NULL,
    doc_id integer NOT NULL,
    party_type character varying(10) NOT NULL,
    party_id integer NOT NULL,
    amount numeric(16,4) NOT NULL,
    note character varying(300),
    created_by integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.payment_allocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.payment_allocations_id_seq OWNED BY public.payment_allocations.id;

CREATE TABLE public.payroll_audit_logs (
    id integer NOT NULL,
    company_id integer,
    payroll_run_id integer,
    action character varying(50) NOT NULL,
    performed_by integer NOT NULL,
    details text,
    ip_address character varying(50),
    performed_at timestamp without time zone
);

CREATE SEQUENCE public.payroll_audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.payroll_audit_logs_id_seq OWNED BY public.payroll_audit_logs.id;

CREATE TABLE public.payroll_components (
    id integer NOT NULL,
    company_id integer,
    profile_id integer NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(20) NOT NULL,
    calculation_method character varying(30),
    value numeric(20,6),
    is_taxable boolean
);

CREATE SEQUENCE public.payroll_components_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.payroll_components_id_seq OWNED BY public.payroll_components.id;

CREATE TABLE public.payroll_profiles (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    basic_salary numeric(20,6),
    effective_from date NOT NULL,
    payment_method character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.payroll_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.payroll_profiles_id_seq OWNED BY public.payroll_profiles.id;

CREATE TABLE public.payroll_runs (
    id integer NOT NULL,
    company_id integer,
    month integer NOT NULL,
    year integer NOT NULL,
    run_date timestamp without time zone,
    status character varying(20),
    total_gross numeric(20,6),
    total_deductions numeric(20,6),
    total_net numeric(20,6),
    employee_count integer,
    processed_by integer,
    approved_by integer,
    approved_at timestamp without time zone,
    notes text,
    paid_at timestamp without time zone
);

CREATE SEQUENCE public.payroll_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.payroll_runs_id_seq OWNED BY public.payroll_runs.id;

CREATE TABLE public.payroll_settings (
    id integer NOT NULL,
    company_id integer,
    overtime_multiplier numeric(20,6),
    overtime_hours_basis numeric(20,6),
    eobi_enabled boolean,
    eobi_wage_base numeric(20,6),
    eobi_employee_pct numeric(20,6),
    eobi_employer_pct numeric(20,6),
    surcharge_threshold numeric(20,6),
    surcharge_pct numeric(20,6),
    gratuity_enabled boolean,
    gratuity_basis character varying(10),
    gratuity_days_per_year numeric(20,6),
    leave_encashment_enabled boolean
);

CREATE SEQUENCE public.payroll_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.payroll_settings_id_seq OWNED BY public.payroll_settings.id;

CREATE TABLE public.payroll_slips (
    id integer NOT NULL,
    company_id integer,
    payroll_run_id integer NOT NULL,
    user_id integer NOT NULL,
    basic_salary numeric(20,6),
    allowances numeric(20,6),
    deductions numeric(20,6),
    gross_pay numeric(20,6),
    total_deductions numeric(20,6),
    net_pay numeric(20,6),
    taxable_pay numeric(20,6),
    components_json text,
    pdf_filename character varying(255),
    created_at timestamp without time zone
);

CREATE SEQUENCE public.payroll_slips_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.payroll_slips_id_seq OWNED BY public.payroll_slips.id;

CREATE TABLE public.performance_goals (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    target_date date,
    status character varying(20),
    progress_pct integer,
    created_by integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.performance_goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.performance_goals_id_seq OWNED BY public.performance_goals.id;

CREATE TABLE public.performance_reviews (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    reviewer_id integer NOT NULL,
    review_period character varying(50) NOT NULL,
    overall_score double precision,
    productivity_rating integer,
    quality_rating integer,
    teamwork_rating integer,
    punctuality_rating integer,
    strengths text,
    improvements text,
    feedback text,
    status character varying(20),
    completed_at timestamp without time zone,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.performance_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.performance_reviews_id_seq OWNED BY public.performance_reviews.id;

CREATE TABLE public.permissions (
    id integer NOT NULL,
    role_id integer NOT NULL,
    resource character varying(100) NOT NULL,
    can_read boolean,
    can_write boolean,
    can_delete boolean
);

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;

CREATE TABLE public.pf_config (
    id integer NOT NULL,
    company_id integer,
    employee_contribution_pct numeric(20,6),
    employer_contribution_pct numeric(20,6),
    contribution_base character varying(10),
    max_loan_percentage numeric(20,6),
    interest_rate numeric(20,6),
    min_service_months_for_loan integer,
    is_active boolean,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.pf_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.pf_config_id_seq OWNED BY public.pf_config.id;

CREATE TABLE public.pf_contributions (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    employee_amount numeric(20,6),
    employer_amount numeric(20,6),
    total_amount numeric(20,6),
    created_at timestamp without time zone
);

CREATE SEQUENCE public.pf_contributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.pf_contributions_id_seq OWNED BY public.pf_contributions.id;

CREATE TABLE public.pf_ledger (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    transaction_date date NOT NULL,
    transaction_type character varying(30) NOT NULL,
    description text,
    debit numeric(20,6),
    credit numeric(20,6),
    balance numeric(20,6),
    reference_id integer,
    payroll_run_id integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.pf_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.pf_ledger_id_seq OWNED BY public.pf_ledger.id;

CREATE TABLE public.pf_loan_requests (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    amount numeric(20,6) NOT NULL,
    installment_months integer,
    purpose text NOT NULL,
    status character varying(20),
    approved_by integer,
    approved_at timestamp without time zone,
    monthly_installment numeric(20,6),
    remaining_amount numeric(20,6),
    created_at timestamp without time zone
);

CREATE SEQUENCE public.pf_loan_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.pf_loan_requests_id_seq OWNED BY public.pf_loan_requests.id;

CREATE TABLE public.pf_profit_distributions (
    id integer NOT NULL,
    company_id integer,
    month integer NOT NULL,
    year integer NOT NULL,
    total_profit numeric(20,6) NOT NULL,
    distributed_at timestamp without time zone,
    distributed_by integer,
    status character varying(20)
);

CREATE SEQUENCE public.pf_profit_distributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.pf_profit_distributions_id_seq OWNED BY public.pf_profit_distributions.id;

CREATE TABLE public.pf_settlements (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    total_employee_contrib numeric(20,6),
    total_employer_contrib numeric(20,6),
    total_profit_distributed numeric(20,6),
    outstanding_loan numeric(20,6),
    net_settlement numeric(20,6),
    status character varying(20),
    settled_by integer,
    settled_at timestamp without time zone,
    pdf_statement character varying(255),
    created_at timestamp without time zone
);

CREATE SEQUENCE public.pf_settlements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.pf_settlements_id_seq OWNED BY public.pf_settlements.id;

CREATE TABLE public.pf_withdrawal_requests (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    amount numeric(20,6) NOT NULL,
    reason text NOT NULL,
    status character varying(20),
    approved_by integer,
    approved_at timestamp without time zone,
    disbursed_at timestamp without time zone,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.pf_withdrawal_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.pf_withdrawal_requests_id_seq OWNED BY public.pf_withdrawal_requests.id;

CREATE TABLE public.project_labels (
    id integer NOT NULL,
    company_id integer,
    name character varying(120) NOT NULL,
    is_active boolean,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.project_labels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.project_labels_id_seq OWNED BY public.project_labels.id;

CREATE TABLE public.project_tasks (
    id integer NOT NULL,
    company_id integer,
    work_package_id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    estimated_hours double precision,
    assigned_to integer,
    due_date date,
    status character varying(20),
    created_at timestamp without time zone
);

CREATE SEQUENCE public.project_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.project_tasks_id_seq OWNED BY public.project_tasks.id;

CREATE TABLE public.projects (
    id integer NOT NULL,
    company_id integer,
    name character varying(200) NOT NULL,
    code character varying(20),
    description text,
    department character varying(100),
    project_manager_id integer,
    start_date date,
    end_date date,
    status character varying(20),
    is_billable boolean,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;

CREATE TABLE public.registration_requests (
    id integer NOT NULL,
    full_name character varying(120) NOT NULL,
    email character varying(120) NOT NULL,
    phone character varying(30),
    password_hash character varying(255) NOT NULL,
    company_name character varying(200),
    notes text,
    status character varying(15) NOT NULL,
    seen boolean NOT NULL,
    reviewed_by integer,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL
);

CREATE SEQUENCE public.registration_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.registration_requests_id_seq OWNED BY public.registration_requests.id;

CREATE TABLE public.report_settings (
    id integer NOT NULL,
    company_id integer,
    pl_structure_json text,
    pl_detail_rows integer,
    invoice_party_mode character varying(10),
    purchase_party_mode character varying(10),
    sales_party_mode character varying(10),
    purchase_template_text text,
    sales_template_text text,
    purchase_template_id integer,
    sales_template_id integer,
    cash_flow_method character varying(20),
    twcf_cash_floor numeric(16,4),
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.report_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.report_settings_id_seq OWNED BY public.report_settings.id;

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(200)
);

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;

CREATE TABLE public.salary_revisions (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    previous_basic numeric(20,6),
    new_basic numeric(20,6) NOT NULL,
    reason text,
    approved_by integer,
    effective_from date NOT NULL,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.salary_revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.salary_revisions_id_seq OWNED BY public.salary_revisions.id;

CREATE TABLE public.scrap_items (
    id integer NOT NULL,
    company_id integer,
    voucher_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(200),
    quantity numeric(16,4) NOT NULL,
    unit_cost numeric(16,4),
    total_cost numeric(16,4)
);

CREATE SEQUENCE public.scrap_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.scrap_items_id_seq OWNED BY public.scrap_items.id;

CREATE TABLE public.scrap_vouchers (
    id integer NOT NULL,
    company_id integer,
    voucher_number character varying(50) NOT NULL,
    date timestamp without time zone,
    reason text,
    charge_account_id integer,
    label_id integer,
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone
);

CREATE SEQUENCE public.scrap_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.scrap_vouchers_id_seq OWNED BY public.scrap_vouchers.id;

CREATE TABLE public.stock_adjustment_items (
    id integer NOT NULL,
    company_id integer,
    voucher_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(200),
    system_qty numeric(16,4),
    physical_qty numeric(16,4),
    difference numeric(16,4),
    unit_cost numeric(16,4),
    total_cost numeric(16,4)
);

CREATE SEQUENCE public.stock_adjustment_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.stock_adjustment_items_id_seq OWNED BY public.stock_adjustment_items.id;

CREATE TABLE public.stock_adjustment_vouchers (
    id integer NOT NULL,
    company_id integer,
    voucher_number character varying(50) NOT NULL,
    date timestamp without time zone,
    reason text,
    label_id integer,
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone
);

CREATE SEQUENCE public.stock_adjustment_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.stock_adjustment_vouchers_id_seq OWNED BY public.stock_adjustment_vouchers.id;

CREATE TABLE public.stock_cost_adjustments (
    id integer NOT NULL,
    company_id integer,
    product_id integer NOT NULL,
    ledger_id integer,
    voucher_type character varying(50) NOT NULL,
    voucher_id integer NOT NULL,
    voucher_number character varying(50),
    old_cost numeric(16,4) NOT NULL,
    new_cost numeric(16,4) NOT NULL,
    delta numeric(16,4) NOT NULL,
    trigger character varying(120),
    journal_entry_id integer,
    entry_date date,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.stock_cost_adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.stock_cost_adjustments_id_seq OWNED BY public.stock_cost_adjustments.id;

CREATE TABLE public.stock_layers (
    id integer NOT NULL,
    company_id integer,
    product_id integer NOT NULL,
    source_ledger_id integer,
    unit_cost numeric(16,4) NOT NULL,
    qty_original numeric(16,4) NOT NULL,
    qty_remaining numeric(16,4) NOT NULL,
    value_remaining numeric(18,4) NOT NULL,
    method character varying(20) NOT NULL,
    is_revaluation boolean,
    created_at timestamp without time zone,
    notes text
);

CREATE SEQUENCE public.stock_layers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.stock_layers_id_seq OWNED BY public.stock_layers.id;

CREATE TABLE public.stock_ledger (
    id integer NOT NULL,
    company_id integer,
    product_id integer NOT NULL,
    voucher_type character varying(50) NOT NULL,
    voucher_id integer NOT NULL,
    voucher_number character varying(50) NOT NULL,
    transaction_type character varying(10) NOT NULL,
    quantity numeric(16,4) NOT NULL,
    unit_cost numeric(16,4) NOT NULL,
    total_cost numeric(16,4) NOT NULL,
    running_qty numeric(16,4) NOT NULL,
    running_cost numeric(16,4) NOT NULL,
    running_avg numeric(16,4) NOT NULL,
    valuation_method character varying(20),
    txn_date date,
    created_at timestamp without time zone,
    created_by integer NOT NULL,
    notes text
);

CREATE SEQUENCE public.stock_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.stock_ledger_id_seq OWNED BY public.stock_ledger.id;

CREATE TABLE public.stock_take_items (
    id integer NOT NULL,
    company_id integer,
    stock_take_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(200),
    system_qty numeric(16,4),
    physical_qty numeric(16,4),
    difference numeric(16,4),
    unit_cost numeric(16,4)
);

CREATE SEQUENCE public.stock_take_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.stock_take_items_id_seq OWNED BY public.stock_take_items.id;

CREATE TABLE public.stock_takes (
    id integer NOT NULL,
    company_id integer,
    reference character varying(50) NOT NULL,
    date timestamp without time zone,
    location character varying(100),
    status character varying(20),
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone,
    approved_at timestamp without time zone,
    adjustment_voucher_id integer
);

CREATE SEQUENCE public.stock_takes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.stock_takes_id_seq OWNED BY public.stock_takes.id;

CREATE TABLE public.stored_files (
    id integer NOT NULL,
    company_id integer,
    key character varying(300) NOT NULL,
    content_type character varying(120),
    size integer NOT NULL,
    data bytea NOT NULL,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.stored_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.stored_files_id_seq OWNED BY public.stored_files.id;

CREATE TABLE public.tax_rate_accounts (
    id integer NOT NULL,
    company_id integer,
    rate_pct numeric(20,6) NOT NULL,
    account_id integer NOT NULL
);

CREATE SEQUENCE public.tax_rate_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.tax_rate_accounts_id_seq OWNED BY public.tax_rate_accounts.id;

CREATE TABLE public.team_events (
    id integer NOT NULL,
    company_id integer,
    title character varying(200) NOT NULL,
    description text,
    event_date date NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    location character varying(200),
    event_type character varying(50),
    created_by integer NOT NULL,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.team_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.team_events_id_seq OWNED BY public.team_events.id;

CREATE TABLE public.time_policies (
    id integer NOT NULL,
    company_id integer,
    name character varying(100) NOT NULL,
    department character varying(100),
    shift_start time without time zone NOT NULL,
    shift_end time without time zone NOT NULL,
    grace_period_minutes integer,
    max_regular_hours double precision,
    max_overtime_hours double precision,
    max_consecutive_days integer,
    require_break boolean,
    min_break_minutes integer,
    is_active boolean,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.time_policies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.time_policies_id_seq OWNED BY public.time_policies.id;

CREATE TABLE public.timesheet_approvals (
    id integer NOT NULL,
    company_id integer,
    week_id integer NOT NULL,
    approver_id integer NOT NULL,
    status character varying(20),
    comment text,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.timesheet_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.timesheet_approvals_id_seq OWNED BY public.timesheet_approvals.id;

CREATE TABLE public.timesheet_entries (
    id integer NOT NULL,
    company_id integer,
    week_id integer NOT NULL,
    day date NOT NULL,
    project character varying(200),
    task character varying(200) NOT NULL,
    hours double precision NOT NULL,
    description text,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.timesheet_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.timesheet_entries_id_seq OWNED BY public.timesheet_entries.id;

CREATE TABLE public.timesheet_merged_reports (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    total_hours double precision,
    overtime_hours double precision,
    project_breakdown text,
    generated_at timestamp without time zone
);

CREATE SEQUENCE public.timesheet_merged_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.timesheet_merged_reports_id_seq OWNED BY public.timesheet_merged_reports.id;

CREATE TABLE public.timesheet_weeks (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    week_start date NOT NULL,
    week_end date NOT NULL,
    status character varying(20),
    total_hours double precision,
    submitted_at timestamp without time zone,
    approved_at timestamp without time zone,
    approved_by integer,
    notes text,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.timesheet_weeks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.timesheet_weeks_id_seq OWNED BY public.timesheet_weeks.id;

CREATE TABLE public.twcf_lines (
    id integer NOT NULL,
    company_id integer,
    direction character varying(5) NOT NULL,
    category character varying(30) NOT NULL,
    description character varying(200) NOT NULL,
    amount numeric(16,4) NOT NULL,
    start_date date NOT NULL,
    frequency character varying(10) NOT NULL,
    day_of_week integer,
    day_of_month integer,
    month integer,
    created_at timestamp without time zone
);

CREATE SEQUENCE public.twcf_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.twcf_lines_id_seq OWNED BY public.twcf_lines.id;

CREATE TABLE public.user_permissions (
    id integer NOT NULL,
    company_id integer,
    user_id integer NOT NULL,
    resource character varying(100) NOT NULL,
    can_view boolean,
    can_create boolean,
    can_edit boolean,
    can_approve boolean,
    can_delete boolean
);

CREATE SEQUENCE public.user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.user_permissions_id_seq OWNED BY public.user_permissions.id;

CREATE TABLE public.users (
    id integer NOT NULL,
    employee_code character varying(20) NOT NULL,
    email character varying(120) NOT NULL,
    login_id character varying(120),
    password_hash character varying(256) NOT NULL,
    full_name character varying(100) NOT NULL,
    role_id integer NOT NULL,
    manager_id integer,
    designation character varying(100),
    department character varying(100),
    date_of_birth date,
    date_of_joining date,
    phone character varying(20),
    cnic character varying(20),
    bank_name character varying(100),
    bank_account_title character varying(100),
    bank_account_number character varying(50),
    emergency_contact character varying(100),
    emergency_phone character varying(20),
    address text,
    profile_image character varying(255),
    is_active boolean,
    has_hr_access boolean,
    has_inventory_access boolean,
    has_invoicing_access boolean,
    has_finance_access boolean,
    has_accounting_access boolean,
    has_fbr_access boolean,
    has_fixed_assets_access boolean,
    has_executive_access boolean,
    is_super_admin boolean,
    max_companies_owned integer,
    max_companies_joined integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;

CREATE TABLE public.voucher_numbers (
    id integer NOT NULL,
    company_id integer,
    prefix character varying(20) NOT NULL,
    next_number integer NOT NULL
);

CREATE SEQUENCE public.voucher_numbers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.voucher_numbers_id_seq OWNED BY public.voucher_numbers.id;

CREATE TABLE public.work_packages (
    id integer NOT NULL,
    company_id integer,
    project_id integer NOT NULL,
    name character varying(200) NOT NULL,
    code character varying(20),
    description text,
    estimated_hours double precision,
    status character varying(20),
    created_at timestamp without time zone
);

CREATE SEQUENCE public.work_packages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.work_packages_id_seq OWNED BY public.work_packages.id;

ALTER TABLE ONLY public.accounting_periods ALTER COLUMN id SET DEFAULT nextval('public.accounting_periods_id_seq'::regclass);

ALTER TABLE ONLY public.accounting_voucher_lines ALTER COLUMN id SET DEFAULT nextval('public.accounting_voucher_lines_id_seq'::regclass);

ALTER TABLE ONLY public.accounting_vouchers ALTER COLUMN id SET DEFAULT nextval('public.accounting_vouchers_id_seq'::regclass);

ALTER TABLE ONLY public.additional_charges ALTER COLUMN id SET DEFAULT nextval('public.additional_charges_id_seq'::regclass);

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);

ALTER TABLE ONLY public.approval_workflows ALTER COLUMN id SET DEFAULT nextval('public.approval_workflows_id_seq'::regclass);

ALTER TABLE ONLY public.asset_depreciation ALTER COLUMN id SET DEFAULT nextval('public.asset_depreciation_id_seq'::regclass);

ALTER TABLE ONLY public.asset_transfers ALTER COLUMN id SET DEFAULT nextval('public.asset_transfers_id_seq'::regclass);

ALTER TABLE ONLY public.attendance ALTER COLUMN id SET DEFAULT nextval('public.attendance_id_seq'::regclass);

ALTER TABLE ONLY public.attendance_corrections ALTER COLUMN id SET DEFAULT nextval('public.attendance_corrections_id_seq'::regclass);

ALTER TABLE ONLY public.attendance_logs ALTER COLUMN id SET DEFAULT nextval('public.attendance_logs_id_seq'::regclass);

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);

ALTER TABLE ONLY public.bank_rec_items ALTER COLUMN id SET DEFAULT nextval('public.bank_rec_items_id_seq'::regclass);

ALTER TABLE ONLY public.bank_reconciliations ALTER COLUMN id SET DEFAULT nextval('public.bank_reconciliations_id_seq'::regclass);

ALTER TABLE ONLY public.break_logs ALTER COLUMN id SET DEFAULT nextval('public.break_logs_id_seq'::regclass);

ALTER TABLE ONLY public.button_permissions ALTER COLUMN id SET DEFAULT nextval('public.button_permissions_id_seq'::regclass);

ALTER TABLE ONLY public.category_revenue_accounts ALTER COLUMN id SET DEFAULT nextval('public.category_revenue_accounts_id_seq'::regclass);

ALTER TABLE ONLY public.change_requests ALTER COLUMN id SET DEFAULT nextval('public.change_requests_id_seq'::regclass);

ALTER TABLE ONLY public.charge_ledger_defaults ALTER COLUMN id SET DEFAULT nextval('public.charge_ledger_defaults_id_seq'::regclass);

ALTER TABLE ONLY public.chart_of_accounts ALTER COLUMN id SET DEFAULT nextval('public.chart_of_accounts_id_seq'::regclass);

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);

ALTER TABLE ONLY public.company_holidays ALTER COLUMN id SET DEFAULT nextval('public.company_holidays_id_seq'::regclass);

ALTER TABLE ONLY public.company_info ALTER COLUMN id SET DEFAULT nextval('public.company_info_id_seq'::regclass);

ALTER TABLE ONLY public.company_invitations ALTER COLUMN id SET DEFAULT nextval('public.company_invitations_id_seq'::regclass);

ALTER TABLE ONLY public.company_memberships ALTER COLUMN id SET DEFAULT nextval('public.company_memberships_id_seq'::regclass);

ALTER TABLE ONLY public.consumption_items ALTER COLUMN id SET DEFAULT nextval('public.consumption_items_id_seq'::regclass);

ALTER TABLE ONLY public.consumption_vouchers ALTER COLUMN id SET DEFAULT nextval('public.consumption_vouchers_id_seq'::regclass);

ALTER TABLE ONLY public.digital_files ALTER COLUMN id SET DEFAULT nextval('public.digital_files_id_seq'::regclass);

ALTER TABLE ONLY public.email_logs ALTER COLUMN id SET DEFAULT nextval('public.email_logs_id_seq'::regclass);

ALTER TABLE ONLY public.exec_account_selections ALTER COLUMN id SET DEFAULT nextval('public.exec_account_selections_id_seq'::regclass);

ALTER TABLE ONLY public.fa_categories ALTER COLUMN id SET DEFAULT nextval('public.fa_categories_id_seq'::regclass);

ALTER TABLE ONLY public.fbr_config ALTER COLUMN id SET DEFAULT nextval('public.fbr_config_id_seq'::regclass);

ALTER TABLE ONLY public.fbr_invoice_records ALTER COLUMN id SET DEFAULT nextval('public.fbr_invoice_records_id_seq'::regclass);

ALTER TABLE ONLY public.file_categories ALTER COLUMN id SET DEFAULT nextval('public.file_categories_id_seq'::regclass);

ALTER TABLE ONLY public.fiscal_year_rule ALTER COLUMN id SET DEFAULT nextval('public.fiscal_year_rule_id_seq'::regclass);

ALTER TABLE ONLY public.fixed_assets ALTER COLUMN id SET DEFAULT nextval('public.fixed_assets_id_seq'::regclass);

ALTER TABLE ONLY public.gl_daily_balances ALTER COLUMN id SET DEFAULT nextval('public.gl_daily_balances_id_seq'::regclass);

ALTER TABLE ONLY public.global_limits ALTER COLUMN id SET DEFAULT nextval('public.global_limits_id_seq'::regclass);

ALTER TABLE ONLY public.income_tax_slabs ALTER COLUMN id SET DEFAULT nextval('public.income_tax_slabs_id_seq'::regclass);

ALTER TABLE ONLY public.inv_categories ALTER COLUMN id SET DEFAULT nextval('public.inv_categories_id_seq'::regclass);

ALTER TABLE ONLY public.inv_customers ALTER COLUMN id SET DEFAULT nextval('public.inv_customers_id_seq'::regclass);

ALTER TABLE ONLY public.inv_invoice_items ALTER COLUMN id SET DEFAULT nextval('public.inv_invoice_items_id_seq'::regclass);

ALTER TABLE ONLY public.inv_invoices ALTER COLUMN id SET DEFAULT nextval('public.inv_invoices_id_seq'::regclass);

ALTER TABLE ONLY public.inv_products ALTER COLUMN id SET DEFAULT nextval('public.inv_products_id_seq'::regclass);

ALTER TABLE ONLY public.inv_purchase_invoice_items ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_invoice_items_id_seq'::regclass);

ALTER TABLE ONLY public.inv_purchase_invoices ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_invoices_id_seq'::regclass);

ALTER TABLE ONLY public.inv_purchase_order_items ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_order_items_id_seq'::regclass);

ALTER TABLE ONLY public.inv_purchase_orders ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_orders_id_seq'::regclass);

ALTER TABLE ONLY public.inv_purchase_return_items ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_return_items_id_seq'::regclass);

ALTER TABLE ONLY public.inv_purchase_returns ALTER COLUMN id SET DEFAULT nextval('public.inv_purchase_returns_id_seq'::regclass);

ALTER TABLE ONLY public.inv_sales_order_items ALTER COLUMN id SET DEFAULT nextval('public.inv_sales_order_items_id_seq'::regclass);

ALTER TABLE ONLY public.inv_sales_orders ALTER COLUMN id SET DEFAULT nextval('public.inv_sales_orders_id_seq'::regclass);

ALTER TABLE ONLY public.inv_sales_return_items ALTER COLUMN id SET DEFAULT nextval('public.inv_sales_return_items_id_seq'::regclass);

ALTER TABLE ONLY public.inv_sales_returns ALTER COLUMN id SET DEFAULT nextval('public.inv_sales_returns_id_seq'::regclass);

ALTER TABLE ONLY public.inv_stock_movements ALTER COLUMN id SET DEFAULT nextval('public.inv_stock_movements_id_seq'::regclass);

ALTER TABLE ONLY public.inv_suppliers ALTER COLUMN id SET DEFAULT nextval('public.inv_suppliers_id_seq'::regclass);

ALTER TABLE ONLY public.inv_units ALTER COLUMN id SET DEFAULT nextval('public.inv_units_id_seq'::regclass);

ALTER TABLE ONLY public.inventory_settings ALTER COLUMN id SET DEFAULT nextval('public.inventory_settings_id_seq'::regclass);

ALTER TABLE ONLY public.invoice_settings ALTER COLUMN id SET DEFAULT nextval('public.invoice_settings_id_seq'::regclass);

ALTER TABLE ONLY public.invoice_templates ALTER COLUMN id SET DEFAULT nextval('public.invoice_templates_id_seq'::regclass);

ALTER TABLE ONLY public.journal_entries ALTER COLUMN id SET DEFAULT nextval('public.journal_entries_id_seq'::regclass);

ALTER TABLE ONLY public.journal_lines ALTER COLUMN id SET DEFAULT nextval('public.journal_lines_id_seq'::regclass);

ALTER TABLE ONLY public.kanban_boards ALTER COLUMN id SET DEFAULT nextval('public.kanban_boards_id_seq'::regclass);

ALTER TABLE ONLY public.kanban_tasks ALTER COLUMN id SET DEFAULT nextval('public.kanban_tasks_id_seq'::regclass);

ALTER TABLE ONLY public.layer_consumptions ALTER COLUMN id SET DEFAULT nextval('public.layer_consumptions_id_seq'::regclass);

ALTER TABLE ONLY public.leave_approvals ALTER COLUMN id SET DEFAULT nextval('public.leave_approvals_id_seq'::regclass);

ALTER TABLE ONLY public.leave_quotas ALTER COLUMN id SET DEFAULT nextval('public.leave_quotas_id_seq'::regclass);

ALTER TABLE ONLY public.leave_requests ALTER COLUMN id SET DEFAULT nextval('public.leave_requests_id_seq'::regclass);

ALTER TABLE ONLY public.leave_types ALTER COLUMN id SET DEFAULT nextval('public.leave_types_id_seq'::regclass);

ALTER TABLE ONLY public.loan_advance_requests ALTER COLUMN id SET DEFAULT nextval('public.loan_advance_requests_id_seq'::regclass);

ALTER TABLE ONLY public.loan_repayments ALTER COLUMN id SET DEFAULT nextval('public.loan_repayments_id_seq'::regclass);

ALTER TABLE ONLY public.notification_recipients ALTER COLUMN id SET DEFAULT nextval('public.notification_recipients_id_seq'::regclass);

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);

ALTER TABLE ONLY public.overtime_accounts ALTER COLUMN id SET DEFAULT nextval('public.overtime_accounts_id_seq'::regclass);

ALTER TABLE ONLY public.payment_allocations ALTER COLUMN id SET DEFAULT nextval('public.payment_allocations_id_seq'::regclass);

ALTER TABLE ONLY public.payroll_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.payroll_audit_logs_id_seq'::regclass);

ALTER TABLE ONLY public.payroll_components ALTER COLUMN id SET DEFAULT nextval('public.payroll_components_id_seq'::regclass);

ALTER TABLE ONLY public.payroll_profiles ALTER COLUMN id SET DEFAULT nextval('public.payroll_profiles_id_seq'::regclass);

ALTER TABLE ONLY public.payroll_runs ALTER COLUMN id SET DEFAULT nextval('public.payroll_runs_id_seq'::regclass);

ALTER TABLE ONLY public.payroll_settings ALTER COLUMN id SET DEFAULT nextval('public.payroll_settings_id_seq'::regclass);

ALTER TABLE ONLY public.payroll_slips ALTER COLUMN id SET DEFAULT nextval('public.payroll_slips_id_seq'::regclass);

ALTER TABLE ONLY public.performance_goals ALTER COLUMN id SET DEFAULT nextval('public.performance_goals_id_seq'::regclass);

ALTER TABLE ONLY public.performance_reviews ALTER COLUMN id SET DEFAULT nextval('public.performance_reviews_id_seq'::regclass);

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);

ALTER TABLE ONLY public.pf_config ALTER COLUMN id SET DEFAULT nextval('public.pf_config_id_seq'::regclass);

ALTER TABLE ONLY public.pf_contributions ALTER COLUMN id SET DEFAULT nextval('public.pf_contributions_id_seq'::regclass);

ALTER TABLE ONLY public.pf_ledger ALTER COLUMN id SET DEFAULT nextval('public.pf_ledger_id_seq'::regclass);

ALTER TABLE ONLY public.pf_loan_requests ALTER COLUMN id SET DEFAULT nextval('public.pf_loan_requests_id_seq'::regclass);

ALTER TABLE ONLY public.pf_profit_distributions ALTER COLUMN id SET DEFAULT nextval('public.pf_profit_distributions_id_seq'::regclass);

ALTER TABLE ONLY public.pf_settlements ALTER COLUMN id SET DEFAULT nextval('public.pf_settlements_id_seq'::regclass);

ALTER TABLE ONLY public.pf_withdrawal_requests ALTER COLUMN id SET DEFAULT nextval('public.pf_withdrawal_requests_id_seq'::regclass);

ALTER TABLE ONLY public.project_labels ALTER COLUMN id SET DEFAULT nextval('public.project_labels_id_seq'::regclass);

ALTER TABLE ONLY public.project_tasks ALTER COLUMN id SET DEFAULT nextval('public.project_tasks_id_seq'::regclass);

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);

ALTER TABLE ONLY public.registration_requests ALTER COLUMN id SET DEFAULT nextval('public.registration_requests_id_seq'::regclass);

ALTER TABLE ONLY public.report_settings ALTER COLUMN id SET DEFAULT nextval('public.report_settings_id_seq'::regclass);

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);

ALTER TABLE ONLY public.salary_revisions ALTER COLUMN id SET DEFAULT nextval('public.salary_revisions_id_seq'::regclass);

ALTER TABLE ONLY public.scrap_items ALTER COLUMN id SET DEFAULT nextval('public.scrap_items_id_seq'::regclass);

ALTER TABLE ONLY public.scrap_vouchers ALTER COLUMN id SET DEFAULT nextval('public.scrap_vouchers_id_seq'::regclass);

ALTER TABLE ONLY public.stock_adjustment_items ALTER COLUMN id SET DEFAULT nextval('public.stock_adjustment_items_id_seq'::regclass);

ALTER TABLE ONLY public.stock_adjustment_vouchers ALTER COLUMN id SET DEFAULT nextval('public.stock_adjustment_vouchers_id_seq'::regclass);

ALTER TABLE ONLY public.stock_cost_adjustments ALTER COLUMN id SET DEFAULT nextval('public.stock_cost_adjustments_id_seq'::regclass);

ALTER TABLE ONLY public.stock_layers ALTER COLUMN id SET DEFAULT nextval('public.stock_layers_id_seq'::regclass);

ALTER TABLE ONLY public.stock_ledger ALTER COLUMN id SET DEFAULT nextval('public.stock_ledger_id_seq'::regclass);

ALTER TABLE ONLY public.stock_take_items ALTER COLUMN id SET DEFAULT nextval('public.stock_take_items_id_seq'::regclass);

ALTER TABLE ONLY public.stock_takes ALTER COLUMN id SET DEFAULT nextval('public.stock_takes_id_seq'::regclass);

ALTER TABLE ONLY public.stored_files ALTER COLUMN id SET DEFAULT nextval('public.stored_files_id_seq'::regclass);

ALTER TABLE ONLY public.tax_rate_accounts ALTER COLUMN id SET DEFAULT nextval('public.tax_rate_accounts_id_seq'::regclass);

ALTER TABLE ONLY public.team_events ALTER COLUMN id SET DEFAULT nextval('public.team_events_id_seq'::regclass);

ALTER TABLE ONLY public.time_policies ALTER COLUMN id SET DEFAULT nextval('public.time_policies_id_seq'::regclass);

ALTER TABLE ONLY public.timesheet_approvals ALTER COLUMN id SET DEFAULT nextval('public.timesheet_approvals_id_seq'::regclass);

ALTER TABLE ONLY public.timesheet_entries ALTER COLUMN id SET DEFAULT nextval('public.timesheet_entries_id_seq'::regclass);

ALTER TABLE ONLY public.timesheet_merged_reports ALTER COLUMN id SET DEFAULT nextval('public.timesheet_merged_reports_id_seq'::regclass);

ALTER TABLE ONLY public.timesheet_weeks ALTER COLUMN id SET DEFAULT nextval('public.timesheet_weeks_id_seq'::regclass);

ALTER TABLE ONLY public.twcf_lines ALTER COLUMN id SET DEFAULT nextval('public.twcf_lines_id_seq'::regclass);

ALTER TABLE ONLY public.user_permissions ALTER COLUMN id SET DEFAULT nextval('public.user_permissions_id_seq'::regclass);

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);

ALTER TABLE ONLY public.voucher_numbers ALTER COLUMN id SET DEFAULT nextval('public.voucher_numbers_id_seq'::regclass);

ALTER TABLE ONLY public.work_packages ALTER COLUMN id SET DEFAULT nextval('public.work_packages_id_seq'::regclass);

INSERT INTO public.accounting_periods VALUES
	(1, 1, '2021', 'FY 2021', '2021-01-01', '2021-12-31', true, false, true, '2026-10-29 08:52:22.889832', NULL),
	(2, 1, '2022', 'FY 2022', '2022-01-01', '2022-12-31', true, false, true, '2026-10-29 08:52:22.889838', NULL),
	(3, 1, '2023', 'FY 2023', '2023-01-01', '2023-12-31', true, false, true, '2026-10-29 08:52:22.88984', NULL),
	(4, 1, '2024', 'FY 2024', '2024-01-01', '2024-12-31', true, false, true, '2026-10-29 08:52:22.889842', NULL),
	(5, 1, '2025', 'FY 2025', '2025-01-01', '2025-12-31', true, false, true, '2026-10-29 08:52:22.889844', NULL),
	(6, 1, '2026', 'FY 2026', '2026-01-01', '2026-12-31', true, false, true, '2026-10-29 08:52:22.889845', NULL),
	(7, 1, '2027', 'FY 2027', '2027-01-01', '2027-12-31', true, false, true, '2026-10-29 08:52:22.889846', NULL),
	(8, 1, '2028', 'FY 2028', '2028-01-01', '2028-12-31', true, false, true, '2026-10-29 08:52:22.889848', NULL),
	(9, 2, '2021', 'FY 2021', '2021-01-01', '2021-12-31', true, false, true, '2026-10-29 08:52:25.200594', NULL),
	(10, 2, '2022', 'FY 2022', '2022-01-01', '2022-12-31', true, false, true, '2026-10-29 08:52:25.200598', NULL),
	(11, 2, '2023', 'FY 2023', '2023-01-01', '2023-12-31', true, false, true, '2026-10-29 08:52:25.2006', NULL),
	(12, 2, '2024', 'FY 2024', '2024-01-01', '2024-12-31', true, false, true, '2026-10-29 08:52:25.200601', NULL),
	(13, 2, '2025', 'FY 2025', '2025-01-01', '2025-12-31', true, false, true, '2026-10-29 08:52:25.200603', NULL),
	(14, 2, '2026', 'FY 2026', '2026-01-01', '2026-12-31', true, false, true, '2026-10-29 08:52:25.200604', NULL),
	(15, 2, '2027', 'FY 2027', '2027-01-01', '2027-12-31', true, false, true, '2026-10-29 08:52:25.200605', NULL),
	(16, 2, '2028', 'FY 2028', '2028-01-01', '2028-12-31', true, false, true, '2026-10-29 08:52:25.200607', NULL),
	(17, 3, '2021', 'FY 2021', '2021-01-01', '2021-12-31', true, false, true, '2026-10-29 08:52:26.20092', NULL),
	(18, 3, '2022', 'FY 2022', '2022-01-01', '2022-12-31', true, false, true, '2026-10-29 08:52:26.200924', NULL),
	(19, 3, '2023', 'FY 2023', '2023-01-01', '2023-12-31', true, false, true, '2026-10-29 08:52:26.200926', NULL),
	(20, 3, '2024', 'FY 2024', '2024-01-01', '2024-12-31', true, false, true, '2026-10-29 08:52:26.200927', NULL),
	(21, 3, '2025', 'FY 2025', '2025-01-01', '2025-12-31', true, false, true, '2026-10-29 08:52:26.200929', NULL),
	(22, 3, '2026', 'FY 2026', '2026-01-01', '2026-12-31', true, false, true, '2026-10-29 08:52:26.20093', NULL),
	(23, 3, '2027', 'FY 2027', '2027-01-01', '2027-12-31', true, false, true, '2026-10-29 08:52:26.200931', NULL),
	(24, 3, '2028', 'FY 2028', '2028-01-01', '2028-12-31', true, false, true, '2026-10-29 08:52:26.200933', NULL),
	(25, 4, '2021', 'FY 2021', '2021-01-01', '2021-12-31', true, false, true, '2026-10-29 08:52:27.231636', NULL),
	(26, 4, '2022', 'FY 2022', '2022-01-01', '2022-12-31', true, false, true, '2026-10-29 08:52:27.231642', NULL),
	(27, 4, '2023', 'FY 2023', '2023-01-01', '2023-12-31', true, false, true, '2026-10-29 08:52:27.231645', NULL),
	(28, 4, '2024', 'FY 2024', '2024-01-01', '2024-12-31', true, false, true, '2026-10-29 08:52:27.231646', NULL),
	(29, 4, '2025', 'FY 2025', '2025-01-01', '2025-12-31', true, false, true, '2026-10-29 08:52:27.231648', NULL),
	(30, 4, '2026', 'FY 2026', '2026-01-01', '2026-12-31', true, false, true, '2026-10-29 08:52:27.23165', NULL),
	(31, 4, '2027', 'FY 2027', '2027-01-01', '2027-12-31', true, false, true, '2026-10-29 08:52:27.231651', NULL),
	(32, 4, '2028', 'FY 2028', '2028-01-01', '2028-12-31', true, false, true, '2026-10-29 08:52:27.231653', NULL);

INSERT INTO public.alembic_version VALUES
	('0015_membership_employment');

INSERT INTO public.audit_logs VALUES
	(1, 1, '2026-10-29 08:52:21.550449', NULL, NULL, 'create', 'accounting', 'Account', 1, '1', 'Account 1 created', '{"company_id": 1, "code": "1", "name": "Assets", "type": "asset", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(2, 1, '2026-10-29 08:52:21.555431', NULL, NULL, 'create', 'accounting', 'Account', 2, '1-01', 'Account 1-01 created', '{"company_id": 1, "code": "1-01", "name": "Current Assets", "type": "asset", "parent_id": 1, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/'),
	(3, 1, '2026-10-29 08:52:21.559177', NULL, NULL, 'create', 'accounting', 'Account', 3, '1-01-01', 'Account 1-01-01 created', '{"company_id": 1, "code": "1-01-01", "name": "Cash & Cash Equivalents", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true, "cash_flow_activity": "cash"}', '127.0.0.1', '/'),
	(4, 1, '2026-10-29 08:52:21.562836', NULL, NULL, 'create', 'accounting', 'Account', 4, '1-01-01-01', 'Account 1-01-01-01 created', '{"company_id": 1, "code": "1-01-01-01", "name": "Cash in Hand", "type": "asset", "parent_id": 3, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(5, 1, '2026-10-29 08:52:21.566646', NULL, NULL, 'create', 'accounting', 'Account', 5, '1-01-01-02', 'Account 1-01-01-02 created', '{"company_id": 1, "code": "1-01-01-02", "name": "Bank Accounts", "type": "asset", "parent_id": 3, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(6, 1, '2026-10-29 08:52:21.570444', NULL, NULL, 'create', 'accounting', 'Account', 6, '1-01-02', 'Account 1-01-02 created', '{"company_id": 1, "code": "1-01-02", "name": "Trade Receivables", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(7, 1, '2026-10-29 08:52:21.57421', NULL, NULL, 'create', 'accounting', 'Account', 7, '1-01-02-01', 'Account 1-01-02-01 created', '{"company_id": 1, "code": "1-01-02-01", "name": "Trade Debtors", "type": "asset", "parent_id": 6, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(8, 1, '2026-10-29 08:52:21.578197', NULL, NULL, 'create', 'accounting', 'Account', 8, '1-01-02-02', 'Account 1-01-02-02 created', '{"company_id": 1, "code": "1-01-02-02", "name": "Doubtful Receivables", "type": "asset", "parent_id": 6, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(9, 1, '2026-10-29 08:52:21.581949', NULL, NULL, 'create', 'accounting', 'Account', 9, '1-01-03', 'Account 1-01-03 created', '{"company_id": 1, "code": "1-01-03", "name": "Other Receivables", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(10, 1, '2026-10-29 08:52:21.585578', NULL, NULL, 'create', 'accounting', 'Account', 10, '1-01-03-01', 'Account 1-01-03-01 created', '{"company_id": 1, "code": "1-01-03-01", "name": "Employee Loans & Advances", "type": "asset", "parent_id": 9, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(11, 1, '2026-10-29 08:52:21.589263', NULL, NULL, 'create', 'accounting', 'Account', 11, '1-01-03-02', 'Account 1-01-03-02 created', '{"company_id": 1, "code": "1-01-03-02", "name": "Advances to Suppliers", "type": "asset", "parent_id": 9, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(12, 1, '2026-10-29 08:52:21.59297', NULL, NULL, 'create', 'accounting', 'Account', 12, '1-01-04', 'Account 1-01-04 created', '{"company_id": 1, "code": "1-01-04", "name": "Inventories", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(13, 1, '2026-10-29 08:52:21.59655', NULL, NULL, 'create', 'accounting', 'Account', 13, '1-01-04-01', 'Account 1-01-04-01 created', '{"company_id": 1, "code": "1-01-04-01", "name": "Trading Goods Stock", "type": "asset", "parent_id": 12, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(14, 1, '2026-10-29 08:52:21.60016', NULL, NULL, 'create', 'accounting', 'Account', 14, '1-01-05', 'Account 1-01-05 created', '{"company_id": 1, "code": "1-01-05", "name": "Tax Assets", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(15, 1, '2026-10-29 08:52:21.603946', NULL, NULL, 'create', 'accounting', 'Account', 15, '1-01-05-01', 'Account 1-01-05-01 created', '{"company_id": 1, "code": "1-01-05-01", "name": "Input Sales Tax", "type": "asset", "parent_id": 14, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(16, 1, '2026-10-29 08:52:21.60756', NULL, NULL, 'create', 'accounting', 'Account', 16, '1-01-05-02', 'Account 1-01-05-02 created', '{"company_id": 1, "code": "1-01-05-02", "name": "WHT Receivable", "type": "asset", "parent_id": 14, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(17, 1, '2026-10-29 08:52:21.611415', NULL, NULL, 'create', 'accounting', 'Account', 17, '1-01-06', 'Account 1-01-06 created', '{"company_id": 1, "code": "1-01-06", "name": "Prepayments & Other", "type": "asset", "parent_id": 2, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(18, 1, '2026-10-29 08:52:21.615551', NULL, NULL, 'create', 'accounting', 'Account', 18, '1-01-06-01', 'Account 1-01-06-01 created', '{"company_id": 1, "code": "1-01-06-01", "name": "Suspense & Clearing", "type": "asset", "parent_id": 17, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(19, 1, '2026-10-29 08:52:21.620281', NULL, NULL, 'create', 'accounting', 'Account', 19, '1-01-06-02', 'Account 1-01-06-02 created', '{"company_id": 1, "code": "1-01-06-02", "name": "Prepaid Expenses", "type": "asset", "parent_id": 17, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(20, 1, '2026-10-29 08:52:21.624932', NULL, NULL, 'create', 'accounting', 'Account', 20, '1-01-06-03', 'Account 1-01-06-03 created', '{"company_id": 1, "code": "1-01-06-03", "name": "Other Current Assets", "type": "asset", "parent_id": 17, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(21, 1, '2026-10-29 08:52:21.629569', NULL, NULL, 'create', 'accounting', 'Account', 21, '1-02', 'Account 1-02 created', '{"company_id": 1, "code": "1-02", "name": "Non-Current Assets", "type": "asset", "parent_id": 1, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "investing"}', '127.0.0.1', '/'),
	(22, 1, '2026-10-29 08:52:21.634281', NULL, NULL, 'create', 'accounting', 'Account', 22, '1-02-01', 'Account 1-02-01 created', '{"company_id": 1, "code": "1-02-01", "name": "Property, Plant & Equipment", "type": "asset", "parent_id": 21, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(23, 1, '2026-10-29 08:52:21.638727', NULL, NULL, 'create', 'accounting', 'Account', 23, '1-02-01-01', 'Account 1-02-01-01 created', '{"company_id": 1, "code": "1-02-01-01", "name": "Owned Assets", "type": "asset", "parent_id": 22, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(24, 1, '2026-10-29 08:52:21.643175', NULL, NULL, 'create', 'accounting', 'Account', 24, '1-02-02', 'Account 1-02-02 created', '{"company_id": 1, "code": "1-02-02", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 21, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(25, 1, '2026-10-29 08:52:21.647635', NULL, NULL, 'create', 'accounting', 'Account', 25, '1-02-02-01', 'Account 1-02-02-01 created', '{"company_id": 1, "code": "1-02-02-01", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 24, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(26, 1, '2026-10-29 08:52:21.652219', NULL, NULL, 'create', 'accounting', 'Account', 26, '1-02-03', 'Account 1-02-03 created', '{"company_id": 1, "code": "1-02-03", "name": "Intangible Assets", "type": "asset", "parent_id": 21, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(27, 1, '2026-10-29 08:52:21.656579', NULL, NULL, 'create', 'accounting', 'Account', 27, '1-02-03-01', 'Account 1-02-03-01 created', '{"company_id": 1, "code": "1-02-03-01", "name": "Intangibles", "type": "asset", "parent_id": 26, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(28, 1, '2026-10-29 08:52:21.659317', NULL, NULL, 'create', 'accounting', 'Account', 28, '2', 'Account 2 created', '{"company_id": 1, "code": "2", "name": "Liabilities", "type": "liability", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(29, 1, '2026-10-29 08:52:21.663656', NULL, NULL, 'create', 'accounting', 'Account', 29, '2-01', 'Account 2-01 created', '{"company_id": 1, "code": "2-01", "name": "Current Liabilities", "type": "liability", "parent_id": 28, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/'),
	(30, 1, '2026-10-29 08:52:21.668456', NULL, NULL, 'create', 'accounting', 'Account', 30, '2-01-01', 'Account 2-01-01 created', '{"company_id": 1, "code": "2-01-01", "name": "Trade Payables", "type": "liability", "parent_id": 29, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(31, 1, '2026-10-29 08:52:21.6727', NULL, NULL, 'create', 'accounting', 'Account', 31, '2-01-01-01', 'Account 2-01-01-01 created', '{"company_id": 1, "code": "2-01-01-01", "name": "Trade Creditors", "type": "liability", "parent_id": 30, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(32, 1, '2026-10-29 08:52:21.676575', NULL, NULL, 'create', 'accounting', 'Account', 32, '2-01-02', 'Account 2-01-02 created', '{"company_id": 1, "code": "2-01-02", "name": "Accrued & Payroll Liabilities", "type": "liability", "parent_id": 29, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(33, 1, '2026-10-29 08:52:21.681129', NULL, NULL, 'create', 'accounting', 'Account', 33, '2-01-02-01', 'Account 2-01-02-01 created', '{"company_id": 1, "code": "2-01-02-01", "name": "Employee Payables", "type": "liability", "parent_id": 32, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(34, 1, '2026-10-29 08:52:21.6849', NULL, NULL, 'create', 'accounting', 'Account', 34, '2-01-02-02', 'Account 2-01-02-02 created', '{"company_id": 1, "code": "2-01-02-02", "name": "Payroll Liabilities", "type": "liability", "parent_id": 32, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(35, 1, '2026-10-29 08:52:21.688605', NULL, NULL, 'create', 'accounting', 'Account', 35, '2-01-02-03', 'Account 2-01-02-03 created', '{"company_id": 1, "code": "2-01-02-03", "name": "Accrued Expenses", "type": "liability", "parent_id": 32, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(36, 1, '2026-10-29 08:52:21.692314', NULL, NULL, 'create', 'accounting', 'Account', 36, '2-01-03', 'Account 2-01-03 created', '{"company_id": 1, "code": "2-01-03", "name": "Tax Liabilities", "type": "liability", "parent_id": 29, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(37, 1, '2026-10-29 08:52:21.696159', NULL, NULL, 'create', 'accounting', 'Account', 37, '2-01-03-01', 'Account 2-01-03-01 created', '{"company_id": 1, "code": "2-01-03-01", "name": "Output Sales Tax", "type": "liability", "parent_id": 36, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(38, 1, '2026-10-29 08:52:21.699786', NULL, NULL, 'create', 'accounting', 'Account', 38, '2-01-03-02', 'Account 2-01-03-02 created', '{"company_id": 1, "code": "2-01-03-02", "name": "Income Tax Payable", "type": "liability", "parent_id": 36, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(39, 1, '2026-10-29 08:52:21.703688', NULL, NULL, 'create', 'accounting', 'Account', 39, '2-01-03-03', 'Account 2-01-03-03 created', '{"company_id": 1, "code": "2-01-03-03", "name": "WHT Payable", "type": "liability", "parent_id": 36, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(40, 1, '2026-10-29 08:52:21.707583', NULL, NULL, 'create', 'accounting', 'Account', 40, '2-01-03-04', 'Account 2-01-03-04 created', '{"company_id": 1, "code": "2-01-03-04", "name": "Further Tax Payable", "type": "liability", "parent_id": 36, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(41, 1, '2026-10-29 08:52:21.711532', NULL, NULL, 'create', 'accounting', 'Account', 41, '2-01-04', 'Account 2-01-04 created', '{"company_id": 1, "code": "2-01-04", "name": "Advances from Customers", "type": "liability", "parent_id": 29, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(42, 1, '2026-10-29 08:52:21.716163', NULL, NULL, 'create', 'accounting', 'Account', 42, '2-01-04-01', 'Account 2-01-04-01 created', '{"company_id": 1, "code": "2-01-04-01", "name": "Customer Advances", "type": "liability", "parent_id": 41, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(43, 1, '2026-10-29 08:52:21.721073', NULL, NULL, 'create', 'accounting', 'Account', 43, '2-02', 'Account 2-02 created', '{"company_id": 1, "code": "2-02", "name": "Non-Current Liabilities", "type": "liability", "parent_id": 28, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/'),
	(44, 1, '2026-10-29 08:52:21.724938', NULL, NULL, 'create', 'accounting', 'Account', 44, '2-02-01', 'Account 2-02-01 created', '{"company_id": 1, "code": "2-02-01", "name": "Long-term Loans", "type": "liability", "parent_id": 43, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(45, 1, '2026-10-29 08:52:21.728638', NULL, NULL, 'create', 'accounting', 'Account', 45, '2-02-01-01', 'Account 2-02-01-01 created', '{"company_id": 1, "code": "2-02-01-01", "name": "Long-term Loans", "type": "liability", "parent_id": 44, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(46, 1, '2026-10-29 08:52:21.73228', NULL, NULL, 'create', 'accounting', 'Account', 46, '2-02-02', 'Account 2-02-02 created', '{"company_id": 1, "code": "2-02-02", "name": "Employee End-of-Service Benefits", "type": "liability", "parent_id": 43, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(47, 1, '2026-10-29 08:52:21.737271', NULL, NULL, 'create', 'accounting', 'Account', 47, '2-02-02-01', 'Account 2-02-02-01 created', '{"company_id": 1, "code": "2-02-02-01", "name": "EOSB Provision", "type": "liability", "parent_id": 46, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(48, 1, '2026-10-29 08:52:21.739805', NULL, NULL, 'create', 'accounting', 'Account', 48, '3', 'Account 3 created', '{"company_id": 1, "code": "3", "name": "Equity", "type": "equity", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/'),
	(49, 1, '2026-10-29 08:52:21.743695', NULL, NULL, 'create', 'accounting', 'Account', 49, '3-01', 'Account 3-01 created', '{"company_id": 1, "code": "3-01", "name": "Capital", "type": "equity", "parent_id": 48, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(50, 1, '2026-10-29 08:52:21.747386', NULL, NULL, 'create', 'accounting', 'Account', 50, '3-01-01', 'Account 3-01-01 created', '{"company_id": 1, "code": "3-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 49, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(51, 1, '2026-10-29 08:52:21.751182', NULL, NULL, 'create', 'accounting', 'Account', 51, '3-01-01-01', 'Account 3-01-01-01 created', '{"company_id": 1, "code": "3-01-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 50, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(52, 1, '2026-10-29 08:52:21.754923', NULL, NULL, 'create', 'accounting', 'Account', 52, '3-02', 'Account 3-02 created', '{"company_id": 1, "code": "3-02", "name": "Reserves & Retained Earnings", "type": "equity", "parent_id": 48, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(53, 1, '2026-10-29 08:52:21.758616', NULL, NULL, 'create', 'accounting', 'Account', 53, '3-02-01', 'Account 3-02-01 created', '{"company_id": 1, "code": "3-02-01", "name": "Retained Earnings", "type": "equity", "parent_id": 52, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(54, 1, '2026-10-29 08:52:21.762357', NULL, NULL, 'create', 'accounting', 'Account', 54, '3-02-01-01', 'Account 3-02-01-01 created', '{"company_id": 1, "code": "3-02-01-01", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 53, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(55, 1, '2026-10-29 08:52:21.766204', NULL, NULL, 'create', 'accounting', 'Account', 55, '3-02-01-02', 'Account 3-02-01-02 created', '{"company_id": 1, "code": "3-02-01-02", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 53, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(56, 1, '2026-10-29 08:52:21.769895', NULL, NULL, 'create', 'accounting', 'Account', 56, '3-02-02', 'Account 3-02-02 created', '{"company_id": 1, "code": "3-02-02", "name": "Dividends", "type": "equity", "parent_id": 52, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(57, 1, '2026-10-29 08:52:21.773677', NULL, NULL, 'create', 'accounting', 'Account', 57, '3-02-02-01', 'Account 3-02-02-01 created', '{"company_id": 1, "code": "3-02-02-01", "name": "Dividends", "type": "equity", "parent_id": 56, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(58, 1, '2026-10-29 08:52:21.777489', NULL, NULL, 'create', 'accounting', 'Account', 58, '3-02-03', 'Account 3-02-03 created', '{"company_id": 1, "code": "3-02-03", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 52, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(59, 1, '2026-10-29 08:52:21.781309', NULL, NULL, 'create', 'accounting', 'Account', 59, '3-02-03-01', 'Account 3-02-03-01 created', '{"company_id": 1, "code": "3-02-03-01", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 58, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(60, 1, '2026-10-29 08:52:21.783764', NULL, NULL, 'create', 'accounting', 'Account', 60, '4', 'Account 4 created', '{"company_id": 1, "code": "4", "name": "Revenue", "type": "revenue", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/'),
	(61, 1, '2026-10-29 08:52:21.787432', NULL, NULL, 'create', 'accounting', 'Account', 61, '4-01', 'Account 4-01 created', '{"company_id": 1, "code": "4-01", "name": "Sales", "type": "revenue", "parent_id": 60, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales"}', '127.0.0.1', '/'),
	(62, 1, '2026-10-29 08:52:21.79148', NULL, NULL, 'create', 'accounting', 'Account', 62, '4-01-01', 'Account 4-01-01 created', '{"company_id": 1, "code": "4-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 61, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(63, 1, '2026-10-29 08:52:21.795167', NULL, NULL, 'create', 'accounting', 'Account', 63, '4-01-01-01', 'Account 4-01-01-01 created', '{"company_id": 1, "code": "4-01-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 62, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(64, 1, '2026-10-29 08:52:21.798864', NULL, NULL, 'create', 'accounting', 'Account', 64, '4-01-02', 'Account 4-01-02 created', '{"company_id": 1, "code": "4-01-02", "name": "Service Income", "type": "revenue", "parent_id": 61, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(65, 1, '2026-10-29 08:52:21.802498', NULL, NULL, 'create', 'accounting', 'Account', 65, '4-01-02-01', 'Account 4-01-02-01 created', '{"company_id": 1, "code": "4-01-02-01", "name": "Service Income", "type": "revenue", "parent_id": 64, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(66, 1, '2026-10-29 08:52:21.806261', NULL, NULL, 'create', 'accounting', 'Account', 66, '4-02', 'Account 4-02 created', '{"company_id": 1, "code": "4-02", "name": "Sales Returns & Discounts", "type": "revenue", "parent_id": 60, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales_returns"}', '127.0.0.1', '/'),
	(67, 1, '2026-10-29 08:52:21.809958', NULL, NULL, 'create', 'accounting', 'Account', 67, '4-02-01', 'Account 4-02-01 created', '{"company_id": 1, "code": "4-02-01", "name": "Sales Returns", "type": "revenue", "parent_id": 66, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(68, 1, '2026-10-29 08:52:21.813657', NULL, NULL, 'create', 'accounting', 'Account', 68, '4-02-01-01', 'Account 4-02-01-01 created', '{"company_id": 1, "code": "4-02-01-01", "name": "Sales Returns", "type": "revenue", "parent_id": 67, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(69, 1, '2026-10-29 08:52:21.817512', NULL, NULL, 'create', 'accounting', 'Account', 69, '4-02-02', 'Account 4-02-02 created', '{"company_id": 1, "code": "4-02-02", "name": "Discounts Allowed", "type": "revenue", "parent_id": 66, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(70, 1, '2026-10-29 08:52:21.821203', NULL, NULL, 'create', 'accounting', 'Account', 70, '4-02-02-01', 'Account 4-02-02-01 created', '{"company_id": 1, "code": "4-02-02-01", "name": "Discounts Allowed", "type": "revenue", "parent_id": 69, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(71, 1, '2026-10-29 08:52:21.824908', NULL, NULL, 'create', 'accounting', 'Account', 71, '4-03', 'Account 4-03 created', '{"company_id": 1, "code": "4-03", "name": "Other Income", "type": "revenue", "parent_id": 60, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_income"}', '127.0.0.1', '/'),
	(72, 1, '2026-10-29 08:52:21.828703', NULL, NULL, 'create', 'accounting', 'Account', 72, '4-03-01', 'Account 4-03-01 created', '{"company_id": 1, "code": "4-03-01", "name": "Other Income", "type": "revenue", "parent_id": 71, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(73, 1, '2026-10-29 08:52:21.83255', NULL, NULL, 'create', 'accounting', 'Account', 73, '4-03-01-01', 'Account 4-03-01-01 created', '{"company_id": 1, "code": "4-03-01-01", "name": "Other Income", "type": "revenue", "parent_id": 72, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(74, 1, '2026-10-29 08:52:21.834958', NULL, NULL, 'create', 'accounting', 'Account', 74, '5', 'Account 5 created', '{"company_id": 1, "code": "5", "name": "Expenses", "type": "expense", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/'),
	(75, 1, '2026-10-29 08:52:21.838727', NULL, NULL, 'create', 'accounting', 'Account', 75, '5-01', 'Account 5-01 created', '{"company_id": 1, "code": "5-01", "name": "Cost of Sales", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "cost_of_sales"}', '127.0.0.1', '/'),
	(76, 1, '2026-10-29 08:52:21.842508', NULL, NULL, 'create', 'accounting', 'Account', 76, '5-01-01', 'Account 5-01-01 created', '{"company_id": 1, "code": "5-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 75, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(77, 1, '2026-10-29 08:52:21.846684', NULL, NULL, 'create', 'accounting', 'Account', 77, '5-01-01-01', 'Account 5-01-01-01 created', '{"company_id": 1, "code": "5-01-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 76, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(78, 1, '2026-10-29 08:52:21.850248', NULL, NULL, 'create', 'accounting', 'Account', 78, '5-01-02', 'Account 5-01-02 created', '{"company_id": 1, "code": "5-01-02", "name": "Stock Losses, Scrap & Adjustments", "type": "expense", "parent_id": 75, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(79, 1, '2026-10-29 08:52:21.854071', NULL, NULL, 'create', 'accounting', 'Account', 79, '5-01-02-01', 'Account 5-01-02-01 created', '{"company_id": 1, "code": "5-01-02-01", "name": "Stock Losses & Scrap", "type": "expense", "parent_id": 78, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(80, 1, '2026-10-29 08:52:21.857988', NULL, NULL, 'create', 'accounting', 'Account', 80, '5-02', 'Account 5-02 created', '{"company_id": 1, "code": "5-02", "name": "Administrative Expenses", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "admin"}', '127.0.0.1', '/'),
	(81, 1, '2026-10-29 08:52:21.861693', NULL, NULL, 'create', 'accounting', 'Account', 81, '5-02-01', 'Account 5-02-01 created', '{"company_id": 1, "code": "5-02-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 80, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(82, 1, '2026-10-29 08:52:21.866077', NULL, NULL, 'create', 'accounting', 'Account', 82, '5-02-01-01', 'Account 5-02-01-01 created', '{"company_id": 1, "code": "5-02-01-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 81, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(83, 1, '2026-10-29 08:52:21.869847', NULL, NULL, 'create', 'accounting', 'Account', 83, '5-02-02', 'Account 5-02-02 created', '{"company_id": 1, "code": "5-02-02", "name": "Rent & Utilities", "type": "expense", "parent_id": 80, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(84, 1, '2026-10-29 08:52:21.873644', NULL, NULL, 'create', 'accounting', 'Account', 84, '5-02-02-01', 'Account 5-02-02-01 created', '{"company_id": 1, "code": "5-02-02-01", "name": "Rent & Utilities", "type": "expense", "parent_id": 83, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(85, 1, '2026-10-29 08:52:21.877285', NULL, NULL, 'create', 'accounting', 'Account', 85, '5-02-03', 'Account 5-02-03 created', '{"company_id": 1, "code": "5-02-03", "name": "Office & Supplies", "type": "expense", "parent_id": 80, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(86, 1, '2026-10-29 08:52:21.881212', NULL, NULL, 'create', 'accounting', 'Account', 86, '5-02-03-01', 'Account 5-02-03-01 created', '{"company_id": 1, "code": "5-02-03-01", "name": "Office & Supplies", "type": "expense", "parent_id": 85, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(87, 1, '2026-10-29 08:52:21.885522', NULL, NULL, 'create', 'accounting', 'Account', 87, '5-02-04', 'Account 5-02-04 created', '{"company_id": 1, "code": "5-02-04", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 80, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(88, 1, '2026-10-29 08:52:21.889055', NULL, NULL, 'create', 'accounting', 'Account', 88, '5-02-04-01', 'Account 5-02-04-01 created', '{"company_id": 1, "code": "5-02-04-01", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 87, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(89, 1, '2026-10-29 08:52:21.892593', NULL, NULL, 'create', 'accounting', 'Account', 89, '5-02-05', 'Account 5-02-05 created', '{"company_id": 1, "code": "5-02-05", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 80, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(90, 1, '2026-10-29 08:52:21.896154', NULL, NULL, 'create', 'accounting', 'Account', 90, '5-02-05-01', 'Account 5-02-05-01 created', '{"company_id": 1, "code": "5-02-05-01", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 89, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(91, 1, '2026-10-29 08:52:21.899815', NULL, NULL, 'create', 'accounting', 'Account', 91, '5-03', 'Account 5-03 created', '{"company_id": 1, "code": "5-03", "name": "Selling & Distribution", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "selling_distribution"}', '127.0.0.1', '/'),
	(92, 1, '2026-10-29 08:52:21.903425', NULL, NULL, 'create', 'accounting', 'Account', 92, '5-03-01', 'Account 5-03-01 created', '{"company_id": 1, "code": "5-03-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 91, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(93, 1, '2026-10-29 08:52:21.907131', NULL, NULL, 'create', 'accounting', 'Account', 93, '5-03-01-01', 'Account 5-03-01-01 created', '{"company_id": 1, "code": "5-03-01-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 92, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(94, 1, '2026-10-29 08:52:21.91106', NULL, NULL, 'create', 'accounting', 'Account', 94, '5-03-02', 'Account 5-03-02 created', '{"company_id": 1, "code": "5-03-02", "name": "Commissions", "type": "expense", "parent_id": 91, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(95, 1, '2026-10-29 08:52:21.914775', NULL, NULL, 'create', 'accounting', 'Account', 95, '5-03-02-01', 'Account 5-03-02-01 created', '{"company_id": 1, "code": "5-03-02-01", "name": "Commissions", "type": "expense", "parent_id": 94, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(96, 1, '2026-10-29 08:52:21.91855', NULL, NULL, 'create', 'accounting', 'Account', 96, '5-03-03', 'Account 5-03-03 created', '{"company_id": 1, "code": "5-03-03", "name": "Marketing & Advertising", "type": "expense", "parent_id": 91, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(97, 1, '2026-10-29 08:52:21.922332', NULL, NULL, 'create', 'accounting', 'Account', 97, '5-03-03-01', 'Account 5-03-03-01 created', '{"company_id": 1, "code": "5-03-03-01", "name": "Marketing & Advertising", "type": "expense", "parent_id": 96, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(98, 1, '2026-10-29 08:52:21.92624', NULL, NULL, 'create', 'accounting', 'Account', 98, '5-04', 'Account 5-04 created', '{"company_id": 1, "code": "5-04", "name": "Other Operating Expenses", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_operating"}', '127.0.0.1', '/'),
	(99, 1, '2026-10-29 08:52:21.930012', NULL, NULL, 'create', 'accounting', 'Account', 99, '5-04-01', 'Account 5-04-01 created', '{"company_id": 1, "code": "5-04-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 98, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(100, 1, '2026-10-29 08:52:21.933789', NULL, NULL, 'create', 'accounting', 'Account', 100, '5-04-01-01', 'Account 5-04-01-01 created', '{"company_id": 1, "code": "5-04-01-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 99, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(101, 1, '2026-10-29 08:52:21.937698', NULL, NULL, 'create', 'accounting', 'Account', 101, '5-05', 'Account 5-05 created', '{"company_id": 1, "code": "5-05", "name": "Finance Costs", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "finance_cost"}', '127.0.0.1', '/'),
	(102, 1, '2026-10-29 08:52:21.941407', NULL, NULL, 'create', 'accounting', 'Account', 102, '5-05-01', 'Account 5-05-01 created', '{"company_id": 1, "code": "5-05-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 101, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(103, 1, '2026-10-29 08:52:21.945253', NULL, NULL, 'create', 'accounting', 'Account', 103, '5-05-01-01', 'Account 5-05-01-01 created', '{"company_id": 1, "code": "5-05-01-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 102, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(104, 1, '2026-10-29 08:52:21.949184', NULL, NULL, 'create', 'accounting', 'Account', 104, '5-06', 'Account 5-06 created', '{"company_id": 1, "code": "5-06", "name": "Taxation", "type": "expense", "parent_id": 74, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "income_tax"}', '127.0.0.1', '/'),
	(105, 1, '2026-10-29 08:52:21.953213', NULL, NULL, 'create', 'accounting', 'Account', 105, '5-06-01', 'Account 5-06-01 created', '{"company_id": 1, "code": "5-06-01", "name": "Income Tax", "type": "expense", "parent_id": 104, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(106, 1, '2026-10-29 08:52:21.95719', NULL, NULL, 'create', 'accounting', 'Account', 106, '5-06-01-01', 'Account 5-06-01-01 created', '{"company_id": 1, "code": "5-06-01-01", "name": "Income Tax", "type": "expense", "parent_id": 105, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/'),
	(107, 1, '2026-10-29 08:52:21.963571', NULL, NULL, 'create', 'accounting', 'Account', 107, '1-01-01-01-0001', 'Account 1-01-01-01-0001 created', '{"company_id": 1, "code": "1-01-01-01-0001", "name": "Main Cash", "type": "asset", "parent_id": 4, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(108, 1, '2026-10-29 08:52:21.967405', NULL, NULL, 'create', 'accounting', 'Account', 108, '1-01-02-01-0001', 'Account 1-01-02-01-0001 created', '{"company_id": 1, "code": "1-01-02-01-0001", "name": "Trade Debtors \u2014 General", "type": "asset", "parent_id": 7, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(109, 1, '2026-10-29 08:52:21.971344', NULL, NULL, 'create', 'accounting', 'Account', 109, '1-01-03-02-0001', 'Account 1-01-03-02-0001 created', '{"company_id": 1, "code": "1-01-03-02-0001", "name": "Advances to Suppliers \u2014 General", "type": "asset", "parent_id": 11, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(110, 1, '2026-10-29 08:52:21.975161', NULL, NULL, 'create', 'accounting', 'Account', 110, '1-01-04-01-0001', 'Account 1-01-04-01-0001 created', '{"company_id": 1, "code": "1-01-04-01-0001", "name": "Stock \u2014 General", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(111, 1, '2026-10-29 08:52:21.979094', NULL, NULL, 'create', 'accounting', 'Account', 111, '1-01-05-01-0001', 'Account 1-01-05-01-0001 created', '{"company_id": 1, "code": "1-01-05-01-0001", "name": "Input Sales Tax", "type": "asset", "parent_id": 15, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(112, 1, '2026-10-29 08:52:21.982689', NULL, NULL, 'create', 'accounting', 'Account', 112, '1-01-05-02-0001', 'Account 1-01-05-02-0001 created', '{"company_id": 1, "code": "1-01-05-02-0001", "name": "WHT Receivable", "type": "asset", "parent_id": 16, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(113, 1, '2026-10-29 08:52:21.987792', NULL, NULL, 'create', 'accounting', 'Account', 113, '1-01-06-01-0001', 'Account 1-01-06-01-0001 created', '{"company_id": 1, "code": "1-01-06-01-0001", "name": "Suspense Account", "type": "asset", "parent_id": 18, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(114, 1, '2026-10-29 08:52:21.99152', NULL, NULL, 'create', 'accounting', 'Account', 114, '1-01-06-02-0001', 'Account 1-01-06-02-0001 created', '{"company_id": 1, "code": "1-01-06-02-0001", "name": "Prepaid Expenses \u2014 General", "type": "asset", "parent_id": 19, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(115, 1, '2026-10-29 08:52:21.995332', NULL, NULL, 'create', 'accounting', 'Account', 115, '1-02-01-01-0001', 'Account 1-02-01-01-0001 created', '{"company_id": 1, "code": "1-02-01-01-0001", "name": "Fixed Assets \u2014 General", "type": "asset", "parent_id": 23, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(116, 1, '2026-10-29 08:52:21.999222', NULL, NULL, 'create', 'accounting', 'Account', 116, '1-02-02-01-0001', 'Account 1-02-02-01-0001 created', '{"company_id": 1, "code": "1-02-02-01-0001", "name": "Accumulated Depreciation \u2014 General", "type": "asset", "parent_id": 25, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(117, 1, '2026-10-29 08:52:22.003425', NULL, NULL, 'create', 'accounting', 'Account', 117, '1-02-03-01-0001', 'Account 1-02-03-01-0001 created', '{"company_id": 1, "code": "1-02-03-01-0001", "name": "Intangibles \u2014 General", "type": "asset", "parent_id": 27, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(118, 1, '2026-10-29 08:52:22.007184', NULL, NULL, 'create', 'accounting', 'Account', 118, '2-01-01-01-0001', 'Account 2-01-01-01-0001 created', '{"company_id": 1, "code": "2-01-01-01-0001", "name": "Trade Creditors \u2014 General", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(119, 1, '2026-10-29 08:52:22.01203', NULL, NULL, 'create', 'accounting', 'Account', 119, '2-01-02-02-0001', 'Account 2-01-02-02-0001 created', '{"company_id": 1, "code": "2-01-02-02-0001", "name": "Salary Payable", "type": "liability", "parent_id": 34, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(120, 1, '2026-10-29 08:52:22.019295', NULL, NULL, 'create', 'accounting', 'Account', 120, '2-01-02-02-0002', 'Account 2-01-02-02-0002 created', '{"company_id": 1, "code": "2-01-02-02-0002", "name": "PF Payable", "type": "liability", "parent_id": 34, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(121, 1, '2026-10-29 08:52:22.024017', NULL, NULL, 'create', 'accounting', 'Account', 121, '2-01-02-02-0003', 'Account 2-01-02-02-0003 created', '{"company_id": 1, "code": "2-01-02-02-0003", "name": "Loan Deductions Clearing", "type": "liability", "parent_id": 34, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(122, 1, '2026-10-29 08:52:22.02817', NULL, NULL, 'create', 'accounting', 'Account', 122, '2-01-02-02-0004', 'Account 2-01-02-02-0004 created', '{"company_id": 1, "code": "2-01-02-02-0004", "name": "Other Payroll Deductions Payable", "type": "liability", "parent_id": 34, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(123, 1, '2026-10-29 08:52:22.032803', NULL, NULL, 'create', 'accounting', 'Account', 123, '2-01-02-03-0001', 'Account 2-01-02-03-0001 created', '{"company_id": 1, "code": "2-01-02-03-0001", "name": "Accrued Expenses \u2014 General", "type": "liability", "parent_id": 35, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(124, 1, '2026-10-29 08:52:22.03812', NULL, NULL, 'create', 'accounting', 'Account', 124, '2-01-03-01-0001', 'Account 2-01-03-01-0001 created', '{"company_id": 1, "code": "2-01-03-01-0001", "name": "Output Sales Tax", "type": "liability", "parent_id": 37, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(125, 1, '2026-10-29 08:52:22.043125', NULL, NULL, 'create', 'accounting', 'Account', 125, '2-01-03-02-0001', 'Account 2-01-03-02-0001 created', '{"company_id": 1, "code": "2-01-03-02-0001", "name": "Income Tax Payable", "type": "liability", "parent_id": 38, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(126, 1, '2026-10-29 08:52:22.048409', NULL, NULL, 'create', 'accounting', 'Account', 126, '2-01-03-03-0001', 'Account 2-01-03-03-0001 created', '{"company_id": 1, "code": "2-01-03-03-0001", "name": "WHT Payable", "type": "liability", "parent_id": 39, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(127, 1, '2026-10-29 08:52:22.05374', NULL, NULL, 'create', 'accounting', 'Account', 127, '2-01-03-04-0001', 'Account 2-01-03-04-0001 created', '{"company_id": 1, "code": "2-01-03-04-0001", "name": "Further Tax Payable", "type": "liability", "parent_id": 40, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(128, 1, '2026-10-29 08:52:22.059113', NULL, NULL, 'create', 'accounting', 'Account', 128, '2-01-04-01-0001', 'Account 2-01-04-01-0001 created', '{"company_id": 1, "code": "2-01-04-01-0001", "name": "Customer Advances \u2014 General", "type": "liability", "parent_id": 42, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(129, 1, '2026-10-29 08:52:22.064195', NULL, NULL, 'create', 'accounting', 'Account', 129, '2-02-01-01-0001', 'Account 2-02-01-01-0001 created', '{"company_id": 1, "code": "2-02-01-01-0001", "name": "Long-term Loans \u2014 General", "type": "liability", "parent_id": 45, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(130, 1, '2026-10-29 08:52:22.069567', NULL, NULL, 'create', 'accounting', 'Account', 130, '2-02-02-01-0001', 'Account 2-02-02-01-0001 created', '{"company_id": 1, "code": "2-02-02-01-0001", "name": "EOSB Provision \u2014 General", "type": "liability", "parent_id": 47, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(131, 1, '2026-10-29 08:52:22.075242', NULL, NULL, 'create', 'accounting', 'Account', 131, '3-01-01-01-0001', 'Account 3-01-01-01-0001 created', '{"company_id": 1, "code": "3-01-01-01-0001", "name": "Share Capital", "type": "equity", "parent_id": 51, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(132, 1, '2026-10-29 08:52:22.080992', NULL, NULL, 'create', 'accounting', 'Account', 132, '3-01-01-01-0002', 'Account 3-01-01-01-0002 created', '{"company_id": 1, "code": "3-01-01-01-0002", "name": "Suspense Equity", "type": "equity", "parent_id": 51, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(133, 1, '2026-10-29 08:52:22.087618', NULL, NULL, 'create', 'accounting', 'Account', 133, '3-02-01-01-0001', 'Account 3-02-01-01-0001 created', '{"company_id": 1, "code": "3-02-01-01-0001", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 54, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(134, 1, '2026-10-29 08:52:22.093947', NULL, NULL, 'create', 'accounting', 'Account', 134, '3-02-01-02-0001', 'Account 3-02-01-02-0001 created', '{"company_id": 1, "code": "3-02-01-02-0001", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 55, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(135, 1, '2026-10-29 08:52:22.100092', NULL, NULL, 'create', 'accounting', 'Account', 135, '3-02-02-01-0001', 'Account 3-02-02-01-0001 created', '{"company_id": 1, "code": "3-02-02-01-0001", "name": "Dividends", "type": "equity", "parent_id": 57, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(136, 1, '2026-10-29 08:52:22.106072', NULL, NULL, 'create', 'accounting', 'Account', 136, '3-02-03-01-0001', 'Account 3-02-03-01-0001 created', '{"company_id": 1, "code": "3-02-03-01-0001", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 59, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(137, 1, '2026-10-29 08:52:22.112206', NULL, NULL, 'create', 'accounting', 'Account', 137, '4-01-01-01-0001', 'Account 4-01-01-01-0001 created', '{"company_id": 1, "code": "4-01-01-01-0001", "name": "Sales \u2014 General", "type": "revenue", "parent_id": 63, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(138, 1, '2026-10-29 08:52:22.118071', NULL, NULL, 'create', 'accounting', 'Account', 138, '4-01-02-01-0001', 'Account 4-01-02-01-0001 created', '{"company_id": 1, "code": "4-01-02-01-0001", "name": "Service Income \u2014 General", "type": "revenue", "parent_id": 65, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(139, 1, '2026-10-29 08:52:22.123843', NULL, NULL, 'create', 'accounting', 'Account', 139, '4-02-01-01-0001', 'Account 4-02-01-01-0001 created', '{"company_id": 1, "code": "4-02-01-01-0001", "name": "Sales Returns \u2014 General", "type": "revenue", "parent_id": 68, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(140, 1, '2026-10-29 08:52:22.129433', NULL, NULL, 'create', 'accounting', 'Account', 140, '4-02-02-01-0001', 'Account 4-02-02-01-0001 created', '{"company_id": 1, "code": "4-02-02-01-0001", "name": "Discounts Allowed \u2014 General", "type": "revenue", "parent_id": 70, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(141, 1, '2026-10-29 08:52:22.135106', NULL, NULL, 'create', 'accounting', 'Account', 141, '4-03-01-01-0001', 'Account 4-03-01-01-0001 created', '{"company_id": 1, "code": "4-03-01-01-0001", "name": "Other Income \u2014 General", "type": "revenue", "parent_id": 73, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(142, 1, '2026-10-29 08:52:22.140143', NULL, NULL, 'create', 'accounting', 'Account', 142, '5-01-01-01-0001', 'Account 5-01-01-01-0001 created', '{"company_id": 1, "code": "5-01-01-01-0001", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 77, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(143, 1, '2026-10-29 08:52:22.144871', NULL, NULL, 'create', 'accounting', 'Account', 143, '5-01-02-01-0001', 'Account 5-01-02-01-0001 created', '{"company_id": 1, "code": "5-01-02-01-0001", "name": "Scrap / Write-off", "type": "expense", "parent_id": 79, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(144, 1, '2026-10-29 08:52:22.149766', NULL, NULL, 'create', 'accounting', 'Account', 144, '5-01-02-01-0002', 'Account 5-01-02-01-0002 created', '{"company_id": 1, "code": "5-01-02-01-0002", "name": "Inventory Adjustment", "type": "expense", "parent_id": 79, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(145, 1, '2026-10-29 08:52:22.154584', NULL, NULL, 'create', 'accounting', 'Account', 145, '5-01-02-01-0003', 'Account 5-01-02-01-0003 created', '{"company_id": 1, "code": "5-01-02-01-0003", "name": "Consumption Expense", "type": "expense", "parent_id": 79, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(146, 1, '2026-10-29 08:52:22.159331', NULL, NULL, 'create', 'accounting', 'Account', 146, '5-01-02-01-0004', 'Account 5-01-02-01-0004 created', '{"company_id": 1, "code": "5-01-02-01-0004", "name": "Inventory Cost Variance", "type": "expense", "parent_id": 79, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(147, 1, '2026-10-29 08:52:22.16396', NULL, NULL, 'create', 'accounting', 'Account', 147, '5-02-01-01-0001', 'Account 5-02-01-01-0001 created', '{"company_id": 1, "code": "5-02-01-01-0001", "name": "Salary Expense", "type": "expense", "parent_id": 82, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(148, 1, '2026-10-29 08:52:22.168717', NULL, NULL, 'create', 'accounting', 'Account', 148, '5-02-01-01-0002', 'Account 5-02-01-01-0002 created', '{"company_id": 1, "code": "5-02-01-01-0002", "name": "PF Employer Expense", "type": "expense", "parent_id": 82, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(149, 1, '2026-10-29 08:52:22.173293', NULL, NULL, 'create', 'accounting', 'Account', 149, '5-02-02-01-0001', 'Account 5-02-02-01-0001 created', '{"company_id": 1, "code": "5-02-02-01-0001", "name": "Rent Expense", "type": "expense", "parent_id": 84, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(150, 1, '2026-10-29 08:52:22.177891', NULL, NULL, 'create', 'accounting', 'Account', 150, '5-02-02-01-0002', 'Account 5-02-02-01-0002 created', '{"company_id": 1, "code": "5-02-02-01-0002", "name": "Utilities Expense", "type": "expense", "parent_id": 84, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(151, 1, '2026-10-29 08:52:22.182584', NULL, NULL, 'create', 'accounting', 'Account', 151, '5-02-03-01-0001', 'Account 5-02-03-01-0001 created', '{"company_id": 1, "code": "5-02-03-01-0001", "name": "Office Supplies", "type": "expense", "parent_id": 86, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(152, 1, '2026-10-29 08:52:22.187053', NULL, NULL, 'create', 'accounting', 'Account', 152, '5-02-04-01-0001', 'Account 5-02-04-01-0001 created', '{"company_id": 1, "code": "5-02-04-01-0001", "name": "Depreciation Expense", "type": "expense", "parent_id": 88, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(153, 1, '2026-10-29 08:52:22.191534', NULL, NULL, 'create', 'accounting', 'Account', 153, '5-02-05-01-0001', 'Account 5-02-05-01-0001 created', '{"company_id": 1, "code": "5-02-05-01-0001", "name": "Fees, Taxes & Licenses \u2014 General", "type": "expense", "parent_id": 90, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(154, 1, '2026-10-29 08:52:22.195903', NULL, NULL, 'create', 'accounting', 'Account', 154, '5-03-01-01-0001', 'Account 5-03-01-01-0001 created', '{"company_id": 1, "code": "5-03-01-01-0001", "name": "Freight & Transportation \u2014 General", "type": "expense", "parent_id": 93, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(155, 1, '2026-10-29 08:52:22.200014', NULL, NULL, 'create', 'accounting', 'Account', 155, '5-03-02-01-0001', 'Account 5-03-02-01-0001 created', '{"company_id": 1, "code": "5-03-02-01-0001", "name": "Commissions \u2014 General", "type": "expense", "parent_id": 95, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(156, 1, '2026-10-29 08:52:22.203942', NULL, NULL, 'create', 'accounting', 'Account', 156, '5-03-03-01-0001', 'Account 5-03-03-01-0001 created', '{"company_id": 1, "code": "5-03-03-01-0001", "name": "Marketing & Advertising \u2014 General", "type": "expense", "parent_id": 97, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(157, 1, '2026-10-29 08:52:22.207798', NULL, NULL, 'create', 'accounting', 'Account', 157, '5-04-01-01-0001', 'Account 5-04-01-01-0001 created', '{"company_id": 1, "code": "5-04-01-01-0001", "name": "Other Expenses \u2014 General", "type": "expense", "parent_id": 100, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(158, 1, '2026-10-29 08:52:22.211802', NULL, NULL, 'create', 'accounting', 'Account', 158, '5-04-01-01-0002', 'Account 5-04-01-01-0002 created', '{"company_id": 1, "code": "5-04-01-01-0002", "name": "Loss/(Gain) on Disposal of Fixed Assets", "type": "expense", "parent_id": 100, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(159, 1, '2026-10-29 08:52:22.215556', NULL, NULL, 'create', 'accounting', 'Account', 159, '5-05-01-01-0001', 'Account 5-05-01-01-0001 created', '{"company_id": 1, "code": "5-05-01-01-0001", "name": "Bank Charges", "type": "expense", "parent_id": 103, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(160, 1, '2026-10-29 08:52:22.219541', NULL, NULL, 'create', 'accounting', 'Account', 160, '5-05-01-01-0002', 'Account 5-05-01-01-0002 created', '{"company_id": 1, "code": "5-05-01-01-0002", "name": "Interest Expense", "type": "expense", "parent_id": 103, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(161, 1, '2026-10-29 08:52:22.222409', NULL, NULL, 'create', 'accounting', 'Account', 161, '5-06-01-01-0001', 'Account 5-06-01-01-0001 created', '{"company_id": 1, "code": "5-06-01-01-0001", "name": "Income Tax Expense", "type": "expense", "parent_id": 106, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(162, 1, '2026-10-29 08:52:22.411735', NULL, NULL, 'create', 'admin', 'User', 1, 'admin@gmail.com', 'User admin@gmail.com created', '{"employee_code": "SYSADMIN", "email": "admin@gmail.com", "password_hash": "\u2022\u2022\u2022", "full_name": "Administrator", "role_id": 1, "designation": "System Administrator", "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true, "has_inventory_access": true}', '127.0.0.1', '/'),
	(163, 1, '2026-10-29 08:52:22.493719', NULL, NULL, 'create', 'admin', 'User', 2, 'admin@solarkon.com', 'User admin@solarkon.com created', '{"employee_code": "ADM001", "email": "admin@solarkon.com", "password_hash": "\u2022\u2022\u2022", "full_name": "System Admin", "role_id": 3, "designation": "Employee", "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true}', '127.0.0.1', '/'),
	(164, 1, '2026-10-29 08:52:22.590323', NULL, NULL, 'create', 'admin', 'User', 3, 'manager@solarkon.com', 'User manager@solarkon.com created', '{"employee_code": "MGR002", "email": "manager@solarkon.com", "password_hash": "\u2022\u2022\u2022", "full_name": "Manager User", "role_id": 2, "designation": "Manager", "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true, "has_inventory_access": true}', '127.0.0.1', '/'),
	(165, 1, '2026-10-29 08:52:22.685265', NULL, NULL, 'create', 'admin', 'User', 4, 'emp@solarkon.com', 'User emp@solarkon.com created', '{"employee_code": "EMP001", "email": "emp@solarkon.com", "password_hash": "\u2022\u2022\u2022", "full_name": "Employee User", "role_id": 3, "designation": "Employee", "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true}', '127.0.0.1', '/'),
	(166, 1, '2026-10-29 08:52:22.695292', NULL, NULL, 'create', 'admin', 'User', 5, 'john.doe@solarkon.com', 'User john.doe@solarkon.com created', '{"employee_code": "EMP002", "email": "john.doe@solarkon.com", "password_hash": "\u2022\u2022\u2022", "full_name": "John Doe", "role_id": 3, "designation": "Employee", "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true}', '127.0.0.1', '/'),
	(167, 1, '2026-10-29 08:52:22.753679', NULL, NULL, 'create', 'inventory', 'Product', 1, 'SOL-MONO-450', 'Product SOL-MONO-450 created', '{"company_id": 1, "sku": "SOL-MONO-450", "name": "Monocrystalline Solar Panel 450W", "category_id": 1, "unit_price": 32000.0, "cost_price": 28000.0, "reorder_level": 10, "current_stock": 50, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(168, 1, '2026-10-29 08:52:22.756941', NULL, NULL, 'create', 'inventory', 'Product', 2, 'SOL-MONO-550', 'Product SOL-MONO-550 created', '{"company_id": 1, "sku": "SOL-MONO-550", "name": "Monocrystalline Solar Panel 550W", "category_id": 1, "unit_price": 42000.0, "cost_price": 37000.0, "reorder_level": 5, "current_stock": 30, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(169, 1, '2026-10-29 08:52:22.760121', NULL, NULL, 'create', 'inventory', 'Product', 3, 'SOL-POLY-330', 'Product SOL-POLY-330 created', '{"company_id": 1, "sku": "SOL-POLY-330", "name": "Polycrystalline Solar Panel 330W", "category_id": 1, "unit_price": 22000.0, "cost_price": 18500.0, "reorder_level": 8, "current_stock": 40, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(170, 1, '2026-10-29 08:52:22.763313', NULL, NULL, 'create', 'inventory', 'Product', 4, 'INV-5KW', 'Product INV-5KW created', '{"company_id": 1, "sku": "INV-5KW", "name": "5kW Hybrid Inverter", "category_id": 2, "unit_price": 85000.0, "cost_price": 72000.0, "reorder_level": 3, "current_stock": 15, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(171, 1, '2026-10-29 08:52:22.766658', NULL, NULL, 'create', 'inventory', 'Product', 5, 'INV-10KW', 'Product INV-10KW created', '{"company_id": 1, "sku": "INV-10KW", "name": "10kW Hybrid Inverter", "category_id": 2, "unit_price": 145000.0, "cost_price": 125000.0, "reorder_level": 2, "current_stock": 10, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(172, 1, '2026-10-29 08:52:22.769992', NULL, NULL, 'create', 'inventory', 'Product', 6, 'INV-3KW', 'Product INV-3KW created', '{"company_id": 1, "sku": "INV-3KW", "name": "3kW String Inverter", "category_id": 2, "unit_price": 55000.0, "cost_price": 46000.0, "reorder_level": 4, "current_stock": 20, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(173, 1, '2026-10-29 08:52:22.77333', NULL, NULL, 'create', 'inventory', 'Product', 7, 'BAT-LFP-5KWH', 'Product BAT-LFP-5KWH created', '{"company_id": 1, "sku": "BAT-LFP-5KWH", "name": "5kWh LiFePO4 Battery", "category_id": 3, "unit_price": 180000.0, "cost_price": 155000.0, "reorder_level": 5, "current_stock": 25, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(174, 1, '2026-10-29 08:52:22.776501', NULL, NULL, 'create', 'inventory', 'Product', 8, 'BAT-LFP-10KWH', 'Product BAT-LFP-10KWH created', '{"company_id": 1, "sku": "BAT-LFP-10KWH", "name": "10kWh LiFePO4 Battery", "category_id": 3, "unit_price": 320000.0, "cost_price": 280000.0, "reorder_level": 3, "current_stock": 15, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(175, 1, '2026-10-29 08:52:22.779644', NULL, NULL, 'create', 'inventory', 'Product', 9, 'BAT-TUB-200', 'Product BAT-TUB-200 created', '{"company_id": 1, "sku": "BAT-TUB-200", "name": "200Ah Tubular Battery", "category_id": 3, "unit_price": 45000.0, "cost_price": 38000.0, "reorder_level": 5, "current_stock": 30, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(176, 1, '2026-10-29 08:52:22.78287', NULL, NULL, 'create', 'inventory', 'Product', 10, 'CBL-SOL-4MM', 'Product CBL-SOL-4MM created', '{"company_id": 1, "sku": "CBL-SOL-4MM", "name": "Solar DC Cable 4mm (per meter)", "category_id": 4, "unit_price": 180.0, "cost_price": 120.0, "reorder_level": 100, "current_stock": 500, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(177, 1, '2026-10-29 08:52:22.786187', NULL, NULL, 'create', 'inventory', 'Product', 11, 'CBL-AC-2.5MM', 'Product CBL-AC-2.5MM created', '{"company_id": 1, "sku": "CBL-AC-2.5MM", "name": "AC Cable 2.5mm (per meter)", "category_id": 4, "unit_price": 120.0, "cost_price": 80.0, "reorder_level": 200, "current_stock": 1000, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(178, 1, '2026-10-29 08:52:22.789382', NULL, NULL, 'create', 'inventory', 'Product', 12, 'CBL-MC4', 'Product CBL-MC4 created', '{"company_id": 1, "sku": "CBL-MC4", "name": "MC4 Connector Pair", "category_id": 4, "unit_price": 350.0, "cost_price": 250.0, "reorder_level": 50, "current_stock": 200, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(179, 1, '2026-10-29 08:52:22.792803', NULL, NULL, 'create', 'inventory', 'Product', 13, 'MNT-ALU-RACK', 'Product MNT-ALU-RACK created', '{"company_id": 1, "sku": "MNT-ALU-RACK", "name": "Aluminum Mounting Rack (set)", "category_id": 5, "unit_price": 8500.0, "cost_price": 6500.0, "reorder_level": 5, "current_stock": 20, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(180, 1, '2026-10-29 08:52:22.796111', NULL, NULL, 'create', 'inventory', 'Product', 14, 'MNT-RAIL-2M', 'Product MNT-RAIL-2M created', '{"company_id": 1, "sku": "MNT-RAIL-2M", "name": "Mounting Rail 2m", "category_id": 5, "unit_price": 2200.0, "cost_price": 1600.0, "reorder_level": 10, "current_stock": 50, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(181, 1, '2026-10-29 08:52:22.799491', NULL, NULL, 'create', 'inventory', 'Product', 15, 'ELEC-DB', 'Product ELEC-DB created', '{"company_id": 1, "sku": "ELEC-DB", "name": "Distribution Board 16-way", "category_id": 6, "unit_price": 4500.0, "cost_price": 3200.0, "reorder_level": 5, "current_stock": 30, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(182, 1, '2026-10-29 08:52:22.802761', NULL, NULL, 'create', 'inventory', 'Product', 16, 'ELEC-SPD', 'Product ELEC-SPD created', '{"company_id": 1, "sku": "ELEC-SPD", "name": "Surge Protection Device", "category_id": 6, "unit_price": 2800.0, "cost_price": 2000.0, "reorder_level": 8, "current_stock": 40, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(183, 1, '2026-10-29 08:52:22.805924', NULL, NULL, 'create', 'inventory', 'Product', 17, 'ELEC-MCB-16A', 'Product ELEC-MCB-16A created', '{"company_id": 1, "sku": "ELEC-MCB-16A", "name": "MCB 16A Single Pole", "category_id": 6, "unit_price": 350.0, "cost_price": 220.0, "reorder_level": 20, "current_stock": 100, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(184, 1, '2026-10-29 08:52:22.80927', NULL, NULL, 'create', 'inventory', 'Product', 18, 'TOOL-CRIMP', 'Product TOOL-CRIMP created', '{"company_id": 1, "sku": "TOOL-CRIMP", "name": "Solar Crimping Tool", "category_id": 7, "unit_price": 5500.0, "cost_price": 4200.0, "reorder_level": 2, "current_stock": 10, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(185, 1, '2026-10-29 08:52:22.81287', NULL, NULL, 'create', 'inventory', 'Product', 19, 'TOOL-MULTI', 'Product TOOL-MULTI created', '{"company_id": 1, "sku": "TOOL-MULTI", "name": "Digital Multimeter", "category_id": 7, "unit_price": 3500.0, "cost_price": 2500.0, "reorder_level": 3, "current_stock": 15, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(186, 1, '2026-10-29 08:52:22.816267', NULL, NULL, 'create', 'inventory', 'Product', 20, 'SAFE-HLMT', 'Product SAFE-HLMT created', '{"company_id": 1, "sku": "SAFE-HLMT", "name": "Safety Helmet", "category_id": 8, "unit_price": 800.0, "cost_price": 500.0, "reorder_level": 10, "current_stock": 50, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(187, 1, '2026-10-29 08:52:22.819944', NULL, NULL, 'create', 'inventory', 'Product', 21, 'SAFE-GLOVES', 'Product SAFE-GLOVES created', '{"company_id": 1, "sku": "SAFE-GLOVES", "name": "Insulated Gloves (pair)", "category_id": 8, "unit_price": 1200.0, "cost_price": 800.0, "reorder_level": 10, "current_stock": 40, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(188, 1, '2026-10-29 08:52:22.82528', NULL, NULL, 'create', 'inventory', 'Product', 22, 'SAFE-HARNESS', 'Product SAFE-HARNESS created', '{"company_id": 1, "sku": "SAFE-HARNESS", "name": "Safety Harness", "category_id": 8, "unit_price": 4500.0, "cost_price": 3200.0, "reorder_level": 3, "current_stock": 15, "unit": "pcs", "is_active": true}', '127.0.0.1', '/'),
	(189, 1, '2026-10-29 08:52:22.828371', NULL, NULL, 'create', 'invoicing', 'Supplier', 1, 'Longi Solar Pakistan', 'Supplier Longi Solar Pakistan created', '{"company_id": 1, "name": "Longi Solar Pakistan", "contact_person": "Mr. Ahmed", "email": "ahmed@longi.pk", "phone": "021-34567890", "address": "PLOT 12, SITE AREA", "city": "Karachi", "is_active": true}', '127.0.0.1', '/'),
	(190, 1, '2026-10-29 08:52:22.831364', NULL, NULL, 'create', 'invoicing', 'Supplier', 2, 'JA Solar Technologies', 'Supplier JA Solar Technologies created', '{"company_id": 1, "name": "JA Solar Technologies", "contact_person": "Mr. Usman", "email": "usman@jasolar.com", "phone": "042-35678901", "address": "23-G, Gulberg III", "city": "Lahore", "is_active": true}', '127.0.0.1', '/'),
	(191, 1, '2026-10-29 08:52:22.83436', NULL, NULL, 'create', 'invoicing', 'Supplier', 3, 'BYD Energy Solutions', 'Supplier BYD Energy Solutions created', '{"company_id": 1, "name": "BYD Energy Solutions", "contact_person": "Mr. Kamran", "email": "kamran@byd.com", "phone": "021-36789012", "address": "Business Bay, Clifton", "city": "Karachi", "is_active": true}', '127.0.0.1', '/'),
	(192, 1, '2026-10-29 08:52:22.83736', NULL, NULL, 'create', 'invoicing', 'Supplier', 4, 'Growatt Inverters', 'Supplier Growatt Inverters created', '{"company_id": 1, "name": "Growatt Inverters", "contact_person": "Mr. Hassan", "email": "hassan@growatt.com", "phone": "042-37890123", "address": "55 Main Boulevard", "city": "Lahore", "is_active": true}', '127.0.0.1', '/'),
	(193, 1, '2026-10-29 08:52:22.841064', NULL, NULL, 'create', 'invoicing', 'Supplier', 5, 'Al-Rashid Traders', 'Supplier Al-Rashid Traders created', '{"company_id": 1, "name": "Al-Rashid Traders", "contact_person": "Mr. Rashid", "email": "rashid@alrashid.com", "phone": "0315-1234567", "address": "Steel Market, Bolton Market", "city": "Karachi", "is_active": true}', '127.0.0.1', '/'),
	(194, 1, '2026-10-29 08:52:22.846287', NULL, NULL, 'create', 'invoicing', 'Supplier', 6, 'Pakistan Cable Co.', 'Supplier Pakistan Cable Co. created', '{"company_id": 1, "name": "Pakistan Cable Co.", "contact_person": "Mr. Faisal", "email": "faisal@pakcable.com", "phone": "021-38901234", "address": "Industrial Area, Kot Lakhpat", "city": "Lahore", "is_active": true}', '127.0.0.1', '/'),
	(195, 1, '2026-10-29 08:52:22.849991', NULL, NULL, 'create', 'invoicing', 'Customer', 1, 'SolarTech Solutions', 'Customer SolarTech Solutions created', '{"company_id": 1, "name": "SolarTech Solutions", "email": "imran@solartech.com", "phone": "0300-1111111", "address": "7-A, Johar Town", "city": "Lahore", "credit_limit": 1000000, "is_active": true}', '127.0.0.1', '/'),
	(196, 1, '2026-10-29 08:52:22.853137', NULL, NULL, 'create', 'invoicing', 'Customer', 2, 'Green Energy Pakistan', 'Customer Green Energy Pakistan created', '{"company_id": 1, "name": "Green Energy Pakistan", "email": "fatima@greenenergy.com", "phone": "0300-2222222", "address": "15-B, Phase 2, DHA", "city": "Karachi", "credit_limit": 2000000, "is_active": true}', '127.0.0.1', '/'),
	(197, 1, '2026-10-29 08:52:22.856869', NULL, NULL, 'create', 'invoicing', 'Customer', 3, 'BuildRight Construction', 'Customer BuildRight Construction created', '{"company_id": 1, "name": "BuildRight Construction", "email": "ali@buildright.com", "phone": "0300-3333333", "address": "3rd Floor, Al-Falah Plaza", "city": "Islamabad", "credit_limit": 1500000, "is_active": true}', '127.0.0.1', '/'),
	(198, 1, '2026-10-29 08:52:22.86126', NULL, NULL, 'create', 'invoicing', 'Customer', 4, 'Home Solutions Ltd.', 'Customer Home Solutions Ltd. created', '{"company_id": 1, "name": "Home Solutions Ltd.", "email": "zafar@homesol.com", "phone": "0300-4444444", "address": "88, Garden Town", "city": "Lahore", "credit_limit": 500000, "is_active": true}', '127.0.0.1', '/'),
	(199, 1, '2026-10-29 08:52:22.867562', NULL, NULL, 'create', 'inventory', 'Inventory settings', 1, '1', 'Inventory settings 1 created', '{"company_id": 1, "valuation_method": "weighted_average", "decimal_places": 4, "auto_generate_vouchers": true, "purchase_flow": "with_po", "sales_flow": "with_so"}', '127.0.0.1', '/'),
	(200, 1, '2026-10-29 08:52:22.875814', NULL, NULL, 'create', 'settings', 'Company profile', 1, 'SolarKon Energy Solutions', 'Company profile SolarKon Energy Solutions created', '{"company_id": 1, "company_name": "SolarKon Energy Solutions", "country": "Pakistan", "fiscal_year_start_month": 1, "currency": "PKR", "currency_symbol": "Rs.", "date_format": "Y-m-d", "number_format": "en", "timezone": "Asia/Karachi"}', '127.0.0.1', '/');
INSERT INTO public.audit_logs VALUES
	(201, 1, '2026-10-29 08:52:22.893561', NULL, NULL, 'create', 'accounting', 'Accounting period', 1, 'FY 2021', 'Accounting period FY 2021 created', '{"company_id": 1, "fiscal_year": "2021", "period_name": "FY 2021", "start_date": "2021-01-01", "end_date": "2021-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/'),
	(202, 1, '2026-10-29 08:52:22.893566', NULL, NULL, 'create', 'accounting', 'Accounting period', 2, 'FY 2022', 'Accounting period FY 2022 created', '{"company_id": 1, "fiscal_year": "2022", "period_name": "FY 2022", "start_date": "2022-01-01", "end_date": "2022-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/'),
	(203, 1, '2026-10-29 08:52:22.893567', NULL, NULL, 'create', 'accounting', 'Accounting period', 3, 'FY 2023', 'Accounting period FY 2023 created', '{"company_id": 1, "fiscal_year": "2023", "period_name": "FY 2023", "start_date": "2023-01-01", "end_date": "2023-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/'),
	(204, 1, '2026-10-29 08:52:22.893569', NULL, NULL, 'create', 'accounting', 'Accounting period', 4, 'FY 2024', 'Accounting period FY 2024 created', '{"company_id": 1, "fiscal_year": "2024", "period_name": "FY 2024", "start_date": "2024-01-01", "end_date": "2024-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/'),
	(205, 1, '2026-10-29 08:52:22.89357', NULL, NULL, 'create', 'accounting', 'Accounting period', 5, 'FY 2025', 'Accounting period FY 2025 created', '{"company_id": 1, "fiscal_year": "2025", "period_name": "FY 2025", "start_date": "2025-01-01", "end_date": "2025-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/'),
	(206, 1, '2026-10-29 08:52:22.893571', NULL, NULL, 'create', 'accounting', 'Accounting period', 6, 'FY 2026', 'Accounting period FY 2026 created', '{"company_id": 1, "fiscal_year": "2026", "period_name": "FY 2026", "start_date": "2026-01-01", "end_date": "2026-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/'),
	(207, 1, '2026-10-29 08:52:22.893572', NULL, NULL, 'create', 'accounting', 'Accounting period', 7, 'FY 2027', 'Accounting period FY 2027 created', '{"company_id": 1, "fiscal_year": "2027", "period_name": "FY 2027", "start_date": "2027-01-01", "end_date": "2027-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/'),
	(208, 1, '2026-10-29 08:52:22.893573', NULL, NULL, 'create', 'accounting', 'Accounting period', 8, 'FY 2028', 'Accounting period FY 2028 created', '{"company_id": 1, "fiscal_year": "2028", "period_name": "FY 2028", "start_date": "2028-01-01", "end_date": "2028-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/'),
	(252, 1, '2026-10-29 08:52:23.203527', NULL, NULL, 'post', 'accounting', 'Journal entry', 1, 'OPEN-00001', 'Journal entry OPEN-00001 posted — Opening stock — Monocrystalline Solar Panel 450W', NULL, '127.0.0.1', '/'),
	(253, 1, '2026-10-29 08:52:23.246349', NULL, NULL, 'post', 'accounting', 'Journal entry', 2, 'OPEN-00002', 'Journal entry OPEN-00002 posted — Opening stock — Monocrystalline Solar Panel 550W', NULL, '127.0.0.1', '/'),
	(254, 1, '2026-10-29 08:52:23.285835', NULL, NULL, 'post', 'accounting', 'Journal entry', 3, 'OPEN-00003', 'Journal entry OPEN-00003 posted — Opening stock — Polycrystalline Solar Panel 330W', NULL, '127.0.0.1', '/'),
	(255, 1, '2026-10-29 08:52:23.329991', NULL, NULL, 'post', 'accounting', 'Journal entry', 4, 'OPEN-00004', 'Journal entry OPEN-00004 posted — Opening stock — 5kW Hybrid Inverter', NULL, '127.0.0.1', '/'),
	(256, 1, '2026-10-29 08:52:23.373144', NULL, NULL, 'post', 'accounting', 'Journal entry', 5, 'OPEN-00005', 'Journal entry OPEN-00005 posted — Opening stock — 10kW Hybrid Inverter', NULL, '127.0.0.1', '/'),
	(257, 1, '2026-10-29 08:52:23.414146', NULL, NULL, 'post', 'accounting', 'Journal entry', 6, 'OPEN-00006', 'Journal entry OPEN-00006 posted — Opening stock — 3kW String Inverter', NULL, '127.0.0.1', '/'),
	(258, 1, '2026-10-29 08:52:23.455167', NULL, NULL, 'post', 'accounting', 'Journal entry', 7, 'OPEN-00007', 'Journal entry OPEN-00007 posted — Opening stock — 5kWh LiFePO4 Battery', NULL, '127.0.0.1', '/'),
	(259, 1, '2026-10-29 08:52:23.496927', NULL, NULL, 'post', 'accounting', 'Journal entry', 8, 'OPEN-00008', 'Journal entry OPEN-00008 posted — Opening stock — 10kWh LiFePO4 Battery', NULL, '127.0.0.1', '/'),
	(260, 1, '2026-10-29 08:52:23.53794', NULL, NULL, 'post', 'accounting', 'Journal entry', 9, 'OPEN-00009', 'Journal entry OPEN-00009 posted — Opening stock — 200Ah Tubular Battery', NULL, '127.0.0.1', '/'),
	(261, 1, '2026-10-29 08:52:23.57828', NULL, NULL, 'post', 'accounting', 'Journal entry', 10, 'OPEN-00010', 'Journal entry OPEN-00010 posted — Opening stock — Solar DC Cable 4mm (per meter)', NULL, '127.0.0.1', '/'),
	(262, 1, '2026-10-29 08:52:23.615333', NULL, NULL, 'post', 'accounting', 'Journal entry', 11, 'OPEN-00011', 'Journal entry OPEN-00011 posted — Opening stock — AC Cable 2.5mm (per meter)', NULL, '127.0.0.1', '/'),
	(263, 1, '2026-10-29 08:52:23.653389', NULL, NULL, 'post', 'accounting', 'Journal entry', 12, 'OPEN-00012', 'Journal entry OPEN-00012 posted — Opening stock — MC4 Connector Pair', NULL, '127.0.0.1', '/'),
	(264, 1, '2026-10-29 08:52:23.693863', NULL, NULL, 'post', 'accounting', 'Journal entry', 13, 'OPEN-00013', 'Journal entry OPEN-00013 posted — Opening stock — Aluminum Mounting Rack (set)', NULL, '127.0.0.1', '/'),
	(265, 1, '2026-10-29 08:52:23.731546', NULL, NULL, 'post', 'accounting', 'Journal entry', 14, 'OPEN-00014', 'Journal entry OPEN-00014 posted — Opening stock — Mounting Rail 2m', NULL, '127.0.0.1', '/'),
	(266, 1, '2026-10-29 08:52:23.770782', NULL, NULL, 'post', 'accounting', 'Journal entry', 15, 'OPEN-00015', 'Journal entry OPEN-00015 posted — Opening stock — Distribution Board 16-way', NULL, '127.0.0.1', '/'),
	(267, 1, '2026-10-29 08:52:23.81024', NULL, NULL, 'post', 'accounting', 'Journal entry', 16, 'OPEN-00016', 'Journal entry OPEN-00016 posted — Opening stock — Surge Protection Device', NULL, '127.0.0.1', '/'),
	(268, 1, '2026-10-29 08:52:23.852213', NULL, NULL, 'post', 'accounting', 'Journal entry', 17, 'OPEN-00017', 'Journal entry OPEN-00017 posted — Opening stock — MCB 16A Single Pole', NULL, '127.0.0.1', '/'),
	(269, 1, '2026-10-29 08:52:23.893395', NULL, NULL, 'post', 'accounting', 'Journal entry', 18, 'OPEN-00018', 'Journal entry OPEN-00018 posted — Opening stock — Solar Crimping Tool', NULL, '127.0.0.1', '/'),
	(270, 1, '2026-10-29 08:52:23.933158', NULL, NULL, 'post', 'accounting', 'Journal entry', 19, 'OPEN-00019', 'Journal entry OPEN-00019 posted — Opening stock — Digital Multimeter', NULL, '127.0.0.1', '/'),
	(271, 1, '2026-10-29 08:52:23.974606', NULL, NULL, 'post', 'accounting', 'Journal entry', 20, 'OPEN-00020', 'Journal entry OPEN-00020 posted — Opening stock — Safety Helmet', NULL, '127.0.0.1', '/'),
	(272, 1, '2026-10-29 08:52:24.016251', NULL, NULL, 'post', 'accounting', 'Journal entry', 21, 'OPEN-00021', 'Journal entry OPEN-00021 posted — Opening stock — Insulated Gloves (pair)', NULL, '127.0.0.1', '/'),
	(273, 1, '2026-10-29 08:52:24.057882', NULL, NULL, 'post', 'accounting', 'Journal entry', 22, 'OPEN-00022', 'Journal entry OPEN-00022 posted — Opening stock — Safety Harness', NULL, '127.0.0.1', '/'),
	(274, 1, '2026-10-29 08:52:24.152601', NULL, NULL, 'create', 'admin', 'Membership', 1, '1', 'Membership 1 created', '{"company_id": 1, "user_id": 1, "role_id": 1, "status": "active", "employee_code": "SYSADMIN", "joined_at": "2026-10-29T08:52:24.149660", "designation": "System Administrator"}', '127.0.0.1', '/'),
	(275, 1, '2026-10-29 08:52:24.156182', NULL, NULL, 'create', 'admin', 'Membership', 2, '3', 'Membership 3 created', '{"company_id": 1, "user_id": 3, "role_id": 2, "status": "active", "employee_code": "MGR002", "joined_at": "2026-10-29T08:52:24.153732", "designation": "Manager"}', '127.0.0.1', '/'),
	(276, 1, '2026-10-29 08:52:24.16039', NULL, NULL, 'create', 'admin', 'Membership', 3, '4', 'Membership 4 created', '{"company_id": 1, "user_id": 4, "role_id": 3, "status": "active", "employee_code": "EMP001", "joined_at": "2026-10-29T08:52:24.156975", "designation": "Employee"}', '127.0.0.1', '/'),
	(277, 1, '2026-10-29 08:52:24.163679', NULL, NULL, 'create', 'admin', 'Membership', 4, '5', 'Membership 5 created', '{"company_id": 1, "user_id": 5, "role_id": 3, "status": "active", "employee_code": "EMP002", "joined_at": "2026-10-29T08:52:24.161126", "designation": "Employee"}', '127.0.0.1', '/'),
	(278, 1, '2026-10-29 08:52:24.166747', NULL, NULL, 'update', 'admin', 'User', 1, 'admin@gmail.com', 'User admin@gmail.com edited (is super admin)', '[{"field": "is_super_admin", "old": false, "new": true}]', '127.0.0.1', '/'),
	(279, NULL, '2026-10-29 08:52:24.275582', 1, 'Administrator', 'login', 'admin', NULL, NULL, NULL, 'Super admin Administrator entered the console', NULL, '127.0.0.1', '/superadmin/login'),
	(280, 1, '2026-10-29 08:52:24.381389', 1, 'Administrator', 'create', 'admin', 'User', 6, 'owner.one@ref.test', 'User owner.one@ref.test created', '{"employee_code": "SA0006", "email": "owner.one@ref.test", "login_id": "owner.one@ref.test", "password_hash": "\u2022\u2022\u2022", "full_name": "Owner console-one", "role_id": 1, "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true, "has_inventory_access": true, "has_invoicing_access": true, "has_finance_access": true, "has_accounting_access": true, "has_fbr_access": true, "has_fixed_assets_access": true, "has_executive_access": true}', '127.0.0.1', '/superadmin/companies/'),
	(281, 2, '2026-10-29 08:52:24.383778', 1, 'Administrator', 'create', 'admin', 'Membership', 5, '6', 'Membership 6 created', '{"company_id": 2, "user_id": 6, "role_id": 1, "status": "active", "employee_code": "SA0006", "joined_at": "2026-10-29T08:52:24.382988"}', '127.0.0.1', '/superadmin/companies/'),
	(452, 2, '2026-10-29 08:52:25.215158', 1, 'Administrator', 'create', 'settings', 'Report settings', 2, '2', 'Report settings 2 created', '{"company_id": 2, "pl_detail_rows": 10, "invoice_party_mode": "relevant", "purchase_party_mode": "relevant", "sales_party_mode": "relevant", "cash_flow_method": "indirect"}', '127.0.0.1', '/superadmin/companies/'),
	(453, 2, '2026-10-29 08:52:25.220413', 1, 'Administrator', 'create', 'inventory', 'Inventory settings', 2, '2', 'Inventory settings 2 created', '{"company_id": 2, "valuation_method": "weighted_average", "decimal_places": 4, "auto_generate_vouchers": true, "purchase_flow": "with_po", "sales_flow": "with_so"}', '127.0.0.1', '/superadmin/companies/'),
	(467, 3, '2026-10-29 08:52:25.412802', 1, 'Administrator', 'create', 'accounting', 'Account', 371, '1-01-04', 'Account 1-01-04 created', '{"company_id": 3, "code": "1-01-04", "name": "Inventories", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(209, 1, '2026-10-29 08:52:22.904842', NULL, NULL, 'create', 'settings', 'Report settings', 1, '1', 'Report settings 1 created', '{"company_id": 1, "pl_detail_rows": 10, "invoice_party_mode": "relevant", "purchase_party_mode": "relevant", "sales_party_mode": "relevant", "cash_flow_method": "indirect"}', '127.0.0.1', '/'),
	(210, 1, '2026-10-29 08:52:22.913441', NULL, NULL, 'create', 'accounting', 'Account', 162, '2-01-01-01-0101', 'Account 2-01-01-01-0101 created', '{"company_id": 1, "code": "2-01-01-01-0101", "name": "Longi Solar Pakistan", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(211, 1, '2026-10-29 08:52:22.918889', NULL, NULL, 'create', 'accounting', 'Account', 163, '2-01-01-01-0102', 'Account 2-01-01-01-0102 created', '{"company_id": 1, "code": "2-01-01-01-0102", "name": "JA Solar Technologies", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(212, 1, '2026-10-29 08:52:22.924321', NULL, NULL, 'create', 'accounting', 'Account', 164, '2-01-01-01-0103', 'Account 2-01-01-01-0103 created', '{"company_id": 1, "code": "2-01-01-01-0103", "name": "BYD Energy Solutions", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(213, 1, '2026-10-29 08:52:22.92967', NULL, NULL, 'create', 'accounting', 'Account', 165, '2-01-01-01-0104', 'Account 2-01-01-01-0104 created', '{"company_id": 1, "code": "2-01-01-01-0104", "name": "Growatt Inverters", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(214, 1, '2026-10-29 08:52:22.934719', NULL, NULL, 'create', 'accounting', 'Account', 166, '2-01-01-01-0105', 'Account 2-01-01-01-0105 created', '{"company_id": 1, "code": "2-01-01-01-0105", "name": "Al-Rashid Traders", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(215, 1, '2026-10-29 08:52:22.940344', NULL, NULL, 'create', 'accounting', 'Account', 167, '2-01-01-01-0106', 'Account 2-01-01-01-0106 created', '{"company_id": 1, "code": "2-01-01-01-0106", "name": "Pakistan Cable Co.", "type": "liability", "parent_id": 31, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(216, 1, '2026-10-29 08:52:22.948984', NULL, NULL, 'create', 'accounting', 'Account', 168, '1-01-02-01-0101', 'Account 1-01-02-01-0101 created', '{"company_id": 1, "code": "1-01-02-01-0101", "name": "SolarTech Solutions", "type": "asset", "parent_id": 7, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(217, 1, '2026-10-29 08:52:22.954739', NULL, NULL, 'create', 'accounting', 'Account', 169, '1-01-02-01-0102', 'Account 1-01-02-01-0102 created', '{"company_id": 1, "code": "1-01-02-01-0102", "name": "Green Energy Pakistan", "type": "asset", "parent_id": 7, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(218, 1, '2026-10-29 08:52:22.961112', NULL, NULL, 'create', 'accounting', 'Account', 170, '1-01-02-01-0103', 'Account 1-01-02-01-0103 created', '{"company_id": 1, "code": "1-01-02-01-0103", "name": "BuildRight Construction", "type": "asset", "parent_id": 7, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(219, 1, '2026-10-29 08:52:22.966611', NULL, NULL, 'create', 'accounting', 'Account', 171, '1-01-02-01-0104', 'Account 1-01-02-01-0104 created', '{"company_id": 1, "code": "1-01-02-01-0104", "name": "Home Solutions Ltd.", "type": "asset", "parent_id": 7, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(220, 1, '2026-10-29 08:52:22.974314', NULL, NULL, 'create', 'accounting', 'Account', 172, '1-01-04-01-0101', 'Account 1-01-04-01-0101 created', '{"company_id": 1, "code": "1-01-04-01-0101", "name": "Monocrystalline Solar Panel 450W (SOL-MONO-450)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(221, 1, '2026-10-29 08:52:22.979257', NULL, NULL, 'create', 'accounting', 'Account', 173, '1-01-04-01-0102', 'Account 1-01-04-01-0102 created', '{"company_id": 1, "code": "1-01-04-01-0102", "name": "Monocrystalline Solar Panel 550W (SOL-MONO-550)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(222, 1, '2026-10-29 08:52:22.9842', NULL, NULL, 'create', 'accounting', 'Account', 174, '1-01-04-01-0103', 'Account 1-01-04-01-0103 created', '{"company_id": 1, "code": "1-01-04-01-0103", "name": "Polycrystalline Solar Panel 330W (SOL-POLY-330)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(223, 1, '2026-10-29 08:52:22.989385', NULL, NULL, 'create', 'accounting', 'Account', 175, '1-01-04-01-0104', 'Account 1-01-04-01-0104 created', '{"company_id": 1, "code": "1-01-04-01-0104", "name": "5kW Hybrid Inverter (INV-5KW)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(224, 1, '2026-10-29 08:52:22.994376', NULL, NULL, 'create', 'accounting', 'Account', 176, '1-01-04-01-0105', 'Account 1-01-04-01-0105 created', '{"company_id": 1, "code": "1-01-04-01-0105", "name": "10kW Hybrid Inverter (INV-10KW)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(225, 1, '2026-10-29 08:52:22.999176', NULL, NULL, 'create', 'accounting', 'Account', 177, '1-01-04-01-0106', 'Account 1-01-04-01-0106 created', '{"company_id": 1, "code": "1-01-04-01-0106", "name": "3kW String Inverter (INV-3KW)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(226, 1, '2026-10-29 08:52:23.003934', NULL, NULL, 'create', 'accounting', 'Account', 178, '1-01-04-01-0107', 'Account 1-01-04-01-0107 created', '{"company_id": 1, "code": "1-01-04-01-0107", "name": "5kWh LiFePO4 Battery (BAT-LFP-5KWH)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(227, 1, '2026-10-29 08:52:23.008845', NULL, NULL, 'create', 'accounting', 'Account', 179, '1-01-04-01-0108', 'Account 1-01-04-01-0108 created', '{"company_id": 1, "code": "1-01-04-01-0108", "name": "10kWh LiFePO4 Battery (BAT-LFP-10KWH)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(228, 1, '2026-10-29 08:52:23.013724', NULL, NULL, 'create', 'accounting', 'Account', 180, '1-01-04-01-0109', 'Account 1-01-04-01-0109 created', '{"company_id": 1, "code": "1-01-04-01-0109", "name": "200Ah Tubular Battery (BAT-TUB-200)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(229, 1, '2026-10-29 08:52:23.018556', NULL, NULL, 'create', 'accounting', 'Account', 181, '1-01-04-01-0110', 'Account 1-01-04-01-0110 created', '{"company_id": 1, "code": "1-01-04-01-0110", "name": "Solar DC Cable 4mm (per meter) (CBL-SOL-4MM)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(230, 1, '2026-10-29 08:52:23.023249', NULL, NULL, 'create', 'accounting', 'Account', 182, '1-01-04-01-0111', 'Account 1-01-04-01-0111 created', '{"company_id": 1, "code": "1-01-04-01-0111", "name": "AC Cable 2.5mm (per meter) (CBL-AC-2.5MM)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(231, 1, '2026-10-29 08:52:23.028764', NULL, NULL, 'create', 'accounting', 'Account', 183, '1-01-04-01-0112', 'Account 1-01-04-01-0112 created', '{"company_id": 1, "code": "1-01-04-01-0112", "name": "MC4 Connector Pair (CBL-MC4)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(232, 1, '2026-10-29 08:52:23.033318', NULL, NULL, 'create', 'accounting', 'Account', 184, '1-01-04-01-0113', 'Account 1-01-04-01-0113 created', '{"company_id": 1, "code": "1-01-04-01-0113", "name": "Aluminum Mounting Rack (set) (MNT-ALU-RACK)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(233, 1, '2026-10-29 08:52:23.037872', NULL, NULL, 'create', 'accounting', 'Account', 185, '1-01-04-01-0114', 'Account 1-01-04-01-0114 created', '{"company_id": 1, "code": "1-01-04-01-0114", "name": "Mounting Rail 2m (MNT-RAIL-2M)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(234, 1, '2026-10-29 08:52:23.042749', NULL, NULL, 'create', 'accounting', 'Account', 186, '1-01-04-01-0115', 'Account 1-01-04-01-0115 created', '{"company_id": 1, "code": "1-01-04-01-0115", "name": "Distribution Board 16-way (ELEC-DB)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(235, 1, '2026-10-29 08:52:23.048362', NULL, NULL, 'create', 'accounting', 'Account', 187, '1-01-04-01-0116', 'Account 1-01-04-01-0116 created', '{"company_id": 1, "code": "1-01-04-01-0116", "name": "Surge Protection Device (ELEC-SPD)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(236, 1, '2026-10-29 08:52:23.053255', NULL, NULL, 'create', 'accounting', 'Account', 188, '1-01-04-01-0117', 'Account 1-01-04-01-0117 created', '{"company_id": 1, "code": "1-01-04-01-0117", "name": "MCB 16A Single Pole (ELEC-MCB-16A)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(237, 1, '2026-10-29 08:52:23.058081', NULL, NULL, 'create', 'accounting', 'Account', 189, '1-01-04-01-0118', 'Account 1-01-04-01-0118 created', '{"company_id": 1, "code": "1-01-04-01-0118", "name": "Solar Crimping Tool (TOOL-CRIMP)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(238, 1, '2026-10-29 08:52:23.063149', NULL, NULL, 'create', 'accounting', 'Account', 190, '1-01-04-01-0119', 'Account 1-01-04-01-0119 created', '{"company_id": 1, "code": "1-01-04-01-0119", "name": "Digital Multimeter (TOOL-MULTI)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(239, 1, '2026-10-29 08:52:23.069175', NULL, NULL, 'create', 'accounting', 'Account', 191, '1-01-04-01-0120', 'Account 1-01-04-01-0120 created', '{"company_id": 1, "code": "1-01-04-01-0120", "name": "Safety Helmet (SAFE-HLMT)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(240, 1, '2026-10-29 08:52:23.077299', NULL, NULL, 'create', 'accounting', 'Account', 192, '1-01-04-01-0121', 'Account 1-01-04-01-0121 created', '{"company_id": 1, "code": "1-01-04-01-0121", "name": "Insulated Gloves (pair) (SAFE-GLOVES)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(241, 1, '2026-10-29 08:52:23.085856', NULL, NULL, 'create', 'accounting', 'Account', 193, '1-01-04-01-0122', 'Account 1-01-04-01-0122 created', '{"company_id": 1, "code": "1-01-04-01-0122", "name": "Safety Harness (SAFE-HARNESS)", "type": "asset", "parent_id": 13, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(242, 1, '2026-10-29 08:52:23.096458', NULL, NULL, 'create', 'accounting', 'Account', 194, '2-01-02-01-0101', 'Account 2-01-02-01-0101 created', '{"company_id": 1, "code": "2-01-02-01-0101", "name": "Administrator (SYSADMIN)", "type": "liability", "parent_id": 33, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(243, 1, '2026-10-29 08:52:23.101352', NULL, NULL, 'update', 'admin', 'User', 1, 'admin@gmail.com', 'User admin@gmail.com edited (login id)', '[{"field": "login_id", "old": null, "new": "admin@gmail.com"}]', '127.0.0.1', '/'),
	(244, 1, '2026-10-29 08:52:23.106472', NULL, NULL, 'create', 'accounting', 'Account', 195, '2-01-02-01-0102', 'Account 2-01-02-01-0102 created', '{"company_id": 1, "code": "2-01-02-01-0102", "name": "System Admin (ADM001)", "type": "liability", "parent_id": 33, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(245, 1, '2026-10-29 08:52:23.109786', NULL, NULL, 'update', 'admin', 'User', 2, 'admin@solarkon.com', 'User admin@solarkon.com edited (login id)', '[{"field": "login_id", "old": null, "new": "admin@solarkon.com"}]', '127.0.0.1', '/'),
	(246, 1, '2026-10-29 08:52:23.115505', NULL, NULL, 'create', 'accounting', 'Account', 196, '2-01-02-01-0103', 'Account 2-01-02-01-0103 created', '{"company_id": 1, "code": "2-01-02-01-0103", "name": "Manager User (MGR002)", "type": "liability", "parent_id": 33, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(247, 1, '2026-10-29 08:52:23.119165', NULL, NULL, 'update', 'admin', 'User', 3, 'manager@solarkon.com', 'User manager@solarkon.com edited (login id)', '[{"field": "login_id", "old": null, "new": "manager@solarkon.com"}]', '127.0.0.1', '/'),
	(248, 1, '2026-10-29 08:52:23.123852', NULL, NULL, 'create', 'accounting', 'Account', 197, '2-01-02-01-0104', 'Account 2-01-02-01-0104 created', '{"company_id": 1, "code": "2-01-02-01-0104", "name": "Employee User (EMP001)", "type": "liability", "parent_id": 33, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(249, 1, '2026-10-29 08:52:23.126982', NULL, NULL, 'update', 'admin', 'User', 4, 'emp@solarkon.com', 'User emp@solarkon.com edited (login id)', '[{"field": "login_id", "old": null, "new": "emp@solarkon.com"}]', '127.0.0.1', '/'),
	(250, 1, '2026-10-29 08:52:23.132118', NULL, NULL, 'create', 'accounting', 'Account', 198, '2-01-02-01-0105', 'Account 2-01-02-01-0105 created', '{"company_id": 1, "code": "2-01-02-01-0105", "name": "John Doe (EMP002)", "type": "liability", "parent_id": 33, "level": 5, "is_active": true}', '127.0.0.1', '/'),
	(251, 1, '2026-10-29 08:52:23.136628', NULL, NULL, 'update', 'admin', 'User', 5, 'john.doe@solarkon.com', 'User john.doe@solarkon.com edited (login id)', '[{"field": "login_id", "old": null, "new": "john.doe@solarkon.com"}]', '127.0.0.1', '/'),
	(282, 2, '2026-10-29 08:52:24.396057', 1, 'Administrator', 'create', 'accounting', 'Account', 199, '1', 'Account 1 created', '{"company_id": 2, "code": "1", "name": "Assets", "type": "asset", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(283, 2, '2026-10-29 08:52:24.400721', 1, 'Administrator', 'create', 'accounting', 'Account', 200, '1-01', 'Account 1-01 created', '{"company_id": 2, "code": "1-01", "name": "Current Assets", "type": "asset", "parent_id": 199, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(284, 2, '2026-10-29 08:52:24.405282', 1, 'Administrator', 'create', 'accounting', 'Account', 201, '1-01-01', 'Account 1-01-01 created', '{"company_id": 2, "code": "1-01-01", "name": "Cash & Cash Equivalents", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true, "cash_flow_activity": "cash"}', '127.0.0.1', '/superadmin/companies/'),
	(285, 2, '2026-10-29 08:52:24.409883', 1, 'Administrator', 'create', 'accounting', 'Account', 202, '1-01-01-01', 'Account 1-01-01-01 created', '{"company_id": 2, "code": "1-01-01-01", "name": "Cash in Hand", "type": "asset", "parent_id": 201, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(286, 2, '2026-10-29 08:52:24.414289', 1, 'Administrator', 'create', 'accounting', 'Account', 203, '1-01-01-02', 'Account 1-01-01-02 created', '{"company_id": 2, "code": "1-01-01-02", "name": "Bank Accounts", "type": "asset", "parent_id": 201, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(287, 2, '2026-10-29 08:52:24.418405', 1, 'Administrator', 'create', 'accounting', 'Account', 204, '1-01-02', 'Account 1-01-02 created', '{"company_id": 2, "code": "1-01-02", "name": "Trade Receivables", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(288, 2, '2026-10-29 08:52:24.422179', 1, 'Administrator', 'create', 'accounting', 'Account', 205, '1-01-02-01', 'Account 1-01-02-01 created', '{"company_id": 2, "code": "1-01-02-01", "name": "Trade Debtors", "type": "asset", "parent_id": 204, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(289, 2, '2026-10-29 08:52:24.425973', 1, 'Administrator', 'create', 'accounting', 'Account', 206, '1-01-02-02', 'Account 1-01-02-02 created', '{"company_id": 2, "code": "1-01-02-02", "name": "Doubtful Receivables", "type": "asset", "parent_id": 204, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(290, 2, '2026-10-29 08:52:24.429672', 1, 'Administrator', 'create', 'accounting', 'Account', 207, '1-01-03', 'Account 1-01-03 created', '{"company_id": 2, "code": "1-01-03", "name": "Other Receivables", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(291, 2, '2026-10-29 08:52:24.433381', 1, 'Administrator', 'create', 'accounting', 'Account', 208, '1-01-03-01', 'Account 1-01-03-01 created', '{"company_id": 2, "code": "1-01-03-01", "name": "Employee Loans & Advances", "type": "asset", "parent_id": 207, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(292, 2, '2026-10-29 08:52:24.437256', 1, 'Administrator', 'create', 'accounting', 'Account', 209, '1-01-03-02', 'Account 1-01-03-02 created', '{"company_id": 2, "code": "1-01-03-02", "name": "Advances to Suppliers", "type": "asset", "parent_id": 207, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(293, 2, '2026-10-29 08:52:24.441065', 1, 'Administrator', 'create', 'accounting', 'Account', 210, '1-01-04', 'Account 1-01-04 created', '{"company_id": 2, "code": "1-01-04", "name": "Inventories", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(294, 2, '2026-10-29 08:52:24.444824', 1, 'Administrator', 'create', 'accounting', 'Account', 211, '1-01-04-01', 'Account 1-01-04-01 created', '{"company_id": 2, "code": "1-01-04-01", "name": "Trading Goods Stock", "type": "asset", "parent_id": 210, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(295, 2, '2026-10-29 08:52:24.448614', 1, 'Administrator', 'create', 'accounting', 'Account', 212, '1-01-05', 'Account 1-01-05 created', '{"company_id": 2, "code": "1-01-05", "name": "Tax Assets", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(296, 2, '2026-10-29 08:52:24.45246', 1, 'Administrator', 'create', 'accounting', 'Account', 213, '1-01-05-01', 'Account 1-01-05-01 created', '{"company_id": 2, "code": "1-01-05-01", "name": "Input Sales Tax", "type": "asset", "parent_id": 212, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(297, 2, '2026-10-29 08:52:24.456618', 1, 'Administrator', 'create', 'accounting', 'Account', 214, '1-01-05-02', 'Account 1-01-05-02 created', '{"company_id": 2, "code": "1-01-05-02", "name": "WHT Receivable", "type": "asset", "parent_id": 212, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(298, 2, '2026-10-29 08:52:24.460726', 1, 'Administrator', 'create', 'accounting', 'Account', 215, '1-01-06', 'Account 1-01-06 created', '{"company_id": 2, "code": "1-01-06", "name": "Prepayments & Other", "type": "asset", "parent_id": 200, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(299, 2, '2026-10-29 08:52:24.465001', 1, 'Administrator', 'create', 'accounting', 'Account', 216, '1-01-06-01', 'Account 1-01-06-01 created', '{"company_id": 2, "code": "1-01-06-01", "name": "Suspense & Clearing", "type": "asset", "parent_id": 215, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(300, 2, '2026-10-29 08:52:24.469016', 1, 'Administrator', 'create', 'accounting', 'Account', 217, '1-01-06-02', 'Account 1-01-06-02 created', '{"company_id": 2, "code": "1-01-06-02", "name": "Prepaid Expenses", "type": "asset", "parent_id": 215, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(301, 2, '2026-10-29 08:52:24.472895', 1, 'Administrator', 'create', 'accounting', 'Account', 218, '1-01-06-03', 'Account 1-01-06-03 created', '{"company_id": 2, "code": "1-01-06-03", "name": "Other Current Assets", "type": "asset", "parent_id": 215, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(302, 2, '2026-10-29 08:52:24.476717', 1, 'Administrator', 'create', 'accounting', 'Account', 219, '1-02', 'Account 1-02 created', '{"company_id": 2, "code": "1-02", "name": "Non-Current Assets", "type": "asset", "parent_id": 199, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "investing"}', '127.0.0.1', '/superadmin/companies/'),
	(303, 2, '2026-10-29 08:52:24.480832', 1, 'Administrator', 'create', 'accounting', 'Account', 220, '1-02-01', 'Account 1-02-01 created', '{"company_id": 2, "code": "1-02-01", "name": "Property, Plant & Equipment", "type": "asset", "parent_id": 219, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(304, 2, '2026-10-29 08:52:24.484668', 1, 'Administrator', 'create', 'accounting', 'Account', 221, '1-02-01-01', 'Account 1-02-01-01 created', '{"company_id": 2, "code": "1-02-01-01", "name": "Owned Assets", "type": "asset", "parent_id": 220, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(305, 2, '2026-10-29 08:52:24.489048', 1, 'Administrator', 'create', 'accounting', 'Account', 222, '1-02-02', 'Account 1-02-02 created', '{"company_id": 2, "code": "1-02-02", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 219, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(306, 2, '2026-10-29 08:52:24.49308', 1, 'Administrator', 'create', 'accounting', 'Account', 223, '1-02-02-01', 'Account 1-02-02-01 created', '{"company_id": 2, "code": "1-02-02-01", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 222, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(307, 2, '2026-10-29 08:52:24.496861', 1, 'Administrator', 'create', 'accounting', 'Account', 224, '1-02-03', 'Account 1-02-03 created', '{"company_id": 2, "code": "1-02-03", "name": "Intangible Assets", "type": "asset", "parent_id": 219, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(308, 2, '2026-10-29 08:52:24.500661', 1, 'Administrator', 'create', 'accounting', 'Account', 225, '1-02-03-01', 'Account 1-02-03-01 created', '{"company_id": 2, "code": "1-02-03-01", "name": "Intangibles", "type": "asset", "parent_id": 224, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(309, 2, '2026-10-29 08:52:24.503085', 1, 'Administrator', 'create', 'accounting', 'Account', 226, '2', 'Account 2 created', '{"company_id": 2, "code": "2", "name": "Liabilities", "type": "liability", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(310, 2, '2026-10-29 08:52:24.507009', 1, 'Administrator', 'create', 'accounting', 'Account', 227, '2-01', 'Account 2-01 created', '{"company_id": 2, "code": "2-01", "name": "Current Liabilities", "type": "liability", "parent_id": 226, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(311, 2, '2026-10-29 08:52:24.510706', 1, 'Administrator', 'create', 'accounting', 'Account', 228, '2-01-01', 'Account 2-01-01 created', '{"company_id": 2, "code": "2-01-01", "name": "Trade Payables", "type": "liability", "parent_id": 227, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(312, 2, '2026-10-29 08:52:24.514873', 1, 'Administrator', 'create', 'accounting', 'Account', 229, '2-01-01-01', 'Account 2-01-01-01 created', '{"company_id": 2, "code": "2-01-01-01", "name": "Trade Creditors", "type": "liability", "parent_id": 228, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(313, 2, '2026-10-29 08:52:24.518673', 1, 'Administrator', 'create', 'accounting', 'Account', 230, '2-01-02', 'Account 2-01-02 created', '{"company_id": 2, "code": "2-01-02", "name": "Accrued & Payroll Liabilities", "type": "liability", "parent_id": 227, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(314, 2, '2026-10-29 08:52:24.523023', 1, 'Administrator', 'create', 'accounting', 'Account', 231, '2-01-02-01', 'Account 2-01-02-01 created', '{"company_id": 2, "code": "2-01-02-01", "name": "Employee Payables", "type": "liability", "parent_id": 230, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(315, 2, '2026-10-29 08:52:24.527344', 1, 'Administrator', 'create', 'accounting', 'Account', 232, '2-01-02-02', 'Account 2-01-02-02 created', '{"company_id": 2, "code": "2-01-02-02", "name": "Payroll Liabilities", "type": "liability", "parent_id": 230, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(316, 2, '2026-10-29 08:52:24.531296', 1, 'Administrator', 'create', 'accounting', 'Account', 233, '2-01-02-03', 'Account 2-01-02-03 created', '{"company_id": 2, "code": "2-01-02-03", "name": "Accrued Expenses", "type": "liability", "parent_id": 230, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(317, 2, '2026-10-29 08:52:24.535148', 1, 'Administrator', 'create', 'accounting', 'Account', 234, '2-01-03', 'Account 2-01-03 created', '{"company_id": 2, "code": "2-01-03", "name": "Tax Liabilities", "type": "liability", "parent_id": 227, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(318, 2, '2026-10-29 08:52:24.53897', 1, 'Administrator', 'create', 'accounting', 'Account', 235, '2-01-03-01', 'Account 2-01-03-01 created', '{"company_id": 2, "code": "2-01-03-01", "name": "Output Sales Tax", "type": "liability", "parent_id": 234, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(319, 2, '2026-10-29 08:52:24.542683', 1, 'Administrator', 'create', 'accounting', 'Account', 236, '2-01-03-02', 'Account 2-01-03-02 created', '{"company_id": 2, "code": "2-01-03-02", "name": "Income Tax Payable", "type": "liability", "parent_id": 234, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(320, 2, '2026-10-29 08:52:24.546538', 1, 'Administrator', 'create', 'accounting', 'Account', 237, '2-01-03-03', 'Account 2-01-03-03 created', '{"company_id": 2, "code": "2-01-03-03", "name": "WHT Payable", "type": "liability", "parent_id": 234, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(321, 2, '2026-10-29 08:52:24.550455', 1, 'Administrator', 'create', 'accounting', 'Account', 238, '2-01-03-04', 'Account 2-01-03-04 created', '{"company_id": 2, "code": "2-01-03-04", "name": "Further Tax Payable", "type": "liability", "parent_id": 234, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(322, 2, '2026-10-29 08:52:24.554304', 1, 'Administrator', 'create', 'accounting', 'Account', 239, '2-01-04', 'Account 2-01-04 created', '{"company_id": 2, "code": "2-01-04", "name": "Advances from Customers", "type": "liability", "parent_id": 227, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(323, 2, '2026-10-29 08:52:24.558291', 1, 'Administrator', 'create', 'accounting', 'Account', 240, '2-01-04-01', 'Account 2-01-04-01 created', '{"company_id": 2, "code": "2-01-04-01", "name": "Customer Advances", "type": "liability", "parent_id": 239, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(324, 2, '2026-10-29 08:52:24.562639', 1, 'Administrator', 'create', 'accounting', 'Account', 241, '2-02', 'Account 2-02 created', '{"company_id": 2, "code": "2-02", "name": "Non-Current Liabilities", "type": "liability", "parent_id": 226, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/superadmin/companies/'),
	(325, 2, '2026-10-29 08:52:24.566519', 1, 'Administrator', 'create', 'accounting', 'Account', 242, '2-02-01', 'Account 2-02-01 created', '{"company_id": 2, "code": "2-02-01", "name": "Long-term Loans", "type": "liability", "parent_id": 241, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(326, 2, '2026-10-29 08:52:24.570346', 1, 'Administrator', 'create', 'accounting', 'Account', 243, '2-02-01-01', 'Account 2-02-01-01 created', '{"company_id": 2, "code": "2-02-01-01", "name": "Long-term Loans", "type": "liability", "parent_id": 242, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(327, 2, '2026-10-29 08:52:24.574449', 1, 'Administrator', 'create', 'accounting', 'Account', 244, '2-02-02', 'Account 2-02-02 created', '{"company_id": 2, "code": "2-02-02", "name": "Employee End-of-Service Benefits", "type": "liability", "parent_id": 241, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(328, 2, '2026-10-29 08:52:24.578459', 1, 'Administrator', 'create', 'accounting', 'Account', 245, '2-02-02-01', 'Account 2-02-02-01 created', '{"company_id": 2, "code": "2-02-02-01", "name": "EOSB Provision", "type": "liability", "parent_id": 244, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(329, 2, '2026-10-29 08:52:24.580949', 1, 'Administrator', 'create', 'accounting', 'Account', 246, '3', 'Account 3 created', '{"company_id": 2, "code": "3", "name": "Equity", "type": "equity", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/superadmin/companies/'),
	(330, 2, '2026-10-29 08:52:24.58485', 1, 'Administrator', 'create', 'accounting', 'Account', 247, '3-01', 'Account 3-01 created', '{"company_id": 2, "code": "3-01", "name": "Capital", "type": "equity", "parent_id": 246, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(331, 2, '2026-10-29 08:52:24.588702', 1, 'Administrator', 'create', 'accounting', 'Account', 248, '3-01-01', 'Account 3-01-01 created', '{"company_id": 2, "code": "3-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 247, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(332, 2, '2026-10-29 08:52:24.59259', 1, 'Administrator', 'create', 'accounting', 'Account', 249, '3-01-01-01', 'Account 3-01-01-01 created', '{"company_id": 2, "code": "3-01-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 248, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(333, 2, '2026-10-29 08:52:24.596546', 1, 'Administrator', 'create', 'accounting', 'Account', 250, '3-02', 'Account 3-02 created', '{"company_id": 2, "code": "3-02", "name": "Reserves & Retained Earnings", "type": "equity", "parent_id": 246, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(334, 2, '2026-10-29 08:52:24.60079', 1, 'Administrator', 'create', 'accounting', 'Account', 251, '3-02-01', 'Account 3-02-01 created', '{"company_id": 2, "code": "3-02-01", "name": "Retained Earnings", "type": "equity", "parent_id": 250, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(335, 2, '2026-10-29 08:52:24.605156', 1, 'Administrator', 'create', 'accounting', 'Account', 252, '3-02-01-01', 'Account 3-02-01-01 created', '{"company_id": 2, "code": "3-02-01-01", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 251, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(336, 2, '2026-10-29 08:52:24.609577', 1, 'Administrator', 'create', 'accounting', 'Account', 253, '3-02-01-02', 'Account 3-02-01-02 created', '{"company_id": 2, "code": "3-02-01-02", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 251, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(337, 2, '2026-10-29 08:52:24.615678', 1, 'Administrator', 'create', 'accounting', 'Account', 254, '3-02-02', 'Account 3-02-02 created', '{"company_id": 2, "code": "3-02-02", "name": "Dividends", "type": "equity", "parent_id": 250, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(338, 2, '2026-10-29 08:52:24.620466', 1, 'Administrator', 'create', 'accounting', 'Account', 255, '3-02-02-01', 'Account 3-02-02-01 created', '{"company_id": 2, "code": "3-02-02-01", "name": "Dividends", "type": "equity", "parent_id": 254, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(339, 2, '2026-10-29 08:52:24.624955', 1, 'Administrator', 'create', 'accounting', 'Account', 256, '3-02-03', 'Account 3-02-03 created', '{"company_id": 2, "code": "3-02-03", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 250, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(340, 2, '2026-10-29 08:52:24.629016', 1, 'Administrator', 'create', 'accounting', 'Account', 257, '3-02-03-01', 'Account 3-02-03-01 created', '{"company_id": 2, "code": "3-02-03-01", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 256, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(341, 2, '2026-10-29 08:52:24.63163', 1, 'Administrator', 'create', 'accounting', 'Account', 258, '4', 'Account 4 created', '{"company_id": 2, "code": "4", "name": "Revenue", "type": "revenue", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(342, 2, '2026-10-29 08:52:24.636187', 1, 'Administrator', 'create', 'accounting', 'Account', 259, '4-01', 'Account 4-01 created', '{"company_id": 2, "code": "4-01", "name": "Sales", "type": "revenue", "parent_id": 258, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales"}', '127.0.0.1', '/superadmin/companies/'),
	(343, 2, '2026-10-29 08:52:24.641152', 1, 'Administrator', 'create', 'accounting', 'Account', 260, '4-01-01', 'Account 4-01-01 created', '{"company_id": 2, "code": "4-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 259, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(344, 2, '2026-10-29 08:52:24.645228', 1, 'Administrator', 'create', 'accounting', 'Account', 261, '4-01-01-01', 'Account 4-01-01-01 created', '{"company_id": 2, "code": "4-01-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 260, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(345, 2, '2026-10-29 08:52:24.649353', 1, 'Administrator', 'create', 'accounting', 'Account', 262, '4-01-02', 'Account 4-01-02 created', '{"company_id": 2, "code": "4-01-02", "name": "Service Income", "type": "revenue", "parent_id": 259, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(346, 2, '2026-10-29 08:52:24.654272', 1, 'Administrator', 'create', 'accounting', 'Account', 263, '4-01-02-01', 'Account 4-01-02-01 created', '{"company_id": 2, "code": "4-01-02-01", "name": "Service Income", "type": "revenue", "parent_id": 262, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(347, 2, '2026-10-29 08:52:24.659342', 1, 'Administrator', 'create', 'accounting', 'Account', 264, '4-02', 'Account 4-02 created', '{"company_id": 2, "code": "4-02", "name": "Sales Returns & Discounts", "type": "revenue", "parent_id": 258, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales_returns"}', '127.0.0.1', '/superadmin/companies/'),
	(348, 2, '2026-10-29 08:52:24.664334', 1, 'Administrator', 'create', 'accounting', 'Account', 265, '4-02-01', 'Account 4-02-01 created', '{"company_id": 2, "code": "4-02-01", "name": "Sales Returns", "type": "revenue", "parent_id": 264, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(349, 2, '2026-10-29 08:52:24.669318', 1, 'Administrator', 'create', 'accounting', 'Account', 266, '4-02-01-01', 'Account 4-02-01-01 created', '{"company_id": 2, "code": "4-02-01-01", "name": "Sales Returns", "type": "revenue", "parent_id": 265, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(350, 2, '2026-10-29 08:52:24.67443', 1, 'Administrator', 'create', 'accounting', 'Account', 267, '4-02-02', 'Account 4-02-02 created', '{"company_id": 2, "code": "4-02-02", "name": "Discounts Allowed", "type": "revenue", "parent_id": 264, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(351, 2, '2026-10-29 08:52:24.679508', 1, 'Administrator', 'create', 'accounting', 'Account', 268, '4-02-02-01', 'Account 4-02-02-01 created', '{"company_id": 2, "code": "4-02-02-01", "name": "Discounts Allowed", "type": "revenue", "parent_id": 267, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(352, 2, '2026-10-29 08:52:24.684402', 1, 'Administrator', 'create', 'accounting', 'Account', 269, '4-03', 'Account 4-03 created', '{"company_id": 2, "code": "4-03", "name": "Other Income", "type": "revenue", "parent_id": 258, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_income"}', '127.0.0.1', '/superadmin/companies/'),
	(353, 2, '2026-10-29 08:52:24.689403', 1, 'Administrator', 'create', 'accounting', 'Account', 270, '4-03-01', 'Account 4-03-01 created', '{"company_id": 2, "code": "4-03-01", "name": "Other Income", "type": "revenue", "parent_id": 269, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(354, 2, '2026-10-29 08:52:24.694254', 1, 'Administrator', 'create', 'accounting', 'Account', 271, '4-03-01-01', 'Account 4-03-01-01 created', '{"company_id": 2, "code": "4-03-01-01", "name": "Other Income", "type": "revenue", "parent_id": 270, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(355, 2, '2026-10-29 08:52:24.697273', 1, 'Administrator', 'create', 'accounting', 'Account', 272, '5', 'Account 5 created', '{"company_id": 2, "code": "5", "name": "Expenses", "type": "expense", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(356, 2, '2026-10-29 08:52:24.70193', 1, 'Administrator', 'create', 'accounting', 'Account', 273, '5-01', 'Account 5-01 created', '{"company_id": 2, "code": "5-01", "name": "Cost of Sales", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "cost_of_sales"}', '127.0.0.1', '/superadmin/companies/'),
	(357, 2, '2026-10-29 08:52:24.70687', 1, 'Administrator', 'create', 'accounting', 'Account', 274, '5-01-01', 'Account 5-01-01 created', '{"company_id": 2, "code": "5-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 273, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(358, 2, '2026-10-29 08:52:24.711752', 1, 'Administrator', 'create', 'accounting', 'Account', 275, '5-01-01-01', 'Account 5-01-01-01 created', '{"company_id": 2, "code": "5-01-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 274, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(359, 2, '2026-10-29 08:52:24.716802', 1, 'Administrator', 'create', 'accounting', 'Account', 276, '5-01-02', 'Account 5-01-02 created', '{"company_id": 2, "code": "5-01-02", "name": "Stock Losses, Scrap & Adjustments", "type": "expense", "parent_id": 273, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(360, 2, '2026-10-29 08:52:24.721784', 1, 'Administrator', 'create', 'accounting', 'Account', 277, '5-01-02-01', 'Account 5-01-02-01 created', '{"company_id": 2, "code": "5-01-02-01", "name": "Stock Losses & Scrap", "type": "expense", "parent_id": 276, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(361, 2, '2026-10-29 08:52:24.726931', 1, 'Administrator', 'create', 'accounting', 'Account', 278, '5-02', 'Account 5-02 created', '{"company_id": 2, "code": "5-02", "name": "Administrative Expenses", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "admin"}', '127.0.0.1', '/superadmin/companies/'),
	(362, 2, '2026-10-29 08:52:24.73164', 1, 'Administrator', 'create', 'accounting', 'Account', 279, '5-02-01', 'Account 5-02-01 created', '{"company_id": 2, "code": "5-02-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 278, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(363, 2, '2026-10-29 08:52:24.736478', 1, 'Administrator', 'create', 'accounting', 'Account', 280, '5-02-01-01', 'Account 5-02-01-01 created', '{"company_id": 2, "code": "5-02-01-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 279, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(364, 2, '2026-10-29 08:52:24.741636', 1, 'Administrator', 'create', 'accounting', 'Account', 281, '5-02-02', 'Account 5-02-02 created', '{"company_id": 2, "code": "5-02-02", "name": "Rent & Utilities", "type": "expense", "parent_id": 278, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(365, 2, '2026-10-29 08:52:24.746562', 1, 'Administrator', 'create', 'accounting', 'Account', 282, '5-02-02-01', 'Account 5-02-02-01 created', '{"company_id": 2, "code": "5-02-02-01", "name": "Rent & Utilities", "type": "expense", "parent_id": 281, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(366, 2, '2026-10-29 08:52:24.75152', 1, 'Administrator', 'create', 'accounting', 'Account', 283, '5-02-03', 'Account 5-02-03 created', '{"company_id": 2, "code": "5-02-03", "name": "Office & Supplies", "type": "expense", "parent_id": 278, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(367, 2, '2026-10-29 08:52:24.756513', 1, 'Administrator', 'create', 'accounting', 'Account', 284, '5-02-03-01', 'Account 5-02-03-01 created', '{"company_id": 2, "code": "5-02-03-01", "name": "Office & Supplies", "type": "expense", "parent_id": 283, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(368, 2, '2026-10-29 08:52:24.762011', 1, 'Administrator', 'create', 'accounting', 'Account', 285, '5-02-04', 'Account 5-02-04 created', '{"company_id": 2, "code": "5-02-04", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 278, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(369, 2, '2026-10-29 08:52:24.76704', 1, 'Administrator', 'create', 'accounting', 'Account', 286, '5-02-04-01', 'Account 5-02-04-01 created', '{"company_id": 2, "code": "5-02-04-01", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 285, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(370, 2, '2026-10-29 08:52:24.771892', 1, 'Administrator', 'create', 'accounting', 'Account', 287, '5-02-05', 'Account 5-02-05 created', '{"company_id": 2, "code": "5-02-05", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 278, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(371, 2, '2026-10-29 08:52:24.776832', 1, 'Administrator', 'create', 'accounting', 'Account', 288, '5-02-05-01', 'Account 5-02-05-01 created', '{"company_id": 2, "code": "5-02-05-01", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 287, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(372, 2, '2026-10-29 08:52:24.781716', 1, 'Administrator', 'create', 'accounting', 'Account', 289, '5-03', 'Account 5-03 created', '{"company_id": 2, "code": "5-03", "name": "Selling & Distribution", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "selling_distribution"}', '127.0.0.1', '/superadmin/companies/'),
	(373, 2, '2026-10-29 08:52:24.786658', 1, 'Administrator', 'create', 'accounting', 'Account', 290, '5-03-01', 'Account 5-03-01 created', '{"company_id": 2, "code": "5-03-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 289, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(374, 2, '2026-10-29 08:52:24.791564', 1, 'Administrator', 'create', 'accounting', 'Account', 291, '5-03-01-01', 'Account 5-03-01-01 created', '{"company_id": 2, "code": "5-03-01-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 290, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(375, 2, '2026-10-29 08:52:24.796705', 1, 'Administrator', 'create', 'accounting', 'Account', 292, '5-03-02', 'Account 5-03-02 created', '{"company_id": 2, "code": "5-03-02", "name": "Commissions", "type": "expense", "parent_id": 289, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(376, 2, '2026-10-29 08:52:24.801829', 1, 'Administrator', 'create', 'accounting', 'Account', 293, '5-03-02-01', 'Account 5-03-02-01 created', '{"company_id": 2, "code": "5-03-02-01", "name": "Commissions", "type": "expense", "parent_id": 292, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(377, 2, '2026-10-29 08:52:24.8069', 1, 'Administrator', 'create', 'accounting', 'Account', 294, '5-03-03', 'Account 5-03-03 created', '{"company_id": 2, "code": "5-03-03", "name": "Marketing & Advertising", "type": "expense", "parent_id": 289, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(378, 2, '2026-10-29 08:52:24.812184', 1, 'Administrator', 'create', 'accounting', 'Account', 295, '5-03-03-01', 'Account 5-03-03-01 created', '{"company_id": 2, "code": "5-03-03-01", "name": "Marketing & Advertising", "type": "expense", "parent_id": 294, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(379, 2, '2026-10-29 08:52:24.817095', 1, 'Administrator', 'create', 'accounting', 'Account', 296, '5-04', 'Account 5-04 created', '{"company_id": 2, "code": "5-04", "name": "Other Operating Expenses", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_operating"}', '127.0.0.1', '/superadmin/companies/'),
	(380, 2, '2026-10-29 08:52:24.821902', 1, 'Administrator', 'create', 'accounting', 'Account', 297, '5-04-01', 'Account 5-04-01 created', '{"company_id": 2, "code": "5-04-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 296, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(381, 2, '2026-10-29 08:52:24.82684', 1, 'Administrator', 'create', 'accounting', 'Account', 298, '5-04-01-01', 'Account 5-04-01-01 created', '{"company_id": 2, "code": "5-04-01-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 297, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(382, 2, '2026-10-29 08:52:24.832115', 1, 'Administrator', 'create', 'accounting', 'Account', 299, '5-05', 'Account 5-05 created', '{"company_id": 2, "code": "5-05", "name": "Finance Costs", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "finance_cost"}', '127.0.0.1', '/superadmin/companies/'),
	(383, 2, '2026-10-29 08:52:24.837375', 1, 'Administrator', 'create', 'accounting', 'Account', 300, '5-05-01', 'Account 5-05-01 created', '{"company_id": 2, "code": "5-05-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 299, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(384, 2, '2026-10-29 08:52:24.843084', 1, 'Administrator', 'create', 'accounting', 'Account', 301, '5-05-01-01', 'Account 5-05-01-01 created', '{"company_id": 2, "code": "5-05-01-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 300, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(385, 2, '2026-10-29 08:52:24.848981', 1, 'Administrator', 'create', 'accounting', 'Account', 302, '5-06', 'Account 5-06 created', '{"company_id": 2, "code": "5-06", "name": "Taxation", "type": "expense", "parent_id": 272, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "income_tax"}', '127.0.0.1', '/superadmin/companies/'),
	(386, 2, '2026-10-29 08:52:24.854835', 1, 'Administrator', 'create', 'accounting', 'Account', 303, '5-06-01', 'Account 5-06-01 created', '{"company_id": 2, "code": "5-06-01", "name": "Income Tax", "type": "expense", "parent_id": 302, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(387, 2, '2026-10-29 08:52:24.86073', 1, 'Administrator', 'create', 'accounting', 'Account', 304, '5-06-01-01', 'Account 5-06-01-01 created', '{"company_id": 2, "code": "5-06-01-01", "name": "Income Tax", "type": "expense", "parent_id": 303, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(388, 2, '2026-10-29 08:52:24.870462', 1, 'Administrator', 'create', 'accounting', 'Account', 305, '1-01-01-01-0001', 'Account 1-01-01-01-0001 created', '{"company_id": 2, "code": "1-01-01-01-0001", "name": "Main Cash", "type": "asset", "parent_id": 202, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(389, 2, '2026-10-29 08:52:24.87639', 1, 'Administrator', 'create', 'accounting', 'Account', 306, '1-01-02-01-0001', 'Account 1-01-02-01-0001 created', '{"company_id": 2, "code": "1-01-02-01-0001", "name": "Trade Debtors \u2014 General", "type": "asset", "parent_id": 205, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(390, 2, '2026-10-29 08:52:24.882333', 1, 'Administrator', 'create', 'accounting', 'Account', 307, '1-01-03-02-0001', 'Account 1-01-03-02-0001 created', '{"company_id": 2, "code": "1-01-03-02-0001", "name": "Advances to Suppliers \u2014 General", "type": "asset", "parent_id": 209, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(391, 2, '2026-10-29 08:52:24.888302', 1, 'Administrator', 'create', 'accounting', 'Account', 308, '1-01-04-01-0001', 'Account 1-01-04-01-0001 created', '{"company_id": 2, "code": "1-01-04-01-0001", "name": "Stock \u2014 General", "type": "asset", "parent_id": 211, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(392, 2, '2026-10-29 08:52:24.894174', 1, 'Administrator', 'create', 'accounting', 'Account', 309, '1-01-05-01-0001', 'Account 1-01-05-01-0001 created', '{"company_id": 2, "code": "1-01-05-01-0001", "name": "Input Sales Tax", "type": "asset", "parent_id": 213, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(393, 2, '2026-10-29 08:52:24.899919', 1, 'Administrator', 'create', 'accounting', 'Account', 310, '1-01-05-02-0001', 'Account 1-01-05-02-0001 created', '{"company_id": 2, "code": "1-01-05-02-0001", "name": "WHT Receivable", "type": "asset", "parent_id": 214, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(394, 2, '2026-10-29 08:52:24.906064', 1, 'Administrator', 'create', 'accounting', 'Account', 311, '1-01-06-01-0001', 'Account 1-01-06-01-0001 created', '{"company_id": 2, "code": "1-01-06-01-0001", "name": "Suspense Account", "type": "asset", "parent_id": 216, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(395, 2, '2026-10-29 08:52:24.911843', 1, 'Administrator', 'create', 'accounting', 'Account', 312, '1-01-06-02-0001', 'Account 1-01-06-02-0001 created', '{"company_id": 2, "code": "1-01-06-02-0001", "name": "Prepaid Expenses \u2014 General", "type": "asset", "parent_id": 217, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(396, 2, '2026-10-29 08:52:24.917578', 1, 'Administrator', 'create', 'accounting', 'Account', 313, '1-02-01-01-0001', 'Account 1-02-01-01-0001 created', '{"company_id": 2, "code": "1-02-01-01-0001", "name": "Fixed Assets \u2014 General", "type": "asset", "parent_id": 221, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(397, 2, '2026-10-29 08:52:24.923447', 1, 'Administrator', 'create', 'accounting', 'Account', 314, '1-02-02-01-0001', 'Account 1-02-02-01-0001 created', '{"company_id": 2, "code": "1-02-02-01-0001", "name": "Accumulated Depreciation \u2014 General", "type": "asset", "parent_id": 223, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES
	(398, 2, '2026-10-29 08:52:24.929127', 1, 'Administrator', 'create', 'accounting', 'Account', 315, '1-02-03-01-0001', 'Account 1-02-03-01-0001 created', '{"company_id": 2, "code": "1-02-03-01-0001", "name": "Intangibles \u2014 General", "type": "asset", "parent_id": 225, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(399, 2, '2026-10-29 08:52:24.934713', 1, 'Administrator', 'create', 'accounting', 'Account', 316, '2-01-01-01-0001', 'Account 2-01-01-01-0001 created', '{"company_id": 2, "code": "2-01-01-01-0001", "name": "Trade Creditors \u2014 General", "type": "liability", "parent_id": 229, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(400, 2, '2026-10-29 08:52:24.939938', 1, 'Administrator', 'create', 'accounting', 'Account', 317, '2-01-02-02-0001', 'Account 2-01-02-02-0001 created', '{"company_id": 2, "code": "2-01-02-02-0001", "name": "Salary Payable", "type": "liability", "parent_id": 232, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(401, 2, '2026-10-29 08:52:24.944911', 1, 'Administrator', 'create', 'accounting', 'Account', 318, '2-01-02-02-0002', 'Account 2-01-02-02-0002 created', '{"company_id": 2, "code": "2-01-02-02-0002", "name": "PF Payable", "type": "liability", "parent_id": 232, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(402, 2, '2026-10-29 08:52:24.949708', 1, 'Administrator', 'create', 'accounting', 'Account', 319, '2-01-02-02-0003', 'Account 2-01-02-02-0003 created', '{"company_id": 2, "code": "2-01-02-02-0003", "name": "Loan Deductions Clearing", "type": "liability", "parent_id": 232, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(403, 2, '2026-10-29 08:52:24.954575', 1, 'Administrator', 'create', 'accounting', 'Account', 320, '2-01-02-02-0004', 'Account 2-01-02-02-0004 created', '{"company_id": 2, "code": "2-01-02-02-0004", "name": "Other Payroll Deductions Payable", "type": "liability", "parent_id": 232, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(404, 2, '2026-10-29 08:52:24.959716', 1, 'Administrator', 'create', 'accounting', 'Account', 321, '2-01-02-03-0001', 'Account 2-01-02-03-0001 created', '{"company_id": 2, "code": "2-01-02-03-0001", "name": "Accrued Expenses \u2014 General", "type": "liability", "parent_id": 233, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(405, 2, '2026-10-29 08:52:24.964655', 1, 'Administrator', 'create', 'accounting', 'Account', 322, '2-01-03-01-0001', 'Account 2-01-03-01-0001 created', '{"company_id": 2, "code": "2-01-03-01-0001", "name": "Output Sales Tax", "type": "liability", "parent_id": 235, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(406, 2, '2026-10-29 08:52:24.969461', 1, 'Administrator', 'create', 'accounting', 'Account', 323, '2-01-03-02-0001', 'Account 2-01-03-02-0001 created', '{"company_id": 2, "code": "2-01-03-02-0001", "name": "Income Tax Payable", "type": "liability", "parent_id": 236, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(407, 2, '2026-10-29 08:52:24.974206', 1, 'Administrator', 'create', 'accounting', 'Account', 324, '2-01-03-03-0001', 'Account 2-01-03-03-0001 created', '{"company_id": 2, "code": "2-01-03-03-0001", "name": "WHT Payable", "type": "liability", "parent_id": 237, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(408, 2, '2026-10-29 08:52:24.979465', 1, 'Administrator', 'create', 'accounting', 'Account', 325, '2-01-03-04-0001', 'Account 2-01-03-04-0001 created', '{"company_id": 2, "code": "2-01-03-04-0001", "name": "Further Tax Payable", "type": "liability", "parent_id": 238, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(409, 2, '2026-10-29 08:52:24.984946', 1, 'Administrator', 'create', 'accounting', 'Account', 326, '2-01-04-01-0001', 'Account 2-01-04-01-0001 created', '{"company_id": 2, "code": "2-01-04-01-0001", "name": "Customer Advances \u2014 General", "type": "liability", "parent_id": 240, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(410, 2, '2026-10-29 08:52:24.98995', 1, 'Administrator', 'create', 'accounting', 'Account', 327, '2-02-01-01-0001', 'Account 2-02-01-01-0001 created', '{"company_id": 2, "code": "2-02-01-01-0001", "name": "Long-term Loans \u2014 General", "type": "liability", "parent_id": 243, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(411, 2, '2026-10-29 08:52:24.99516', 1, 'Administrator', 'create', 'accounting', 'Account', 328, '2-02-02-01-0001', 'Account 2-02-02-01-0001 created', '{"company_id": 2, "code": "2-02-02-01-0001", "name": "EOSB Provision \u2014 General", "type": "liability", "parent_id": 245, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(412, 2, '2026-10-29 08:52:25.000113', 1, 'Administrator', 'create', 'accounting', 'Account', 329, '3-01-01-01-0001', 'Account 3-01-01-01-0001 created', '{"company_id": 2, "code": "3-01-01-01-0001", "name": "Share Capital", "type": "equity", "parent_id": 249, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(413, 2, '2026-10-29 08:52:25.004966', 1, 'Administrator', 'create', 'accounting', 'Account', 330, '3-01-01-01-0002', 'Account 3-01-01-01-0002 created', '{"company_id": 2, "code": "3-01-01-01-0002", "name": "Suspense Equity", "type": "equity", "parent_id": 249, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(414, 2, '2026-10-29 08:52:25.00967', 1, 'Administrator', 'create', 'accounting', 'Account', 331, '3-02-01-01-0001', 'Account 3-02-01-01-0001 created', '{"company_id": 2, "code": "3-02-01-01-0001", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 252, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(415, 2, '2026-10-29 08:52:25.014664', 1, 'Administrator', 'create', 'accounting', 'Account', 332, '3-02-01-02-0001', 'Account 3-02-01-02-0001 created', '{"company_id": 2, "code": "3-02-01-02-0001", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 253, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(416, 2, '2026-10-29 08:52:25.019323', 1, 'Administrator', 'create', 'accounting', 'Account', 333, '3-02-02-01-0001', 'Account 3-02-02-01-0001 created', '{"company_id": 2, "code": "3-02-02-01-0001", "name": "Dividends", "type": "equity", "parent_id": 255, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(417, 2, '2026-10-29 08:52:25.023785', 1, 'Administrator', 'create', 'accounting', 'Account', 334, '3-02-03-01-0001', 'Account 3-02-03-01-0001 created', '{"company_id": 2, "code": "3-02-03-01-0001", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 257, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(418, 2, '2026-10-29 08:52:25.028487', 1, 'Administrator', 'create', 'accounting', 'Account', 335, '4-01-01-01-0001', 'Account 4-01-01-01-0001 created', '{"company_id": 2, "code": "4-01-01-01-0001", "name": "Sales \u2014 General", "type": "revenue", "parent_id": 261, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(419, 2, '2026-10-29 08:52:25.033094', 1, 'Administrator', 'create', 'accounting', 'Account', 336, '4-01-02-01-0001', 'Account 4-01-02-01-0001 created', '{"company_id": 2, "code": "4-01-02-01-0001", "name": "Service Income \u2014 General", "type": "revenue", "parent_id": 263, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(420, 2, '2026-10-29 08:52:25.037957', 1, 'Administrator', 'create', 'accounting', 'Account', 337, '4-02-01-01-0001', 'Account 4-02-01-01-0001 created', '{"company_id": 2, "code": "4-02-01-01-0001", "name": "Sales Returns \u2014 General", "type": "revenue", "parent_id": 266, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(421, 2, '2026-10-29 08:52:25.042933', 1, 'Administrator', 'create', 'accounting', 'Account', 338, '4-02-02-01-0001', 'Account 4-02-02-01-0001 created', '{"company_id": 2, "code": "4-02-02-01-0001", "name": "Discounts Allowed \u2014 General", "type": "revenue", "parent_id": 268, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(422, 2, '2026-10-29 08:52:25.04795', 1, 'Administrator', 'create', 'accounting', 'Account', 339, '4-03-01-01-0001', 'Account 4-03-01-01-0001 created', '{"company_id": 2, "code": "4-03-01-01-0001", "name": "Other Income \u2014 General", "type": "revenue", "parent_id": 271, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(423, 2, '2026-10-29 08:52:25.052776', 1, 'Administrator', 'create', 'accounting', 'Account', 340, '5-01-01-01-0001', 'Account 5-01-01-01-0001 created', '{"company_id": 2, "code": "5-01-01-01-0001", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 275, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(424, 2, '2026-10-29 08:52:25.057919', 1, 'Administrator', 'create', 'accounting', 'Account', 341, '5-01-02-01-0001', 'Account 5-01-02-01-0001 created', '{"company_id": 2, "code": "5-01-02-01-0001", "name": "Scrap / Write-off", "type": "expense", "parent_id": 277, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(425, 2, '2026-10-29 08:52:25.063554', 1, 'Administrator', 'create', 'accounting', 'Account', 342, '5-01-02-01-0002', 'Account 5-01-02-01-0002 created', '{"company_id": 2, "code": "5-01-02-01-0002", "name": "Inventory Adjustment", "type": "expense", "parent_id": 277, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(426, 2, '2026-10-29 08:52:25.069233', 1, 'Administrator', 'create', 'accounting', 'Account', 343, '5-01-02-01-0003', 'Account 5-01-02-01-0003 created', '{"company_id": 2, "code": "5-01-02-01-0003", "name": "Consumption Expense", "type": "expense", "parent_id": 277, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(427, 2, '2026-10-29 08:52:25.074536', 1, 'Administrator', 'create', 'accounting', 'Account', 344, '5-01-02-01-0004', 'Account 5-01-02-01-0004 created', '{"company_id": 2, "code": "5-01-02-01-0004", "name": "Inventory Cost Variance", "type": "expense", "parent_id": 277, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(428, 2, '2026-10-29 08:52:25.079841', 1, 'Administrator', 'create', 'accounting', 'Account', 345, '5-02-01-01-0001', 'Account 5-02-01-01-0001 created', '{"company_id": 2, "code": "5-02-01-01-0001", "name": "Salary Expense", "type": "expense", "parent_id": 280, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(429, 2, '2026-10-29 08:52:25.085263', 1, 'Administrator', 'create', 'accounting', 'Account', 346, '5-02-01-01-0002', 'Account 5-02-01-01-0002 created', '{"company_id": 2, "code": "5-02-01-01-0002", "name": "PF Employer Expense", "type": "expense", "parent_id": 280, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(430, 2, '2026-10-29 08:52:25.090541', 1, 'Administrator', 'create', 'accounting', 'Account', 347, '5-02-02-01-0001', 'Account 5-02-02-01-0001 created', '{"company_id": 2, "code": "5-02-02-01-0001", "name": "Rent Expense", "type": "expense", "parent_id": 282, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(431, 2, '2026-10-29 08:52:25.095627', 1, 'Administrator', 'create', 'accounting', 'Account', 348, '5-02-02-01-0002', 'Account 5-02-02-01-0002 created', '{"company_id": 2, "code": "5-02-02-01-0002", "name": "Utilities Expense", "type": "expense", "parent_id": 282, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(432, 2, '2026-10-29 08:52:25.100874', 1, 'Administrator', 'create', 'accounting', 'Account', 349, '5-02-03-01-0001', 'Account 5-02-03-01-0001 created', '{"company_id": 2, "code": "5-02-03-01-0001", "name": "Office Supplies", "type": "expense", "parent_id": 284, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(433, 2, '2026-10-29 08:52:25.10565', 1, 'Administrator', 'create', 'accounting', 'Account', 350, '5-02-04-01-0001', 'Account 5-02-04-01-0001 created', '{"company_id": 2, "code": "5-02-04-01-0001", "name": "Depreciation Expense", "type": "expense", "parent_id": 286, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(434, 2, '2026-10-29 08:52:25.110611', 1, 'Administrator', 'create', 'accounting', 'Account', 351, '5-02-05-01-0001', 'Account 5-02-05-01-0001 created', '{"company_id": 2, "code": "5-02-05-01-0001", "name": "Fees, Taxes & Licenses \u2014 General", "type": "expense", "parent_id": 288, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(435, 2, '2026-10-29 08:52:25.115551', 1, 'Administrator', 'create', 'accounting', 'Account', 352, '5-03-01-01-0001', 'Account 5-03-01-01-0001 created', '{"company_id": 2, "code": "5-03-01-01-0001", "name": "Freight & Transportation \u2014 General", "type": "expense", "parent_id": 291, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(436, 2, '2026-10-29 08:52:25.120536', 1, 'Administrator', 'create', 'accounting', 'Account', 353, '5-03-02-01-0001', 'Account 5-03-02-01-0001 created', '{"company_id": 2, "code": "5-03-02-01-0001", "name": "Commissions \u2014 General", "type": "expense", "parent_id": 293, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(437, 2, '2026-10-29 08:52:25.125242', 1, 'Administrator', 'create', 'accounting', 'Account', 354, '5-03-03-01-0001', 'Account 5-03-03-01-0001 created', '{"company_id": 2, "code": "5-03-03-01-0001", "name": "Marketing & Advertising \u2014 General", "type": "expense", "parent_id": 295, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(438, 2, '2026-10-29 08:52:25.13003', 1, 'Administrator', 'create', 'accounting', 'Account', 355, '5-04-01-01-0001', 'Account 5-04-01-01-0001 created', '{"company_id": 2, "code": "5-04-01-01-0001", "name": "Other Expenses \u2014 General", "type": "expense", "parent_id": 298, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(439, 2, '2026-10-29 08:52:25.135133', 1, 'Administrator', 'create', 'accounting', 'Account', 356, '5-04-01-01-0002', 'Account 5-04-01-01-0002 created', '{"company_id": 2, "code": "5-04-01-01-0002", "name": "Loss/(Gain) on Disposal of Fixed Assets", "type": "expense", "parent_id": 298, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(440, 2, '2026-10-29 08:52:25.140125', 1, 'Administrator', 'create', 'accounting', 'Account', 357, '5-05-01-01-0001', 'Account 5-05-01-01-0001 created', '{"company_id": 2, "code": "5-05-01-01-0001", "name": "Bank Charges", "type": "expense", "parent_id": 301, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(441, 2, '2026-10-29 08:52:25.144905', 1, 'Administrator', 'create', 'accounting', 'Account', 358, '5-05-01-01-0002', 'Account 5-05-01-01-0002 created', '{"company_id": 2, "code": "5-05-01-01-0002", "name": "Interest Expense", "type": "expense", "parent_id": 301, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(442, 2, '2026-10-29 08:52:25.148624', 1, 'Administrator', 'create', 'accounting', 'Account', 359, '5-06-01-01-0001', 'Account 5-06-01-01-0001 created', '{"company_id": 2, "code": "5-06-01-01-0001", "name": "Income Tax Expense", "type": "expense", "parent_id": 304, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(443, 2, '2026-10-29 08:52:25.192621', 1, 'Administrator', 'create', 'settings', 'Company profile', 2, 'SolarKon Energy Solutions', 'Company profile SolarKon Energy Solutions created', '{"company_id": 2, "company_name": "SolarKon Energy Solutions", "country": "Pakistan", "fiscal_year_start_month": 1, "currency": "PKR", "currency_symbol": "Rs.", "date_format": "Y-m-d", "number_format": "en", "timezone": "Asia/Karachi"}', '127.0.0.1', '/superadmin/companies/'),
	(444, 2, '2026-10-29 08:52:25.202915', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 9, 'FY 2021', 'Accounting period FY 2021 created', '{"company_id": 2, "fiscal_year": "2021", "period_name": "FY 2021", "start_date": "2021-01-01", "end_date": "2021-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(445, 2, '2026-10-29 08:52:25.202919', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 10, 'FY 2022', 'Accounting period FY 2022 created', '{"company_id": 2, "fiscal_year": "2022", "period_name": "FY 2022", "start_date": "2022-01-01", "end_date": "2022-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(446, 2, '2026-10-29 08:52:25.202921', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 11, 'FY 2023', 'Accounting period FY 2023 created', '{"company_id": 2, "fiscal_year": "2023", "period_name": "FY 2023", "start_date": "2023-01-01", "end_date": "2023-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(447, 2, '2026-10-29 08:52:25.202922', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 12, 'FY 2024', 'Accounting period FY 2024 created', '{"company_id": 2, "fiscal_year": "2024", "period_name": "FY 2024", "start_date": "2024-01-01", "end_date": "2024-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(448, 2, '2026-10-29 08:52:25.202923', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 13, 'FY 2025', 'Accounting period FY 2025 created', '{"company_id": 2, "fiscal_year": "2025", "period_name": "FY 2025", "start_date": "2025-01-01", "end_date": "2025-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(449, 2, '2026-10-29 08:52:25.202924', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 14, 'FY 2026', 'Accounting period FY 2026 created', '{"company_id": 2, "fiscal_year": "2026", "period_name": "FY 2026", "start_date": "2026-01-01", "end_date": "2026-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(450, 2, '2026-10-29 08:52:25.202926', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 15, 'FY 2027', 'Accounting period FY 2027 created', '{"company_id": 2, "fiscal_year": "2027", "period_name": "FY 2027", "start_date": "2027-01-01", "end_date": "2027-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(451, 2, '2026-10-29 08:52:25.202927', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 16, 'FY 2028', 'Accounting period FY 2028 created', '{"company_id": 2, "fiscal_year": "2028", "period_name": "FY 2028", "start_date": "2028-01-01", "end_date": "2028-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(456, 3, '2026-10-29 08:52:25.355436', 1, 'Administrator', 'create', 'accounting', 'Account', 360, '1', 'Account 1 created', '{"company_id": 3, "code": "1", "name": "Assets", "type": "asset", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(457, 3, '2026-10-29 08:52:25.360652', 1, 'Administrator', 'create', 'accounting', 'Account', 361, '1-01', 'Account 1-01 created', '{"company_id": 3, "code": "1-01", "name": "Current Assets", "type": "asset", "parent_id": 360, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(458, 3, '2026-10-29 08:52:25.365949', 1, 'Administrator', 'create', 'accounting', 'Account', 362, '1-01-01', 'Account 1-01-01 created', '{"company_id": 3, "code": "1-01-01", "name": "Cash & Cash Equivalents", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true, "cash_flow_activity": "cash"}', '127.0.0.1', '/superadmin/companies/'),
	(459, 3, '2026-10-29 08:52:25.371056', 1, 'Administrator', 'create', 'accounting', 'Account', 363, '1-01-01-01', 'Account 1-01-01-01 created', '{"company_id": 3, "code": "1-01-01-01", "name": "Cash in Hand", "type": "asset", "parent_id": 362, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(460, 3, '2026-10-29 08:52:25.375945', 1, 'Administrator', 'create', 'accounting', 'Account', 364, '1-01-01-02', 'Account 1-01-01-02 created', '{"company_id": 3, "code": "1-01-01-02", "name": "Bank Accounts", "type": "asset", "parent_id": 362, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(461, 3, '2026-10-29 08:52:25.381019', 1, 'Administrator', 'create', 'accounting', 'Account', 365, '1-01-02', 'Account 1-01-02 created', '{"company_id": 3, "code": "1-01-02", "name": "Trade Receivables", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(462, 3, '2026-10-29 08:52:25.386231', 1, 'Administrator', 'create', 'accounting', 'Account', 366, '1-01-02-01', 'Account 1-01-02-01 created', '{"company_id": 3, "code": "1-01-02-01", "name": "Trade Debtors", "type": "asset", "parent_id": 365, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(463, 3, '2026-10-29 08:52:25.391641', 1, 'Administrator', 'create', 'accounting', 'Account', 367, '1-01-02-02', 'Account 1-01-02-02 created', '{"company_id": 3, "code": "1-01-02-02", "name": "Doubtful Receivables", "type": "asset", "parent_id": 365, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(464, 3, '2026-10-29 08:52:25.396915', 1, 'Administrator', 'create', 'accounting', 'Account', 368, '1-01-03', 'Account 1-01-03 created', '{"company_id": 3, "code": "1-01-03", "name": "Other Receivables", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(465, 3, '2026-10-29 08:52:25.402003', 1, 'Administrator', 'create', 'accounting', 'Account', 369, '1-01-03-01', 'Account 1-01-03-01 created', '{"company_id": 3, "code": "1-01-03-01", "name": "Employee Loans & Advances", "type": "asset", "parent_id": 368, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(466, 3, '2026-10-29 08:52:25.407263', 1, 'Administrator', 'create', 'accounting', 'Account', 370, '1-01-03-02', 'Account 1-01-03-02 created', '{"company_id": 3, "code": "1-01-03-02", "name": "Advances to Suppliers", "type": "asset", "parent_id": 368, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(454, 1, '2026-10-29 08:52:25.341467', 1, 'Administrator', 'create', 'admin', 'User', 7, 'owner.two@ref.test', 'User owner.two@ref.test created', '{"employee_code": "SA0007", "email": "owner.two@ref.test", "login_id": "owner.two@ref.test", "password_hash": "\u2022\u2022\u2022", "full_name": "Owner console-two", "role_id": 1, "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true, "has_inventory_access": true, "has_invoicing_access": true, "has_finance_access": true, "has_accounting_access": true, "has_fbr_access": true, "has_fixed_assets_access": true, "has_executive_access": true}', '127.0.0.1', '/superadmin/companies/'),
	(455, 3, '2026-10-29 08:52:25.344236', 1, 'Administrator', 'create', 'admin', 'Membership', 6, '7', 'Membership 7 created', '{"company_id": 3, "user_id": 7, "role_id": 1, "status": "active", "employee_code": "SA0007", "joined_at": "2026-10-29T08:52:25.343383"}', '127.0.0.1', '/superadmin/companies/'),
	(626, 3, '2026-10-29 08:52:26.214118', 1, 'Administrator', 'create', 'settings', 'Report settings', 3, '3', 'Report settings 3 created', '{"company_id": 3, "pl_detail_rows": 10, "invoice_party_mode": "relevant", "purchase_party_mode": "relevant", "sales_party_mode": "relevant", "cash_flow_method": "indirect"}', '127.0.0.1', '/superadmin/companies/'),
	(627, 3, '2026-10-29 08:52:26.219002', 1, 'Administrator', 'create', 'inventory', 'Inventory settings', 3, '3', 'Inventory settings 3 created', '{"company_id": 3, "valuation_method": "weighted_average", "decimal_places": 4, "auto_generate_vouchers": true, "purchase_flow": "with_po", "sales_flow": "with_so"}', '127.0.0.1', '/superadmin/companies/'),
	(628, 1, '2026-10-29 08:52:26.338269', 1, 'Administrator', 'create', 'admin', 'User', 8, 'owner.three@ref.test', 'User owner.three@ref.test created', '{"employee_code": "SA0008", "email": "owner.three@ref.test", "login_id": "owner.three@ref.test", "password_hash": "\u2022\u2022\u2022", "full_name": "Owner console-three", "role_id": 1, "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true, "has_inventory_access": true, "has_invoicing_access": true, "has_finance_access": true, "has_accounting_access": true, "has_fbr_access": true, "has_fixed_assets_access": true, "has_executive_access": true}', '127.0.0.1', '/superadmin/companies/'),
	(629, 4, '2026-10-29 08:52:26.340791', 1, 'Administrator', 'create', 'admin', 'Membership', 7, '8', 'Membership 8 created', '{"company_id": 4, "user_id": 8, "role_id": 1, "status": "active", "employee_code": "SA0008", "joined_at": "2026-10-29T08:52:26.340048"}', '127.0.0.1', '/superadmin/companies/'),
	(800, 4, '2026-10-29 08:52:27.250258', 1, 'Administrator', 'create', 'settings', 'Report settings', 4, '4', 'Report settings 4 created', '{"company_id": 4, "pl_detail_rows": 10, "invoice_party_mode": "relevant", "purchase_party_mode": "relevant", "sales_party_mode": "relevant", "cash_flow_method": "indirect"}', '127.0.0.1', '/superadmin/companies/'),
	(801, 4, '2026-10-29 08:52:27.256611', 1, 'Administrator', 'create', 'inventory', 'Inventory settings', 4, '4', 'Inventory settings 4 created', '{"company_id": 4, "valuation_method": "weighted_average", "decimal_places": 4, "auto_generate_vouchers": true, "purchase_flow": "with_po", "sales_flow": "with_so"}', '127.0.0.1', '/superadmin/companies/'),
	(802, 1, '2026-10-29 08:52:27.400409', 1, 'Administrator', 'create', 'admin', 'User', 9, 'mixed.case@ref.test', 'User mixed.case@ref.test created', '{"employee_code": "SA0009", "email": "mixed.case@ref.test", "login_id": "mixed.case@ref.test", "password_hash": "\u2022\u2022\u2022", "full_name": "Mixed Case", "role_id": 3, "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true}', '127.0.0.1', '/superadmin/users/'),
	(803, 1, '2026-10-29 08:52:27.509013', 1, 'Administrator', 'create', 'admin', 'User', 10, 'second.admin@ref.test', 'User second.admin@ref.test created', '{"employee_code": "SA0010", "email": "second.admin@ref.test", "login_id": "second.admin@ref.test", "password_hash": "\u2022\u2022\u2022", "full_name": "Second Admin", "role_id": 3, "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true}', '127.0.0.1', '/superadmin/users/'),
	(804, 1, '2026-10-29 08:52:27.614469', 1, 'Administrator', 'create', 'admin', 'User', 11, 'invitee.mixed@ref.test', 'User invitee.mixed@ref.test created', '{"employee_code": "SA0011", "email": "invitee.mixed@ref.test", "login_id": "invitee.mixed@ref.test", "password_hash": "\u2022\u2022\u2022", "full_name": "Invitee Mixed", "role_id": 3, "date_of_joining": "2026-10-29", "is_active": true, "has_hr_access": true}', '127.0.0.1', '/superadmin/users/'),
	(805, NULL, '2026-10-29 08:52:27.708154', 6, 'Owner console-one', 'login', 'admin', NULL, NULL, NULL, 'Owner console-one signed in', NULL, '127.0.0.1', '/auth/login'),
	(807, 2, '2026-10-29 08:52:27.912527', 9, 'Mixed Case', 'create', 'admin', 'Membership', 8, '9', 'Membership 9 created', '{"company_id": 2, "user_id": 9, "role_id": 2, "status": "active", "joined_at": "2026-10-29T08:52:27.911196"}', '127.0.0.1', '/settings/invitations/1/accept'),
	(810, NULL, '2026-10-29 08:52:28.219902', 10, 'Second Admin', 'login', 'admin', NULL, NULL, NULL, 'Second Admin signed in', NULL, '127.0.0.1', '/auth/login'),
	(468, 3, '2026-10-29 08:52:25.417934', 1, 'Administrator', 'create', 'accounting', 'Account', 372, '1-01-04-01', 'Account 1-01-04-01 created', '{"company_id": 3, "code": "1-01-04-01", "name": "Trading Goods Stock", "type": "asset", "parent_id": 371, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(469, 3, '2026-10-29 08:52:25.423188', 1, 'Administrator', 'create', 'accounting', 'Account', 373, '1-01-05', 'Account 1-01-05 created', '{"company_id": 3, "code": "1-01-05", "name": "Tax Assets", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(470, 3, '2026-10-29 08:52:25.428463', 1, 'Administrator', 'create', 'accounting', 'Account', 374, '1-01-05-01', 'Account 1-01-05-01 created', '{"company_id": 3, "code": "1-01-05-01", "name": "Input Sales Tax", "type": "asset", "parent_id": 373, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(471, 3, '2026-10-29 08:52:25.433879', 1, 'Administrator', 'create', 'accounting', 'Account', 375, '1-01-05-02', 'Account 1-01-05-02 created', '{"company_id": 3, "code": "1-01-05-02", "name": "WHT Receivable", "type": "asset", "parent_id": 373, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(472, 3, '2026-10-29 08:52:25.439158', 1, 'Administrator', 'create', 'accounting', 'Account', 376, '1-01-06', 'Account 1-01-06 created', '{"company_id": 3, "code": "1-01-06", "name": "Prepayments & Other", "type": "asset", "parent_id": 361, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(473, 3, '2026-10-29 08:52:25.445315', 1, 'Administrator', 'create', 'accounting', 'Account', 377, '1-01-06-01', 'Account 1-01-06-01 created', '{"company_id": 3, "code": "1-01-06-01", "name": "Suspense & Clearing", "type": "asset", "parent_id": 376, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(474, 3, '2026-10-29 08:52:25.450461', 1, 'Administrator', 'create', 'accounting', 'Account', 378, '1-01-06-02', 'Account 1-01-06-02 created', '{"company_id": 3, "code": "1-01-06-02", "name": "Prepaid Expenses", "type": "asset", "parent_id": 376, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(475, 3, '2026-10-29 08:52:25.4555', 1, 'Administrator', 'create', 'accounting', 'Account', 379, '1-01-06-03', 'Account 1-01-06-03 created', '{"company_id": 3, "code": "1-01-06-03", "name": "Other Current Assets", "type": "asset", "parent_id": 376, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(476, 3, '2026-10-29 08:52:25.460704', 1, 'Administrator', 'create', 'accounting', 'Account', 380, '1-02', 'Account 1-02 created', '{"company_id": 3, "code": "1-02", "name": "Non-Current Assets", "type": "asset", "parent_id": 360, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "investing"}', '127.0.0.1', '/superadmin/companies/'),
	(477, 3, '2026-10-29 08:52:25.465902', 1, 'Administrator', 'create', 'accounting', 'Account', 381, '1-02-01', 'Account 1-02-01 created', '{"company_id": 3, "code": "1-02-01", "name": "Property, Plant & Equipment", "type": "asset", "parent_id": 380, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(478, 3, '2026-10-29 08:52:25.470722', 1, 'Administrator', 'create', 'accounting', 'Account', 382, '1-02-01-01', 'Account 1-02-01-01 created', '{"company_id": 3, "code": "1-02-01-01", "name": "Owned Assets", "type": "asset", "parent_id": 381, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(479, 3, '2026-10-29 08:52:25.476115', 1, 'Administrator', 'create', 'accounting', 'Account', 383, '1-02-02', 'Account 1-02-02 created', '{"company_id": 3, "code": "1-02-02", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 380, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(480, 3, '2026-10-29 08:52:25.481676', 1, 'Administrator', 'create', 'accounting', 'Account', 384, '1-02-02-01', 'Account 1-02-02-01 created', '{"company_id": 3, "code": "1-02-02-01", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 383, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(481, 3, '2026-10-29 08:52:25.48735', 1, 'Administrator', 'create', 'accounting', 'Account', 385, '1-02-03', 'Account 1-02-03 created', '{"company_id": 3, "code": "1-02-03", "name": "Intangible Assets", "type": "asset", "parent_id": 380, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(482, 3, '2026-10-29 08:52:25.492682', 1, 'Administrator', 'create', 'accounting', 'Account', 386, '1-02-03-01', 'Account 1-02-03-01 created', '{"company_id": 3, "code": "1-02-03-01", "name": "Intangibles", "type": "asset", "parent_id": 385, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(483, 3, '2026-10-29 08:52:25.495967', 1, 'Administrator', 'create', 'accounting', 'Account', 387, '2', 'Account 2 created', '{"company_id": 3, "code": "2", "name": "Liabilities", "type": "liability", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(484, 3, '2026-10-29 08:52:25.50119', 1, 'Administrator', 'create', 'accounting', 'Account', 388, '2-01', 'Account 2-01 created', '{"company_id": 3, "code": "2-01", "name": "Current Liabilities", "type": "liability", "parent_id": 387, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(485, 3, '2026-10-29 08:52:25.506172', 1, 'Administrator', 'create', 'accounting', 'Account', 389, '2-01-01', 'Account 2-01-01 created', '{"company_id": 3, "code": "2-01-01", "name": "Trade Payables", "type": "liability", "parent_id": 388, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(486, 3, '2026-10-29 08:52:25.511175', 1, 'Administrator', 'create', 'accounting', 'Account', 390, '2-01-01-01', 'Account 2-01-01-01 created', '{"company_id": 3, "code": "2-01-01-01", "name": "Trade Creditors", "type": "liability", "parent_id": 389, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(487, 3, '2026-10-29 08:52:25.516139', 1, 'Administrator', 'create', 'accounting', 'Account', 391, '2-01-02', 'Account 2-01-02 created', '{"company_id": 3, "code": "2-01-02", "name": "Accrued & Payroll Liabilities", "type": "liability", "parent_id": 388, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(488, 3, '2026-10-29 08:52:25.521313', 1, 'Administrator', 'create', 'accounting', 'Account', 392, '2-01-02-01', 'Account 2-01-02-01 created', '{"company_id": 3, "code": "2-01-02-01", "name": "Employee Payables", "type": "liability", "parent_id": 391, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(489, 3, '2026-10-29 08:52:25.525934', 1, 'Administrator', 'create', 'accounting', 'Account', 393, '2-01-02-02', 'Account 2-01-02-02 created', '{"company_id": 3, "code": "2-01-02-02", "name": "Payroll Liabilities", "type": "liability", "parent_id": 391, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(490, 3, '2026-10-29 08:52:25.530601', 1, 'Administrator', 'create', 'accounting', 'Account', 394, '2-01-02-03', 'Account 2-01-02-03 created', '{"company_id": 3, "code": "2-01-02-03", "name": "Accrued Expenses", "type": "liability", "parent_id": 391, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(491, 3, '2026-10-29 08:52:25.535789', 1, 'Administrator', 'create', 'accounting', 'Account', 395, '2-01-03', 'Account 2-01-03 created', '{"company_id": 3, "code": "2-01-03", "name": "Tax Liabilities", "type": "liability", "parent_id": 388, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(492, 3, '2026-10-29 08:52:25.540871', 1, 'Administrator', 'create', 'accounting', 'Account', 396, '2-01-03-01', 'Account 2-01-03-01 created', '{"company_id": 3, "code": "2-01-03-01", "name": "Output Sales Tax", "type": "liability", "parent_id": 395, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(493, 3, '2026-10-29 08:52:25.545881', 1, 'Administrator', 'create', 'accounting', 'Account', 397, '2-01-03-02', 'Account 2-01-03-02 created', '{"company_id": 3, "code": "2-01-03-02", "name": "Income Tax Payable", "type": "liability", "parent_id": 395, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(494, 3, '2026-10-29 08:52:25.551017', 1, 'Administrator', 'create', 'accounting', 'Account', 398, '2-01-03-03', 'Account 2-01-03-03 created', '{"company_id": 3, "code": "2-01-03-03", "name": "WHT Payable", "type": "liability", "parent_id": 395, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(495, 3, '2026-10-29 08:52:25.555829', 1, 'Administrator', 'create', 'accounting', 'Account', 399, '2-01-03-04', 'Account 2-01-03-04 created', '{"company_id": 3, "code": "2-01-03-04", "name": "Further Tax Payable", "type": "liability", "parent_id": 395, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(496, 3, '2026-10-29 08:52:25.56075', 1, 'Administrator', 'create', 'accounting', 'Account', 400, '2-01-04', 'Account 2-01-04 created', '{"company_id": 3, "code": "2-01-04", "name": "Advances from Customers", "type": "liability", "parent_id": 388, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(497, 3, '2026-10-29 08:52:25.565285', 1, 'Administrator', 'create', 'accounting', 'Account', 401, '2-01-04-01', 'Account 2-01-04-01 created', '{"company_id": 3, "code": "2-01-04-01", "name": "Customer Advances", "type": "liability", "parent_id": 400, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(498, 3, '2026-10-29 08:52:25.569876', 1, 'Administrator', 'create', 'accounting', 'Account', 402, '2-02', 'Account 2-02 created', '{"company_id": 3, "code": "2-02", "name": "Non-Current Liabilities", "type": "liability", "parent_id": 387, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/superadmin/companies/'),
	(499, 3, '2026-10-29 08:52:25.574203', 1, 'Administrator', 'create', 'accounting', 'Account', 403, '2-02-01', 'Account 2-02-01 created', '{"company_id": 3, "code": "2-02-01", "name": "Long-term Loans", "type": "liability", "parent_id": 402, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(500, 3, '2026-10-29 08:52:25.578373', 1, 'Administrator', 'create', 'accounting', 'Account', 404, '2-02-01-01', 'Account 2-02-01-01 created', '{"company_id": 3, "code": "2-02-01-01", "name": "Long-term Loans", "type": "liability", "parent_id": 403, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(501, 3, '2026-10-29 08:52:25.582716', 1, 'Administrator', 'create', 'accounting', 'Account', 405, '2-02-02', 'Account 2-02-02 created', '{"company_id": 3, "code": "2-02-02", "name": "Employee End-of-Service Benefits", "type": "liability", "parent_id": 402, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(502, 3, '2026-10-29 08:52:25.587447', 1, 'Administrator', 'create', 'accounting', 'Account', 406, '2-02-02-01', 'Account 2-02-02-01 created', '{"company_id": 3, "code": "2-02-02-01", "name": "EOSB Provision", "type": "liability", "parent_id": 405, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(503, 3, '2026-10-29 08:52:25.590374', 1, 'Administrator', 'create', 'accounting', 'Account', 407, '3', 'Account 3 created', '{"company_id": 3, "code": "3", "name": "Equity", "type": "equity", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/superadmin/companies/'),
	(504, 3, '2026-10-29 08:52:25.595255', 1, 'Administrator', 'create', 'accounting', 'Account', 408, '3-01', 'Account 3-01 created', '{"company_id": 3, "code": "3-01", "name": "Capital", "type": "equity", "parent_id": 407, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(505, 3, '2026-10-29 08:52:25.599976', 1, 'Administrator', 'create', 'accounting', 'Account', 409, '3-01-01', 'Account 3-01-01 created', '{"company_id": 3, "code": "3-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 408, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(506, 3, '2026-10-29 08:52:25.60485', 1, 'Administrator', 'create', 'accounting', 'Account', 410, '3-01-01-01', 'Account 3-01-01-01 created', '{"company_id": 3, "code": "3-01-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 409, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(507, 3, '2026-10-29 08:52:25.609567', 1, 'Administrator', 'create', 'accounting', 'Account', 411, '3-02', 'Account 3-02 created', '{"company_id": 3, "code": "3-02", "name": "Reserves & Retained Earnings", "type": "equity", "parent_id": 407, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(508, 3, '2026-10-29 08:52:25.614445', 1, 'Administrator', 'create', 'accounting', 'Account', 412, '3-02-01', 'Account 3-02-01 created', '{"company_id": 3, "code": "3-02-01", "name": "Retained Earnings", "type": "equity", "parent_id": 411, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(509, 3, '2026-10-29 08:52:25.61936', 1, 'Administrator', 'create', 'accounting', 'Account', 413, '3-02-01-01', 'Account 3-02-01-01 created', '{"company_id": 3, "code": "3-02-01-01", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 412, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(510, 3, '2026-10-29 08:52:25.62427', 1, 'Administrator', 'create', 'accounting', 'Account', 414, '3-02-01-02', 'Account 3-02-01-02 created', '{"company_id": 3, "code": "3-02-01-02", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 412, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(511, 3, '2026-10-29 08:52:25.629189', 1, 'Administrator', 'create', 'accounting', 'Account', 415, '3-02-02', 'Account 3-02-02 created', '{"company_id": 3, "code": "3-02-02", "name": "Dividends", "type": "equity", "parent_id": 411, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(512, 3, '2026-10-29 08:52:25.63397', 1, 'Administrator', 'create', 'accounting', 'Account', 416, '3-02-02-01', 'Account 3-02-02-01 created', '{"company_id": 3, "code": "3-02-02-01", "name": "Dividends", "type": "equity", "parent_id": 415, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(513, 3, '2026-10-29 08:52:25.639279', 1, 'Administrator', 'create', 'accounting', 'Account', 417, '3-02-03', 'Account 3-02-03 created', '{"company_id": 3, "code": "3-02-03", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 411, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(514, 3, '2026-10-29 08:52:25.644027', 1, 'Administrator', 'create', 'accounting', 'Account', 418, '3-02-03-01', 'Account 3-02-03-01 created', '{"company_id": 3, "code": "3-02-03-01", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 417, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(515, 3, '2026-10-29 08:52:25.64705', 1, 'Administrator', 'create', 'accounting', 'Account', 419, '4', 'Account 4 created', '{"company_id": 3, "code": "4", "name": "Revenue", "type": "revenue", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(516, 3, '2026-10-29 08:52:25.6519', 1, 'Administrator', 'create', 'accounting', 'Account', 420, '4-01', 'Account 4-01 created', '{"company_id": 3, "code": "4-01", "name": "Sales", "type": "revenue", "parent_id": 419, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales"}', '127.0.0.1', '/superadmin/companies/'),
	(517, 3, '2026-10-29 08:52:25.657573', 1, 'Administrator', 'create', 'accounting', 'Account', 421, '4-01-01', 'Account 4-01-01 created', '{"company_id": 3, "code": "4-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 420, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(518, 3, '2026-10-29 08:52:25.662901', 1, 'Administrator', 'create', 'accounting', 'Account', 422, '4-01-01-01', 'Account 4-01-01-01 created', '{"company_id": 3, "code": "4-01-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 421, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(519, 3, '2026-10-29 08:52:25.668435', 1, 'Administrator', 'create', 'accounting', 'Account', 423, '4-01-02', 'Account 4-01-02 created', '{"company_id": 3, "code": "4-01-02", "name": "Service Income", "type": "revenue", "parent_id": 420, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(520, 3, '2026-10-29 08:52:25.673983', 1, 'Administrator', 'create', 'accounting', 'Account', 424, '4-01-02-01', 'Account 4-01-02-01 created', '{"company_id": 3, "code": "4-01-02-01", "name": "Service Income", "type": "revenue", "parent_id": 423, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(521, 3, '2026-10-29 08:52:25.679125', 1, 'Administrator', 'create', 'accounting', 'Account', 425, '4-02', 'Account 4-02 created', '{"company_id": 3, "code": "4-02", "name": "Sales Returns & Discounts", "type": "revenue", "parent_id": 419, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales_returns"}', '127.0.0.1', '/superadmin/companies/'),
	(522, 3, '2026-10-29 08:52:25.685024', 1, 'Administrator', 'create', 'accounting', 'Account', 426, '4-02-01', 'Account 4-02-01 created', '{"company_id": 3, "code": "4-02-01", "name": "Sales Returns", "type": "revenue", "parent_id": 425, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(523, 3, '2026-10-29 08:52:25.690633', 1, 'Administrator', 'create', 'accounting', 'Account', 427, '4-02-01-01', 'Account 4-02-01-01 created', '{"company_id": 3, "code": "4-02-01-01", "name": "Sales Returns", "type": "revenue", "parent_id": 426, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(524, 3, '2026-10-29 08:52:25.696274', 1, 'Administrator', 'create', 'accounting', 'Account', 428, '4-02-02', 'Account 4-02-02 created', '{"company_id": 3, "code": "4-02-02", "name": "Discounts Allowed", "type": "revenue", "parent_id": 425, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(525, 3, '2026-10-29 08:52:25.702104', 1, 'Administrator', 'create', 'accounting', 'Account', 429, '4-02-02-01', 'Account 4-02-02-01 created', '{"company_id": 3, "code": "4-02-02-01", "name": "Discounts Allowed", "type": "revenue", "parent_id": 428, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(526, 3, '2026-10-29 08:52:25.707388', 1, 'Administrator', 'create', 'accounting', 'Account', 430, '4-03', 'Account 4-03 created', '{"company_id": 3, "code": "4-03", "name": "Other Income", "type": "revenue", "parent_id": 419, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_income"}', '127.0.0.1', '/superadmin/companies/'),
	(527, 3, '2026-10-29 08:52:25.712544', 1, 'Administrator', 'create', 'accounting', 'Account', 431, '4-03-01', 'Account 4-03-01 created', '{"company_id": 3, "code": "4-03-01", "name": "Other Income", "type": "revenue", "parent_id": 430, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(528, 3, '2026-10-29 08:52:25.7177', 1, 'Administrator', 'create', 'accounting', 'Account', 432, '4-03-01-01', 'Account 4-03-01-01 created', '{"company_id": 3, "code": "4-03-01-01", "name": "Other Income", "type": "revenue", "parent_id": 431, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(529, 3, '2026-10-29 08:52:25.720933', 1, 'Administrator', 'create', 'accounting', 'Account', 433, '5', 'Account 5 created', '{"company_id": 3, "code": "5", "name": "Expenses", "type": "expense", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(530, 3, '2026-10-29 08:52:25.725988', 1, 'Administrator', 'create', 'accounting', 'Account', 434, '5-01', 'Account 5-01 created', '{"company_id": 3, "code": "5-01", "name": "Cost of Sales", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "cost_of_sales"}', '127.0.0.1', '/superadmin/companies/'),
	(531, 3, '2026-10-29 08:52:25.731175', 1, 'Administrator', 'create', 'accounting', 'Account', 435, '5-01-01', 'Account 5-01-01 created', '{"company_id": 3, "code": "5-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 434, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(532, 3, '2026-10-29 08:52:25.736439', 1, 'Administrator', 'create', 'accounting', 'Account', 436, '5-01-01-01', 'Account 5-01-01-01 created', '{"company_id": 3, "code": "5-01-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 435, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(533, 3, '2026-10-29 08:52:25.741556', 1, 'Administrator', 'create', 'accounting', 'Account', 437, '5-01-02', 'Account 5-01-02 created', '{"company_id": 3, "code": "5-01-02", "name": "Stock Losses, Scrap & Adjustments", "type": "expense", "parent_id": 434, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(534, 3, '2026-10-29 08:52:25.746569', 1, 'Administrator', 'create', 'accounting', 'Account', 438, '5-01-02-01', 'Account 5-01-02-01 created', '{"company_id": 3, "code": "5-01-02-01", "name": "Stock Losses & Scrap", "type": "expense", "parent_id": 437, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(535, 3, '2026-10-29 08:52:25.751833', 1, 'Administrator', 'create', 'accounting', 'Account', 439, '5-02', 'Account 5-02 created', '{"company_id": 3, "code": "5-02", "name": "Administrative Expenses", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "admin"}', '127.0.0.1', '/superadmin/companies/'),
	(536, 3, '2026-10-29 08:52:25.75702', 1, 'Administrator', 'create', 'accounting', 'Account', 440, '5-02-01', 'Account 5-02-01 created', '{"company_id": 3, "code": "5-02-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 439, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(537, 3, '2026-10-29 08:52:25.762482', 1, 'Administrator', 'create', 'accounting', 'Account', 441, '5-02-01-01', 'Account 5-02-01-01 created', '{"company_id": 3, "code": "5-02-01-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 440, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(538, 3, '2026-10-29 08:52:25.768054', 1, 'Administrator', 'create', 'accounting', 'Account', 442, '5-02-02', 'Account 5-02-02 created', '{"company_id": 3, "code": "5-02-02", "name": "Rent & Utilities", "type": "expense", "parent_id": 439, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(539, 3, '2026-10-29 08:52:25.773176', 1, 'Administrator', 'create', 'accounting', 'Account', 443, '5-02-02-01', 'Account 5-02-02-01 created', '{"company_id": 3, "code": "5-02-02-01", "name": "Rent & Utilities", "type": "expense", "parent_id": 442, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(540, 3, '2026-10-29 08:52:25.778286', 1, 'Administrator', 'create', 'accounting', 'Account', 444, '5-02-03', 'Account 5-02-03 created', '{"company_id": 3, "code": "5-02-03", "name": "Office & Supplies", "type": "expense", "parent_id": 439, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(541, 3, '2026-10-29 08:52:25.783943', 1, 'Administrator', 'create', 'accounting', 'Account', 445, '5-02-03-01', 'Account 5-02-03-01 created', '{"company_id": 3, "code": "5-02-03-01", "name": "Office & Supplies", "type": "expense", "parent_id": 444, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(542, 3, '2026-10-29 08:52:25.789721', 1, 'Administrator', 'create', 'accounting', 'Account', 446, '5-02-04', 'Account 5-02-04 created', '{"company_id": 3, "code": "5-02-04", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 439, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(543, 3, '2026-10-29 08:52:25.795165', 1, 'Administrator', 'create', 'accounting', 'Account', 447, '5-02-04-01', 'Account 5-02-04-01 created', '{"company_id": 3, "code": "5-02-04-01", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 446, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(544, 3, '2026-10-29 08:52:25.800678', 1, 'Administrator', 'create', 'accounting', 'Account', 448, '5-02-05', 'Account 5-02-05 created', '{"company_id": 3, "code": "5-02-05", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 439, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(545, 3, '2026-10-29 08:52:25.806213', 1, 'Administrator', 'create', 'accounting', 'Account', 449, '5-02-05-01', 'Account 5-02-05-01 created', '{"company_id": 3, "code": "5-02-05-01", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 448, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(546, 3, '2026-10-29 08:52:25.8113', 1, 'Administrator', 'create', 'accounting', 'Account', 450, '5-03', 'Account 5-03 created', '{"company_id": 3, "code": "5-03", "name": "Selling & Distribution", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "selling_distribution"}', '127.0.0.1', '/superadmin/companies/'),
	(547, 3, '2026-10-29 08:52:25.816557', 1, 'Administrator', 'create', 'accounting', 'Account', 451, '5-03-01', 'Account 5-03-01 created', '{"company_id": 3, "code": "5-03-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 450, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(548, 3, '2026-10-29 08:52:25.821712', 1, 'Administrator', 'create', 'accounting', 'Account', 452, '5-03-01-01', 'Account 5-03-01-01 created', '{"company_id": 3, "code": "5-03-01-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 451, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(549, 3, '2026-10-29 08:52:25.827055', 1, 'Administrator', 'create', 'accounting', 'Account', 453, '5-03-02', 'Account 5-03-02 created', '{"company_id": 3, "code": "5-03-02", "name": "Commissions", "type": "expense", "parent_id": 450, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(550, 3, '2026-10-29 08:52:25.832175', 1, 'Administrator', 'create', 'accounting', 'Account', 454, '5-03-02-01', 'Account 5-03-02-01 created', '{"company_id": 3, "code": "5-03-02-01", "name": "Commissions", "type": "expense", "parent_id": 453, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(551, 3, '2026-10-29 08:52:25.837156', 1, 'Administrator', 'create', 'accounting', 'Account', 455, '5-03-03', 'Account 5-03-03 created', '{"company_id": 3, "code": "5-03-03", "name": "Marketing & Advertising", "type": "expense", "parent_id": 450, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(552, 3, '2026-10-29 08:52:25.842226', 1, 'Administrator', 'create', 'accounting', 'Account', 456, '5-03-03-01', 'Account 5-03-03-01 created', '{"company_id": 3, "code": "5-03-03-01", "name": "Marketing & Advertising", "type": "expense", "parent_id": 455, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(553, 3, '2026-10-29 08:52:25.847063', 1, 'Administrator', 'create', 'accounting', 'Account', 457, '5-04', 'Account 5-04 created', '{"company_id": 3, "code": "5-04", "name": "Other Operating Expenses", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_operating"}', '127.0.0.1', '/superadmin/companies/'),
	(554, 3, '2026-10-29 08:52:25.851835', 1, 'Administrator', 'create', 'accounting', 'Account', 458, '5-04-01', 'Account 5-04-01 created', '{"company_id": 3, "code": "5-04-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 457, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(555, 3, '2026-10-29 08:52:25.856492', 1, 'Administrator', 'create', 'accounting', 'Account', 459, '5-04-01-01', 'Account 5-04-01-01 created', '{"company_id": 3, "code": "5-04-01-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 458, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(556, 3, '2026-10-29 08:52:25.861284', 1, 'Administrator', 'create', 'accounting', 'Account', 460, '5-05', 'Account 5-05 created', '{"company_id": 3, "code": "5-05", "name": "Finance Costs", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "finance_cost"}', '127.0.0.1', '/superadmin/companies/'),
	(557, 3, '2026-10-29 08:52:25.865872', 1, 'Administrator', 'create', 'accounting', 'Account', 461, '5-05-01', 'Account 5-05-01 created', '{"company_id": 3, "code": "5-05-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 460, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(558, 3, '2026-10-29 08:52:25.870731', 1, 'Administrator', 'create', 'accounting', 'Account', 462, '5-05-01-01', 'Account 5-05-01-01 created', '{"company_id": 3, "code": "5-05-01-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 461, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(559, 3, '2026-10-29 08:52:25.875282', 1, 'Administrator', 'create', 'accounting', 'Account', 463, '5-06', 'Account 5-06 created', '{"company_id": 3, "code": "5-06", "name": "Taxation", "type": "expense", "parent_id": 433, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "income_tax"}', '127.0.0.1', '/superadmin/companies/'),
	(560, 3, '2026-10-29 08:52:25.879967', 1, 'Administrator', 'create', 'accounting', 'Account', 464, '5-06-01', 'Account 5-06-01 created', '{"company_id": 3, "code": "5-06-01", "name": "Income Tax", "type": "expense", "parent_id": 463, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(561, 3, '2026-10-29 08:52:25.885231', 1, 'Administrator', 'create', 'accounting', 'Account', 465, '5-06-01-01', 'Account 5-06-01-01 created', '{"company_id": 3, "code": "5-06-01-01", "name": "Income Tax", "type": "expense", "parent_id": 464, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(562, 3, '2026-10-29 08:52:25.893309', 1, 'Administrator', 'create', 'accounting', 'Account', 466, '1-01-01-01-0001', 'Account 1-01-01-01-0001 created', '{"company_id": 3, "code": "1-01-01-01-0001", "name": "Main Cash", "type": "asset", "parent_id": 363, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(563, 3, '2026-10-29 08:52:25.898236', 1, 'Administrator', 'create', 'accounting', 'Account', 467, '1-01-02-01-0001', 'Account 1-01-02-01-0001 created', '{"company_id": 3, "code": "1-01-02-01-0001", "name": "Trade Debtors \u2014 General", "type": "asset", "parent_id": 366, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(564, 3, '2026-10-29 08:52:25.90306', 1, 'Administrator', 'create', 'accounting', 'Account', 468, '1-01-03-02-0001', 'Account 1-01-03-02-0001 created', '{"company_id": 3, "code": "1-01-03-02-0001", "name": "Advances to Suppliers \u2014 General", "type": "asset", "parent_id": 370, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(565, 3, '2026-10-29 08:52:25.907709', 1, 'Administrator', 'create', 'accounting', 'Account', 469, '1-01-04-01-0001', 'Account 1-01-04-01-0001 created', '{"company_id": 3, "code": "1-01-04-01-0001", "name": "Stock \u2014 General", "type": "asset", "parent_id": 372, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(566, 3, '2026-10-29 08:52:25.912052', 1, 'Administrator', 'create', 'accounting', 'Account', 470, '1-01-05-01-0001', 'Account 1-01-05-01-0001 created', '{"company_id": 3, "code": "1-01-05-01-0001", "name": "Input Sales Tax", "type": "asset", "parent_id": 374, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(567, 3, '2026-10-29 08:52:25.916375', 1, 'Administrator', 'create', 'accounting', 'Account', 471, '1-01-05-02-0001', 'Account 1-01-05-02-0001 created', '{"company_id": 3, "code": "1-01-05-02-0001", "name": "WHT Receivable", "type": "asset", "parent_id": 375, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(568, 3, '2026-10-29 08:52:25.921004', 1, 'Administrator', 'create', 'accounting', 'Account', 472, '1-01-06-01-0001', 'Account 1-01-06-01-0001 created', '{"company_id": 3, "code": "1-01-06-01-0001", "name": "Suspense Account", "type": "asset", "parent_id": 377, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(569, 3, '2026-10-29 08:52:25.925553', 1, 'Administrator', 'create', 'accounting', 'Account', 473, '1-01-06-02-0001', 'Account 1-01-06-02-0001 created', '{"company_id": 3, "code": "1-01-06-02-0001", "name": "Prepaid Expenses \u2014 General", "type": "asset", "parent_id": 378, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(570, 3, '2026-10-29 08:52:25.930037', 1, 'Administrator', 'create', 'accounting', 'Account', 474, '1-02-01-01-0001', 'Account 1-02-01-01-0001 created', '{"company_id": 3, "code": "1-02-01-01-0001", "name": "Fixed Assets \u2014 General", "type": "asset", "parent_id": 382, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(571, 3, '2026-10-29 08:52:25.934786', 1, 'Administrator', 'create', 'accounting', 'Account', 475, '1-02-02-01-0001', 'Account 1-02-02-01-0001 created', '{"company_id": 3, "code": "1-02-02-01-0001", "name": "Accumulated Depreciation \u2014 General", "type": "asset", "parent_id": 384, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(572, 3, '2026-10-29 08:52:25.93961', 1, 'Administrator', 'create', 'accounting', 'Account', 476, '1-02-03-01-0001', 'Account 1-02-03-01-0001 created', '{"company_id": 3, "code": "1-02-03-01-0001", "name": "Intangibles \u2014 General", "type": "asset", "parent_id": 386, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(573, 3, '2026-10-29 08:52:25.944455', 1, 'Administrator', 'create', 'accounting', 'Account', 477, '2-01-01-01-0001', 'Account 2-01-01-01-0001 created', '{"company_id": 3, "code": "2-01-01-01-0001", "name": "Trade Creditors \u2014 General", "type": "liability", "parent_id": 390, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(574, 3, '2026-10-29 08:52:25.949242', 1, 'Administrator', 'create', 'accounting', 'Account', 478, '2-01-02-02-0001', 'Account 2-01-02-02-0001 created', '{"company_id": 3, "code": "2-01-02-02-0001", "name": "Salary Payable", "type": "liability", "parent_id": 393, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(575, 3, '2026-10-29 08:52:25.954186', 1, 'Administrator', 'create', 'accounting', 'Account', 479, '2-01-02-02-0002', 'Account 2-01-02-02-0002 created', '{"company_id": 3, "code": "2-01-02-02-0002", "name": "PF Payable", "type": "liability", "parent_id": 393, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(576, 3, '2026-10-29 08:52:25.95892', 1, 'Administrator', 'create', 'accounting', 'Account', 480, '2-01-02-02-0003', 'Account 2-01-02-02-0003 created', '{"company_id": 3, "code": "2-01-02-02-0003", "name": "Loan Deductions Clearing", "type": "liability", "parent_id": 393, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(577, 3, '2026-10-29 08:52:25.963248', 1, 'Administrator', 'create', 'accounting', 'Account', 481, '2-01-02-02-0004', 'Account 2-01-02-02-0004 created', '{"company_id": 3, "code": "2-01-02-02-0004", "name": "Other Payroll Deductions Payable", "type": "liability", "parent_id": 393, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(578, 3, '2026-10-29 08:52:25.967936', 1, 'Administrator', 'create', 'accounting', 'Account', 482, '2-01-02-03-0001', 'Account 2-01-02-03-0001 created', '{"company_id": 3, "code": "2-01-02-03-0001", "name": "Accrued Expenses \u2014 General", "type": "liability", "parent_id": 394, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(579, 3, '2026-10-29 08:52:25.972195', 1, 'Administrator', 'create', 'accounting', 'Account', 483, '2-01-03-01-0001', 'Account 2-01-03-01-0001 created', '{"company_id": 3, "code": "2-01-03-01-0001", "name": "Output Sales Tax", "type": "liability", "parent_id": 396, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(580, 3, '2026-10-29 08:52:25.976507', 1, 'Administrator', 'create', 'accounting', 'Account', 484, '2-01-03-02-0001', 'Account 2-01-03-02-0001 created', '{"company_id": 3, "code": "2-01-03-02-0001", "name": "Income Tax Payable", "type": "liability", "parent_id": 397, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(581, 3, '2026-10-29 08:52:25.981124', 1, 'Administrator', 'create', 'accounting', 'Account', 485, '2-01-03-03-0001', 'Account 2-01-03-03-0001 created', '{"company_id": 3, "code": "2-01-03-03-0001", "name": "WHT Payable", "type": "liability", "parent_id": 398, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(582, 3, '2026-10-29 08:52:25.985741', 1, 'Administrator', 'create', 'accounting', 'Account', 486, '2-01-03-04-0001', 'Account 2-01-03-04-0001 created', '{"company_id": 3, "code": "2-01-03-04-0001", "name": "Further Tax Payable", "type": "liability", "parent_id": 399, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(583, 3, '2026-10-29 08:52:25.990674', 1, 'Administrator', 'create', 'accounting', 'Account', 487, '2-01-04-01-0001', 'Account 2-01-04-01-0001 created', '{"company_id": 3, "code": "2-01-04-01-0001", "name": "Customer Advances \u2014 General", "type": "liability", "parent_id": 401, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(584, 3, '2026-10-29 08:52:25.995878', 1, 'Administrator', 'create', 'accounting', 'Account', 488, '2-02-01-01-0001', 'Account 2-02-01-01-0001 created', '{"company_id": 3, "code": "2-02-01-01-0001", "name": "Long-term Loans \u2014 General", "type": "liability", "parent_id": 404, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(585, 3, '2026-10-29 08:52:26.000686', 1, 'Administrator', 'create', 'accounting', 'Account', 489, '2-02-02-01-0001', 'Account 2-02-02-01-0001 created', '{"company_id": 3, "code": "2-02-02-01-0001", "name": "EOSB Provision \u2014 General", "type": "liability", "parent_id": 406, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(586, 3, '2026-10-29 08:52:26.005524', 1, 'Administrator', 'create', 'accounting', 'Account', 490, '3-01-01-01-0001', 'Account 3-01-01-01-0001 created', '{"company_id": 3, "code": "3-01-01-01-0001", "name": "Share Capital", "type": "equity", "parent_id": 410, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(587, 3, '2026-10-29 08:52:26.010317', 1, 'Administrator', 'create', 'accounting', 'Account', 491, '3-01-01-01-0002', 'Account 3-01-01-01-0002 created', '{"company_id": 3, "code": "3-01-01-01-0002", "name": "Suspense Equity", "type": "equity", "parent_id": 410, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(588, 3, '2026-10-29 08:52:26.014896', 1, 'Administrator', 'create', 'accounting', 'Account', 492, '3-02-01-01-0001', 'Account 3-02-01-01-0001 created', '{"company_id": 3, "code": "3-02-01-01-0001", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 413, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES
	(589, 3, '2026-10-29 08:52:26.020627', 1, 'Administrator', 'create', 'accounting', 'Account', 493, '3-02-01-02-0001', 'Account 3-02-01-02-0001 created', '{"company_id": 3, "code": "3-02-01-02-0001", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 414, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(590, 3, '2026-10-29 08:52:26.025703', 1, 'Administrator', 'create', 'accounting', 'Account', 494, '3-02-02-01-0001', 'Account 3-02-02-01-0001 created', '{"company_id": 3, "code": "3-02-02-01-0001", "name": "Dividends", "type": "equity", "parent_id": 416, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(591, 3, '2026-10-29 08:52:26.030193', 1, 'Administrator', 'create', 'accounting', 'Account', 495, '3-02-03-01-0001', 'Account 3-02-03-01-0001 created', '{"company_id": 3, "code": "3-02-03-01-0001", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 418, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(592, 3, '2026-10-29 08:52:26.034722', 1, 'Administrator', 'create', 'accounting', 'Account', 496, '4-01-01-01-0001', 'Account 4-01-01-01-0001 created', '{"company_id": 3, "code": "4-01-01-01-0001", "name": "Sales \u2014 General", "type": "revenue", "parent_id": 422, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(593, 3, '2026-10-29 08:52:26.039673', 1, 'Administrator', 'create', 'accounting', 'Account', 497, '4-01-02-01-0001', 'Account 4-01-02-01-0001 created', '{"company_id": 3, "code": "4-01-02-01-0001", "name": "Service Income \u2014 General", "type": "revenue", "parent_id": 424, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(594, 3, '2026-10-29 08:52:26.044511', 1, 'Administrator', 'create', 'accounting', 'Account', 498, '4-02-01-01-0001', 'Account 4-02-01-01-0001 created', '{"company_id": 3, "code": "4-02-01-01-0001", "name": "Sales Returns \u2014 General", "type": "revenue", "parent_id": 427, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(595, 3, '2026-10-29 08:52:26.049404', 1, 'Administrator', 'create', 'accounting', 'Account', 499, '4-02-02-01-0001', 'Account 4-02-02-01-0001 created', '{"company_id": 3, "code": "4-02-02-01-0001", "name": "Discounts Allowed \u2014 General", "type": "revenue", "parent_id": 429, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(596, 3, '2026-10-29 08:52:26.053879', 1, 'Administrator', 'create', 'accounting', 'Account', 500, '4-03-01-01-0001', 'Account 4-03-01-01-0001 created', '{"company_id": 3, "code": "4-03-01-01-0001", "name": "Other Income \u2014 General", "type": "revenue", "parent_id": 432, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(597, 3, '2026-10-29 08:52:26.058296', 1, 'Administrator', 'create', 'accounting', 'Account', 501, '5-01-01-01-0001', 'Account 5-01-01-01-0001 created', '{"company_id": 3, "code": "5-01-01-01-0001", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 436, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(598, 3, '2026-10-29 08:52:26.062853', 1, 'Administrator', 'create', 'accounting', 'Account', 502, '5-01-02-01-0001', 'Account 5-01-02-01-0001 created', '{"company_id": 3, "code": "5-01-02-01-0001", "name": "Scrap / Write-off", "type": "expense", "parent_id": 438, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(599, 3, '2026-10-29 08:52:26.067608', 1, 'Administrator', 'create', 'accounting', 'Account', 503, '5-01-02-01-0002', 'Account 5-01-02-01-0002 created', '{"company_id": 3, "code": "5-01-02-01-0002", "name": "Inventory Adjustment", "type": "expense", "parent_id": 438, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(600, 3, '2026-10-29 08:52:26.071806', 1, 'Administrator', 'create', 'accounting', 'Account', 504, '5-01-02-01-0003', 'Account 5-01-02-01-0003 created', '{"company_id": 3, "code": "5-01-02-01-0003", "name": "Consumption Expense", "type": "expense", "parent_id": 438, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(601, 3, '2026-10-29 08:52:26.076545', 1, 'Administrator', 'create', 'accounting', 'Account', 505, '5-01-02-01-0004', 'Account 5-01-02-01-0004 created', '{"company_id": 3, "code": "5-01-02-01-0004", "name": "Inventory Cost Variance", "type": "expense", "parent_id": 438, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(602, 3, '2026-10-29 08:52:26.081371', 1, 'Administrator', 'create', 'accounting', 'Account', 506, '5-02-01-01-0001', 'Account 5-02-01-01-0001 created', '{"company_id": 3, "code": "5-02-01-01-0001", "name": "Salary Expense", "type": "expense", "parent_id": 441, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(603, 3, '2026-10-29 08:52:26.086301', 1, 'Administrator', 'create', 'accounting', 'Account', 507, '5-02-01-01-0002', 'Account 5-02-01-01-0002 created', '{"company_id": 3, "code": "5-02-01-01-0002", "name": "PF Employer Expense", "type": "expense", "parent_id": 441, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(604, 3, '2026-10-29 08:52:26.091125', 1, 'Administrator', 'create', 'accounting', 'Account', 508, '5-02-02-01-0001', 'Account 5-02-02-01-0001 created', '{"company_id": 3, "code": "5-02-02-01-0001", "name": "Rent Expense", "type": "expense", "parent_id": 443, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(605, 3, '2026-10-29 08:52:26.096268', 1, 'Administrator', 'create', 'accounting', 'Account', 509, '5-02-02-01-0002', 'Account 5-02-02-01-0002 created', '{"company_id": 3, "code": "5-02-02-01-0002", "name": "Utilities Expense", "type": "expense", "parent_id": 443, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(606, 3, '2026-10-29 08:52:26.101463', 1, 'Administrator', 'create', 'accounting', 'Account', 510, '5-02-03-01-0001', 'Account 5-02-03-01-0001 created', '{"company_id": 3, "code": "5-02-03-01-0001", "name": "Office Supplies", "type": "expense", "parent_id": 445, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(607, 3, '2026-10-29 08:52:26.106472', 1, 'Administrator', 'create', 'accounting', 'Account', 511, '5-02-04-01-0001', 'Account 5-02-04-01-0001 created', '{"company_id": 3, "code": "5-02-04-01-0001", "name": "Depreciation Expense", "type": "expense", "parent_id": 447, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(608, 3, '2026-10-29 08:52:26.11136', 1, 'Administrator', 'create', 'accounting', 'Account', 512, '5-02-05-01-0001', 'Account 5-02-05-01-0001 created', '{"company_id": 3, "code": "5-02-05-01-0001", "name": "Fees, Taxes & Licenses \u2014 General", "type": "expense", "parent_id": 449, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(609, 3, '2026-10-29 08:52:26.116215', 1, 'Administrator', 'create', 'accounting', 'Account', 513, '5-03-01-01-0001', 'Account 5-03-01-01-0001 created', '{"company_id": 3, "code": "5-03-01-01-0001", "name": "Freight & Transportation \u2014 General", "type": "expense", "parent_id": 452, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(610, 3, '2026-10-29 08:52:26.121102', 1, 'Administrator', 'create', 'accounting', 'Account', 514, '5-03-02-01-0001', 'Account 5-03-02-01-0001 created', '{"company_id": 3, "code": "5-03-02-01-0001", "name": "Commissions \u2014 General", "type": "expense", "parent_id": 454, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(611, 3, '2026-10-29 08:52:26.125847', 1, 'Administrator', 'create', 'accounting', 'Account', 515, '5-03-03-01-0001', 'Account 5-03-03-01-0001 created', '{"company_id": 3, "code": "5-03-03-01-0001", "name": "Marketing & Advertising \u2014 General", "type": "expense", "parent_id": 456, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(612, 3, '2026-10-29 08:52:26.130545', 1, 'Administrator', 'create', 'accounting', 'Account', 516, '5-04-01-01-0001', 'Account 5-04-01-01-0001 created', '{"company_id": 3, "code": "5-04-01-01-0001", "name": "Other Expenses \u2014 General", "type": "expense", "parent_id": 459, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(613, 3, '2026-10-29 08:52:26.135459', 1, 'Administrator', 'create', 'accounting', 'Account', 517, '5-04-01-01-0002', 'Account 5-04-01-01-0002 created', '{"company_id": 3, "code": "5-04-01-01-0002", "name": "Loss/(Gain) on Disposal of Fixed Assets", "type": "expense", "parent_id": 459, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(614, 3, '2026-10-29 08:52:26.140318', 1, 'Administrator', 'create', 'accounting', 'Account', 518, '5-05-01-01-0001', 'Account 5-05-01-01-0001 created', '{"company_id": 3, "code": "5-05-01-01-0001", "name": "Bank Charges", "type": "expense", "parent_id": 462, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(615, 3, '2026-10-29 08:52:26.145072', 1, 'Administrator', 'create', 'accounting', 'Account', 519, '5-05-01-01-0002', 'Account 5-05-01-01-0002 created', '{"company_id": 3, "code": "5-05-01-01-0002", "name": "Interest Expense", "type": "expense", "parent_id": 462, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(616, 3, '2026-10-29 08:52:26.148734', 1, 'Administrator', 'create', 'accounting', 'Account', 520, '5-06-01-01-0001', 'Account 5-06-01-01-0001 created', '{"company_id": 3, "code": "5-06-01-01-0001", "name": "Income Tax Expense", "type": "expense", "parent_id": 465, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(617, 3, '2026-10-29 08:52:26.193569', 1, 'Administrator', 'create', 'settings', 'Company profile', 3, 'SolarKon Energy Solutions', 'Company profile SolarKon Energy Solutions created', '{"company_id": 3, "company_name": "SolarKon Energy Solutions", "country": "Pakistan", "fiscal_year_start_month": 1, "currency": "PKR", "currency_symbol": "Rs.", "date_format": "Y-m-d", "number_format": "en", "timezone": "Asia/Karachi"}', '127.0.0.1', '/superadmin/companies/'),
	(618, 3, '2026-10-29 08:52:26.20295', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 17, 'FY 2021', 'Accounting period FY 2021 created', '{"company_id": 3, "fiscal_year": "2021", "period_name": "FY 2021", "start_date": "2021-01-01", "end_date": "2021-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(619, 3, '2026-10-29 08:52:26.202953', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 18, 'FY 2022', 'Accounting period FY 2022 created', '{"company_id": 3, "fiscal_year": "2022", "period_name": "FY 2022", "start_date": "2022-01-01", "end_date": "2022-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(620, 3, '2026-10-29 08:52:26.202955', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 19, 'FY 2023', 'Accounting period FY 2023 created', '{"company_id": 3, "fiscal_year": "2023", "period_name": "FY 2023", "start_date": "2023-01-01", "end_date": "2023-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(621, 3, '2026-10-29 08:52:26.202956', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 20, 'FY 2024', 'Accounting period FY 2024 created', '{"company_id": 3, "fiscal_year": "2024", "period_name": "FY 2024", "start_date": "2024-01-01", "end_date": "2024-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(622, 3, '2026-10-29 08:52:26.202957', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 21, 'FY 2025', 'Accounting period FY 2025 created', '{"company_id": 3, "fiscal_year": "2025", "period_name": "FY 2025", "start_date": "2025-01-01", "end_date": "2025-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(623, 3, '2026-10-29 08:52:26.202958', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 22, 'FY 2026', 'Accounting period FY 2026 created', '{"company_id": 3, "fiscal_year": "2026", "period_name": "FY 2026", "start_date": "2026-01-01", "end_date": "2026-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(624, 3, '2026-10-29 08:52:26.202959', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 23, 'FY 2027', 'Accounting period FY 2027 created', '{"company_id": 3, "fiscal_year": "2027", "period_name": "FY 2027", "start_date": "2027-01-01", "end_date": "2027-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(625, 3, '2026-10-29 08:52:26.202961', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 24, 'FY 2028', 'Accounting period FY 2028 created', '{"company_id": 3, "fiscal_year": "2028", "period_name": "FY 2028", "start_date": "2028-01-01", "end_date": "2028-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(630, 4, '2026-10-29 08:52:26.352844', 1, 'Administrator', 'create', 'accounting', 'Account', 521, '1', 'Account 1 created', '{"company_id": 4, "code": "1", "name": "Assets", "type": "asset", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(631, 4, '2026-10-29 08:52:26.357932', 1, 'Administrator', 'create', 'accounting', 'Account', 522, '1-01', 'Account 1-01 created', '{"company_id": 4, "code": "1-01", "name": "Current Assets", "type": "asset", "parent_id": 521, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(632, 4, '2026-10-29 08:52:26.363029', 1, 'Administrator', 'create', 'accounting', 'Account', 523, '1-01-01', 'Account 1-01-01 created', '{"company_id": 4, "code": "1-01-01", "name": "Cash & Cash Equivalents", "type": "asset", "parent_id": 522, "level": 3, "is_fixed": true, "is_active": true, "cash_flow_activity": "cash"}', '127.0.0.1', '/superadmin/companies/'),
	(633, 4, '2026-10-29 08:52:26.368241', 1, 'Administrator', 'create', 'accounting', 'Account', 524, '1-01-01-01', 'Account 1-01-01-01 created', '{"company_id": 4, "code": "1-01-01-01", "name": "Cash in Hand", "type": "asset", "parent_id": 523, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(634, 4, '2026-10-29 08:52:26.37301', 1, 'Administrator', 'create', 'accounting', 'Account', 525, '1-01-01-02', 'Account 1-01-01-02 created', '{"company_id": 4, "code": "1-01-01-02", "name": "Bank Accounts", "type": "asset", "parent_id": 523, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(635, 4, '2026-10-29 08:52:26.377926', 1, 'Administrator', 'create', 'accounting', 'Account', 526, '1-01-02', 'Account 1-01-02 created', '{"company_id": 4, "code": "1-01-02", "name": "Trade Receivables", "type": "asset", "parent_id": 522, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(636, 4, '2026-10-29 08:52:26.382863', 1, 'Administrator', 'create', 'accounting', 'Account', 527, '1-01-02-01', 'Account 1-01-02-01 created', '{"company_id": 4, "code": "1-01-02-01", "name": "Trade Debtors", "type": "asset", "parent_id": 526, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(637, 4, '2026-10-29 08:52:26.388542', 1, 'Administrator', 'create', 'accounting', 'Account', 528, '1-01-02-02', 'Account 1-01-02-02 created', '{"company_id": 4, "code": "1-01-02-02", "name": "Doubtful Receivables", "type": "asset", "parent_id": 526, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(638, 4, '2026-10-29 08:52:26.393472', 1, 'Administrator', 'create', 'accounting', 'Account', 529, '1-01-03', 'Account 1-01-03 created', '{"company_id": 4, "code": "1-01-03", "name": "Other Receivables", "type": "asset", "parent_id": 522, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(639, 4, '2026-10-29 08:52:26.398298', 1, 'Administrator', 'create', 'accounting', 'Account', 530, '1-01-03-01', 'Account 1-01-03-01 created', '{"company_id": 4, "code": "1-01-03-01", "name": "Employee Loans & Advances", "type": "asset", "parent_id": 529, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(640, 4, '2026-10-29 08:52:26.403205', 1, 'Administrator', 'create', 'accounting', 'Account', 531, '1-01-03-02', 'Account 1-01-03-02 created', '{"company_id": 4, "code": "1-01-03-02", "name": "Advances to Suppliers", "type": "asset", "parent_id": 529, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(641, 4, '2026-10-29 08:52:26.407943', 1, 'Administrator', 'create', 'accounting', 'Account', 532, '1-01-04', 'Account 1-01-04 created', '{"company_id": 4, "code": "1-01-04", "name": "Inventories", "type": "asset", "parent_id": 522, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(642, 4, '2026-10-29 08:52:26.412611', 1, 'Administrator', 'create', 'accounting', 'Account', 533, '1-01-04-01', 'Account 1-01-04-01 created', '{"company_id": 4, "code": "1-01-04-01", "name": "Trading Goods Stock", "type": "asset", "parent_id": 532, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(643, 4, '2026-10-29 08:52:26.41714', 1, 'Administrator', 'create', 'accounting', 'Account', 534, '1-01-05', 'Account 1-01-05 created', '{"company_id": 4, "code": "1-01-05", "name": "Tax Assets", "type": "asset", "parent_id": 522, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(644, 4, '2026-10-29 08:52:26.421761', 1, 'Administrator', 'create', 'accounting', 'Account', 535, '1-01-05-01', 'Account 1-01-05-01 created', '{"company_id": 4, "code": "1-01-05-01", "name": "Input Sales Tax", "type": "asset", "parent_id": 534, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(645, 4, '2026-10-29 08:52:26.426297', 1, 'Administrator', 'create', 'accounting', 'Account', 536, '1-01-05-02', 'Account 1-01-05-02 created', '{"company_id": 4, "code": "1-01-05-02", "name": "WHT Receivable", "type": "asset", "parent_id": 534, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(646, 4, '2026-10-29 08:52:26.430552', 1, 'Administrator', 'create', 'accounting', 'Account', 537, '1-01-06', 'Account 1-01-06 created', '{"company_id": 4, "code": "1-01-06", "name": "Prepayments & Other", "type": "asset", "parent_id": 522, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(647, 4, '2026-10-29 08:52:26.435108', 1, 'Administrator', 'create', 'accounting', 'Account', 538, '1-01-06-01', 'Account 1-01-06-01 created', '{"company_id": 4, "code": "1-01-06-01", "name": "Suspense & Clearing", "type": "asset", "parent_id": 537, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(648, 4, '2026-10-29 08:52:26.439609', 1, 'Administrator', 'create', 'accounting', 'Account', 539, '1-01-06-02', 'Account 1-01-06-02 created', '{"company_id": 4, "code": "1-01-06-02", "name": "Prepaid Expenses", "type": "asset", "parent_id": 537, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(649, 4, '2026-10-29 08:52:26.444155', 1, 'Administrator', 'create', 'accounting', 'Account', 540, '1-01-06-03', 'Account 1-01-06-03 created', '{"company_id": 4, "code": "1-01-06-03", "name": "Other Current Assets", "type": "asset", "parent_id": 537, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(650, 4, '2026-10-29 08:52:26.44879', 1, 'Administrator', 'create', 'accounting', 'Account', 541, '1-02', 'Account 1-02 created', '{"company_id": 4, "code": "1-02", "name": "Non-Current Assets", "type": "asset", "parent_id": 521, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "investing"}', '127.0.0.1', '/superadmin/companies/'),
	(651, 4, '2026-10-29 08:52:26.453711', 1, 'Administrator', 'create', 'accounting', 'Account', 542, '1-02-01', 'Account 1-02-01 created', '{"company_id": 4, "code": "1-02-01", "name": "Property, Plant & Equipment", "type": "asset", "parent_id": 541, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(652, 4, '2026-10-29 08:52:26.45848', 1, 'Administrator', 'create', 'accounting', 'Account', 543, '1-02-01-01', 'Account 1-02-01-01 created', '{"company_id": 4, "code": "1-02-01-01", "name": "Owned Assets", "type": "asset", "parent_id": 542, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(653, 4, '2026-10-29 08:52:26.463188', 1, 'Administrator', 'create', 'accounting', 'Account', 544, '1-02-02', 'Account 1-02-02 created', '{"company_id": 4, "code": "1-02-02", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 541, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(654, 4, '2026-10-29 08:52:26.467842', 1, 'Administrator', 'create', 'accounting', 'Account', 545, '1-02-02-01', 'Account 1-02-02-01 created', '{"company_id": 4, "code": "1-02-02-01", "name": "Accumulated Depreciation", "type": "asset", "parent_id": 544, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(655, 4, '2026-10-29 08:52:26.472586', 1, 'Administrator', 'create', 'accounting', 'Account', 546, '1-02-03', 'Account 1-02-03 created', '{"company_id": 4, "code": "1-02-03", "name": "Intangible Assets", "type": "asset", "parent_id": 541, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(656, 4, '2026-10-29 08:52:26.477586', 1, 'Administrator', 'create', 'accounting', 'Account', 547, '1-02-03-01', 'Account 1-02-03-01 created', '{"company_id": 4, "code": "1-02-03-01", "name": "Intangibles", "type": "asset", "parent_id": 546, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(657, 4, '2026-10-29 08:52:26.480622', 1, 'Administrator', 'create', 'accounting', 'Account', 548, '2', 'Account 2 created', '{"company_id": 4, "code": "2", "name": "Liabilities", "type": "liability", "level": 1, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(658, 4, '2026-10-29 08:52:26.485418', 1, 'Administrator', 'create', 'accounting', 'Account', 549, '2-01', 'Account 2-01 created', '{"company_id": 4, "code": "2-01", "name": "Current Liabilities", "type": "liability", "parent_id": 548, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(659, 4, '2026-10-29 08:52:26.490104', 1, 'Administrator', 'create', 'accounting', 'Account', 550, '2-01-01', 'Account 2-01-01 created', '{"company_id": 4, "code": "2-01-01", "name": "Trade Payables", "type": "liability", "parent_id": 549, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(660, 4, '2026-10-29 08:52:26.494805', 1, 'Administrator', 'create', 'accounting', 'Account', 551, '2-01-01-01', 'Account 2-01-01-01 created', '{"company_id": 4, "code": "2-01-01-01", "name": "Trade Creditors", "type": "liability", "parent_id": 550, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(661, 4, '2026-10-29 08:52:26.49954', 1, 'Administrator', 'create', 'accounting', 'Account', 552, '2-01-02', 'Account 2-01-02 created', '{"company_id": 4, "code": "2-01-02", "name": "Accrued & Payroll Liabilities", "type": "liability", "parent_id": 549, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(662, 4, '2026-10-29 08:52:26.504558', 1, 'Administrator', 'create', 'accounting', 'Account', 553, '2-01-02-01', 'Account 2-01-02-01 created', '{"company_id": 4, "code": "2-01-02-01", "name": "Employee Payables", "type": "liability", "parent_id": 552, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(663, 4, '2026-10-29 08:52:26.509028', 1, 'Administrator', 'create', 'accounting', 'Account', 554, '2-01-02-02', 'Account 2-01-02-02 created', '{"company_id": 4, "code": "2-01-02-02", "name": "Payroll Liabilities", "type": "liability", "parent_id": 552, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(664, 4, '2026-10-29 08:52:26.513453', 1, 'Administrator', 'create', 'accounting', 'Account', 555, '2-01-02-03', 'Account 2-01-02-03 created', '{"company_id": 4, "code": "2-01-02-03", "name": "Accrued Expenses", "type": "liability", "parent_id": 552, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(665, 4, '2026-10-29 08:52:26.517854', 1, 'Administrator', 'create', 'accounting', 'Account', 556, '2-01-03', 'Account 2-01-03 created', '{"company_id": 4, "code": "2-01-03", "name": "Tax Liabilities", "type": "liability", "parent_id": 549, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(666, 4, '2026-10-29 08:52:26.524143', 1, 'Administrator', 'create', 'accounting', 'Account', 557, '2-01-03-01', 'Account 2-01-03-01 created', '{"company_id": 4, "code": "2-01-03-01", "name": "Output Sales Tax", "type": "liability", "parent_id": 556, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(667, 4, '2026-10-29 08:52:26.528952', 1, 'Administrator', 'create', 'accounting', 'Account', 558, '2-01-03-02', 'Account 2-01-03-02 created', '{"company_id": 4, "code": "2-01-03-02", "name": "Income Tax Payable", "type": "liability", "parent_id": 556, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(668, 4, '2026-10-29 08:52:26.533561', 1, 'Administrator', 'create', 'accounting', 'Account', 559, '2-01-03-03', 'Account 2-01-03-03 created', '{"company_id": 4, "code": "2-01-03-03", "name": "WHT Payable", "type": "liability", "parent_id": 556, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(669, 4, '2026-10-29 08:52:26.539118', 1, 'Administrator', 'create', 'accounting', 'Account', 560, '2-01-03-04', 'Account 2-01-03-04 created', '{"company_id": 4, "code": "2-01-03-04", "name": "Further Tax Payable", "type": "liability", "parent_id": 556, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(670, 4, '2026-10-29 08:52:26.543797', 1, 'Administrator', 'create', 'accounting', 'Account', 561, '2-01-04', 'Account 2-01-04 created', '{"company_id": 4, "code": "2-01-04", "name": "Advances from Customers", "type": "liability", "parent_id": 549, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(671, 4, '2026-10-29 08:52:26.548495', 1, 'Administrator', 'create', 'accounting', 'Account', 562, '2-01-04-01', 'Account 2-01-04-01 created', '{"company_id": 4, "code": "2-01-04-01", "name": "Customer Advances", "type": "liability", "parent_id": 561, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(672, 4, '2026-10-29 08:52:26.55318', 1, 'Administrator', 'create', 'accounting', 'Account', 563, '2-02', 'Account 2-02 created', '{"company_id": 4, "code": "2-02", "name": "Non-Current Liabilities", "type": "liability", "parent_id": 548, "level": 2, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/superadmin/companies/'),
	(673, 4, '2026-10-29 08:52:26.557563', 1, 'Administrator', 'create', 'accounting', 'Account', 564, '2-02-01', 'Account 2-02-01 created', '{"company_id": 4, "code": "2-02-01", "name": "Long-term Loans", "type": "liability", "parent_id": 563, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(674, 4, '2026-10-29 08:52:26.561958', 1, 'Administrator', 'create', 'accounting', 'Account', 565, '2-02-01-01', 'Account 2-02-01-01 created', '{"company_id": 4, "code": "2-02-01-01", "name": "Long-term Loans", "type": "liability", "parent_id": 564, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(675, 4, '2026-10-29 08:52:26.566195', 1, 'Administrator', 'create', 'accounting', 'Account', 566, '2-02-02', 'Account 2-02-02 created', '{"company_id": 4, "code": "2-02-02", "name": "Employee End-of-Service Benefits", "type": "liability", "parent_id": 563, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(676, 4, '2026-10-29 08:52:26.570666', 1, 'Administrator', 'create', 'accounting', 'Account', 567, '2-02-02-01', 'Account 2-02-02-01 created', '{"company_id": 4, "code": "2-02-02-01", "name": "EOSB Provision", "type": "liability", "parent_id": 566, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(677, 4, '2026-10-29 08:52:26.573428', 1, 'Administrator', 'create', 'accounting', 'Account', 568, '3', 'Account 3 created', '{"company_id": 4, "code": "3", "name": "Equity", "type": "equity", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "financing"}', '127.0.0.1', '/superadmin/companies/'),
	(678, 4, '2026-10-29 08:52:26.577671', 1, 'Administrator', 'create', 'accounting', 'Account', 569, '3-01', 'Account 3-01 created', '{"company_id": 4, "code": "3-01", "name": "Capital", "type": "equity", "parent_id": 568, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(679, 4, '2026-10-29 08:52:26.582018', 1, 'Administrator', 'create', 'accounting', 'Account', 570, '3-01-01', 'Account 3-01-01 created', '{"company_id": 4, "code": "3-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 569, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(680, 4, '2026-10-29 08:52:26.586804', 1, 'Administrator', 'create', 'accounting', 'Account', 571, '3-01-01-01', 'Account 3-01-01-01 created', '{"company_id": 4, "code": "3-01-01-01", "name": "Owner Capital", "type": "equity", "parent_id": 570, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(681, 4, '2026-10-29 08:52:26.59157', 1, 'Administrator', 'create', 'accounting', 'Account', 572, '3-02', 'Account 3-02 created', '{"company_id": 4, "code": "3-02", "name": "Reserves & Retained Earnings", "type": "equity", "parent_id": 568, "level": 2, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(682, 4, '2026-10-29 08:52:26.596344', 1, 'Administrator', 'create', 'accounting', 'Account', 573, '3-02-01', 'Account 3-02-01 created', '{"company_id": 4, "code": "3-02-01", "name": "Retained Earnings", "type": "equity", "parent_id": 572, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(683, 4, '2026-10-29 08:52:26.600879', 1, 'Administrator', 'create', 'accounting', 'Account', 574, '3-02-01-01', 'Account 3-02-01-01 created', '{"company_id": 4, "code": "3-02-01-01", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 573, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(684, 4, '2026-10-29 08:52:26.605322', 1, 'Administrator', 'create', 'accounting', 'Account', 575, '3-02-01-02', 'Account 3-02-01-02 created', '{"company_id": 4, "code": "3-02-01-02", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 573, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(685, 4, '2026-10-29 08:52:26.609778', 1, 'Administrator', 'create', 'accounting', 'Account', 576, '3-02-02', 'Account 3-02-02 created', '{"company_id": 4, "code": "3-02-02", "name": "Dividends", "type": "equity", "parent_id": 572, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(686, 4, '2026-10-29 08:52:26.61438', 1, 'Administrator', 'create', 'accounting', 'Account', 577, '3-02-02-01', 'Account 3-02-02-01 created', '{"company_id": 4, "code": "3-02-02-01", "name": "Dividends", "type": "equity", "parent_id": 576, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(687, 4, '2026-10-29 08:52:26.61922', 1, 'Administrator', 'create', 'accounting', 'Account', 578, '3-02-03', 'Account 3-02-03 created', '{"company_id": 4, "code": "3-02-03", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 572, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(688, 4, '2026-10-29 08:52:26.624531', 1, 'Administrator', 'create', 'accounting', 'Account', 579, '3-02-03-01', 'Account 3-02-03-01 created', '{"company_id": 4, "code": "3-02-03-01", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 578, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(689, 4, '2026-10-29 08:52:26.62786', 1, 'Administrator', 'create', 'accounting', 'Account', 580, '4', 'Account 4 created', '{"company_id": 4, "code": "4", "name": "Revenue", "type": "revenue", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(690, 4, '2026-10-29 08:52:26.632865', 1, 'Administrator', 'create', 'accounting', 'Account', 581, '4-01', 'Account 4-01 created', '{"company_id": 4, "code": "4-01", "name": "Sales", "type": "revenue", "parent_id": 580, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales"}', '127.0.0.1', '/superadmin/companies/'),
	(691, 4, '2026-10-29 08:52:26.63831', 1, 'Administrator', 'create', 'accounting', 'Account', 582, '4-01-01', 'Account 4-01-01 created', '{"company_id": 4, "code": "4-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 581, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(692, 4, '2026-10-29 08:52:26.643576', 1, 'Administrator', 'create', 'accounting', 'Account', 583, '4-01-01-01', 'Account 4-01-01-01 created', '{"company_id": 4, "code": "4-01-01-01", "name": "Product Sales", "type": "revenue", "parent_id": 582, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(693, 4, '2026-10-29 08:52:26.64853', 1, 'Administrator', 'create', 'accounting', 'Account', 584, '4-01-02', 'Account 4-01-02 created', '{"company_id": 4, "code": "4-01-02", "name": "Service Income", "type": "revenue", "parent_id": 581, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(694, 4, '2026-10-29 08:52:26.65349', 1, 'Administrator', 'create', 'accounting', 'Account', 585, '4-01-02-01', 'Account 4-01-02-01 created', '{"company_id": 4, "code": "4-01-02-01", "name": "Service Income", "type": "revenue", "parent_id": 584, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(695, 4, '2026-10-29 08:52:26.658312', 1, 'Administrator', 'create', 'accounting', 'Account', 586, '4-02', 'Account 4-02 created', '{"company_id": 4, "code": "4-02", "name": "Sales Returns & Discounts", "type": "revenue", "parent_id": 580, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "sales_returns"}', '127.0.0.1', '/superadmin/companies/'),
	(696, 4, '2026-10-29 08:52:26.663041', 1, 'Administrator', 'create', 'accounting', 'Account', 587, '4-02-01', 'Account 4-02-01 created', '{"company_id": 4, "code": "4-02-01", "name": "Sales Returns", "type": "revenue", "parent_id": 586, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(697, 4, '2026-10-29 08:52:26.667769', 1, 'Administrator', 'create', 'accounting', 'Account', 588, '4-02-01-01', 'Account 4-02-01-01 created', '{"company_id": 4, "code": "4-02-01-01", "name": "Sales Returns", "type": "revenue", "parent_id": 587, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(698, 4, '2026-10-29 08:52:26.67277', 1, 'Administrator', 'create', 'accounting', 'Account', 589, '4-02-02', 'Account 4-02-02 created', '{"company_id": 4, "code": "4-02-02", "name": "Discounts Allowed", "type": "revenue", "parent_id": 586, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(699, 4, '2026-10-29 08:52:26.678014', 1, 'Administrator', 'create', 'accounting', 'Account', 590, '4-02-02-01', 'Account 4-02-02-01 created', '{"company_id": 4, "code": "4-02-02-01", "name": "Discounts Allowed", "type": "revenue", "parent_id": 589, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(700, 4, '2026-10-29 08:52:26.683381', 1, 'Administrator', 'create', 'accounting', 'Account', 591, '4-03', 'Account 4-03 created', '{"company_id": 4, "code": "4-03", "name": "Other Income", "type": "revenue", "parent_id": 580, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_income"}', '127.0.0.1', '/superadmin/companies/'),
	(701, 4, '2026-10-29 08:52:26.688995', 1, 'Administrator', 'create', 'accounting', 'Account', 592, '4-03-01', 'Account 4-03-01 created', '{"company_id": 4, "code": "4-03-01", "name": "Other Income", "type": "revenue", "parent_id": 591, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(702, 4, '2026-10-29 08:52:26.69446', 1, 'Administrator', 'create', 'accounting', 'Account', 593, '4-03-01-01', 'Account 4-03-01-01 created', '{"company_id": 4, "code": "4-03-01-01", "name": "Other Income", "type": "revenue", "parent_id": 592, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(703, 4, '2026-10-29 08:52:26.697894', 1, 'Administrator', 'create', 'accounting', 'Account', 594, '5', 'Account 5 created', '{"company_id": 4, "code": "5", "name": "Expenses", "type": "expense", "level": 1, "is_fixed": true, "is_active": true, "cash_flow_activity": "operating"}', '127.0.0.1', '/superadmin/companies/'),
	(704, 4, '2026-10-29 08:52:26.702915', 1, 'Administrator', 'create', 'accounting', 'Account', 595, '5-01', 'Account 5-01 created', '{"company_id": 4, "code": "5-01", "name": "Cost of Sales", "type": "expense", "parent_id": 594, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "cost_of_sales"}', '127.0.0.1', '/superadmin/companies/'),
	(705, 4, '2026-10-29 08:52:26.708007', 1, 'Administrator', 'create', 'accounting', 'Account', 596, '5-01-01', 'Account 5-01-01 created', '{"company_id": 4, "code": "5-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 595, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(706, 4, '2026-10-29 08:52:26.712954', 1, 'Administrator', 'create', 'accounting', 'Account', 597, '5-01-01-01', 'Account 5-01-01-01 created', '{"company_id": 4, "code": "5-01-01-01", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 596, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(707, 4, '2026-10-29 08:52:26.717891', 1, 'Administrator', 'create', 'accounting', 'Account', 598, '5-01-02', 'Account 5-01-02 created', '{"company_id": 4, "code": "5-01-02", "name": "Stock Losses, Scrap & Adjustments", "type": "expense", "parent_id": 595, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(708, 4, '2026-10-29 08:52:26.722583', 1, 'Administrator', 'create', 'accounting', 'Account', 599, '5-01-02-01', 'Account 5-01-02-01 created', '{"company_id": 4, "code": "5-01-02-01", "name": "Stock Losses & Scrap", "type": "expense", "parent_id": 598, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(709, 4, '2026-10-29 08:52:26.727592', 1, 'Administrator', 'create', 'accounting', 'Account', 600, '5-02', 'Account 5-02 created', '{"company_id": 4, "code": "5-02", "name": "Administrative Expenses", "type": "expense", "parent_id": 594, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "admin"}', '127.0.0.1', '/superadmin/companies/'),
	(710, 4, '2026-10-29 08:52:26.732433', 1, 'Administrator', 'create', 'accounting', 'Account', 601, '5-02-01', 'Account 5-02-01 created', '{"company_id": 4, "code": "5-02-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 600, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(711, 4, '2026-10-29 08:52:26.737329', 1, 'Administrator', 'create', 'accounting', 'Account', 602, '5-02-01-01', 'Account 5-02-01-01 created', '{"company_id": 4, "code": "5-02-01-01", "name": "Salaries & Benefits", "type": "expense", "parent_id": 601, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(712, 4, '2026-10-29 08:52:26.742463', 1, 'Administrator', 'create', 'accounting', 'Account', 603, '5-02-02', 'Account 5-02-02 created', '{"company_id": 4, "code": "5-02-02", "name": "Rent & Utilities", "type": "expense", "parent_id": 600, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(713, 4, '2026-10-29 08:52:26.747344', 1, 'Administrator', 'create', 'accounting', 'Account', 604, '5-02-02-01', 'Account 5-02-02-01 created', '{"company_id": 4, "code": "5-02-02-01", "name": "Rent & Utilities", "type": "expense", "parent_id": 603, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(714, 4, '2026-10-29 08:52:26.752132', 1, 'Administrator', 'create', 'accounting', 'Account', 605, '5-02-03', 'Account 5-02-03 created', '{"company_id": 4, "code": "5-02-03", "name": "Office & Supplies", "type": "expense", "parent_id": 600, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(715, 4, '2026-10-29 08:52:26.757027', 1, 'Administrator', 'create', 'accounting', 'Account', 606, '5-02-03-01', 'Account 5-02-03-01 created', '{"company_id": 4, "code": "5-02-03-01", "name": "Office & Supplies", "type": "expense", "parent_id": 605, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(716, 4, '2026-10-29 08:52:26.76207', 1, 'Administrator', 'create', 'accounting', 'Account', 607, '5-02-04', 'Account 5-02-04 created', '{"company_id": 4, "code": "5-02-04", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 600, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(717, 4, '2026-10-29 08:52:26.766773', 1, 'Administrator', 'create', 'accounting', 'Account', 608, '5-02-04-01', 'Account 5-02-04-01 created', '{"company_id": 4, "code": "5-02-04-01", "name": "Depreciation & Amortisation", "type": "expense", "parent_id": 607, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(718, 4, '2026-10-29 08:52:26.771457', 1, 'Administrator', 'create', 'accounting', 'Account', 609, '5-02-05', 'Account 5-02-05 created', '{"company_id": 4, "code": "5-02-05", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 600, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(719, 4, '2026-10-29 08:52:26.776206', 1, 'Administrator', 'create', 'accounting', 'Account', 610, '5-02-05-01', 'Account 5-02-05-01 created', '{"company_id": 4, "code": "5-02-05-01", "name": "Fees, Taxes & Licenses", "type": "expense", "parent_id": 609, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(720, 4, '2026-10-29 08:52:26.780726', 1, 'Administrator', 'create', 'accounting', 'Account', 611, '5-03', 'Account 5-03 created', '{"company_id": 4, "code": "5-03", "name": "Selling & Distribution", "type": "expense", "parent_id": 594, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "selling_distribution"}', '127.0.0.1', '/superadmin/companies/'),
	(721, 4, '2026-10-29 08:52:26.785084', 1, 'Administrator', 'create', 'accounting', 'Account', 612, '5-03-01', 'Account 5-03-01 created', '{"company_id": 4, "code": "5-03-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 611, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(722, 4, '2026-10-29 08:52:26.789248', 1, 'Administrator', 'create', 'accounting', 'Account', 613, '5-03-01-01', 'Account 5-03-01-01 created', '{"company_id": 4, "code": "5-03-01-01", "name": "Freight & Transportation", "type": "expense", "parent_id": 612, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(723, 4, '2026-10-29 08:52:26.793558', 1, 'Administrator', 'create', 'accounting', 'Account', 614, '5-03-02', 'Account 5-03-02 created', '{"company_id": 4, "code": "5-03-02", "name": "Commissions", "type": "expense", "parent_id": 611, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(724, 4, '2026-10-29 08:52:26.798039', 1, 'Administrator', 'create', 'accounting', 'Account', 615, '5-03-02-01', 'Account 5-03-02-01 created', '{"company_id": 4, "code": "5-03-02-01", "name": "Commissions", "type": "expense", "parent_id": 614, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(725, 4, '2026-10-29 08:52:26.802442', 1, 'Administrator', 'create', 'accounting', 'Account', 616, '5-03-03', 'Account 5-03-03 created', '{"company_id": 4, "code": "5-03-03", "name": "Marketing & Advertising", "type": "expense", "parent_id": 611, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(726, 4, '2026-10-29 08:52:26.807158', 1, 'Administrator', 'create', 'accounting', 'Account', 617, '5-03-03-01', 'Account 5-03-03-01 created', '{"company_id": 4, "code": "5-03-03-01", "name": "Marketing & Advertising", "type": "expense", "parent_id": 616, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(727, 4, '2026-10-29 08:52:26.811482', 1, 'Administrator', 'create', 'accounting', 'Account', 618, '5-04', 'Account 5-04 created', '{"company_id": 4, "code": "5-04", "name": "Other Operating Expenses", "type": "expense", "parent_id": 594, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "other_operating"}', '127.0.0.1', '/superadmin/companies/'),
	(728, 4, '2026-10-29 08:52:26.815893', 1, 'Administrator', 'create', 'accounting', 'Account', 619, '5-04-01', 'Account 5-04-01 created', '{"company_id": 4, "code": "5-04-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 618, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(729, 4, '2026-10-29 08:52:26.821202', 1, 'Administrator', 'create', 'accounting', 'Account', 620, '5-04-01-01', 'Account 5-04-01-01 created', '{"company_id": 4, "code": "5-04-01-01", "name": "Other Operating Expenses", "type": "expense", "parent_id": 619, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(730, 4, '2026-10-29 08:52:26.827815', 1, 'Administrator', 'create', 'accounting', 'Account', 621, '5-05', 'Account 5-05 created', '{"company_id": 4, "code": "5-05", "name": "Finance Costs", "type": "expense", "parent_id": 594, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "finance_cost"}', '127.0.0.1', '/superadmin/companies/'),
	(731, 4, '2026-10-29 08:52:26.83425', 1, 'Administrator', 'create', 'accounting', 'Account', 622, '5-05-01', 'Account 5-05-01 created', '{"company_id": 4, "code": "5-05-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 621, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(732, 4, '2026-10-29 08:52:26.839448', 1, 'Administrator', 'create', 'accounting', 'Account', 623, '5-05-01-01', 'Account 5-05-01-01 created', '{"company_id": 4, "code": "5-05-01-01", "name": "Bank & Interest Charges", "type": "expense", "parent_id": 622, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(733, 4, '2026-10-29 08:52:26.844903', 1, 'Administrator', 'create', 'accounting', 'Account', 624, '5-06', 'Account 5-06 created', '{"company_id": 4, "code": "5-06", "name": "Taxation", "type": "expense", "parent_id": 594, "level": 2, "is_fixed": true, "is_active": true, "pl_section": "income_tax"}', '127.0.0.1', '/superadmin/companies/'),
	(734, 4, '2026-10-29 08:52:26.850406', 1, 'Administrator', 'create', 'accounting', 'Account', 625, '5-06-01', 'Account 5-06-01 created', '{"company_id": 4, "code": "5-06-01", "name": "Income Tax", "type": "expense", "parent_id": 624, "level": 3, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(735, 4, '2026-10-29 08:52:26.855878', 1, 'Administrator', 'create', 'accounting', 'Account', 626, '5-06-01-01', 'Account 5-06-01-01 created', '{"company_id": 4, "code": "5-06-01-01", "name": "Income Tax", "type": "expense", "parent_id": 625, "level": 4, "is_fixed": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(736, 4, '2026-10-29 08:52:26.864228', 1, 'Administrator', 'create', 'accounting', 'Account', 627, '1-01-01-01-0001', 'Account 1-01-01-01-0001 created', '{"company_id": 4, "code": "1-01-01-01-0001", "name": "Main Cash", "type": "asset", "parent_id": 524, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(737, 4, '2026-10-29 08:52:26.86956', 1, 'Administrator', 'create', 'accounting', 'Account', 628, '1-01-02-01-0001', 'Account 1-01-02-01-0001 created', '{"company_id": 4, "code": "1-01-02-01-0001", "name": "Trade Debtors \u2014 General", "type": "asset", "parent_id": 527, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(738, 4, '2026-10-29 08:52:26.874965', 1, 'Administrator', 'create', 'accounting', 'Account', 629, '1-01-03-02-0001', 'Account 1-01-03-02-0001 created', '{"company_id": 4, "code": "1-01-03-02-0001", "name": "Advances to Suppliers \u2014 General", "type": "asset", "parent_id": 531, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(739, 4, '2026-10-29 08:52:26.880253', 1, 'Administrator', 'create', 'accounting', 'Account', 630, '1-01-04-01-0001', 'Account 1-01-04-01-0001 created', '{"company_id": 4, "code": "1-01-04-01-0001", "name": "Stock \u2014 General", "type": "asset", "parent_id": 533, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(740, 4, '2026-10-29 08:52:26.885676', 1, 'Administrator', 'create', 'accounting', 'Account', 631, '1-01-05-01-0001', 'Account 1-01-05-01-0001 created', '{"company_id": 4, "code": "1-01-05-01-0001", "name": "Input Sales Tax", "type": "asset", "parent_id": 535, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(741, 4, '2026-10-29 08:52:26.891099', 1, 'Administrator', 'create', 'accounting', 'Account', 632, '1-01-05-02-0001', 'Account 1-01-05-02-0001 created', '{"company_id": 4, "code": "1-01-05-02-0001", "name": "WHT Receivable", "type": "asset", "parent_id": 536, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(742, 4, '2026-10-29 08:52:26.896068', 1, 'Administrator', 'create', 'accounting', 'Account', 633, '1-01-06-01-0001', 'Account 1-01-06-01-0001 created', '{"company_id": 4, "code": "1-01-06-01-0001", "name": "Suspense Account", "type": "asset", "parent_id": 538, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(743, 4, '2026-10-29 08:52:26.900934', 1, 'Administrator', 'create', 'accounting', 'Account', 634, '1-01-06-02-0001', 'Account 1-01-06-02-0001 created', '{"company_id": 4, "code": "1-01-06-02-0001", "name": "Prepaid Expenses \u2014 General", "type": "asset", "parent_id": 539, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(744, 4, '2026-10-29 08:52:26.905814', 1, 'Administrator', 'create', 'accounting', 'Account', 635, '1-02-01-01-0001', 'Account 1-02-01-01-0001 created', '{"company_id": 4, "code": "1-02-01-01-0001", "name": "Fixed Assets \u2014 General", "type": "asset", "parent_id": 543, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(745, 4, '2026-10-29 08:52:26.910985', 1, 'Administrator', 'create', 'accounting', 'Account', 636, '1-02-02-01-0001', 'Account 1-02-02-01-0001 created', '{"company_id": 4, "code": "1-02-02-01-0001", "name": "Accumulated Depreciation \u2014 General", "type": "asset", "parent_id": 545, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(746, 4, '2026-10-29 08:52:26.915827', 1, 'Administrator', 'create', 'accounting', 'Account', 637, '1-02-03-01-0001', 'Account 1-02-03-01-0001 created', '{"company_id": 4, "code": "1-02-03-01-0001", "name": "Intangibles \u2014 General", "type": "asset", "parent_id": 547, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(747, 4, '2026-10-29 08:52:26.920645', 1, 'Administrator', 'create', 'accounting', 'Account', 638, '2-01-01-01-0001', 'Account 2-01-01-01-0001 created', '{"company_id": 4, "code": "2-01-01-01-0001", "name": "Trade Creditors \u2014 General", "type": "liability", "parent_id": 551, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(748, 4, '2026-10-29 08:52:26.925561', 1, 'Administrator', 'create', 'accounting', 'Account', 639, '2-01-02-02-0001', 'Account 2-01-02-02-0001 created', '{"company_id": 4, "code": "2-01-02-02-0001", "name": "Salary Payable", "type": "liability", "parent_id": 554, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(749, 4, '2026-10-29 08:52:26.930766', 1, 'Administrator', 'create', 'accounting', 'Account', 640, '2-01-02-02-0002', 'Account 2-01-02-02-0002 created', '{"company_id": 4, "code": "2-01-02-02-0002", "name": "PF Payable", "type": "liability", "parent_id": 554, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(750, 4, '2026-10-29 08:52:26.935649', 1, 'Administrator', 'create', 'accounting', 'Account', 641, '2-01-02-02-0003', 'Account 2-01-02-02-0003 created', '{"company_id": 4, "code": "2-01-02-02-0003", "name": "Loan Deductions Clearing", "type": "liability", "parent_id": 554, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(751, 4, '2026-10-29 08:52:26.940426', 1, 'Administrator', 'create', 'accounting', 'Account', 642, '2-01-02-02-0004', 'Account 2-01-02-02-0004 created', '{"company_id": 4, "code": "2-01-02-02-0004", "name": "Other Payroll Deductions Payable", "type": "liability", "parent_id": 554, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(752, 4, '2026-10-29 08:52:26.94565', 1, 'Administrator', 'create', 'accounting', 'Account', 643, '2-01-02-03-0001', 'Account 2-01-02-03-0001 created', '{"company_id": 4, "code": "2-01-02-03-0001", "name": "Accrued Expenses \u2014 General", "type": "liability", "parent_id": 555, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(753, 4, '2026-10-29 08:52:26.950462', 1, 'Administrator', 'create', 'accounting', 'Account', 644, '2-01-03-01-0001', 'Account 2-01-03-01-0001 created', '{"company_id": 4, "code": "2-01-03-01-0001", "name": "Output Sales Tax", "type": "liability", "parent_id": 557, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(754, 4, '2026-10-29 08:52:26.955311', 1, 'Administrator', 'create', 'accounting', 'Account', 645, '2-01-03-02-0001', 'Account 2-01-03-02-0001 created', '{"company_id": 4, "code": "2-01-03-02-0001", "name": "Income Tax Payable", "type": "liability", "parent_id": 558, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(755, 4, '2026-10-29 08:52:26.960009', 1, 'Administrator', 'create', 'accounting', 'Account', 646, '2-01-03-03-0001', 'Account 2-01-03-03-0001 created', '{"company_id": 4, "code": "2-01-03-03-0001", "name": "WHT Payable", "type": "liability", "parent_id": 559, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(756, 4, '2026-10-29 08:52:26.964797', 1, 'Administrator', 'create', 'accounting', 'Account', 647, '2-01-03-04-0001', 'Account 2-01-03-04-0001 created', '{"company_id": 4, "code": "2-01-03-04-0001", "name": "Further Tax Payable", "type": "liability", "parent_id": 560, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(757, 4, '2026-10-29 08:52:26.969379', 1, 'Administrator', 'create', 'accounting', 'Account', 648, '2-01-04-01-0001', 'Account 2-01-04-01-0001 created', '{"company_id": 4, "code": "2-01-04-01-0001", "name": "Customer Advances \u2014 General", "type": "liability", "parent_id": 562, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(758, 4, '2026-10-29 08:52:26.974024', 1, 'Administrator', 'create', 'accounting', 'Account', 649, '2-02-01-01-0001', 'Account 2-02-01-01-0001 created', '{"company_id": 4, "code": "2-02-01-01-0001", "name": "Long-term Loans \u2014 General", "type": "liability", "parent_id": 565, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(759, 4, '2026-10-29 08:52:26.979156', 1, 'Administrator', 'create', 'accounting', 'Account', 650, '2-02-02-01-0001', 'Account 2-02-02-01-0001 created', '{"company_id": 4, "code": "2-02-02-01-0001", "name": "EOSB Provision \u2014 General", "type": "liability", "parent_id": 567, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(760, 4, '2026-10-29 08:52:26.984317', 1, 'Administrator', 'create', 'accounting', 'Account', 651, '3-01-01-01-0001', 'Account 3-01-01-01-0001 created', '{"company_id": 4, "code": "3-01-01-01-0001", "name": "Share Capital", "type": "equity", "parent_id": 571, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(761, 4, '2026-10-29 08:52:26.98961', 1, 'Administrator', 'create', 'accounting', 'Account', 652, '3-01-01-01-0002', 'Account 3-01-01-01-0002 created', '{"company_id": 4, "code": "3-01-01-01-0002", "name": "Suspense Equity", "type": "equity", "parent_id": 571, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(762, 4, '2026-10-29 08:52:26.99485', 1, 'Administrator', 'create', 'accounting', 'Account', 653, '3-02-01-01-0001', 'Account 3-02-01-01-0001 created', '{"company_id": 4, "code": "3-02-01-01-0001", "name": "Retained Earnings \u2014 Opening", "type": "equity", "parent_id": 574, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(763, 4, '2026-10-29 08:52:27.000183', 1, 'Administrator', 'create', 'accounting', 'Account', 654, '3-02-01-02-0001', 'Account 3-02-01-02-0001 created', '{"company_id": 4, "code": "3-02-01-02-0001", "name": "Retained Earnings \u2014 Closing", "type": "equity", "parent_id": 575, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(764, 4, '2026-10-29 08:52:27.005286', 1, 'Administrator', 'create', 'accounting', 'Account', 655, '3-02-02-01-0001', 'Account 3-02-02-01-0001 created', '{"company_id": 4, "code": "3-02-02-01-0001", "name": "Dividends", "type": "equity", "parent_id": 577, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(765, 4, '2026-10-29 08:52:27.010356', 1, 'Administrator', 'create', 'accounting', 'Account', 656, '3-02-03-01-0001', 'Account 3-02-03-01-0001 created', '{"company_id": 4, "code": "3-02-03-01-0001", "name": "Other Comprehensive Income", "type": "equity", "parent_id": 579, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(766, 4, '2026-10-29 08:52:27.015587', 1, 'Administrator', 'create', 'accounting', 'Account', 657, '4-01-01-01-0001', 'Account 4-01-01-01-0001 created', '{"company_id": 4, "code": "4-01-01-01-0001", "name": "Sales \u2014 General", "type": "revenue", "parent_id": 583, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(767, 4, '2026-10-29 08:52:27.020637', 1, 'Administrator', 'create', 'accounting', 'Account', 658, '4-01-02-01-0001', 'Account 4-01-02-01-0001 created', '{"company_id": 4, "code": "4-01-02-01-0001", "name": "Service Income \u2014 General", "type": "revenue", "parent_id": 585, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(768, 4, '2026-10-29 08:52:27.026014', 1, 'Administrator', 'create', 'accounting', 'Account', 659, '4-02-01-01-0001', 'Account 4-02-01-01-0001 created', '{"company_id": 4, "code": "4-02-01-01-0001", "name": "Sales Returns \u2014 General", "type": "revenue", "parent_id": 588, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(769, 4, '2026-10-29 08:52:27.03112', 1, 'Administrator', 'create', 'accounting', 'Account', 660, '4-02-02-01-0001', 'Account 4-02-02-01-0001 created', '{"company_id": 4, "code": "4-02-02-01-0001", "name": "Discounts Allowed \u2014 General", "type": "revenue", "parent_id": 590, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(770, 4, '2026-10-29 08:52:27.036153', 1, 'Administrator', 'create', 'accounting', 'Account', 661, '4-03-01-01-0001', 'Account 4-03-01-01-0001 created', '{"company_id": 4, "code": "4-03-01-01-0001", "name": "Other Income \u2014 General", "type": "revenue", "parent_id": 593, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(771, 4, '2026-10-29 08:52:27.041253', 1, 'Administrator', 'create', 'accounting', 'Account', 662, '5-01-01-01-0001', 'Account 5-01-01-01-0001 created', '{"company_id": 4, "code": "5-01-01-01-0001", "name": "Cost of Goods Sold", "type": "expense", "parent_id": 597, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(772, 4, '2026-10-29 08:52:27.047016', 1, 'Administrator', 'create', 'accounting', 'Account', 663, '5-01-02-01-0001', 'Account 5-01-02-01-0001 created', '{"company_id": 4, "code": "5-01-02-01-0001", "name": "Scrap / Write-off", "type": "expense", "parent_id": 599, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(773, 4, '2026-10-29 08:52:27.053634', 1, 'Administrator', 'create', 'accounting', 'Account', 664, '5-01-02-01-0002', 'Account 5-01-02-01-0002 created', '{"company_id": 4, "code": "5-01-02-01-0002", "name": "Inventory Adjustment", "type": "expense", "parent_id": 599, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(774, 4, '2026-10-29 08:52:27.060022', 1, 'Administrator', 'create', 'accounting', 'Account', 665, '5-01-02-01-0003', 'Account 5-01-02-01-0003 created', '{"company_id": 4, "code": "5-01-02-01-0003", "name": "Consumption Expense", "type": "expense", "parent_id": 599, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(775, 4, '2026-10-29 08:52:27.066677', 1, 'Administrator', 'create', 'accounting', 'Account', 666, '5-01-02-01-0004', 'Account 5-01-02-01-0004 created', '{"company_id": 4, "code": "5-01-02-01-0004", "name": "Inventory Cost Variance", "type": "expense", "parent_id": 599, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(776, 4, '2026-10-29 08:52:27.072819', 1, 'Administrator', 'create', 'accounting', 'Account', 667, '5-02-01-01-0001', 'Account 5-02-01-01-0001 created', '{"company_id": 4, "code": "5-02-01-01-0001", "name": "Salary Expense", "type": "expense", "parent_id": 602, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(777, 4, '2026-10-29 08:52:27.079488', 1, 'Administrator', 'create', 'accounting', 'Account', 668, '5-02-01-01-0002', 'Account 5-02-01-01-0002 created', '{"company_id": 4, "code": "5-02-01-01-0002", "name": "PF Employer Expense", "type": "expense", "parent_id": 602, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(778, 4, '2026-10-29 08:52:27.085797', 1, 'Administrator', 'create', 'accounting', 'Account', 669, '5-02-02-01-0001', 'Account 5-02-02-01-0001 created', '{"company_id": 4, "code": "5-02-02-01-0001", "name": "Rent Expense", "type": "expense", "parent_id": 604, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(779, 4, '2026-10-29 08:52:27.092176', 1, 'Administrator', 'create', 'accounting', 'Account', 670, '5-02-02-01-0002', 'Account 5-02-02-01-0002 created', '{"company_id": 4, "code": "5-02-02-01-0002", "name": "Utilities Expense", "type": "expense", "parent_id": 604, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(780, 4, '2026-10-29 08:52:27.099035', 1, 'Administrator', 'create', 'accounting', 'Account', 671, '5-02-03-01-0001', 'Account 5-02-03-01-0001 created', '{"company_id": 4, "code": "5-02-03-01-0001", "name": "Office Supplies", "type": "expense", "parent_id": 606, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(781, 4, '2026-10-29 08:52:27.105573', 1, 'Administrator', 'create', 'accounting', 'Account', 672, '5-02-04-01-0001', 'Account 5-02-04-01-0001 created', '{"company_id": 4, "code": "5-02-04-01-0001", "name": "Depreciation Expense", "type": "expense", "parent_id": 608, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(782, 4, '2026-10-29 08:52:27.112206', 1, 'Administrator', 'create', 'accounting', 'Account', 673, '5-02-05-01-0001', 'Account 5-02-05-01-0001 created', '{"company_id": 4, "code": "5-02-05-01-0001", "name": "Fees, Taxes & Licenses \u2014 General", "type": "expense", "parent_id": 610, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(783, 4, '2026-10-29 08:52:27.118738', 1, 'Administrator', 'create', 'accounting', 'Account', 674, '5-03-01-01-0001', 'Account 5-03-01-01-0001 created', '{"company_id": 4, "code": "5-03-01-01-0001", "name": "Freight & Transportation \u2014 General", "type": "expense", "parent_id": 613, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(784, 4, '2026-10-29 08:52:27.125414', 1, 'Administrator', 'create', 'accounting', 'Account', 675, '5-03-02-01-0001', 'Account 5-03-02-01-0001 created', '{"company_id": 4, "code": "5-03-02-01-0001", "name": "Commissions \u2014 General", "type": "expense", "parent_id": 615, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(785, 4, '2026-10-29 08:52:27.132088', 1, 'Administrator', 'create', 'accounting', 'Account', 676, '5-03-03-01-0001', 'Account 5-03-03-01-0001 created', '{"company_id": 4, "code": "5-03-03-01-0001", "name": "Marketing & Advertising \u2014 General", "type": "expense", "parent_id": 617, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(786, 4, '2026-10-29 08:52:27.138584', 1, 'Administrator', 'create', 'accounting', 'Account', 677, '5-04-01-01-0001', 'Account 5-04-01-01-0001 created', '{"company_id": 4, "code": "5-04-01-01-0001", "name": "Other Expenses \u2014 General", "type": "expense", "parent_id": 620, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(787, 4, '2026-10-29 08:52:27.145388', 1, 'Administrator', 'create', 'accounting', 'Account', 678, '5-04-01-01-0002', 'Account 5-04-01-01-0002 created', '{"company_id": 4, "code": "5-04-01-01-0002", "name": "Loss/(Gain) on Disposal of Fixed Assets", "type": "expense", "parent_id": 620, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(788, 4, '2026-10-29 08:52:27.151889', 1, 'Administrator', 'create', 'accounting', 'Account', 679, '5-05-01-01-0001', 'Account 5-05-01-01-0001 created', '{"company_id": 4, "code": "5-05-01-01-0001", "name": "Bank Charges", "type": "expense", "parent_id": 623, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(789, 4, '2026-10-29 08:52:27.158593', 1, 'Administrator', 'create', 'accounting', 'Account', 680, '5-05-01-01-0002', 'Account 5-05-01-01-0002 created', '{"company_id": 4, "code": "5-05-01-01-0002", "name": "Interest Expense", "type": "expense", "parent_id": 623, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(790, 4, '2026-10-29 08:52:27.163687', 1, 'Administrator', 'create', 'accounting', 'Account', 681, '5-06-01-01-0001', 'Account 5-06-01-01-0001 created', '{"company_id": 4, "code": "5-06-01-01-0001", "name": "Income Tax Expense", "type": "expense", "parent_id": 626, "level": 5, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(791, 4, '2026-10-29 08:52:27.221044', 1, 'Administrator', 'create', 'settings', 'Company profile', 4, 'SolarKon Energy Solutions', 'Company profile SolarKon Energy Solutions created', '{"company_id": 4, "company_name": "SolarKon Energy Solutions", "country": "Pakistan", "fiscal_year_start_month": 1, "currency": "PKR", "currency_symbol": "Rs.", "date_format": "Y-m-d", "number_format": "en", "timezone": "Asia/Karachi"}', '127.0.0.1', '/superadmin/companies/'),
	(792, 4, '2026-10-29 08:52:27.234504', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 25, 'FY 2021', 'Accounting period FY 2021 created', '{"company_id": 4, "fiscal_year": "2021", "period_name": "FY 2021", "start_date": "2021-01-01", "end_date": "2021-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/');
INSERT INTO public.audit_logs VALUES
	(793, 4, '2026-10-29 08:52:27.23451', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 26, 'FY 2022', 'Accounting period FY 2022 created', '{"company_id": 4, "fiscal_year": "2022", "period_name": "FY 2022", "start_date": "2022-01-01", "end_date": "2022-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(794, 4, '2026-10-29 08:52:27.234512', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 27, 'FY 2023', 'Accounting period FY 2023 created', '{"company_id": 4, "fiscal_year": "2023", "period_name": "FY 2023", "start_date": "2023-01-01", "end_date": "2023-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(795, 4, '2026-10-29 08:52:27.234513', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 28, 'FY 2024', 'Accounting period FY 2024 created', '{"company_id": 4, "fiscal_year": "2024", "period_name": "FY 2024", "start_date": "2024-01-01", "end_date": "2024-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(796, 4, '2026-10-29 08:52:27.234515', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 29, 'FY 2025', 'Accounting period FY 2025 created', '{"company_id": 4, "fiscal_year": "2025", "period_name": "FY 2025", "start_date": "2025-01-01", "end_date": "2025-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(797, 4, '2026-10-29 08:52:27.234516', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 30, 'FY 2026', 'Accounting period FY 2026 created', '{"company_id": 4, "fiscal_year": "2026", "period_name": "FY 2026", "start_date": "2026-01-01", "end_date": "2026-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(798, 4, '2026-10-29 08:52:27.234518', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 31, 'FY 2027', 'Accounting period FY 2027 created', '{"company_id": 4, "fiscal_year": "2027", "period_name": "FY 2027", "start_date": "2027-01-01", "end_date": "2027-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(799, 4, '2026-10-29 08:52:27.234519', 1, 'Administrator', 'create', 'accounting', 'Accounting period', 32, 'FY 2028', 'Accounting period FY 2028 created', '{"company_id": 4, "fiscal_year": "2028", "period_name": "FY 2028", "start_date": "2028-01-01", "end_date": "2028-12-31", "is_open": true, "is_active": true}', '127.0.0.1', '/superadmin/companies/'),
	(806, NULL, '2026-10-29 08:52:27.87402', 9, 'Mixed Case', 'login', 'admin', NULL, NULL, NULL, 'Mixed Case signed in', NULL, '127.0.0.1', '/auth/login'),
	(808, 2, '2026-10-29 08:52:27.940372', 6, 'Owner console-one', 'update', 'admin', 'Membership', 8, '9', 'Membership 9 edited (module flags)', '[{"field": "module_flags", "old": null, "new": "{\"accounting\": true, \"executive\": false, \"fbr\": false, \"finance\": false, \"fixed_assets\": false, \"hr\": true, \"inventory\": false, \"invoicing\": false}"}]', '127.0.0.1', '/settings/users/9/rights'),
	(809, NULL, '2026-10-29 08:52:28.067712', 7, 'Owner console-two', 'login', 'admin', NULL, NULL, NULL, 'Owner console-two signed in', NULL, '127.0.0.1', '/auth/login'),
	(811, 3, '2026-10-29 08:52:28.260371', 10, 'Second Admin', 'create', 'admin', 'Membership', 9, '10', 'Membership 10 created', '{"company_id": 3, "user_id": 10, "role_id": 1, "status": "active", "joined_at": "2026-10-29T08:52:28.258717"}', '127.0.0.1', '/settings/invitations/3/accept');

INSERT INTO public.chart_of_accounts VALUES
	(1, 1, '1', 'Assets', 'asset', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.547841'),
	(2, 1, '1-01', 'Current Assets', 'asset', 1, 2, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:21.55377'),
	(3, 1, '1-01-01', 'Cash & Cash Equivalents', 'asset', 2, 3, true, true, NULL, 'cash', NULL, '2026-10-29 08:52:21.557697'),
	(4, 1, '1-01-01-01', 'Cash in Hand', 'asset', 3, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.561358'),
	(5, 1, '1-01-01-02', 'Bank Accounts', 'asset', 3, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.565155'),
	(6, 1, '1-01-02', 'Trade Receivables', 'asset', 2, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.568912'),
	(7, 1, '1-01-02-01', 'Trade Debtors', 'asset', 6, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.57269'),
	(8, 1, '1-01-02-02', 'Doubtful Receivables', 'asset', 6, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.57656'),
	(9, 1, '1-01-03', 'Other Receivables', 'asset', 2, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.580477'),
	(10, 1, '1-01-03-01', 'Employee Loans & Advances', 'asset', 9, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.58412'),
	(11, 1, '1-01-03-02', 'Advances to Suppliers', 'asset', 9, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.587823'),
	(12, 1, '1-01-04', 'Inventories', 'asset', 2, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.591544'),
	(13, 1, '1-01-04-01', 'Trading Goods Stock', 'asset', 12, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.595114'),
	(14, 1, '1-01-05', 'Tax Assets', 'asset', 2, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.598726'),
	(15, 1, '1-01-05-01', 'Input Sales Tax', 'asset', 14, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.602405'),
	(16, 1, '1-01-05-02', 'WHT Receivable', 'asset', 14, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.606116'),
	(17, 1, '1-01-06', 'Prepayments & Other', 'asset', 2, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.609819'),
	(18, 1, '1-01-06-01', 'Suspense & Clearing', 'asset', 17, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.613888'),
	(19, 1, '1-01-06-02', 'Prepaid Expenses', 'asset', 17, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.618387'),
	(20, 1, '1-01-06-03', 'Other Current Assets', 'asset', 17, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.623092'),
	(21, 1, '1-02', 'Non-Current Assets', 'asset', 1, 2, true, true, NULL, 'investing', NULL, '2026-10-29 08:52:21.627707'),
	(22, 1, '1-02-01', 'Property, Plant & Equipment', 'asset', 21, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.632345'),
	(23, 1, '1-02-01-01', 'Owned Assets', 'asset', 22, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.636949'),
	(24, 1, '1-02-02', 'Accumulated Depreciation', 'asset', 21, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.641405'),
	(25, 1, '1-02-02-01', 'Accumulated Depreciation', 'asset', 24, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.645856'),
	(26, 1, '1-02-03', 'Intangible Assets', 'asset', 21, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.650455'),
	(27, 1, '1-02-03-01', 'Intangibles', 'asset', 26, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.654867'),
	(28, 1, '2', 'Liabilities', 'liability', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.657625'),
	(29, 1, '2-01', 'Current Liabilities', 'liability', 28, 2, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:21.661924'),
	(30, 1, '2-01-01', 'Trade Payables', 'liability', 29, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.666732'),
	(31, 1, '2-01-01-01', 'Trade Creditors', 'liability', 30, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.671054'),
	(32, 1, '2-01-02', 'Accrued & Payroll Liabilities', 'liability', 29, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.675097'),
	(33, 1, '2-01-02-01', 'Employee Payables', 'liability', 32, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.678974'),
	(34, 1, '2-01-02-02', 'Payroll Liabilities', 'liability', 32, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.683386'),
	(35, 1, '2-01-02-03', 'Accrued Expenses', 'liability', 32, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.687134'),
	(36, 1, '2-01-03', 'Tax Liabilities', 'liability', 29, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.690845'),
	(37, 1, '2-01-03-01', 'Output Sales Tax', 'liability', 36, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.694571'),
	(38, 1, '2-01-03-02', 'Income Tax Payable', 'liability', 36, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.698377'),
	(39, 1, '2-01-03-03', 'WHT Payable', 'liability', 36, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.702261'),
	(40, 1, '2-01-03-04', 'Further Tax Payable', 'liability', 36, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.705909'),
	(41, 1, '2-01-04', 'Advances from Customers', 'liability', 29, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.709941'),
	(42, 1, '2-01-04-01', 'Customer Advances', 'liability', 41, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.714073'),
	(43, 1, '2-02', 'Non-Current Liabilities', 'liability', 28, 2, true, true, NULL, 'financing', NULL, '2026-10-29 08:52:21.719428'),
	(44, 1, '2-02-01', 'Long-term Loans', 'liability', 43, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.723472'),
	(45, 1, '2-02-01-01', 'Long-term Loans', 'liability', 44, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.727176'),
	(46, 1, '2-02-02', 'Employee End-of-Service Benefits', 'liability', 43, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.730839'),
	(47, 1, '2-02-02-01', 'EOSB Provision', 'liability', 46, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.735426'),
	(48, 1, '3', 'Equity', 'equity', NULL, 1, true, true, NULL, 'financing', NULL, '2026-10-29 08:52:21.738277'),
	(49, 1, '3-01', 'Capital', 'equity', 48, 2, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.742189'),
	(50, 1, '3-01-01', 'Owner Capital', 'equity', 49, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.74593'),
	(51, 1, '3-01-01-01', 'Owner Capital', 'equity', 50, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.749607'),
	(52, 1, '3-02', 'Reserves & Retained Earnings', 'equity', 48, 2, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.753427'),
	(53, 1, '3-02-01', 'Retained Earnings', 'equity', 52, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.757177'),
	(54, 1, '3-02-01-01', 'Retained Earnings — Opening', 'equity', 53, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.760857'),
	(55, 1, '3-02-01-02', 'Retained Earnings — Closing', 'equity', 53, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.764718'),
	(56, 1, '3-02-02', 'Dividends', 'equity', 52, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.768396'),
	(57, 1, '3-02-02-01', 'Dividends', 'equity', 56, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.772221'),
	(58, 1, '3-02-03', 'Other Comprehensive Income', 'equity', 52, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.775901'),
	(59, 1, '3-02-03-01', 'Other Comprehensive Income', 'equity', 58, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.779867'),
	(60, 1, '4', 'Revenue', 'revenue', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:21.782274'),
	(61, 1, '4-01', 'Sales', 'revenue', 60, 2, true, true, NULL, NULL, 'sales', '2026-10-29 08:52:21.785995'),
	(62, 1, '4-01-01', 'Product Sales', 'revenue', 61, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.789942'),
	(63, 1, '4-01-01-01', 'Product Sales', 'revenue', 62, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.793724'),
	(64, 1, '4-01-02', 'Service Income', 'revenue', 61, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.797416'),
	(65, 1, '4-01-02-01', 'Service Income', 'revenue', 64, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.801029'),
	(66, 1, '4-02', 'Sales Returns & Discounts', 'revenue', 60, 2, true, true, NULL, NULL, 'sales_returns', '2026-10-29 08:52:21.804834'),
	(67, 1, '4-02-01', 'Sales Returns', 'revenue', 66, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.808523'),
	(68, 1, '4-02-01-01', 'Sales Returns', 'revenue', 67, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.812195'),
	(69, 1, '4-02-02', 'Discounts Allowed', 'revenue', 66, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.81593'),
	(70, 1, '4-02-02-01', 'Discounts Allowed', 'revenue', 69, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.819734'),
	(71, 1, '4-03', 'Other Income', 'revenue', 60, 2, true, true, NULL, NULL, 'other_income', '2026-10-29 08:52:21.823418'),
	(72, 1, '4-03-01', 'Other Income', 'revenue', 71, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.827184'),
	(73, 1, '4-03-01-01', 'Other Income', 'revenue', 72, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.831071'),
	(74, 1, '5', 'Expenses', 'expense', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:21.833466'),
	(75, 1, '5-01', 'Cost of Sales', 'expense', 74, 2, true, true, NULL, NULL, 'cost_of_sales', '2026-10-29 08:52:21.837211'),
	(76, 1, '5-01-01', 'Cost of Goods Sold', 'expense', 75, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.841008'),
	(77, 1, '5-01-01-01', 'Cost of Goods Sold', 'expense', 76, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.845129'),
	(78, 1, '5-01-02', 'Stock Losses, Scrap & Adjustments', 'expense', 75, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.848841'),
	(79, 1, '5-01-02-01', 'Stock Losses & Scrap', 'expense', 78, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.852515'),
	(80, 1, '5-02', 'Administrative Expenses', 'expense', 74, 2, true, true, NULL, NULL, 'admin', '2026-10-29 08:52:21.856225'),
	(81, 1, '5-02-01', 'Salaries & Benefits', 'expense', 80, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.860155'),
	(82, 1, '5-02-01-01', 'Salaries & Benefits', 'expense', 81, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.864429'),
	(83, 1, '5-02-02', 'Rent & Utilities', 'expense', 80, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.868419'),
	(84, 1, '5-02-02-01', 'Rent & Utilities', 'expense', 83, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.872209'),
	(85, 1, '5-02-03', 'Office & Supplies', 'expense', 80, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.875842'),
	(86, 1, '5-02-03-01', 'Office & Supplies', 'expense', 85, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.879693'),
	(87, 1, '5-02-04', 'Depreciation & Amortisation', 'expense', 80, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.883988'),
	(88, 1, '5-02-04-01', 'Depreciation & Amortisation', 'expense', 87, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.887654'),
	(89, 1, '5-02-05', 'Fees, Taxes & Licenses', 'expense', 80, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.891185'),
	(90, 1, '5-02-05-01', 'Fees, Taxes & Licenses', 'expense', 89, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.894732'),
	(91, 1, '5-03', 'Selling & Distribution', 'expense', 74, 2, true, true, NULL, NULL, 'selling_distribution', '2026-10-29 08:52:21.898392'),
	(92, 1, '5-03-01', 'Freight & Transportation', 'expense', 91, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.901994'),
	(93, 1, '5-03-01-01', 'Freight & Transportation', 'expense', 92, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.905667'),
	(94, 1, '5-03-02', 'Commissions', 'expense', 91, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.909462'),
	(95, 1, '5-03-02-01', 'Commissions', 'expense', 94, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.913295'),
	(96, 1, '5-03-03', 'Marketing & Advertising', 'expense', 91, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.917063'),
	(97, 1, '5-03-03-01', 'Marketing & Advertising', 'expense', 96, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.920837'),
	(98, 1, '5-04', 'Other Operating Expenses', 'expense', 74, 2, true, true, NULL, NULL, 'other_operating', '2026-10-29 08:52:21.924746'),
	(99, 1, '5-04-01', 'Other Operating Expenses', 'expense', 98, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.928522'),
	(100, 1, '5-04-01-01', 'Other Operating Expenses', 'expense', 99, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.932293'),
	(101, 1, '5-05', 'Finance Costs', 'expense', 74, 2, true, true, NULL, NULL, 'finance_cost', '2026-10-29 08:52:21.936083'),
	(102, 1, '5-05-01', 'Bank & Interest Charges', 'expense', 101, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.939911'),
	(103, 1, '5-05-01-01', 'Bank & Interest Charges', 'expense', 102, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.943725'),
	(104, 1, '5-06', 'Taxation', 'expense', 74, 2, true, true, NULL, NULL, 'income_tax', '2026-10-29 08:52:21.947728'),
	(105, 1, '5-06-01', 'Income Tax', 'expense', 104, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.951607'),
	(106, 1, '5-06-01-01', 'Income Tax', 'expense', 105, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:21.955711'),
	(107, 1, '1-01-01-01-0001', 'Main Cash', 'asset', 4, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:21.962163'),
	(108, 1, '1-01-02-01-0001', 'Trade Debtors — General', 'asset', 7, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:21.965929'),
	(109, 1, '1-01-03-02-0001', 'Advances to Suppliers — General', 'asset', 11, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:21.969667'),
	(110, 1, '1-01-04-01-0001', 'Stock — General', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:21.973683'),
	(111, 1, '1-01-05-01-0001', 'Input Sales Tax', 'asset', 15, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:21.977404'),
	(112, 1, '1-01-05-02-0001', 'WHT Receivable', 'asset', 16, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:21.98125'),
	(113, 1, '1-01-06-01-0001', 'Suspense Account', 'asset', 18, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:21.986073'),
	(114, 1, '1-01-06-02-0001', 'Prepaid Expenses — General', 'asset', 19, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:21.990085'),
	(115, 1, '1-02-01-01-0001', 'Fixed Assets — General', 'asset', 23, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:21.993864'),
	(116, 1, '1-02-02-01-0001', 'Accumulated Depreciation — General', 'asset', 25, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:21.997538'),
	(117, 1, '1-02-03-01-0001', 'Intangibles — General', 'asset', 27, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.001478'),
	(118, 1, '2-01-01-01-0001', 'Trade Creditors — General', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.005751'),
	(119, 1, '2-01-02-02-0001', 'Salary Payable', 'liability', 34, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.009945'),
	(120, 1, '2-01-02-02-0002', 'PF Payable', 'liability', 34, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.015457'),
	(121, 1, '2-01-02-02-0003', 'Loan Deductions Clearing', 'liability', 34, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.022377'),
	(122, 1, '2-01-02-02-0004', 'Other Payroll Deductions Payable', 'liability', 34, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.02656'),
	(123, 1, '2-01-02-03-0001', 'Accrued Expenses — General', 'liability', 35, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.030875'),
	(124, 1, '2-01-03-01-0001', 'Output Sales Tax', 'liability', 37, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.036094'),
	(125, 1, '2-01-03-02-0001', 'Income Tax Payable', 'liability', 38, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.041144'),
	(126, 1, '2-01-03-03-0001', 'WHT Payable', 'liability', 39, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.046176'),
	(127, 1, '2-01-03-04-0001', 'Further Tax Payable', 'liability', 40, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.051671'),
	(128, 1, '2-01-04-01-0001', 'Customer Advances — General', 'liability', 42, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.056997'),
	(129, 1, '2-02-01-01-0001', 'Long-term Loans — General', 'liability', 45, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.062196'),
	(130, 1, '2-02-02-01-0001', 'EOSB Provision — General', 'liability', 47, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.067327'),
	(131, 1, '3-01-01-01-0001', 'Share Capital', 'equity', 51, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.072974'),
	(132, 1, '3-01-01-01-0002', 'Suspense Equity', 'equity', 51, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.078701'),
	(133, 1, '3-02-01-01-0001', 'Retained Earnings — Opening', 'equity', 54, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.084978'),
	(134, 1, '3-02-01-02-0001', 'Retained Earnings — Closing', 'equity', 55, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.091596'),
	(135, 1, '3-02-02-01-0001', 'Dividends', 'equity', 57, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.097673'),
	(136, 1, '3-02-03-01-0001', 'Other Comprehensive Income', 'equity', 59, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.10369'),
	(137, 1, '4-01-01-01-0001', 'Sales — General', 'revenue', 63, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.109673'),
	(138, 1, '4-01-02-01-0001', 'Service Income — General', 'revenue', 65, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.115798'),
	(139, 1, '4-02-01-01-0001', 'Sales Returns — General', 'revenue', 68, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.121572'),
	(140, 1, '4-02-02-01-0001', 'Discounts Allowed — General', 'revenue', 70, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.127263'),
	(141, 1, '4-03-01-01-0001', 'Other Income — General', 'revenue', 73, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.13297'),
	(142, 1, '5-01-01-01-0001', 'Cost of Goods Sold', 'expense', 77, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.138234'),
	(143, 1, '5-01-02-01-0001', 'Scrap / Write-off', 'expense', 79, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.143005'),
	(144, 1, '5-01-02-01-0002', 'Inventory Adjustment', 'expense', 79, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.147724'),
	(145, 1, '5-01-02-01-0003', 'Consumption Expense', 'expense', 79, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.152687'),
	(146, 1, '5-01-02-01-0004', 'Inventory Cost Variance', 'expense', 79, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.157431'),
	(147, 1, '5-02-01-01-0001', 'Salary Expense', 'expense', 82, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.162142'),
	(148, 1, '5-02-01-01-0002', 'PF Employer Expense', 'expense', 82, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.166903'),
	(149, 1, '5-02-02-01-0001', 'Rent Expense', 'expense', 84, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.171479'),
	(150, 1, '5-02-02-01-0002', 'Utilities Expense', 'expense', 84, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.176071'),
	(151, 1, '5-02-03-01-0001', 'Office Supplies', 'expense', 86, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.180665'),
	(152, 1, '5-02-04-01-0001', 'Depreciation Expense', 'expense', 88, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.185299'),
	(153, 1, '5-02-05-01-0001', 'Fees, Taxes & Licenses — General', 'expense', 90, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.189731'),
	(154, 1, '5-03-01-01-0001', 'Freight & Transportation — General', 'expense', 93, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.194219'),
	(155, 1, '5-03-02-01-0001', 'Commissions — General', 'expense', 95, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.198465'),
	(156, 1, '5-03-03-01-0001', 'Marketing & Advertising — General', 'expense', 97, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.202386'),
	(157, 1, '5-04-01-01-0001', 'Other Expenses — General', 'expense', 100, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.206307'),
	(158, 1, '5-04-01-01-0002', 'Loss/(Gain) on Disposal of Fixed Assets', 'expense', 100, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.210031'),
	(159, 1, '5-05-01-01-0001', 'Bank Charges', 'expense', 103, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.214105'),
	(160, 1, '5-05-01-01-0002', 'Interest Expense', 'expense', 103, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.217959'),
	(161, 1, '5-06-01-01-0001', 'Income Tax Expense', 'expense', 106, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.221804'),
	(162, 1, '2-01-01-01-0101', 'Longi Solar Pakistan', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.911365'),
	(163, 1, '2-01-01-01-0102', 'JA Solar Technologies', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.916741'),
	(164, 1, '2-01-01-01-0103', 'BYD Energy Solutions', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.92212'),
	(165, 1, '2-01-01-01-0104', 'Growatt Inverters', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.927628'),
	(166, 1, '2-01-01-01-0105', 'Al-Rashid Traders', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.932717'),
	(167, 1, '2-01-01-01-0106', 'Pakistan Cable Co.', 'liability', 31, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.938105'),
	(168, 1, '1-01-02-01-0101', 'SolarTech Solutions', 'asset', 7, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.946697'),
	(169, 1, '1-01-02-01-0102', 'Green Energy Pakistan', 'asset', 7, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.952387'),
	(170, 1, '1-01-02-01-0103', 'BuildRight Construction', 'asset', 7, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.958771'),
	(171, 1, '1-01-02-01-0104', 'Home Solutions Ltd.', 'asset', 7, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.964561'),
	(172, 1, '1-01-04-01-0101', 'Monocrystalline Solar Panel 450W (SOL-MONO-450)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.972387'),
	(173, 1, '1-01-04-01-0102', 'Monocrystalline Solar Panel 550W (SOL-MONO-550)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.977283'),
	(174, 1, '1-01-04-01-0103', 'Polycrystalline Solar Panel 330W (SOL-POLY-330)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.982238'),
	(175, 1, '1-01-04-01-0104', '5kW Hybrid Inverter (INV-5KW)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.987251'),
	(176, 1, '1-01-04-01-0105', '10kW Hybrid Inverter (INV-10KW)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.992414'),
	(177, 1, '1-01-04-01-0106', '3kW String Inverter (INV-3KW)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:22.997263'),
	(178, 1, '1-01-04-01-0107', '5kWh LiFePO4 Battery (BAT-LFP-5KWH)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.002043'),
	(179, 1, '1-01-04-01-0108', '10kWh LiFePO4 Battery (BAT-LFP-10KWH)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.00682'),
	(180, 1, '1-01-04-01-0109', '200Ah Tubular Battery (BAT-TUB-200)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.011759'),
	(181, 1, '1-01-04-01-0110', 'Solar DC Cable 4mm (per meter) (CBL-SOL-4MM)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.016622'),
	(182, 1, '1-01-04-01-0111', 'AC Cable 2.5mm (per meter) (CBL-AC-2.5MM)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.021411'),
	(183, 1, '1-01-04-01-0112', 'MC4 Connector Pair (CBL-MC4)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.025976'),
	(184, 1, '1-01-04-01-0113', 'Aluminum Mounting Rack (set) (MNT-ALU-RACK)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.031491'),
	(185, 1, '1-01-04-01-0114', 'Mounting Rail 2m (MNT-RAIL-2M)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.036103'),
	(186, 1, '1-01-04-01-0115', 'Distribution Board 16-way (ELEC-DB)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.040892'),
	(187, 1, '1-01-04-01-0116', 'Surge Protection Device (ELEC-SPD)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.046219'),
	(188, 1, '1-01-04-01-0117', 'MCB 16A Single Pole (ELEC-MCB-16A)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.05134'),
	(189, 1, '1-01-04-01-0118', 'Solar Crimping Tool (TOOL-CRIMP)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.056168'),
	(190, 1, '1-01-04-01-0119', 'Digital Multimeter (TOOL-MULTI)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.061084'),
	(191, 1, '1-01-04-01-0120', 'Safety Helmet (SAFE-HLMT)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.066694'),
	(192, 1, '1-01-04-01-0121', 'Insulated Gloves (pair) (SAFE-GLOVES)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.073914'),
	(193, 1, '1-01-04-01-0122', 'Safety Harness (SAFE-HARNESS)', 'asset', 13, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.081775'),
	(194, 1, '2-01-02-01-0101', 'Administrator (SYSADMIN)', 'liability', 33, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.092038'),
	(195, 1, '2-01-02-01-0102', 'System Admin (ADM001)', 'liability', 33, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.103135'),
	(196, 1, '2-01-02-01-0103', 'Manager User (MGR002)', 'liability', 33, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.111614'),
	(197, 1, '2-01-02-01-0104', 'Employee User (EMP001)', 'liability', 33, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.120778'),
	(198, 1, '2-01-02-01-0105', 'John Doe (EMP002)', 'liability', 33, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:23.128505'),
	(199, 2, '1', 'Assets', 'asset', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.389936'),
	(200, 2, '1-01', 'Current Assets', 'asset', 199, 2, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:24.398883');
INSERT INTO public.chart_of_accounts VALUES
	(201, 2, '1-01-01', 'Cash & Cash Equivalents', 'asset', 200, 3, true, true, NULL, 'cash', NULL, '2026-10-29 08:52:24.403459'),
	(202, 2, '1-01-01-01', 'Cash in Hand', 'asset', 201, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.407981'),
	(203, 2, '1-01-01-02', 'Bank Accounts', 'asset', 201, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.412539'),
	(204, 2, '1-01-02', 'Trade Receivables', 'asset', 200, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.416829'),
	(205, 2, '1-01-02-01', 'Trade Debtors', 'asset', 204, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.420703'),
	(206, 2, '1-01-02-02', 'Doubtful Receivables', 'asset', 204, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.424503'),
	(207, 2, '1-01-03', 'Other Receivables', 'asset', 200, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.428196'),
	(208, 2, '1-01-03-01', 'Employee Loans & Advances', 'asset', 207, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.431898'),
	(209, 2, '1-01-03-02', 'Advances to Suppliers', 'asset', 207, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.435608'),
	(210, 2, '1-01-04', 'Inventories', 'asset', 200, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.439562'),
	(211, 2, '1-01-04-01', 'Trading Goods Stock', 'asset', 210, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.443327'),
	(212, 2, '1-01-05', 'Tax Assets', 'asset', 200, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.447124'),
	(213, 2, '1-01-05-01', 'Input Sales Tax', 'asset', 212, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.450972'),
	(214, 2, '1-01-05-02', 'WHT Receivable', 'asset', 212, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.455118'),
	(215, 2, '1-01-06', 'Prepayments & Other', 'asset', 200, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.45902'),
	(216, 2, '1-01-06-01', 'Suspense & Clearing', 'asset', 215, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.463193'),
	(217, 2, '1-01-06-02', 'Prepaid Expenses', 'asset', 215, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.467467'),
	(218, 2, '1-01-06-03', 'Other Current Assets', 'asset', 215, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.471462'),
	(219, 2, '1-02', 'Non-Current Assets', 'asset', 199, 2, true, true, NULL, 'investing', NULL, '2026-10-29 08:52:24.475239'),
	(220, 2, '1-02-01', 'Property, Plant & Equipment', 'asset', 219, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.479294'),
	(221, 2, '1-02-01-01', 'Owned Assets', 'asset', 220, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.483108'),
	(222, 2, '1-02-02', 'Accumulated Depreciation', 'asset', 219, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.487375'),
	(223, 2, '1-02-02-01', 'Accumulated Depreciation', 'asset', 222, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.491466'),
	(224, 2, '1-02-03', 'Intangible Assets', 'asset', 219, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.495348'),
	(225, 2, '1-02-03-01', 'Intangibles', 'asset', 224, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.49912'),
	(226, 2, '2', 'Liabilities', 'liability', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.501574'),
	(227, 2, '2-01', 'Current Liabilities', 'liability', 226, 2, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:24.505399'),
	(228, 2, '2-01-01', 'Trade Payables', 'liability', 227, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.509238'),
	(229, 2, '2-01-01-01', 'Trade Creditors', 'liability', 228, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.51337'),
	(230, 2, '2-01-02', 'Accrued & Payroll Liabilities', 'liability', 227, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.517151'),
	(231, 2, '2-01-02-01', 'Employee Payables', 'liability', 230, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.521161'),
	(232, 2, '2-01-02-02', 'Payroll Liabilities', 'liability', 230, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.525763'),
	(233, 2, '2-01-02-03', 'Accrued Expenses', 'liability', 230, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.529796'),
	(234, 2, '2-01-03', 'Tax Liabilities', 'liability', 227, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.533551'),
	(235, 2, '2-01-03-01', 'Output Sales Tax', 'liability', 234, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.537427'),
	(236, 2, '2-01-03-02', 'Income Tax Payable', 'liability', 234, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.541212'),
	(237, 2, '2-01-03-03', 'WHT Payable', 'liability', 234, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.545055'),
	(238, 2, '2-01-03-04', 'Further Tax Payable', 'liability', 234, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.548941'),
	(239, 2, '2-01-04', 'Advances from Customers', 'liability', 227, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.552772'),
	(240, 2, '2-01-04-01', 'Customer Advances', 'liability', 239, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.556725'),
	(241, 2, '2-02', 'Non-Current Liabilities', 'liability', 226, 2, true, true, NULL, 'financing', NULL, '2026-10-29 08:52:24.56074'),
	(242, 2, '2-02-01', 'Long-term Loans', 'liability', 241, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.564978'),
	(243, 2, '2-02-01-01', 'Long-term Loans', 'liability', 242, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.568839'),
	(244, 2, '2-02-02', 'Employee End-of-Service Benefits', 'liability', 241, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.572898'),
	(245, 2, '2-02-02-01', 'EOSB Provision', 'liability', 244, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.576929'),
	(246, 2, '3', 'Equity', 'equity', NULL, 1, true, true, NULL, 'financing', NULL, '2026-10-29 08:52:24.57942'),
	(247, 2, '3-01', 'Capital', 'equity', 246, 2, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.58327'),
	(248, 2, '3-01-01', 'Owner Capital', 'equity', 247, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.587174'),
	(249, 2, '3-01-01-01', 'Owner Capital', 'equity', 248, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.591094'),
	(250, 2, '3-02', 'Reserves & Retained Earnings', 'equity', 246, 2, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.59499'),
	(251, 2, '3-02-01', 'Retained Earnings', 'equity', 250, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.598976'),
	(252, 2, '3-02-01-01', 'Retained Earnings — Opening', 'equity', 251, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.603233'),
	(253, 2, '3-02-01-02', 'Retained Earnings — Closing', 'equity', 251, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.607844'),
	(254, 2, '3-02-02', 'Dividends', 'equity', 250, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.613781'),
	(255, 2, '3-02-02-01', 'Dividends', 'equity', 254, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.618652'),
	(256, 2, '3-02-03', 'Other Comprehensive Income', 'equity', 250, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.623336'),
	(257, 2, '3-02-03-01', 'Other Comprehensive Income', 'equity', 256, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.627485'),
	(258, 2, '4', 'Revenue', 'revenue', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:24.629991'),
	(259, 2, '4-01', 'Sales', 'revenue', 258, 2, true, true, NULL, NULL, 'sales', '2026-10-29 08:52:24.634383'),
	(260, 2, '4-01-01', 'Product Sales', 'revenue', 259, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.639295'),
	(261, 2, '4-01-01-01', 'Product Sales', 'revenue', 260, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.643553'),
	(262, 2, '4-01-02', 'Service Income', 'revenue', 259, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.647658'),
	(263, 2, '4-01-02-01', 'Service Income', 'revenue', 262, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.65215'),
	(264, 2, '4-02', 'Sales Returns & Discounts', 'revenue', 258, 2, true, true, NULL, NULL, 'sales_returns', '2026-10-29 08:52:24.657333'),
	(265, 2, '4-02-01', 'Sales Returns', 'revenue', 264, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.662361'),
	(266, 2, '4-02-01-01', 'Sales Returns', 'revenue', 265, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.667337'),
	(267, 2, '4-02-02', 'Discounts Allowed', 'revenue', 264, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.672464'),
	(268, 2, '4-02-02-01', 'Discounts Allowed', 'revenue', 267, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.677389'),
	(269, 2, '4-03', 'Other Income', 'revenue', 258, 2, true, true, NULL, NULL, 'other_income', '2026-10-29 08:52:24.682481'),
	(270, 2, '4-03-01', 'Other Income', 'revenue', 269, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.68733'),
	(271, 2, '4-03-01-01', 'Other Income', 'revenue', 270, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.692326'),
	(272, 2, '5', 'Expenses', 'expense', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:24.695448'),
	(273, 2, '5-01', 'Cost of Sales', 'expense', 272, 2, true, true, NULL, NULL, 'cost_of_sales', '2026-10-29 08:52:24.70008'),
	(274, 2, '5-01-01', 'Cost of Goods Sold', 'expense', 273, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.704801'),
	(275, 2, '5-01-01-01', 'Cost of Goods Sold', 'expense', 274, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.709806'),
	(276, 2, '5-01-02', 'Stock Losses, Scrap & Adjustments', 'expense', 273, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.714808'),
	(277, 2, '5-01-02-01', 'Stock Losses & Scrap', 'expense', 276, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.719817'),
	(278, 2, '5-02', 'Administrative Expenses', 'expense', 272, 2, true, true, NULL, NULL, 'admin', '2026-10-29 08:52:24.724957'),
	(279, 2, '5-02-01', 'Salaries & Benefits', 'expense', 278, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.729782'),
	(280, 2, '5-02-01-01', 'Salaries & Benefits', 'expense', 279, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.734515'),
	(281, 2, '5-02-02', 'Rent & Utilities', 'expense', 278, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.739518'),
	(282, 2, '5-02-02-01', 'Rent & Utilities', 'expense', 281, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.744625'),
	(283, 2, '5-02-03', 'Office & Supplies', 'expense', 278, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.749543'),
	(284, 2, '5-02-03-01', 'Office & Supplies', 'expense', 283, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.754521'),
	(285, 2, '5-02-04', 'Depreciation & Amortisation', 'expense', 278, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.760009'),
	(286, 2, '5-02-04-01', 'Depreciation & Amortisation', 'expense', 285, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.765072'),
	(287, 2, '5-02-05', 'Fees, Taxes & Licenses', 'expense', 278, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.769989'),
	(288, 2, '5-02-05-01', 'Fees, Taxes & Licenses', 'expense', 287, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.774785'),
	(289, 2, '5-03', 'Selling & Distribution', 'expense', 272, 2, true, true, NULL, NULL, 'selling_distribution', '2026-10-29 08:52:24.779774'),
	(290, 2, '5-03-01', 'Freight & Transportation', 'expense', 289, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.784715'),
	(291, 2, '5-03-01-01', 'Freight & Transportation', 'expense', 290, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.789618'),
	(292, 2, '5-03-02', 'Commissions', 'expense', 289, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.794734'),
	(293, 2, '5-03-02-01', 'Commissions', 'expense', 292, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.799805'),
	(294, 2, '5-03-03', 'Marketing & Advertising', 'expense', 289, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.804903'),
	(295, 2, '5-03-03-01', 'Marketing & Advertising', 'expense', 294, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.810001'),
	(296, 2, '5-04', 'Other Operating Expenses', 'expense', 272, 2, true, true, NULL, NULL, 'other_operating', '2026-10-29 08:52:24.815143'),
	(297, 2, '5-04-01', 'Other Operating Expenses', 'expense', 296, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.820018'),
	(298, 2, '5-04-01-01', 'Other Operating Expenses', 'expense', 297, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.824836'),
	(299, 2, '5-05', 'Finance Costs', 'expense', 272, 2, true, true, NULL, NULL, 'finance_cost', '2026-10-29 08:52:24.830056'),
	(300, 2, '5-05-01', 'Bank & Interest Charges', 'expense', 299, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.835285'),
	(301, 2, '5-05-01-01', 'Bank & Interest Charges', 'expense', 300, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.840788'),
	(302, 2, '5-06', 'Taxation', 'expense', 272, 2, true, true, NULL, NULL, 'income_tax', '2026-10-29 08:52:24.846547'),
	(303, 2, '5-06-01', 'Income Tax', 'expense', 302, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.852464'),
	(304, 2, '5-06-01-01', 'Income Tax', 'expense', 303, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:24.858383'),
	(305, 2, '1-01-01-01-0001', 'Main Cash', 'asset', 202, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.868034'),
	(306, 2, '1-01-02-01-0001', 'Trade Debtors — General', 'asset', 205, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.87408'),
	(307, 2, '1-01-03-02-0001', 'Advances to Suppliers — General', 'asset', 209, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.879861'),
	(308, 2, '1-01-04-01-0001', 'Stock — General', 'asset', 211, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.885994'),
	(309, 2, '1-01-05-01-0001', 'Input Sales Tax', 'asset', 213, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.89189'),
	(310, 2, '1-01-05-02-0001', 'WHT Receivable', 'asset', 214, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.897636'),
	(311, 2, '1-01-06-01-0001', 'Suspense Account', 'asset', 216, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.903746'),
	(312, 2, '1-01-06-02-0001', 'Prepaid Expenses — General', 'asset', 217, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.909563'),
	(313, 2, '1-02-01-01-0001', 'Fixed Assets — General', 'asset', 221, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.915303'),
	(314, 2, '1-02-02-01-0001', 'Accumulated Depreciation — General', 'asset', 223, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.921009'),
	(315, 2, '1-02-03-01-0001', 'Intangibles — General', 'asset', 225, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.926813'),
	(316, 2, '2-01-01-01-0001', 'Trade Creditors — General', 'liability', 229, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.932513'),
	(317, 2, '2-01-02-02-0001', 'Salary Payable', 'liability', 232, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.937926'),
	(318, 2, '2-01-02-02-0002', 'PF Payable', 'liability', 232, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.942987'),
	(319, 2, '2-01-02-02-0003', 'Loan Deductions Clearing', 'liability', 232, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.947808'),
	(320, 2, '2-01-02-02-0004', 'Other Payroll Deductions Payable', 'liability', 232, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.95262'),
	(321, 2, '2-01-02-03-0001', 'Accrued Expenses — General', 'liability', 233, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.95761'),
	(322, 2, '2-01-03-01-0001', 'Output Sales Tax', 'liability', 235, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.962706'),
	(323, 2, '2-01-03-02-0001', 'Income Tax Payable', 'liability', 236, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.967563'),
	(324, 2, '2-01-03-03-0001', 'WHT Payable', 'liability', 237, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.972321'),
	(325, 2, '2-01-03-04-0001', 'Further Tax Payable', 'liability', 238, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.977517'),
	(326, 2, '2-01-04-01-0001', 'Customer Advances — General', 'liability', 240, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.982881'),
	(327, 2, '2-02-01-01-0001', 'Long-term Loans — General', 'liability', 243, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.987974'),
	(328, 2, '2-02-02-01-0001', 'EOSB Provision — General', 'liability', 245, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.993021'),
	(329, 2, '3-01-01-01-0001', 'Share Capital', 'equity', 249, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:24.998166'),
	(330, 2, '3-01-01-01-0002', 'Suspense Equity', 'equity', 249, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.003068'),
	(331, 2, '3-02-01-01-0001', 'Retained Earnings — Opening', 'equity', 252, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.007793'),
	(332, 2, '3-02-01-02-0001', 'Retained Earnings — Closing', 'equity', 253, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.012733'),
	(333, 2, '3-02-02-01-0001', 'Dividends', 'equity', 255, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.017546'),
	(334, 2, '3-02-03-01-0001', 'Other Comprehensive Income', 'equity', 257, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.022008'),
	(335, 2, '4-01-01-01-0001', 'Sales — General', 'revenue', 261, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.026567'),
	(336, 2, '4-01-02-01-0001', 'Service Income — General', 'revenue', 263, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.031261'),
	(337, 2, '4-02-01-01-0001', 'Sales Returns — General', 'revenue', 266, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.035981'),
	(338, 2, '4-02-02-01-0001', 'Discounts Allowed — General', 'revenue', 268, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.040976'),
	(339, 2, '4-03-01-01-0001', 'Other Income — General', 'revenue', 271, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.046043'),
	(340, 2, '5-01-01-01-0001', 'Cost of Goods Sold', 'expense', 275, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.05086'),
	(341, 2, '5-01-02-01-0001', 'Scrap / Write-off', 'expense', 277, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.055902'),
	(342, 2, '5-01-02-01-0002', 'Inventory Adjustment', 'expense', 277, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.061107'),
	(343, 2, '5-01-02-01-0003', 'Consumption Expense', 'expense', 277, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.06708'),
	(344, 2, '5-01-02-01-0004', 'Inventory Cost Variance', 'expense', 277, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.072449'),
	(345, 2, '5-02-01-01-0001', 'Salary Expense', 'expense', 280, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.077767'),
	(346, 2, '5-02-01-01-0002', 'PF Employer Expense', 'expense', 280, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.083171'),
	(347, 2, '5-02-02-01-0001', 'Rent Expense', 'expense', 282, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.088531'),
	(348, 2, '5-02-02-01-0002', 'Utilities Expense', 'expense', 282, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.093609'),
	(349, 2, '5-02-03-01-0001', 'Office Supplies', 'expense', 284, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.098767'),
	(350, 2, '5-02-04-01-0001', 'Depreciation Expense', 'expense', 286, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.103749'),
	(351, 2, '5-02-05-01-0001', 'Fees, Taxes & Licenses — General', 'expense', 288, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.10865'),
	(352, 2, '5-03-01-01-0001', 'Freight & Transportation — General', 'expense', 291, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.113594'),
	(353, 2, '5-03-02-01-0001', 'Commissions — General', 'expense', 293, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.118671'),
	(354, 2, '5-03-03-01-0001', 'Marketing & Advertising — General', 'expense', 295, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.123363'),
	(355, 2, '5-04-01-01-0001', 'Other Expenses — General', 'expense', 298, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.128097'),
	(356, 2, '5-04-01-01-0002', 'Loss/(Gain) on Disposal of Fixed Assets', 'expense', 298, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.133024'),
	(357, 2, '5-05-01-01-0001', 'Bank Charges', 'expense', 301, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.138187'),
	(358, 2, '5-05-01-01-0002', 'Interest Expense', 'expense', 301, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.143012'),
	(359, 2, '5-06-01-01-0001', 'Income Tax Expense', 'expense', 304, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.147827'),
	(360, 3, '1', 'Assets', 'asset', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.350261'),
	(361, 3, '1-01', 'Current Assets', 'asset', 360, 2, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:25.358654'),
	(362, 3, '1-01-01', 'Cash & Cash Equivalents', 'asset', 361, 3, true, true, NULL, 'cash', NULL, '2026-10-29 08:52:25.363854'),
	(363, 3, '1-01-01-01', 'Cash in Hand', 'asset', 362, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.368952'),
	(364, 3, '1-01-01-02', 'Bank Accounts', 'asset', 362, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.373952'),
	(365, 3, '1-01-02', 'Trade Receivables', 'asset', 361, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.378926'),
	(366, 3, '1-01-02-01', 'Trade Debtors', 'asset', 365, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.384084'),
	(367, 3, '1-01-02-02', 'Doubtful Receivables', 'asset', 365, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.389626'),
	(368, 3, '1-01-03', 'Other Receivables', 'asset', 361, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.39472'),
	(369, 3, '1-01-03-01', 'Employee Loans & Advances', 'asset', 368, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.4'),
	(370, 3, '1-01-03-02', 'Advances to Suppliers', 'asset', 368, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.405067'),
	(371, 3, '1-01-04', 'Inventories', 'asset', 361, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.410636'),
	(372, 3, '1-01-04-01', 'Trading Goods Stock', 'asset', 371, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.415842'),
	(373, 3, '1-01-05', 'Tax Assets', 'asset', 361, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.421114'),
	(374, 3, '1-01-05-01', 'Input Sales Tax', 'asset', 373, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.426425'),
	(375, 3, '1-01-05-02', 'WHT Receivable', 'asset', 373, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.431693'),
	(376, 3, '1-01-06', 'Prepayments & Other', 'asset', 361, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.437103'),
	(377, 3, '1-01-06-01', 'Suspense & Clearing', 'asset', 376, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.442231'),
	(378, 3, '1-01-06-02', 'Prepaid Expenses', 'asset', 376, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.448517'),
	(379, 3, '1-01-06-03', 'Other Current Assets', 'asset', 376, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.453471'),
	(380, 3, '1-02', 'Non-Current Assets', 'asset', 360, 2, true, true, NULL, 'investing', NULL, '2026-10-29 08:52:25.458702'),
	(381, 3, '1-02-01', 'Property, Plant & Equipment', 'asset', 380, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.463945'),
	(382, 3, '1-02-01-01', 'Owned Assets', 'asset', 381, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.468799'),
	(383, 3, '1-02-02', 'Accumulated Depreciation', 'asset', 380, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.474026'),
	(384, 3, '1-02-02-01', 'Accumulated Depreciation', 'asset', 383, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.479306'),
	(385, 3, '1-02-03', 'Intangible Assets', 'asset', 380, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.485244'),
	(386, 3, '1-02-03-01', 'Intangibles', 'asset', 385, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.490557'),
	(387, 3, '2', 'Liabilities', 'liability', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.493989'),
	(388, 3, '2-01', 'Current Liabilities', 'liability', 387, 2, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:25.49905'),
	(389, 3, '2-01-01', 'Trade Payables', 'liability', 388, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.504195'),
	(390, 3, '2-01-01-01', 'Trade Creditors', 'liability', 389, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.509178'),
	(391, 3, '2-01-02', 'Accrued & Payroll Liabilities', 'liability', 388, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.514149'),
	(392, 3, '2-01-02-01', 'Employee Payables', 'liability', 391, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.519432'),
	(393, 3, '2-01-02-02', 'Payroll Liabilities', 'liability', 391, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.524138'),
	(394, 3, '2-01-02-03', 'Accrued Expenses', 'liability', 391, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.528811'),
	(395, 3, '2-01-03', 'Tax Liabilities', 'liability', 388, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.533648'),
	(396, 3, '2-01-03-01', 'Output Sales Tax', 'liability', 395, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.538947'),
	(397, 3, '2-01-03-02', 'Income Tax Payable', 'liability', 395, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.543973'),
	(398, 3, '2-01-03-03', 'WHT Payable', 'liability', 395, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.549248'),
	(399, 3, '2-01-03-04', 'Further Tax Payable', 'liability', 395, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.554026'),
	(400, 3, '2-01-04', 'Advances from Customers', 'liability', 388, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.558899');
INSERT INTO public.chart_of_accounts VALUES
	(401, 3, '2-01-04-01', 'Customer Advances', 'liability', 400, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.563556'),
	(402, 3, '2-02', 'Non-Current Liabilities', 'liability', 387, 2, true, true, NULL, 'financing', NULL, '2026-10-29 08:52:25.568014'),
	(403, 3, '2-02-01', 'Long-term Loans', 'liability', 402, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.57259'),
	(404, 3, '2-02-01-01', 'Long-term Loans', 'liability', 403, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.57674'),
	(405, 3, '2-02-02', 'Employee End-of-Service Benefits', 'liability', 402, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.581064'),
	(406, 3, '2-02-02-01', 'EOSB Provision', 'liability', 405, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.585709'),
	(407, 3, '3', 'Equity', 'equity', NULL, 1, true, true, NULL, 'financing', NULL, '2026-10-29 08:52:25.588583'),
	(408, 3, '3-01', 'Capital', 'equity', 407, 2, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.593256'),
	(409, 3, '3-01-01', 'Owner Capital', 'equity', 408, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.598072'),
	(410, 3, '3-01-01-01', 'Owner Capital', 'equity', 409, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.602997'),
	(411, 3, '3-02', 'Reserves & Retained Earnings', 'equity', 407, 2, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.607695'),
	(412, 3, '3-02-01', 'Retained Earnings', 'equity', 411, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.612562'),
	(413, 3, '3-02-01-01', 'Retained Earnings — Opening', 'equity', 412, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.6173'),
	(414, 3, '3-02-01-02', 'Retained Earnings — Closing', 'equity', 412, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.622296'),
	(415, 3, '3-02-02', 'Dividends', 'equity', 411, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.627252'),
	(416, 3, '3-02-02-01', 'Dividends', 'equity', 415, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.632051'),
	(417, 3, '3-02-03', 'Other Comprehensive Income', 'equity', 411, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.63732'),
	(418, 3, '3-02-03-01', 'Other Comprehensive Income', 'equity', 417, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.642175'),
	(419, 3, '4', 'Revenue', 'revenue', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:25.645205'),
	(420, 3, '4-01', 'Sales', 'revenue', 419, 2, true, true, NULL, NULL, 'sales', '2026-10-29 08:52:25.649941'),
	(421, 3, '4-01-01', 'Product Sales', 'revenue', 420, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.655495'),
	(422, 3, '4-01-01-01', 'Product Sales', 'revenue', 421, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.660793'),
	(423, 3, '4-01-02', 'Service Income', 'revenue', 420, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.666332'),
	(424, 3, '4-01-02-01', 'Service Income', 'revenue', 423, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.671722'),
	(425, 3, '4-02', 'Sales Returns & Discounts', 'revenue', 419, 2, true, true, NULL, NULL, 'sales_returns', '2026-10-29 08:52:25.677109'),
	(426, 3, '4-02-01', 'Sales Returns', 'revenue', 425, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.682695'),
	(427, 3, '4-02-01-01', 'Sales Returns', 'revenue', 426, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.688488'),
	(428, 3, '4-02-02', 'Discounts Allowed', 'revenue', 425, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.693999'),
	(429, 3, '4-02-02-01', 'Discounts Allowed', 'revenue', 428, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.699848'),
	(430, 3, '4-03', 'Other Income', 'revenue', 419, 2, true, true, NULL, NULL, 'other_income', '2026-10-29 08:52:25.705348'),
	(431, 3, '4-03-01', 'Other Income', 'revenue', 430, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.710379'),
	(432, 3, '4-03-01-01', 'Other Income', 'revenue', 431, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.715684'),
	(433, 3, '5', 'Expenses', 'expense', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:25.718968'),
	(434, 3, '5-01', 'Cost of Sales', 'expense', 433, 2, true, true, NULL, NULL, 'cost_of_sales', '2026-10-29 08:52:25.724013'),
	(435, 3, '5-01-01', 'Cost of Goods Sold', 'expense', 434, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.72899'),
	(436, 3, '5-01-01-01', 'Cost of Goods Sold', 'expense', 435, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.734307'),
	(437, 3, '5-01-02', 'Stock Losses, Scrap & Adjustments', 'expense', 434, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.739562'),
	(438, 3, '5-01-02-01', 'Stock Losses & Scrap', 'expense', 437, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.744572'),
	(439, 3, '5-02', 'Administrative Expenses', 'expense', 433, 2, true, true, NULL, NULL, 'admin', '2026-10-29 08:52:25.749901'),
	(440, 3, '5-02-01', 'Salaries & Benefits', 'expense', 439, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.754937'),
	(441, 3, '5-02-01-01', 'Salaries & Benefits', 'expense', 440, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.76025'),
	(442, 3, '5-02-02', 'Rent & Utilities', 'expense', 439, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.765832'),
	(443, 3, '5-02-02-01', 'Rent & Utilities', 'expense', 442, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.771152'),
	(444, 3, '5-02-03', 'Office & Supplies', 'expense', 439, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.776247'),
	(445, 3, '5-02-03-01', 'Office & Supplies', 'expense', 444, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.781729'),
	(446, 3, '5-02-04', 'Depreciation & Amortisation', 'expense', 439, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.787598'),
	(447, 3, '5-02-04-01', 'Depreciation & Amortisation', 'expense', 446, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.793092'),
	(448, 3, '5-02-05', 'Fees, Taxes & Licenses', 'expense', 439, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.798548'),
	(449, 3, '5-02-05-01', 'Fees, Taxes & Licenses', 'expense', 448, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.804022'),
	(450, 3, '5-03', 'Selling & Distribution', 'expense', 433, 2, true, true, NULL, NULL, 'selling_distribution', '2026-10-29 08:52:25.809252'),
	(451, 3, '5-03-01', 'Freight & Transportation', 'expense', 450, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.814491'),
	(452, 3, '5-03-01-01', 'Freight & Transportation', 'expense', 451, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.819707'),
	(453, 3, '5-03-02', 'Commissions', 'expense', 450, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.825023'),
	(454, 3, '5-03-02-01', 'Commissions', 'expense', 453, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.830197'),
	(455, 3, '5-03-03', 'Marketing & Advertising', 'expense', 450, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.835172'),
	(456, 3, '5-03-03-01', 'Marketing & Advertising', 'expense', 455, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.840165'),
	(457, 3, '5-04', 'Other Operating Expenses', 'expense', 433, 2, true, true, NULL, NULL, 'other_operating', '2026-10-29 08:52:25.845159'),
	(458, 3, '5-04-01', 'Other Operating Expenses', 'expense', 457, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.84998'),
	(459, 3, '5-04-01-01', 'Other Operating Expenses', 'expense', 458, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.85465'),
	(460, 3, '5-05', 'Finance Costs', 'expense', 433, 2, true, true, NULL, NULL, 'finance_cost', '2026-10-29 08:52:25.859445'),
	(461, 3, '5-05-01', 'Bank & Interest Charges', 'expense', 460, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.864082'),
	(462, 3, '5-05-01-01', 'Bank & Interest Charges', 'expense', 461, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.868974'),
	(463, 3, '5-06', 'Taxation', 'expense', 433, 2, true, true, NULL, NULL, 'income_tax', '2026-10-29 08:52:25.873312'),
	(464, 3, '5-06-01', 'Income Tax', 'expense', 463, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.878103'),
	(465, 3, '5-06-01-01', 'Income Tax', 'expense', 464, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:25.882802'),
	(466, 3, '1-01-01-01-0001', 'Main Cash', 'asset', 363, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.891287'),
	(467, 3, '1-01-02-01-0001', 'Trade Debtors — General', 'asset', 366, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.896322'),
	(468, 3, '1-01-03-02-0001', 'Advances to Suppliers — General', 'asset', 370, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.901099'),
	(469, 3, '1-01-04-01-0001', 'Stock — General', 'asset', 372, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.905875'),
	(470, 3, '1-01-05-01-0001', 'Input Sales Tax', 'asset', 374, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.91036'),
	(471, 3, '1-01-05-02-0001', 'WHT Receivable', 'asset', 375, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.914729'),
	(472, 3, '1-01-06-01-0001', 'Suspense Account', 'asset', 377, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.919245'),
	(473, 3, '1-01-06-02-0001', 'Prepaid Expenses — General', 'asset', 378, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.92368'),
	(474, 3, '1-02-01-01-0001', 'Fixed Assets — General', 'asset', 382, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.928314'),
	(475, 3, '1-02-02-01-0001', 'Accumulated Depreciation — General', 'asset', 384, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.932683'),
	(476, 3, '1-02-03-01-0001', 'Intangibles — General', 'asset', 386, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.937756'),
	(477, 3, '2-01-01-01-0001', 'Trade Creditors — General', 'liability', 390, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.942619'),
	(478, 3, '2-01-02-02-0001', 'Salary Payable', 'liability', 393, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.947346'),
	(479, 3, '2-01-02-02-0002', 'PF Payable', 'liability', 393, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.952308'),
	(480, 3, '2-01-02-02-0003', 'Loan Deductions Clearing', 'liability', 393, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.957065'),
	(481, 3, '2-01-02-02-0004', 'Other Payroll Deductions Payable', 'liability', 393, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.961554'),
	(482, 3, '2-01-02-03-0001', 'Accrued Expenses — General', 'liability', 394, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.96593'),
	(483, 3, '2-01-03-01-0001', 'Output Sales Tax', 'liability', 396, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.970551'),
	(484, 3, '2-01-03-02-0001', 'Income Tax Payable', 'liability', 397, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.974858'),
	(485, 3, '2-01-03-03-0001', 'WHT Payable', 'liability', 398, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.979293'),
	(486, 3, '2-01-03-04-0001', 'Further Tax Payable', 'liability', 399, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.983974'),
	(487, 3, '2-01-04-01-0001', 'Customer Advances — General', 'liability', 401, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.988826'),
	(488, 3, '2-02-01-01-0001', 'Long-term Loans — General', 'liability', 404, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.993929'),
	(489, 3, '2-02-02-01-0001', 'EOSB Provision — General', 'liability', 406, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:25.998608'),
	(490, 3, '3-01-01-01-0001', 'Share Capital', 'equity', 410, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.003622'),
	(491, 3, '3-01-01-01-0002', 'Suspense Equity', 'equity', 410, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.008437'),
	(492, 3, '3-02-01-01-0001', 'Retained Earnings — Opening', 'equity', 413, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.013167'),
	(493, 3, '3-02-01-02-0001', 'Retained Earnings — Closing', 'equity', 414, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.018307'),
	(494, 3, '3-02-02-01-0001', 'Dividends', 'equity', 416, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.023607'),
	(495, 3, '3-02-03-01-0001', 'Other Comprehensive Income', 'equity', 418, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.02843'),
	(496, 3, '4-01-01-01-0001', 'Sales — General', 'revenue', 422, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.032769'),
	(497, 3, '4-01-02-01-0001', 'Service Income — General', 'revenue', 424, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.037872'),
	(498, 3, '4-02-01-01-0001', 'Sales Returns — General', 'revenue', 427, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.042584'),
	(499, 3, '4-02-02-01-0001', 'Discounts Allowed — General', 'revenue', 429, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.04735'),
	(500, 3, '4-03-01-01-0001', 'Other Income — General', 'revenue', 432, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.05221'),
	(501, 3, '5-01-01-01-0001', 'Cost of Goods Sold', 'expense', 436, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.056505'),
	(502, 3, '5-01-02-01-0001', 'Scrap / Write-off', 'expense', 438, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.061021'),
	(503, 3, '5-01-02-01-0002', 'Inventory Adjustment', 'expense', 438, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.06562'),
	(504, 3, '5-01-02-01-0003', 'Consumption Expense', 'expense', 438, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.07021'),
	(505, 3, '5-01-02-01-0004', 'Inventory Cost Variance', 'expense', 438, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.074528'),
	(506, 3, '5-02-01-01-0001', 'Salary Expense', 'expense', 441, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.079465'),
	(507, 3, '5-02-01-01-0002', 'PF Employer Expense', 'expense', 441, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.084464'),
	(508, 3, '5-02-02-01-0001', 'Rent Expense', 'expense', 443, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.089204'),
	(509, 3, '5-02-02-01-0002', 'Utilities Expense', 'expense', 443, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.094273'),
	(510, 3, '5-02-03-01-0001', 'Office Supplies', 'expense', 445, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.099315'),
	(511, 3, '5-02-04-01-0001', 'Depreciation Expense', 'expense', 447, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.104525'),
	(512, 3, '5-02-05-01-0001', 'Fees, Taxes & Licenses — General', 'expense', 449, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.109431'),
	(513, 3, '5-03-01-01-0001', 'Freight & Transportation — General', 'expense', 452, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.114321'),
	(514, 3, '5-03-02-01-0001', 'Commissions — General', 'expense', 454, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.119242'),
	(515, 3, '5-03-03-01-0001', 'Marketing & Advertising — General', 'expense', 456, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.123944'),
	(516, 3, '5-04-01-01-0001', 'Other Expenses — General', 'expense', 459, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.128689'),
	(517, 3, '5-04-01-01-0002', 'Loss/(Gain) on Disposal of Fixed Assets', 'expense', 459, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.133386'),
	(518, 3, '5-05-01-01-0001', 'Bank Charges', 'expense', 462, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.138435'),
	(519, 3, '5-05-01-01-0002', 'Interest Expense', 'expense', 462, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.143215'),
	(520, 3, '5-06-01-01-0001', 'Income Tax Expense', 'expense', 465, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.147954'),
	(521, 4, '1', 'Assets', 'asset', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.347317'),
	(522, 4, '1-01', 'Current Assets', 'asset', 521, 2, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:26.355925'),
	(523, 4, '1-01-01', 'Cash & Cash Equivalents', 'asset', 522, 3, true, true, NULL, 'cash', NULL, '2026-10-29 08:52:26.360994'),
	(524, 4, '1-01-01-01', 'Cash in Hand', 'asset', 523, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.36609'),
	(525, 4, '1-01-01-02', 'Bank Accounts', 'asset', 523, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.371121'),
	(526, 4, '1-01-02', 'Trade Receivables', 'asset', 522, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.375898'),
	(527, 4, '1-01-02-01', 'Trade Debtors', 'asset', 526, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.380866'),
	(528, 4, '1-01-02-02', 'Doubtful Receivables', 'asset', 526, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.386331'),
	(529, 4, '1-01-03', 'Other Receivables', 'asset', 522, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.391545'),
	(530, 4, '1-01-03-01', 'Employee Loans & Advances', 'asset', 529, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.396392'),
	(531, 4, '1-01-03-02', 'Advances to Suppliers', 'asset', 529, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.40114'),
	(532, 4, '1-01-04', 'Inventories', 'asset', 522, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.406062'),
	(533, 4, '1-01-04-01', 'Trading Goods Stock', 'asset', 532, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.41075'),
	(534, 4, '1-01-05', 'Tax Assets', 'asset', 522, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.415344'),
	(535, 4, '1-01-05-01', 'Input Sales Tax', 'asset', 534, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.419993'),
	(536, 4, '1-01-05-02', 'WHT Receivable', 'asset', 534, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.424487'),
	(537, 4, '1-01-06', 'Prepayments & Other', 'asset', 522, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.428894'),
	(538, 4, '1-01-06-01', 'Suspense & Clearing', 'asset', 537, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.433208'),
	(539, 4, '1-01-06-02', 'Prepaid Expenses', 'asset', 537, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.437903'),
	(540, 4, '1-01-06-03', 'Other Current Assets', 'asset', 537, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.442363'),
	(541, 4, '1-02', 'Non-Current Assets', 'asset', 521, 2, true, true, NULL, 'investing', NULL, '2026-10-29 08:52:26.447064'),
	(542, 4, '1-02-01', 'Property, Plant & Equipment', 'asset', 541, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.451803'),
	(543, 4, '1-02-01-01', 'Owned Assets', 'asset', 542, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.456595'),
	(544, 4, '1-02-02', 'Accumulated Depreciation', 'asset', 541, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.461302'),
	(545, 4, '1-02-02-01', 'Accumulated Depreciation', 'asset', 544, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.46593'),
	(546, 4, '1-02-03', 'Intangible Assets', 'asset', 541, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.470898'),
	(547, 4, '1-02-03-01', 'Intangibles', 'asset', 546, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.475766'),
	(548, 4, '2', 'Liabilities', 'liability', NULL, 1, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.478834'),
	(549, 4, '2-01', 'Current Liabilities', 'liability', 548, 2, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:26.48343'),
	(550, 4, '2-01-01', 'Trade Payables', 'liability', 549, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.488252'),
	(551, 4, '2-01-01-01', 'Trade Creditors', 'liability', 550, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.492912'),
	(552, 4, '2-01-02', 'Accrued & Payroll Liabilities', 'liability', 549, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.49768'),
	(553, 4, '2-01-02-01', 'Employee Payables', 'liability', 552, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.502689'),
	(554, 4, '2-01-02-02', 'Payroll Liabilities', 'liability', 552, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.507261'),
	(555, 4, '2-01-02-03', 'Accrued Expenses', 'liability', 552, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.511741'),
	(556, 4, '2-01-03', 'Tax Liabilities', 'liability', 549, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.515967'),
	(557, 4, '2-01-03-01', 'Output Sales Tax', 'liability', 556, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.522434'),
	(558, 4, '2-01-03-02', 'Income Tax Payable', 'liability', 556, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.52717'),
	(559, 4, '2-01-03-03', 'WHT Payable', 'liability', 556, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.531738'),
	(560, 4, '2-01-03-04', 'Further Tax Payable', 'liability', 556, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.537162'),
	(561, 4, '2-01-04', 'Advances from Customers', 'liability', 549, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.54197'),
	(562, 4, '2-01-04-01', 'Customer Advances', 'liability', 561, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.546646'),
	(563, 4, '2-02', 'Non-Current Liabilities', 'liability', 548, 2, true, true, NULL, 'financing', NULL, '2026-10-29 08:52:26.551242'),
	(564, 4, '2-02-01', 'Long-term Loans', 'liability', 563, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.555877'),
	(565, 4, '2-02-01-01', 'Long-term Loans', 'liability', 564, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.560348'),
	(566, 4, '2-02-02', 'Employee End-of-Service Benefits', 'liability', 563, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.564576'),
	(567, 4, '2-02-02-01', 'EOSB Provision', 'liability', 566, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.569018'),
	(568, 4, '3', 'Equity', 'equity', NULL, 1, true, true, NULL, 'financing', NULL, '2026-10-29 08:52:26.571805'),
	(569, 4, '3-01', 'Capital', 'equity', 568, 2, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.575947'),
	(570, 4, '3-01-01', 'Owner Capital', 'equity', 569, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.580299'),
	(571, 4, '3-01-01-01', 'Owner Capital', 'equity', 570, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.58495'),
	(572, 4, '3-02', 'Reserves & Retained Earnings', 'equity', 568, 2, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.589746'),
	(573, 4, '3-02-01', 'Retained Earnings', 'equity', 572, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.594409'),
	(574, 4, '3-02-01-01', 'Retained Earnings — Opening', 'equity', 573, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.598989'),
	(575, 4, '3-02-01-02', 'Retained Earnings — Closing', 'equity', 573, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.603603'),
	(576, 4, '3-02-02', 'Dividends', 'equity', 572, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.608001'),
	(577, 4, '3-02-02-01', 'Dividends', 'equity', 576, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.6126'),
	(578, 4, '3-02-03', 'Other Comprehensive Income', 'equity', 572, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.617272'),
	(579, 4, '3-02-03-01', 'Other Comprehensive Income', 'equity', 578, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.622401'),
	(580, 4, '4', 'Revenue', 'revenue', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:26.625895'),
	(581, 4, '4-01', 'Sales', 'revenue', 580, 2, true, true, NULL, NULL, 'sales', '2026-10-29 08:52:26.630878'),
	(582, 4, '4-01-01', 'Product Sales', 'revenue', 581, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.636243'),
	(583, 4, '4-01-01-01', 'Product Sales', 'revenue', 582, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.641561'),
	(584, 4, '4-01-02', 'Service Income', 'revenue', 581, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.646603'),
	(585, 4, '4-01-02-01', 'Service Income', 'revenue', 584, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.651421'),
	(586, 4, '4-02', 'Sales Returns & Discounts', 'revenue', 580, 2, true, true, NULL, NULL, 'sales_returns', '2026-10-29 08:52:26.656444'),
	(587, 4, '4-02-01', 'Sales Returns', 'revenue', 586, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.661169'),
	(588, 4, '4-02-01-01', 'Sales Returns', 'revenue', 587, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.665875'),
	(589, 4, '4-02-02', 'Discounts Allowed', 'revenue', 586, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.670823'),
	(590, 4, '4-02-02-01', 'Discounts Allowed', 'revenue', 589, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.675896'),
	(591, 4, '4-03', 'Other Income', 'revenue', 580, 2, true, true, NULL, NULL, 'other_income', '2026-10-29 08:52:26.681294'),
	(592, 4, '4-03-01', 'Other Income', 'revenue', 591, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.686721'),
	(593, 4, '4-03-01-01', 'Other Income', 'revenue', 592, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.692345'),
	(594, 4, '5', 'Expenses', 'expense', NULL, 1, true, true, NULL, 'operating', NULL, '2026-10-29 08:52:26.69586'),
	(595, 4, '5-01', 'Cost of Sales', 'expense', 594, 2, true, true, NULL, NULL, 'cost_of_sales', '2026-10-29 08:52:26.700944'),
	(596, 4, '5-01-01', 'Cost of Goods Sold', 'expense', 595, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.705912'),
	(597, 4, '5-01-01-01', 'Cost of Goods Sold', 'expense', 596, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.71102'),
	(598, 4, '5-01-02', 'Stock Losses, Scrap & Adjustments', 'expense', 595, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.715901'),
	(599, 4, '5-01-02-01', 'Stock Losses & Scrap', 'expense', 598, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.72074'),
	(600, 4, '5-02', 'Administrative Expenses', 'expense', 594, 2, true, true, NULL, NULL, 'admin', '2026-10-29 08:52:26.725689');
INSERT INTO public.chart_of_accounts VALUES
	(601, 4, '5-02-01', 'Salaries & Benefits', 'expense', 600, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.730526'),
	(602, 4, '5-02-01-01', 'Salaries & Benefits', 'expense', 601, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.735408'),
	(603, 4, '5-02-02', 'Rent & Utilities', 'expense', 600, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.740185'),
	(604, 4, '5-02-02-01', 'Rent & Utilities', 'expense', 603, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.745412'),
	(605, 4, '5-02-03', 'Office & Supplies', 'expense', 600, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.750246'),
	(606, 4, '5-02-03-01', 'Office & Supplies', 'expense', 605, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.75503'),
	(607, 4, '5-02-04', 'Depreciation & Amortisation', 'expense', 600, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.760157'),
	(608, 4, '5-02-04-01', 'Depreciation & Amortisation', 'expense', 607, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.764936'),
	(609, 4, '5-02-05', 'Fees, Taxes & Licenses', 'expense', 600, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.769605'),
	(610, 4, '5-02-05-01', 'Fees, Taxes & Licenses', 'expense', 609, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.77423'),
	(611, 4, '5-03', 'Selling & Distribution', 'expense', 594, 2, true, true, NULL, NULL, 'selling_distribution', '2026-10-29 08:52:26.779005'),
	(612, 4, '5-03-01', 'Freight & Transportation', 'expense', 611, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.783464'),
	(613, 4, '5-03-01-01', 'Freight & Transportation', 'expense', 612, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.78765'),
	(614, 4, '5-03-02', 'Commissions', 'expense', 611, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.791922'),
	(615, 4, '5-03-02-01', 'Commissions', 'expense', 614, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.796362'),
	(616, 4, '5-03-03', 'Marketing & Advertising', 'expense', 611, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.800682'),
	(617, 4, '5-03-03-01', 'Marketing & Advertising', 'expense', 616, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.805213'),
	(618, 4, '5-04', 'Other Operating Expenses', 'expense', 594, 2, true, true, NULL, NULL, 'other_operating', '2026-10-29 08:52:26.809836'),
	(619, 4, '5-04-01', 'Other Operating Expenses', 'expense', 618, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.814238'),
	(620, 4, '5-04-01-01', 'Other Operating Expenses', 'expense', 619, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.818987'),
	(621, 4, '5-05', 'Finance Costs', 'expense', 594, 2, true, true, NULL, NULL, 'finance_cost', '2026-10-29 08:52:26.825451'),
	(622, 4, '5-05-01', 'Bank & Interest Charges', 'expense', 621, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.831847'),
	(623, 4, '5-05-01-01', 'Bank & Interest Charges', 'expense', 622, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.837475'),
	(624, 4, '5-06', 'Taxation', 'expense', 594, 2, true, true, NULL, NULL, 'income_tax', '2026-10-29 08:52:26.842673'),
	(625, 4, '5-06-01', 'Income Tax', 'expense', 624, 3, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.848164'),
	(626, 4, '5-06-01-01', 'Income Tax', 'expense', 625, 4, true, true, NULL, NULL, NULL, '2026-10-29 08:52:26.853593'),
	(627, 4, '1-01-01-01-0001', 'Main Cash', 'asset', 524, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.862108'),
	(628, 4, '1-01-02-01-0001', 'Trade Debtors — General', 'asset', 527, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.867489'),
	(629, 4, '1-01-03-02-0001', 'Advances to Suppliers — General', 'asset', 531, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.872703'),
	(630, 4, '1-01-04-01-0001', 'Stock — General', 'asset', 533, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.878153'),
	(631, 4, '1-01-05-01-0001', 'Input Sales Tax', 'asset', 535, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.88348'),
	(632, 4, '1-01-05-02-0001', 'WHT Receivable', 'asset', 536, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.88907'),
	(633, 4, '1-01-06-01-0001', 'Suspense Account', 'asset', 538, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.894171'),
	(634, 4, '1-01-06-02-0001', 'Prepaid Expenses — General', 'asset', 539, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.89902'),
	(635, 4, '1-02-01-01-0001', 'Fixed Assets — General', 'asset', 543, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.903879'),
	(636, 4, '1-02-02-01-0001', 'Accumulated Depreciation — General', 'asset', 545, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.908871'),
	(637, 4, '1-02-03-01-0001', 'Intangibles — General', 'asset', 547, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.91391'),
	(638, 4, '2-01-01-01-0001', 'Trade Creditors — General', 'liability', 551, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.918719'),
	(639, 4, '2-01-02-02-0001', 'Salary Payable', 'liability', 554, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.923579'),
	(640, 4, '2-01-02-02-0002', 'PF Payable', 'liability', 554, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.928763'),
	(641, 4, '2-01-02-02-0003', 'Loan Deductions Clearing', 'liability', 554, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.933756'),
	(642, 4, '2-01-02-02-0004', 'Other Payroll Deductions Payable', 'liability', 554, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.93852'),
	(643, 4, '2-01-02-03-0001', 'Accrued Expenses — General', 'liability', 555, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.943375'),
	(644, 4, '2-01-03-01-0001', 'Output Sales Tax', 'liability', 557, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.948565'),
	(645, 4, '2-01-03-02-0001', 'Income Tax Payable', 'liability', 558, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.953351'),
	(646, 4, '2-01-03-03-0001', 'WHT Payable', 'liability', 559, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.958147'),
	(647, 4, '2-01-03-04-0001', 'Further Tax Payable', 'liability', 560, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.962957'),
	(648, 4, '2-01-04-01-0001', 'Customer Advances — General', 'liability', 562, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.967569'),
	(649, 4, '2-02-01-01-0001', 'Long-term Loans — General', 'liability', 565, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.972187'),
	(650, 4, '2-02-02-01-0001', 'EOSB Provision — General', 'liability', 567, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.976951'),
	(651, 4, '3-01-01-01-0001', 'Share Capital', 'equity', 571, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.982264'),
	(652, 4, '3-01-01-01-0002', 'Suspense Equity', 'equity', 571, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.987535'),
	(653, 4, '3-02-01-01-0001', 'Retained Earnings — Opening', 'equity', 574, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.992809'),
	(654, 4, '3-02-01-02-0001', 'Retained Earnings — Closing', 'equity', 575, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:26.99815'),
	(655, 4, '3-02-02-01-0001', 'Dividends', 'equity', 577, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.003277'),
	(656, 4, '3-02-03-01-0001', 'Other Comprehensive Income', 'equity', 579, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.008358'),
	(657, 4, '4-01-01-01-0001', 'Sales — General', 'revenue', 583, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.01341'),
	(658, 4, '4-01-02-01-0001', 'Service Income — General', 'revenue', 585, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.018653'),
	(659, 4, '4-02-01-01-0001', 'Sales Returns — General', 'revenue', 588, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.02385'),
	(660, 4, '4-02-02-01-0001', 'Discounts Allowed — General', 'revenue', 590, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.029187'),
	(661, 4, '4-03-01-01-0001', 'Other Income — General', 'revenue', 593, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.034224'),
	(662, 4, '5-01-01-01-0001', 'Cost of Goods Sold', 'expense', 597, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.039195'),
	(663, 4, '5-01-02-01-0001', 'Scrap / Write-off', 'expense', 599, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.044583'),
	(664, 4, '5-01-02-01-0002', 'Inventory Adjustment', 'expense', 599, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.050933'),
	(665, 4, '5-01-02-01-0003', 'Consumption Expense', 'expense', 599, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.057547'),
	(666, 4, '5-01-02-01-0004', 'Inventory Cost Variance', 'expense', 599, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.06425'),
	(667, 4, '5-02-01-01-0001', 'Salary Expense', 'expense', 602, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.070404'),
	(668, 4, '5-02-01-01-0002', 'PF Employer Expense', 'expense', 602, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.076993'),
	(669, 4, '5-02-02-01-0001', 'Rent Expense', 'expense', 604, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.083355'),
	(670, 4, '5-02-02-01-0002', 'Utilities Expense', 'expense', 604, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.089615'),
	(671, 4, '5-02-03-01-0001', 'Office Supplies', 'expense', 606, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.09624'),
	(672, 4, '5-02-04-01-0001', 'Depreciation Expense', 'expense', 608, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.103028'),
	(673, 4, '5-02-05-01-0001', 'Fees, Taxes & Licenses — General', 'expense', 610, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.109612'),
	(674, 4, '5-03-01-01-0001', 'Freight & Transportation — General', 'expense', 613, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.116209'),
	(675, 4, '5-03-02-01-0001', 'Commissions — General', 'expense', 615, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.122884'),
	(676, 4, '5-03-03-01-0001', 'Marketing & Advertising — General', 'expense', 617, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.129426'),
	(677, 4, '5-04-01-01-0001', 'Other Expenses — General', 'expense', 620, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.136081'),
	(678, 4, '5-04-01-01-0002', 'Loss/(Gain) on Disposal of Fixed Assets', 'expense', 620, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.14259'),
	(679, 4, '5-05-01-01-0001', 'Bank Charges', 'expense', 623, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.149331'),
	(680, 4, '5-05-01-01-0002', 'Interest Expense', 'expense', 623, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.155976'),
	(681, 4, '5-06-01-01-0001', 'Income Tax Expense', 'expense', 626, 5, false, true, NULL, NULL, NULL, '2026-10-29 08:52:27.162629');

INSERT INTO public.companies VALUES
	(1, 'Default Company', 'default', true, 'free', NULL, 1, true, true, true, true, true, true, true, true, NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 08:52:21.241682', '2026-10-29 08:52:24.165091'),
	(2, 'Console console-one', 'console-one', true, 'free', NULL, 1, true, true, true, true, true, true, true, true, NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 08:52:24.374505', '2026-10-29 08:52:24.374508'),
	(3, 'Console console-two', 'console-two', true, 'free', NULL, 1, true, true, true, true, true, true, true, true, NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 08:52:25.3339', '2026-10-29 08:52:25.333903'),
	(4, 'Console console-three', 'console-three', true, 'free', NULL, 1, true, true, true, true, true, true, true, true, NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 08:52:26.330903', '2026-10-29 08:52:26.330906');

INSERT INTO public.company_info VALUES
	(1, 1, 'SolarKon Energy Solutions', NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 08:52:22.873473', '2026-10-29 08:52:22.873478'),
	(2, 2, 'SolarKon Energy Solutions', NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 08:52:25.190866', '2026-10-29 08:52:25.190869'),
	(3, 3, 'SolarKon Energy Solutions', NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 08:52:26.191906', '2026-10-29 08:52:26.19191'),
	(4, 4, 'SolarKon Energy Solutions', NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'PKR', 'Rs.', 'Y-m-d', 'en', 'Asia/Karachi', '2026-10-29 08:52:27.21886', '2026-10-29 08:52:27.218865');

INSERT INTO public.company_invitations VALUES
	(1, 2, 'mixed.case@ref.test', 2, 6, 'accepted', '2026-10-29 08:52:27.78793'),
	(3, 3, 'second.admin@ref.test', 1, 7, 'accepted', '2026-10-29 08:52:28.125121'),
	(2, 2, 'Invitee.Mixed@Ref.Test', 3, 6, 'sent', '2026-10-29 08:52:27.970636');

INSERT INTO public.company_memberships VALUES
	(1, 1, 1, 1, 'active', 'SYSADMIN', '2026-10-29 08:52:24.14966', NULL, NULL, NULL, 'System Administrator', NULL),
	(2, 1, 3, 2, 'active', 'MGR002', '2026-10-29 08:52:24.153732', NULL, NULL, NULL, 'Manager', NULL),
	(3, 1, 4, 3, 'active', 'EMP001', '2026-10-29 08:52:24.156975', NULL, NULL, NULL, 'Employee', NULL),
	(4, 1, 5, 3, 'active', 'EMP002', '2026-10-29 08:52:24.161126', NULL, NULL, NULL, 'Employee', NULL),
	(5, 2, 6, 1, 'active', 'SA0006', '2026-10-29 08:52:24.382988', NULL, NULL, NULL, NULL, NULL),
	(6, 3, 7, 1, 'active', 'SA0007', '2026-10-29 08:52:25.343383', NULL, NULL, NULL, NULL, NULL),
	(8, 2, 9, 2, 'active', NULL, '2026-10-29 08:52:27.911196', NULL, '{"accounting": true, "executive": false, "fbr": false, "finance": false, "fixed_assets": false, "hr": true, "inventory": false, "invoicing": false}', NULL, NULL, NULL),
	(9, 3, 10, 1, 'active', NULL, '2026-10-29 08:52:28.258717', NULL, NULL, NULL, NULL, NULL),
	(7, 4, 8, 1, 'blocked', 'SA0008', '2026-10-29 08:52:26.340048', NULL, NULL, NULL, NULL, NULL);

INSERT INTO public.fa_categories VALUES
	(1, 1, 'Computers & IT Equipment', 'Desktop computers, laptops, servers, printers', 5, 'straight_line', 0.000000, true, '2026-10-29 08:52:21.515652'),
	(2, 1, 'Office Furniture', 'Desks, chairs, cabinets, shelving', 10, 'straight_line', 5.000000, true, '2026-10-29 08:52:21.5182'),
	(3, 1, 'Vehicles', 'Cars, trucks, forklifts', 8, 'declining_balance', 10.000000, true, '2026-10-29 08:52:21.519822'),
	(4, 1, 'Machinery & Equipment', 'Production machines, tools, heavy equipment', 15, 'straight_line', 5.000000, true, '2026-10-29 08:52:21.521435'),
	(5, 1, 'Buildings & Leasehold Improvements', 'Office buildings, warehouse, renovations', 30, 'straight_line', 10.000000, true, '2026-10-29 08:52:21.523186'),
	(6, 1, 'Software & Licenses', 'ERP licenses, development tools', 3, 'straight_line', 0.000000, true, '2026-10-29 08:52:21.525034'),
	(7, 2, 'Computers & IT Equipment', 'Desktop computers, laptops, servers, printers', 5, 'straight_line', 0.000000, true, '2026-10-29 08:52:25.175746'),
	(8, 2, 'Office Furniture', 'Desks, chairs, cabinets, shelving', 10, 'straight_line', 5.000000, true, '2026-10-29 08:52:25.177887'),
	(9, 2, 'Vehicles', 'Cars, trucks, forklifts', 8, 'declining_balance', 10.000000, true, '2026-10-29 08:52:25.180159'),
	(10, 2, 'Machinery & Equipment', 'Production machines, tools, heavy equipment', 15, 'straight_line', 5.000000, true, '2026-10-29 08:52:25.182352'),
	(11, 2, 'Buildings & Leasehold Improvements', 'Office buildings, warehouse, renovations', 30, 'straight_line', 10.000000, true, '2026-10-29 08:52:25.184492'),
	(12, 2, 'Software & Licenses', 'ERP licenses, development tools', 3, 'straight_line', 0.000000, true, '2026-10-29 08:52:25.187326'),
	(13, 3, 'Computers & IT Equipment', 'Desktop computers, laptops, servers, printers', 5, 'straight_line', 0.000000, true, '2026-10-29 08:52:26.1765'),
	(14, 3, 'Office Furniture', 'Desks, chairs, cabinets, shelving', 10, 'straight_line', 5.000000, true, '2026-10-29 08:52:26.178816'),
	(15, 3, 'Vehicles', 'Cars, trucks, forklifts', 8, 'declining_balance', 10.000000, true, '2026-10-29 08:52:26.181085'),
	(16, 3, 'Machinery & Equipment', 'Production machines, tools, heavy equipment', 15, 'straight_line', 5.000000, true, '2026-10-29 08:52:26.183297'),
	(17, 3, 'Buildings & Leasehold Improvements', 'Office buildings, warehouse, renovations', 30, 'straight_line', 10.000000, true, '2026-10-29 08:52:26.185502'),
	(18, 3, 'Software & Licenses', 'ERP licenses, development tools', 3, 'straight_line', 0.000000, true, '2026-10-29 08:52:26.188343'),
	(19, 4, 'Computers & IT Equipment', 'Desktop computers, laptops, servers, printers', 5, 'straight_line', 0.000000, true, '2026-10-29 08:52:27.199153'),
	(20, 4, 'Office Furniture', 'Desks, chairs, cabinets, shelving', 10, 'straight_line', 5.000000, true, '2026-10-29 08:52:27.202077'),
	(21, 4, 'Vehicles', 'Cars, trucks, forklifts', 8, 'declining_balance', 10.000000, true, '2026-10-29 08:52:27.204978'),
	(22, 4, 'Machinery & Equipment', 'Production machines, tools, heavy equipment', 15, 'straight_line', 5.000000, true, '2026-10-29 08:52:27.207839'),
	(23, 4, 'Buildings & Leasehold Improvements', 'Office buildings, warehouse, renovations', 30, 'straight_line', 10.000000, true, '2026-10-29 08:52:27.210695'),
	(24, 4, 'Software & Licenses', 'ERP licenses, development tools', 3, 'straight_line', 0.000000, true, '2026-10-29 08:52:27.214306');

INSERT INTO public.fiscal_year_rule VALUES
	(1, 1, 1, 1, '2026-10-29 08:52:22.879819', '2026-10-29 08:52:22.879823'),
	(2, 2, 1, 1, '2026-10-29 08:52:25.195375', '2026-10-29 08:52:25.195379'),
	(3, 3, 1, 1, '2026-10-29 08:52:26.196274', '2026-10-29 08:52:26.196278'),
	(4, 4, 1, 1, '2026-10-29 08:52:27.224991', '2026-10-29 08:52:27.224997');

INSERT INTO public.gl_daily_balances VALUES
	(2, 1, 172, 0, '2026-10-29', 1400000.0000, 0.0000, 1),
	(4, 1, 173, 0, '2026-10-29', 1110000.0000, 0.0000, 1),
	(6, 1, 174, 0, '2026-10-29', 740000.0000, 0.0000, 1),
	(8, 1, 175, 0, '2026-10-29', 1080000.0000, 0.0000, 1),
	(10, 1, 176, 0, '2026-10-29', 1250000.0000, 0.0000, 1),
	(12, 1, 177, 0, '2026-10-29', 920000.0000, 0.0000, 1),
	(14, 1, 178, 0, '2026-10-29', 3875000.0000, 0.0000, 1),
	(16, 1, 179, 0, '2026-10-29', 4200000.0000, 0.0000, 1),
	(18, 1, 180, 0, '2026-10-29', 1140000.0000, 0.0000, 1),
	(20, 1, 181, 0, '2026-10-29', 60000.0000, 0.0000, 1),
	(22, 1, 182, 0, '2026-10-29', 80000.0000, 0.0000, 1),
	(24, 1, 183, 0, '2026-10-29', 50000.0000, 0.0000, 1),
	(26, 1, 184, 0, '2026-10-29', 130000.0000, 0.0000, 1),
	(28, 1, 185, 0, '2026-10-29', 80000.0000, 0.0000, 1),
	(30, 1, 186, 0, '2026-10-29', 96000.0000, 0.0000, 1),
	(32, 1, 187, 0, '2026-10-29', 80000.0000, 0.0000, 1),
	(34, 1, 188, 0, '2026-10-29', 22000.0000, 0.0000, 1),
	(36, 1, 189, 0, '2026-10-29', 42000.0000, 0.0000, 1),
	(38, 1, 190, 0, '2026-10-29', 37500.0000, 0.0000, 1),
	(40, 1, 191, 0, '2026-10-29', 25000.0000, 0.0000, 1),
	(42, 1, 192, 0, '2026-10-29', 32000.0000, 0.0000, 1),
	(1, 1, 132, 0, '2026-10-29', 0.0000, 16497500.0000, 22),
	(44, 1, 193, 0, '2026-10-29', 48000.0000, 0.0000, 1);

INSERT INTO public.global_limits VALUES
	(1, 3, 25, NULL, '2026-10-29 08:52:21.399454');

INSERT INTO public.inv_categories VALUES
	(1, 1, 'Solar Panels', 'Solar Panels category', NULL, true, '2026-10-29 08:52:22.694618'),
	(2, 1, 'Inverters', 'Inverters category', NULL, true, '2026-10-29 08:52:22.697551'),
	(3, 1, 'Batteries', 'Batteries category', NULL, true, '2026-10-29 08:52:22.699677'),
	(4, 1, 'Cables & Wiring', 'Cables & Wiring category', NULL, true, '2026-10-29 08:52:22.701699'),
	(5, 1, 'Mounting Structures', 'Mounting Structures category', NULL, true, '2026-10-29 08:52:22.703692'),
	(6, 1, 'Electrical Components', 'Electrical Components category', NULL, true, '2026-10-29 08:52:22.705706'),
	(7, 1, 'Tools & Equipment', 'Tools & Equipment category', NULL, true, '2026-10-29 08:52:22.70778'),
	(8, 1, 'Safety Gear', 'Safety Gear category', NULL, true, '2026-10-29 08:52:22.71019');

INSERT INTO public.inv_customers VALUES
	(1, 1, 'SolarTech Solutions', NULL, 'imran@solartech.com', '0300-1111111', NULL, '7-A, Johar Town', 'Lahore', NULL, NULL, 1000000.000000, NULL, NULL, true, '2026-10-29 08:52:22.845581'),
	(2, 1, 'Green Energy Pakistan', NULL, 'fatima@greenenergy.com', '0300-2222222', NULL, '15-B, Phase 2, DHA', 'Karachi', NULL, NULL, 2000000.000000, NULL, NULL, true, '2026-10-29 08:52:22.849576'),
	(3, 1, 'BuildRight Construction', NULL, 'ali@buildright.com', '0300-3333333', NULL, '3rd Floor, Al-Falah Plaza', 'Islamabad', NULL, NULL, 1500000.000000, NULL, NULL, true, '2026-10-29 08:52:22.852765'),
	(4, 1, 'Home Solutions Ltd.', NULL, 'zafar@homesol.com', '0300-4444444', NULL, '88, Garden Town', 'Lahore', NULL, NULL, 500000.000000, NULL, NULL, true, '2026-10-29 08:52:22.856451');

INSERT INTO public.inv_products VALUES
	(1, 1, 'SOL-MONO-450', 'Monocrystalline Solar Panel 450W', NULL, 1, 32000.000000, 28000.000000, 10, 50.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.749222', '2026-10-29 08:52:22.749227'),
	(2, 1, 'SOL-MONO-550', 'Monocrystalline Solar Panel 550W', NULL, 1, 42000.000000, 37000.000000, 5, 30.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.753168', '2026-10-29 08:52:22.753174'),
	(3, 1, 'SOL-POLY-330', 'Polycrystalline Solar Panel 330W', NULL, 1, 22000.000000, 18500.000000, 8, 40.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.756517', '2026-10-29 08:52:22.75652'),
	(4, 1, 'INV-5KW', '5kW Hybrid Inverter', NULL, 2, 85000.000000, 72000.000000, 3, 15.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.759697', '2026-10-29 08:52:22.7597'),
	(5, 1, 'INV-10KW', '10kW Hybrid Inverter', NULL, 2, 145000.000000, 125000.000000, 2, 10.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.76287', '2026-10-29 08:52:22.762874'),
	(6, 1, 'INV-3KW', '3kW String Inverter', NULL, 2, 55000.000000, 46000.000000, 4, 20.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.766173', '2026-10-29 08:52:22.766177'),
	(7, 1, 'BAT-LFP-5KWH', '5kWh LiFePO4 Battery', NULL, 3, 180000.000000, 155000.000000, 5, 25.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.769537', '2026-10-29 08:52:22.769541'),
	(8, 1, 'BAT-LFP-10KWH', '10kWh LiFePO4 Battery', NULL, 3, 320000.000000, 280000.000000, 3, 15.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.77293', '2026-10-29 08:52:22.772933'),
	(9, 1, 'BAT-TUB-200', '200Ah Tubular Battery', NULL, 3, 45000.000000, 38000.000000, 5, 30.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.776092', '2026-10-29 08:52:22.776095'),
	(10, 1, 'CBL-SOL-4MM', 'Solar DC Cable 4mm (per meter)', NULL, 4, 180.000000, 120.000000, 100, 500.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.779254', '2026-10-29 08:52:22.779257'),
	(11, 1, 'CBL-AC-2.5MM', 'AC Cable 2.5mm (per meter)', NULL, 4, 120.000000, 80.000000, 200, 1000.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.782417', '2026-10-29 08:52:22.78242'),
	(12, 1, 'CBL-MC4', 'MC4 Connector Pair', NULL, 4, 350.000000, 250.000000, 50, 200.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.785787', '2026-10-29 08:52:22.785791'),
	(13, 1, 'MNT-ALU-RACK', 'Aluminum Mounting Rack (set)', NULL, 5, 8500.000000, 6500.000000, 5, 20.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.788951', '2026-10-29 08:52:22.788954'),
	(14, 1, 'MNT-RAIL-2M', 'Mounting Rail 2m', NULL, 5, 2200.000000, 1600.000000, 10, 50.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.792373', '2026-10-29 08:52:22.792376'),
	(15, 1, 'ELEC-DB', 'Distribution Board 16-way', NULL, 6, 4500.000000, 3200.000000, 5, 30.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.795678', '2026-10-29 08:52:22.795682'),
	(16, 1, 'ELEC-SPD', 'Surge Protection Device', NULL, 6, 2800.000000, 2000.000000, 8, 40.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.799043', '2026-10-29 08:52:22.799046'),
	(17, 1, 'ELEC-MCB-16A', 'MCB 16A Single Pole', NULL, 6, 350.000000, 220.000000, 20, 100.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.802361', '2026-10-29 08:52:22.802364'),
	(18, 1, 'TOOL-CRIMP', 'Solar Crimping Tool', NULL, 7, 5500.000000, 4200.000000, 2, 10.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.805532', '2026-10-29 08:52:22.805535'),
	(19, 1, 'TOOL-MULTI', 'Digital Multimeter', NULL, 7, 3500.000000, 2500.000000, 3, 15.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.808716', '2026-10-29 08:52:22.80872'),
	(20, 1, 'SAFE-HLMT', 'Safety Helmet', NULL, 8, 800.000000, 500.000000, 10, 50.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.812444', '2026-10-29 08:52:22.812448'),
	(21, 1, 'SAFE-GLOVES', 'Insulated Gloves (pair)', NULL, 8, 1200.000000, 800.000000, 10, 40.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.815815', '2026-10-29 08:52:22.815819'),
	(22, 1, 'SAFE-HARNESS', 'Safety Harness', NULL, 8, 4500.000000, 3200.000000, 3, 15.0000, 'pcs', '', 0.000000, true, '2026-10-29 08:52:22.819519', '2026-10-29 08:52:22.819522');

INSERT INTO public.inv_suppliers VALUES
	(1, 1, 'Longi Solar Pakistan', 'Mr. Ahmed', 'ahmed@longi.pk', '021-34567890', NULL, 'PLOT 12, SITE AREA', 'Karachi', NULL, NULL, NULL, NULL, true, '2026-10-29 08:52:22.824586'),
	(2, 1, 'JA Solar Technologies', 'Mr. Usman', 'usman@jasolar.com', '042-35678901', NULL, '23-G, Gulberg III', 'Lahore', NULL, NULL, NULL, NULL, true, '2026-10-29 08:52:22.828005'),
	(3, 1, 'BYD Energy Solutions', 'Mr. Kamran', 'kamran@byd.com', '021-36789012', NULL, 'Business Bay, Clifton', 'Karachi', NULL, NULL, NULL, NULL, true, '2026-10-29 08:52:22.831013'),
	(4, 1, 'Growatt Inverters', 'Mr. Hassan', 'hassan@growatt.com', '042-37890123', NULL, '55 Main Boulevard', 'Lahore', NULL, NULL, NULL, NULL, true, '2026-10-29 08:52:22.834'),
	(5, 1, 'Al-Rashid Traders', 'Mr. Rashid', 'rashid@alrashid.com', '0315-1234567', NULL, 'Steel Market, Bolton Market', 'Karachi', NULL, NULL, NULL, NULL, true, '2026-10-29 08:52:22.837003'),
	(6, 1, 'Pakistan Cable Co.', 'Mr. Faisal', 'faisal@pakcable.com', '021-38901234', NULL, 'Industrial Area, Kot Lakhpat', 'Lahore', NULL, NULL, NULL, NULL, true, '2026-10-29 08:52:22.840695');

INSERT INTO public.inv_units VALUES
	(1, 1, 'Piece', 'pcs', 'Individual unit count', true, '2026-10-29 08:52:22.715101'),
	(2, 1, 'Kilogram', 'kg', 'Weight in kilograms', true, '2026-10-29 08:52:22.717801'),
	(3, 1, 'Gram', 'g', 'Weight in grams', true, '2026-10-29 08:52:22.71988'),
	(4, 1, 'Meter', 'm', 'Length in meters', true, '2026-10-29 08:52:22.721979'),
	(5, 1, 'Liter', 'l', 'Volume in liters', true, '2026-10-29 08:52:22.724282'),
	(6, 1, 'Box', 'box', 'Box or carton', true, '2026-10-29 08:52:22.726344'),
	(7, 1, 'Set', 'set', 'Complete set', true, '2026-10-29 08:52:22.728363'),
	(8, 1, 'Pair', 'pair', 'Two units', true, '2026-10-29 08:52:22.730407'),
	(9, 1, 'Dozen', 'doz', '12 units', true, '2026-10-29 08:52:22.732368'),
	(10, 1, 'Square Meter', 'sqm', 'Area measurement', true, '2026-10-29 08:52:22.734407'),
	(11, 1, 'Kilowatt', 'kW', 'Power rating', true, '2026-10-29 08:52:22.736513'),
	(12, 1, 'Watt', 'W', 'Power rating', true, '2026-10-29 08:52:22.738858'),
	(13, 1, 'Ampere', 'A', 'Current measurement', true, '2026-10-29 08:52:22.741102'),
	(14, 1, 'Volt', 'V', 'Voltage measurement', true, '2026-10-29 08:52:22.74222');

INSERT INTO public.inventory_settings VALUES
	(1, 1, 'weighted_average', false, 4, true, 'with_po', 'with_so', NULL, NULL, NULL, false, false, NULL, NULL),
	(2, 2, 'weighted_average', false, 4, true, 'with_po', 'with_so', NULL, NULL, NULL, false, false, NULL, NULL),
	(3, 3, 'weighted_average', false, 4, true, 'with_po', 'with_so', NULL, NULL, NULL, false, false, NULL, NULL),
	(4, 4, 'weighted_average', false, 4, true, 'with_po', 'with_so', NULL, NULL, NULL, false, false, NULL, NULL);

INSERT INTO public.invoice_templates VALUES
	(1, 1, 'Standard Sales Invoice', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:23.141147', '2026-10-29 08:52:23.141152'),
	(2, 1, 'Sales Invoice (Item Wise)', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:23.141154', '2026-10-29 08:52:23.141155'),
	(3, 1, 'Standard Purchase Invoice', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:23.145231', '2026-10-29 08:52:23.145235'),
	(4, 1, 'Purchase Invoice (Item Wise)', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:23.145237', '2026-10-29 08:52:23.145238'),
	(5, 2, 'Standard Sales Invoice', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:25.222992', '2026-10-29 08:52:25.222996'),
	(6, 2, 'Sales Invoice (Item Wise)', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:25.222998', '2026-10-29 08:52:25.223'),
	(7, 2, 'Standard Purchase Invoice', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:25.225897', '2026-10-29 08:52:25.225901'),
	(8, 2, 'Purchase Invoice (Item Wise)', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:25.225902', '2026-10-29 08:52:25.225903'),
	(9, 3, 'Standard Sales Invoice', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:26.221419', '2026-10-29 08:52:26.221423'),
	(10, 3, 'Sales Invoice (Item Wise)', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:26.221425', '2026-10-29 08:52:26.221426'),
	(11, 3, 'Standard Purchase Invoice', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:26.224099', '2026-10-29 08:52:26.224103'),
	(12, 3, 'Purchase Invoice (Item Wise)', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:26.224105', '2026-10-29 08:52:26.224106'),
	(13, 4, 'Standard Sales Invoice', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:27.259728', '2026-10-29 08:52:27.259733'),
	(14, 4, 'Sales Invoice (Item Wise)', 'sales', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">SALES INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Bill To</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Prepared By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Authorised Signatory</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">Thank you for your business.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_delivery": true, "show_installation": true, "show_bank_details": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:27.259735', '2026-10-29 08:52:27.259737'),
	(15, 4, 'Standard Purchase Invoice', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #0f766e;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#0f766e;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#0f766e;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', true, 'classic', '#0f766e', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "combined", "tax_display": "combined", "charges_display": "combined", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:27.263543', '2026-10-29 08:52:27.263549'),
	(16, 4, 'Purchase Invoice (Item Wise)', 'purchase', '<style>
@page{size:A4;margin:14mm}
.inv-sheet{width:210mm;min-height:297mm;box-sizing:border-box;padding:14mm;
  margin:0 auto;background:#fff;color:#0f172a;font-size:13px;line-height:1.5;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  position:relative;display:flex;flex-direction:column}
.inv-sheet *{box-sizing:border-box}
/* Flex items do not shrink-to-fit the way blocks do; without this a table or a
   heading can end up narrower than the page. */
.inv-sheet>*{flex:none;width:100%}

/* Signatures and the closing line belong at the foot of the sheet, not
   wherever the item list happened to stop. The bottom padding is the strip the
   page number sits in, so the closing line does not share its baseline. */
.inv-sheet>.inv-foot{margin-top:auto;padding-top:10mm;padding-bottom:7mm}

/* Page numbers, bottom-right. Stamped by script because the count depends on
   how far the content actually runs, and Chromium does not implement the
   @page margin boxes that would otherwise carry counter(page). */
.inv-pagenums{position:absolute;left:14mm;right:14mm;top:14mm;bottom:14mm;
  width:auto;pointer-events:none}
.inv-pageno{position:absolute;right:0;font-size:9px;color:#94a3b8;
  letter-spacing:.3px;white-space:nowrap}

/* Items table: columns size themselves to their content, and only the
   description is allowed to wrap. Without the nowrap a long header squeezes a
   money column until "1,234,567.00" breaks across two lines.
   Size is set once, on the table — cells inherit it and pad in em — so the
   auto-fit below can resize the whole table by changing a single property. */
.inv-sheet table.inv-items{width:100%;border-collapse:collapse;table-layout:auto}
.inv-sheet table.inv-items th,
.inv-sheet table.inv-items td{white-space:nowrap;overflow-wrap:normal}
/* Headers read as labels for the column, so they sit centred in the cell both
   ways — including the tall ones that wrap to two or three lines. The body
   cells keep their own alignment: numbers right, codes left. */
.inv-sheet table.inv-items th{white-space:normal;word-break:normal;
  overflow-wrap:break-word;text-align:center;vertical-align:middle;
  line-height:1.25;font-size:.95em}
/* Every other column takes exactly the width its content needs — width:1% on a
   nowrap cell resolves to min-content — so the slack all lands on the
   description instead of being shared out and leaving it to wrap early. */
.inv-sheet table.inv-items th:not(.inv-desc),
.inv-sheet table.inv-items td:not(.inv-desc){width:1%}
/* The description absorbs the width the other columns do not need, and is the
   one cell that may run to a second line. */
.inv-sheet table.inv-items td.inv-desc{white-space:normal;overflow-wrap:break-word;
  width:100%;min-width:22mm}
.inv-sheet table.inv-items th.inv-desc{width:100%;min-width:22mm}
.inv-sheet table.inv-items tr{page-break-inside:avoid}
.inv-sheet table.inv-items thead{display:table-header-group}

/* The summary stays pinned to the right edge at a fixed width, so adding or
   removing item columns moves it not at all. */
.inv-sheet table.inv-totals{width:100%;border-collapse:collapse;margin-top:14px;
  page-break-inside:avoid}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-gap{width:auto}
.inv-sheet table.inv-totals>tbody>tr>td.inv-totals-box{width:72mm}

@media print{
  /* The @page margin is the paper margin; a second one on the sheet would
     double it and push the table off the page again. The scale applied for
     small screens has no business on paper, where the sheet is already the
     size of the page. */
  .inv-sheet{width:auto;min-height:0;padding:0;margin:0!important;
    transform:none!important;zoom:1!important}
  /* Padding is gone on paper — the @page margin is doing that job — so the
     number strip has to sit flush with the content box instead. */
  .inv-pagenums{left:0;right:0;top:0;bottom:0}
  .inv-sheet table.inv-items th{background:#1e293b!important;color:#fff!important;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style><script>
(function () {
  function fitOne(sheet, tbl) {
    var cs = window.getComputedStyle(sheet);
    var avail = sheet.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    if (!avail || avail <= 0) { return; }
    var start = parseFloat(tbl.getAttribute(''data-basesize'') || ''0'');
    if (!start) {
      start = parseFloat(window.getComputedStyle(tbl).fontSize) || 11;
      tbl.setAttribute(''data-basesize'', start);
    }
    var size = start;
    tbl.style.fontSize = size + ''px'';
    // Step down until it fits. The floor is the point past which the paper is
    // not readable anyway; below it, let the description column wrap harder
    // rather than shrink the type into illegibility.
    for (var i = 0; i < 60 && tbl.scrollWidth > avail + 1 && size > 5.5; i++) {
      size = Math.round((size - 0.25) * 100) / 100;
      tbl.style.fontSize = size + ''px'';
    }
    if (tbl.scrollWidth > avail + 1) {
      tbl.style.tableLayout = ''fixed'';
      tbl.style.width = ''100%'';
    }
  }
  // A sheet is a fixed 210mm because that is what A4 is. On any screen narrower
  // than that — a phone, a split pane, the settings preview — show the whole
  // page scaled down rather than letting it hang off the side or reflowing it
  // into something that is no longer A4. What you see stays the page, just
  // smaller, so the preview still answers "does this fit on paper".
  //
  // zoom rather than transform: zoom shrinks the layout box, so the document
  // ends where the sheet ends. A transform only repaints, leaving the full
  // 297mm reserved and a screenful of dead space under a scaled-down page.
  var CAN_ZOOM = (typeof document.documentElement.style.zoom !== ''undefined'');

  function unscale(sheet) {
    sheet.style.zoom = '''';
    sheet.style.transform = '''';
    sheet.style.marginRight = '''';
    sheet.style.marginBottom = '''';
  }

  function scaleSheet(sheet) {
    if (window.matchMedia && window.matchMedia(''print'').matches) { return; }
    var box = sheet.parentElement || document.body;
    var avail = box.clientWidth;
    var natural = sheet.offsetWidth;
    if (!avail || !natural || avail >= natural) { return; }
    var k = avail / natural;
    if (CAN_ZOOM) { sheet.style.zoom = k; return; }
    // Fallback for engines without zoom: transform, then pull the leftover
    // width and height back in so nothing scrolls to empty space.
    sheet.style.transformOrigin = ''top left'';
    sheet.style.transform = ''scale('' + k + '')'';
    sheet.style.marginRight = -Math.round(natural - avail) + ''px'';
    sheet.style.marginBottom = -Math.round(sheet.offsetHeight * (1 - k)) + ''px'';
  }

  // Millimetres in CSS pixels, measured rather than assumed — a page zoom or a
  // non-96dpi setting changes it.
  function mmPx() {
    var probe = document.createElement(''div'');
    probe.style.cssText = ''position:absolute;visibility:hidden;width:100mm;height:0'';
    document.body.appendChild(probe);
    var px = probe.offsetWidth / 100;
    document.body.removeChild(probe);
    return px || (96 / 25.4);
  }

  // A4 minus the 14mm margins top and bottom: the strip of paper one page of
  // content actually gets.
  var PAGE_CONTENT_MM = 297 - 28;

  function stampPages(sheet) {
    var host = sheet.querySelector(''.inv-pagenums'');
    if (!host) { return; }
    host.innerHTML = '''';
    var mm = mmPx();
    var per = PAGE_CONTENT_MM * mm;
    if (!per || !host.clientHeight) { return; }
    var printing = !!(window.matchMedia && window.matchMedia(''print'').matches);

    // A hair of tolerance, or a page that fills exactly to its margin claims a
    // second, empty one.
    var pages = Math.max(1, Math.ceil((host.clientHeight - 2) / per));

    // On screen the sheet is one continuous block, so round it up to whole
    // pages. That keeps it looking like the stack of paper it will print as,
    // and it puts the signature block — which floats to the bottom — at the
    // foot of the last page rather than partway down it.
    // On paper the browser is already doing the pagination; growing the sheet
    // there would just add a blank page at the end.
    sheet.style.minHeight = printing ? '''' : (pages * per + 28 * mm) + ''px'';

    var total = host.clientHeight;
    for (var i = 0; i < pages; i++) {
      var tag = document.createElement(''div'');
      tag.className = ''inv-pageno'';
      tag.textContent = ''Page '' + (i + 1) + '' of '' + pages;
      host.appendChild(tag);
      // Sit the tag''s baseline just inside the bottom edge of each page''s
      // content strip — measured from its own height, so it is never half cut
      // off by the edge — and never past where the content actually ends, or
      // the last one is stranded outside the sheet and never drawn.
      var h = tag.offsetHeight || 12;
      var y = (i + 1) * per - h - 1;
      tag.style.top = Math.max(0, Math.min(y, total - h - 1)) + ''px'';
    }
  }

  // A sheet is usually laid out inside something not visible yet — the preview
  // pane behind a tab, the mobile preview before it slides up. Measured while
  // hidden every width is zero, so the fit is skipped; nothing then fires when
  // the container is finally shown and the page is left at full 210mm inside a
  // phone-width frame, overflowing to the right with the summary off-screen.
  // Watching the box it sits in catches that moment and every later resize.
  //
  // Wired from fitAll rather than on load: this script is emitted ahead of the
  // sheet markup, so at the time it first runs there is no sheet to observe.
  var ro = null;
  function observeSheets(sheets) {
    if (!window.ResizeObserver) { return; }
    if (!ro) {
      ro = new ResizeObserver(function (entries) {
        // Width is what drives the scale. Refitting on a height change would
        // chase the height the fit itself just produced.
        var moved = false;
        for (var i = 0; i < entries.length; i++) {
          var el = entries[i].target;
          var w = el.clientWidth;
          if (el.__invLastW !== w) { el.__invLastW = w; moved = true; }
        }
        if (!moved) { return; }
        clearTimeout(window.__invFitT);
        window.__invFitT = setTimeout(fitAll, 60);
      });
    }
    for (var s = 0; s < sheets.length; s++) {
      var box = sheets[s].parentElement;
      if (box && !box.__invObserved) {
        box.__invObserved = true;
        box.__invLastW = box.clientWidth;
        ro.observe(box);
      }
    }
  }

  function fitAll() {
    var sheets = document.querySelectorAll(''.inv-sheet'');
    observeSheets(sheets);
    for (var s = 0; s < sheets.length; s++) {
      // Measure at true size: a scale left over from the last pass would make
      // the sheet look narrower than A4 and shrink the type for no reason.
      unscale(sheets[s]);
      // Type first — the table has to fit the sheet''s own 182mm whatever size
      // the sheet is being displayed at.
      var tables = sheets[s].querySelectorAll(''table.inv-items'');
      for (var t = 0; t < tables.length; t++) { fitOne(sheets[s], tables[t]); }
      // Then count pages, which depends on the height the fitted type produced.
      stampPages(sheets[s]);
      scaleSheet(sheets[s]);
    }
  }
  if (document.readyState === ''loading'') {
    document.addEventListener(''DOMContentLoaded'', fitAll);
  } else {
    fitAll();
  }
  window.addEventListener(''load'', fitAll);
  // ResizeObserver is the right tool for "the pane just became visible", but it
  // is suspended while a tab is not rendering and absent on older engines. A
  // few settling passes cover the common case — a preview revealed a moment
  // after load — without depending on it. Bounded, so this cannot become a
  // polling loop.
  var settleAt = [200, 600, 1500];
  for (var q = 0; q < settleAt.length; q++) { setTimeout(fitAll, settleAt[q]); }
  // Print geometry differs from screen geometry, so measure again for paper.
  if (window.matchMedia) {
    try { window.matchMedia(''print'').addListener(fitAll); } catch (e) {}
  }
  window.addEventListener(''beforeprint'', fitAll);
  window.addEventListener(''resize'', function () {
    clearTimeout(window.__invFitT);
    window.__invFitT = setTimeout(fitAll, 120);
  });

  window.invoiceFitSheets = fitAll;
})();
</script><div class="inv-sheet inv-sheet-v1">
  <div style="text-align:center;padding-bottom:16px;">
    {{company_logo}}
    <div style="font-size:24px;font-weight:800;letter-spacing:.5px;margin-top:6px;">{{company_name}}</div>
    <div style="color:#475569;margin-top:3px;">{{company_address}}, {{company_city}}</div>
    <div style="color:#475569;">{{company_phone}} &nbsp;&bull;&nbsp; {{company_email}}</div>
    <div style="color:#64748b;">NTN {{company_tax_id}}</div>
  </div>
  <div style="border-top:3px double #b91c1c;margin:4px 0 18px;"></div>
  <div style="text-align:center;font-size:15px;font-weight:800;letter-spacing:3px;color:#b91c1c;margin-bottom:18px;">PURCHASE INVOICE</div>
  <table style="width:100%;border-collapse:collapse;margin-bottom:18px;">
    <tr>
      <td style="width:55%;vertical-align:top;">
        <div style="font-size:10px;font-weight:700;letter-spacing:1px;color:#64748b;text-transform:uppercase;">From</div>
        <div style="font-weight:700;font-size:15px;margin:4px 0 2px;">{{party_name}}</div>
        <div style="color:#475569;">{{party_address}}</div>
        <div style="color:#475569;">{{party_city}}</div>
        <div style="color:#475569;">{{party_phone}}</div>
        <div style="color:#475569;">{{party_email}}</div>
        <div style="color:#475569;margin-top:3px;">NTN {{party_tax_id}}</div>
      </td>
      <td style="width:45%;vertical-align:top;text-align:right;line-height:1.9;">
        <div><span style="color:#64748b;">Invoice #</span> <strong>{{invoice_no}}</strong></div>
        <div><span style="color:#64748b;">Date</span> <strong>{{invoice_date}}</strong></div>
        <div><span style="color:#64748b;">Due</span> <strong>{{due_date}}</strong></div>
      </td>
    </tr>
  </table>
  {{items_table}}
  {{totals_table}}
  <div style="margin-top:26px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:12px;color:#475569;"><div style="font-weight:700;color:#0f172a;margin-bottom:3px;">Notes</div>{{notes}}</div>
  <div class="inv-foot"><table style="width:100%;margin-top:44px;border-collapse:collapse;"><tr><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Checked By</td><td style="width:10%;"></td><td style="width:45%;border-top:1px solid #94a3b8;padding-top:6px;font-size:11px;color:#64748b;text-align:center;">Approved By</td></tr></table>
    <div style="margin-top:22px;text-align:center;font-size:11px;color:#b91c1c;letter-spacing:.4px;">This document is for internal record.</div></div>
<div class="inv-pagenums" aria-hidden="true"></div></div>', false, 'classic', '#b91c1c', '{"show_logo": true, "show_company_tax_id": true, "show_status": false, "show_due_date": true, "show_party_address": true, "show_party_contact": true, "show_party_tax_id": true, "show_discount": true, "show_tax": true, "show_commission": true, "show_freight": true, "show_loading": true, "show_withholding": true, "discount_display": "per_line", "tax_display": "per_line", "charges_display": "per_line", "show_notes": true, "show_signature": true, "show_thanks": true}', '2026-10-29 08:52:27.263551', '2026-10-29 08:52:27.263553');

INSERT INTO public.journal_entries VALUES
	(1, 1, 'OPENING', 1, 'OPEN-00001', 'Opening stock — Monocrystalline Solar Panel 450W', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.200352', true),
	(2, 1, 'OPENING', 2, 'OPEN-00002', 'Opening stock — Monocrystalline Solar Panel 550W', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.244416', true),
	(3, 1, 'OPENING', 3, 'OPEN-00003', 'Opening stock — Polycrystalline Solar Panel 330W', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.283752', true),
	(4, 1, 'OPENING', 4, 'OPEN-00004', 'Opening stock — 5kW Hybrid Inverter', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.327895', true),
	(5, 1, 'OPENING', 5, 'OPEN-00005', 'Opening stock — 10kW Hybrid Inverter', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.371112', true),
	(6, 1, 'OPENING', 6, 'OPEN-00006', 'Opening stock — 3kW String Inverter', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.412093', true),
	(7, 1, 'OPENING', 7, 'OPEN-00007', 'Opening stock — 5kWh LiFePO4 Battery', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.453123', true),
	(8, 1, 'OPENING', 8, 'OPEN-00008', 'Opening stock — 10kWh LiFePO4 Battery', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.494917', true),
	(9, 1, 'OPENING', 9, 'OPEN-00009', 'Opening stock — 200Ah Tubular Battery', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.535918', true),
	(10, 1, 'OPENING', 10, 'OPEN-00010', 'Opening stock — Solar DC Cable 4mm (per meter)', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.576385', true),
	(11, 1, 'OPENING', 11, 'OPEN-00011', 'Opening stock — AC Cable 2.5mm (per meter)', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.613525', true),
	(12, 1, 'OPENING', 12, 'OPEN-00012', 'Opening stock — MC4 Connector Pair', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.651396', true),
	(13, 1, 'OPENING', 13, 'OPEN-00013', 'Opening stock — Aluminum Mounting Rack (set)', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.691951', true),
	(14, 1, 'OPENING', 14, 'OPEN-00014', 'Opening stock — Mounting Rail 2m', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.729644', true),
	(15, 1, 'OPENING', 15, 'OPEN-00015', 'Opening stock — Distribution Board 16-way', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.768838', true),
	(16, 1, 'OPENING', 16, 'OPEN-00016', 'Opening stock — Surge Protection Device', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.808318', true),
	(17, 1, 'OPENING', 17, 'OPEN-00017', 'Opening stock — MCB 16A Single Pole', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.850116', true),
	(18, 1, 'OPENING', 18, 'OPEN-00018', 'Opening stock — Solar Crimping Tool', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.89139', true),
	(19, 1, 'OPENING', 19, 'OPEN-00019', 'Opening stock — Digital Multimeter', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.931238', true),
	(20, 1, 'OPENING', 20, 'OPEN-00020', 'Opening stock — Safety Helmet', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:23.97253', true),
	(21, 1, 'OPENING', 21, 'OPEN-00021', 'Opening stock — Insulated Gloves (pair)', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:24.014207', true),
	(22, 1, 'OPENING', 22, 'OPEN-00022', 'Opening stock — Safety Harness', '2026-10-29 00:00:00', 1, '2026-10-29 08:52:24.0557', true);

INSERT INTO public.journal_lines VALUES
	(1, 1, 1, 172, 1400000.0000, 0.0000, 'Opening stock Monocrystalline Solar Panel 450W', NULL),
	(2, 1, 1, 132, 0.0000, 1400000.0000, 'Opening balance — Monocrystalline Solar Panel 450W', NULL),
	(3, 1, 2, 173, 1110000.0000, 0.0000, 'Opening stock Monocrystalline Solar Panel 550W', NULL),
	(4, 1, 2, 132, 0.0000, 1110000.0000, 'Opening balance — Monocrystalline Solar Panel 550W', NULL),
	(5, 1, 3, 174, 740000.0000, 0.0000, 'Opening stock Polycrystalline Solar Panel 330W', NULL),
	(6, 1, 3, 132, 0.0000, 740000.0000, 'Opening balance — Polycrystalline Solar Panel 330W', NULL),
	(7, 1, 4, 175, 1080000.0000, 0.0000, 'Opening stock 5kW Hybrid Inverter', NULL),
	(8, 1, 4, 132, 0.0000, 1080000.0000, 'Opening balance — 5kW Hybrid Inverter', NULL),
	(9, 1, 5, 176, 1250000.0000, 0.0000, 'Opening stock 10kW Hybrid Inverter', NULL),
	(10, 1, 5, 132, 0.0000, 1250000.0000, 'Opening balance — 10kW Hybrid Inverter', NULL),
	(11, 1, 6, 177, 920000.0000, 0.0000, 'Opening stock 3kW String Inverter', NULL),
	(12, 1, 6, 132, 0.0000, 920000.0000, 'Opening balance — 3kW String Inverter', NULL),
	(13, 1, 7, 178, 3875000.0000, 0.0000, 'Opening stock 5kWh LiFePO4 Battery', NULL),
	(14, 1, 7, 132, 0.0000, 3875000.0000, 'Opening balance — 5kWh LiFePO4 Battery', NULL),
	(15, 1, 8, 179, 4200000.0000, 0.0000, 'Opening stock 10kWh LiFePO4 Battery', NULL),
	(16, 1, 8, 132, 0.0000, 4200000.0000, 'Opening balance — 10kWh LiFePO4 Battery', NULL),
	(17, 1, 9, 180, 1140000.0000, 0.0000, 'Opening stock 200Ah Tubular Battery', NULL),
	(18, 1, 9, 132, 0.0000, 1140000.0000, 'Opening balance — 200Ah Tubular Battery', NULL),
	(19, 1, 10, 181, 60000.0000, 0.0000, 'Opening stock Solar DC Cable 4mm (per meter)', NULL),
	(20, 1, 10, 132, 0.0000, 60000.0000, 'Opening balance — Solar DC Cable 4mm (per meter)', NULL),
	(21, 1, 11, 182, 80000.0000, 0.0000, 'Opening stock AC Cable 2.5mm (per meter)', NULL),
	(22, 1, 11, 132, 0.0000, 80000.0000, 'Opening balance — AC Cable 2.5mm (per meter)', NULL),
	(23, 1, 12, 183, 50000.0000, 0.0000, 'Opening stock MC4 Connector Pair', NULL),
	(24, 1, 12, 132, 0.0000, 50000.0000, 'Opening balance — MC4 Connector Pair', NULL),
	(25, 1, 13, 184, 130000.0000, 0.0000, 'Opening stock Aluminum Mounting Rack (set)', NULL),
	(26, 1, 13, 132, 0.0000, 130000.0000, 'Opening balance — Aluminum Mounting Rack (set)', NULL),
	(27, 1, 14, 185, 80000.0000, 0.0000, 'Opening stock Mounting Rail 2m', NULL),
	(28, 1, 14, 132, 0.0000, 80000.0000, 'Opening balance — Mounting Rail 2m', NULL),
	(29, 1, 15, 186, 96000.0000, 0.0000, 'Opening stock Distribution Board 16-way', NULL),
	(30, 1, 15, 132, 0.0000, 96000.0000, 'Opening balance — Distribution Board 16-way', NULL),
	(31, 1, 16, 187, 80000.0000, 0.0000, 'Opening stock Surge Protection Device', NULL),
	(32, 1, 16, 132, 0.0000, 80000.0000, 'Opening balance — Surge Protection Device', NULL),
	(33, 1, 17, 188, 22000.0000, 0.0000, 'Opening stock MCB 16A Single Pole', NULL),
	(34, 1, 17, 132, 0.0000, 22000.0000, 'Opening balance — MCB 16A Single Pole', NULL),
	(35, 1, 18, 189, 42000.0000, 0.0000, 'Opening stock Solar Crimping Tool', NULL),
	(36, 1, 18, 132, 0.0000, 42000.0000, 'Opening balance — Solar Crimping Tool', NULL),
	(37, 1, 19, 190, 37500.0000, 0.0000, 'Opening stock Digital Multimeter', NULL),
	(38, 1, 19, 132, 0.0000, 37500.0000, 'Opening balance — Digital Multimeter', NULL),
	(39, 1, 20, 191, 25000.0000, 0.0000, 'Opening stock Safety Helmet', NULL),
	(40, 1, 20, 132, 0.0000, 25000.0000, 'Opening balance — Safety Helmet', NULL),
	(41, 1, 21, 192, 32000.0000, 0.0000, 'Opening stock Insulated Gloves (pair)', NULL),
	(42, 1, 21, 132, 0.0000, 32000.0000, 'Opening balance — Insulated Gloves (pair)', NULL),
	(43, 1, 22, 193, 48000.0000, 0.0000, 'Opening stock Safety Harness', NULL),
	(44, 1, 22, 132, 0.0000, 48000.0000, 'Opening balance — Safety Harness', NULL);

INSERT INTO public.permissions VALUES
	(1, 1, 'attendance', true, true, true),
	(2, 1, 'leaves', true, true, true),
	(3, 1, 'ess', true, true, true),
	(4, 1, 'reports', true, true, true),
	(5, 1, 'mss', true, true, true),
	(6, 1, 'workplace', true, true, true),
	(7, 1, 'timesheets', true, true, true),
	(8, 1, 'digital_files', true, true, true),
	(9, 1, 'compensation', true, true, true),
	(10, 1, 'communications', true, true, true),
	(11, 1, 'pf', true, true, true),
	(12, 1, 'users', true, true, true),
	(13, 1, 'products', true, true, true),
	(14, 1, 'suppliers', true, true, true),
	(15, 1, 'purchase_invoice', true, true, true),
	(16, 1, 'purchase_return', true, true, true),
	(17, 1, 'sales', true, true, true),
	(18, 1, 'inventory', true, true, true),
	(19, 2, 'attendance', true, true, false),
	(20, 2, 'leaves', true, true, false),
	(21, 2, 'ess', true, true, false),
	(22, 2, 'reports', true, false, false),
	(23, 2, 'mss', true, true, false),
	(24, 2, 'workplace', true, true, false),
	(25, 2, 'timesheets', true, true, false),
	(26, 2, 'digital_files', true, false, false),
	(27, 2, 'compensation', true, false, false),
	(28, 2, 'communications', true, false, false),
	(29, 2, 'pf', true, false, false),
	(30, 2, 'users', false, false, false),
	(31, 2, 'products', true, true, false),
	(32, 2, 'suppliers', true, true, false),
	(33, 2, 'purchase_invoice', true, true, false),
	(34, 2, 'purchase_return', true, true, false),
	(35, 2, 'sales', true, true, false),
	(36, 2, 'inventory', true, false, false),
	(37, 3, 'attendance', true, true, false),
	(38, 3, 'leaves', true, true, false),
	(39, 3, 'ess', true, true, false),
	(40, 3, 'reports', false, false, false),
	(41, 3, 'mss', false, false, false),
	(42, 3, 'workplace', true, false, false),
	(43, 3, 'timesheets', true, true, false),
	(44, 3, 'digital_files', true, false, false),
	(45, 3, 'compensation', false, false, false),
	(46, 3, 'communications', true, false, false),
	(47, 3, 'pf', true, false, false),
	(48, 3, 'users', false, false, false),
	(49, 3, 'products', false, false, false),
	(50, 3, 'suppliers', false, false, false),
	(51, 3, 'purchase_invoice', false, false, false),
	(52, 3, 'purchase_return', false, false, false),
	(53, 3, 'sales', false, false, false),
	(54, 3, 'inventory', false, false, false);

INSERT INTO public.report_settings VALUES
	(1, 1, NULL, 10, 'relevant', 'relevant', 'relevant', NULL, NULL, NULL, NULL, 'indirect', NULL, '2026-10-29 08:52:22.902313'),
	(2, 2, NULL, 10, 'relevant', 'relevant', 'relevant', NULL, NULL, NULL, NULL, 'indirect', NULL, '2026-10-29 08:52:25.209475'),
	(3, 3, NULL, 10, 'relevant', 'relevant', 'relevant', NULL, NULL, NULL, NULL, 'indirect', NULL, '2026-10-29 08:52:26.208952'),
	(4, 4, NULL, 10, 'relevant', 'relevant', 'relevant', NULL, NULL, NULL, NULL, 'indirect', NULL, '2026-10-29 08:52:27.243307');

INSERT INTO public.roles VALUES
	(1, 'admin', 'Admin role'),
	(2, 'manager', 'Manager role'),
	(3, 'employee', 'Employee role');

INSERT INTO public.stock_layers VALUES
	(1, 1, 1, 1, 28000.0000, 50.0000, 50.0000, 1400000.0000, 'weighted_average', false, '2026-10-29 08:52:23.176978', 'Opening balance (pre-costing-engine stock)'),
	(2, 1, 2, 2, 37000.0000, 30.0000, 30.0000, 1110000.0000, 'weighted_average', false, '2026-10-29 08:52:23.223083', 'Opening balance (pre-costing-engine stock)'),
	(3, 1, 3, 3, 18500.0000, 40.0000, 40.0000, 740000.0000, 'weighted_average', false, '2026-10-29 08:52:23.263683', 'Opening balance (pre-costing-engine stock)'),
	(4, 1, 4, 4, 72000.0000, 15.0000, 15.0000, 1080000.0000, 'weighted_average', false, '2026-10-29 08:52:23.305522', 'Opening balance (pre-costing-engine stock)'),
	(5, 1, 5, 5, 125000.0000, 10.0000, 10.0000, 1250000.0000, 'weighted_average', false, '2026-10-29 08:52:23.349856', 'Opening balance (pre-costing-engine stock)'),
	(6, 1, 6, 6, 46000.0000, 20.0000, 20.0000, 920000.0000, 'weighted_average', false, '2026-10-29 08:52:23.390721', 'Opening balance (pre-costing-engine stock)'),
	(7, 1, 7, 7, 155000.0000, 25.0000, 25.0000, 3875000.0000, 'weighted_average', false, '2026-10-29 08:52:23.432049', 'Opening balance (pre-costing-engine stock)'),
	(8, 1, 8, 8, 280000.0000, 15.0000, 15.0000, 4200000.0000, 'weighted_average', false, '2026-10-29 08:52:23.473085', 'Opening balance (pre-costing-engine stock)'),
	(9, 1, 9, 9, 38000.0000, 30.0000, 30.0000, 1140000.0000, 'weighted_average', false, '2026-10-29 08:52:23.514727', 'Opening balance (pre-costing-engine stock)'),
	(10, 1, 10, 10, 120.0000, 500.0000, 500.0000, 60000.0000, 'weighted_average', false, '2026-10-29 08:52:23.555512', 'Opening balance (pre-costing-engine stock)'),
	(11, 1, 11, 11, 80.0000, 1000.0000, 1000.0000, 80000.0000, 'weighted_average', false, '2026-10-29 08:52:23.594755', 'Opening balance (pre-costing-engine stock)'),
	(12, 1, 12, 12, 250.0000, 200.0000, 200.0000, 50000.0000, 'weighted_average', false, '2026-10-29 08:52:23.631528', 'Opening balance (pre-costing-engine stock)'),
	(13, 1, 13, 13, 6500.0000, 20.0000, 20.0000, 130000.0000, 'weighted_average', false, '2026-10-29 08:52:23.670169', 'Opening balance (pre-costing-engine stock)'),
	(14, 1, 14, 14, 1600.0000, 50.0000, 50.0000, 80000.0000, 'weighted_average', false, '2026-10-29 08:52:23.710133', 'Opening balance (pre-costing-engine stock)'),
	(15, 1, 15, 15, 3200.0000, 30.0000, 30.0000, 96000.0000, 'weighted_average', false, '2026-10-29 08:52:23.748653', 'Opening balance (pre-costing-engine stock)'),
	(16, 1, 16, 16, 2000.0000, 40.0000, 40.0000, 80000.0000, 'weighted_average', false, '2026-10-29 08:52:23.787879', 'Opening balance (pre-costing-engine stock)'),
	(17, 1, 17, 17, 220.0000, 100.0000, 100.0000, 22000.0000, 'weighted_average', false, '2026-10-29 08:52:23.827305', 'Opening balance (pre-costing-engine stock)'),
	(18, 1, 18, 18, 4200.0000, 10.0000, 10.0000, 42000.0000, 'weighted_average', false, '2026-10-29 08:52:23.870001', 'Opening balance (pre-costing-engine stock)'),
	(19, 1, 19, 19, 2500.0000, 15.0000, 15.0000, 37500.0000, 'weighted_average', false, '2026-10-29 08:52:23.910724', 'Opening balance (pre-costing-engine stock)'),
	(20, 1, 20, 20, 500.0000, 50.0000, 50.0000, 25000.0000, 'weighted_average', false, '2026-10-29 08:52:23.950955', 'Opening balance (pre-costing-engine stock)'),
	(21, 1, 21, 21, 800.0000, 40.0000, 40.0000, 32000.0000, 'weighted_average', false, '2026-10-29 08:52:23.992674', 'Opening balance (pre-costing-engine stock)'),
	(22, 1, 22, 22, 3200.0000, 15.0000, 15.0000, 48000.0000, 'weighted_average', false, '2026-10-29 08:52:24.033855', 'Opening balance (pre-costing-engine stock)');

INSERT INTO public.stock_ledger VALUES
	(1, 1, 1, 'OPENING', 1, 'OPEN-00001', 'IN', 50.0000, 28000.0000, 1400000.0000, 50.0000, 1400000.0000, 28000.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.167379', 1, 'Opening balance (pre-costing-engine stock)'),
	(2, 1, 2, 'OPENING', 2, 'OPEN-00002', 'IN', 30.0000, 37000.0000, 1110000.0000, 30.0000, 1110000.0000, 37000.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.216963', 1, 'Opening balance (pre-costing-engine stock)'),
	(3, 1, 3, 'OPENING', 3, 'OPEN-00003', 'IN', 40.0000, 18500.0000, 740000.0000, 40.0000, 740000.0000, 18500.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.256689', 1, 'Opening balance (pre-costing-engine stock)'),
	(4, 1, 4, 'OPENING', 4, 'OPEN-00004', 'IN', 15.0000, 72000.0000, 1080000.0000, 15.0000, 1080000.0000, 72000.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.299037', 1, 'Opening balance (pre-costing-engine stock)'),
	(5, 1, 5, 'OPENING', 5, 'OPEN-00005', 'IN', 10.0000, 125000.0000, 1250000.0000, 10.0000, 1250000.0000, 125000.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.343465', 1, 'Opening balance (pre-costing-engine stock)'),
	(6, 1, 6, 'OPENING', 6, 'OPEN-00006', 'IN', 20.0000, 46000.0000, 920000.0000, 20.0000, 920000.0000, 46000.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.384798', 1, 'Opening balance (pre-costing-engine stock)'),
	(7, 1, 7, 'OPENING', 7, 'OPEN-00007', 'IN', 25.0000, 155000.0000, 3875000.0000, 25.0000, 3875000.0000, 155000.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.425842', 1, 'Opening balance (pre-costing-engine stock)'),
	(8, 1, 8, 'OPENING', 8, 'OPEN-00008', 'IN', 15.0000, 280000.0000, 4200000.0000, 15.0000, 4200000.0000, 280000.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.467041', 1, 'Opening balance (pre-costing-engine stock)'),
	(9, 1, 9, 'OPENING', 9, 'OPEN-00009', 'IN', 30.0000, 38000.0000, 1140000.0000, 30.0000, 1140000.0000, 38000.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.508817', 1, 'Opening balance (pre-costing-engine stock)'),
	(10, 1, 10, 'OPENING', 10, 'OPEN-00010', 'IN', 500.0000, 120.0000, 60000.0000, 500.0000, 60000.0000, 120.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.549694', 1, 'Opening balance (pre-costing-engine stock)'),
	(11, 1, 11, 'OPENING', 11, 'OPEN-00011', 'IN', 1000.0000, 80.0000, 80000.0000, 1000.0000, 80000.0000, 80.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.588978', 1, 'Opening balance (pre-costing-engine stock)'),
	(12, 1, 12, 'OPENING', 12, 'OPEN-00012', 'IN', 200.0000, 250.0000, 50000.0000, 200.0000, 50000.0000, 250.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.626083', 1, 'Opening balance (pre-costing-engine stock)'),
	(13, 1, 13, 'OPENING', 13, 'OPEN-00013', 'IN', 20.0000, 6500.0000, 130000.0000, 20.0000, 130000.0000, 6500.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.664451', 1, 'Opening balance (pre-costing-engine stock)'),
	(14, 1, 14, 'OPENING', 14, 'OPEN-00014', 'IN', 50.0000, 1600.0000, 80000.0000, 50.0000, 80000.0000, 1600.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.70494', 1, 'Opening balance (pre-costing-engine stock)'),
	(15, 1, 15, 'OPENING', 15, 'OPEN-00015', 'IN', 30.0000, 3200.0000, 96000.0000, 30.0000, 96000.0000, 3200.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.742948', 1, 'Opening balance (pre-costing-engine stock)'),
	(16, 1, 16, 'OPENING', 16, 'OPEN-00016', 'IN', 40.0000, 2000.0000, 80000.0000, 40.0000, 80000.0000, 2000.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.78211', 1, 'Opening balance (pre-costing-engine stock)'),
	(17, 1, 17, 'OPENING', 17, 'OPEN-00017', 'IN', 100.0000, 220.0000, 22000.0000, 100.0000, 22000.0000, 220.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.821599', 1, 'Opening balance (pre-costing-engine stock)'),
	(18, 1, 18, 'OPENING', 18, 'OPEN-00018', 'IN', 10.0000, 4200.0000, 42000.0000, 10.0000, 42000.0000, 4200.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.864263', 1, 'Opening balance (pre-costing-engine stock)'),
	(19, 1, 19, 'OPENING', 19, 'OPEN-00019', 'IN', 15.0000, 2500.0000, 37500.0000, 15.0000, 37500.0000, 2500.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.904833', 1, 'Opening balance (pre-costing-engine stock)'),
	(20, 1, 20, 'OPENING', 20, 'OPEN-00020', 'IN', 50.0000, 500.0000, 25000.0000, 50.0000, 25000.0000, 500.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.944623', 1, 'Opening balance (pre-costing-engine stock)'),
	(21, 1, 21, 'OPENING', 21, 'OPEN-00021', 'IN', 40.0000, 800.0000, 32000.0000, 40.0000, 32000.0000, 800.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:23.986736', 1, 'Opening balance (pre-costing-engine stock)'),
	(22, 1, 22, 'OPENING', 22, 'OPEN-00022', 'IN', 15.0000, 3200.0000, 48000.0000, 15.0000, 48000.0000, 3200.0000, 'weighted_average', '2026-10-29', '2026-10-29 08:52:24.028257', 1, 'Opening balance (pre-costing-engine stock)');

INSERT INTO public.user_permissions VALUES
	(1, 2, 9, 'employees', false, false, false, false, false),
	(2, 2, 9, 'attendance', false, false, false, false, false),
	(3, 2, 9, 'leaves', false, false, false, false, false),
	(4, 2, 9, 'payroll', false, false, false, false, false),
	(5, 2, 9, 'loans', false, false, false, false, false),
	(6, 2, 9, 'pf', false, false, false, false, false),
	(7, 2, 9, 'products', false, false, false, false, false),
	(8, 2, 9, 'categories', false, false, false, false, false),
	(9, 2, 9, 'stock', false, false, false, false, false),
	(10, 2, 9, 'consumption_vouchers', false, false, false, false, false),
	(11, 2, 9, 'scrap_vouchers', false, false, false, false, false),
	(12, 2, 9, 'adjustment_vouchers', false, false, false, false, false),
	(13, 2, 9, 'stock_take_vouchers', false, false, false, false, false),
	(14, 2, 9, 'inventory_reports', false, false, false, false, false),
	(15, 2, 9, 'suppliers', false, false, false, false, false),
	(16, 2, 9, 'customers', false, false, false, false, false),
	(17, 2, 9, 'purchase_orders', false, false, false, false, false),
	(18, 2, 9, 'sales_orders', false, false, false, false, false),
	(19, 2, 9, 'purchase_invoices', false, false, false, false, false),
	(20, 2, 9, 'purchase_returns', false, false, false, false, false),
	(21, 2, 9, 'sales_invoices', false, false, false, false, false),
	(22, 2, 9, 'sales_returns', false, false, false, false, false),
	(23, 2, 9, 'payment_tracking', false, false, false, false, false),
	(24, 2, 9, 'financial_reports', false, false, false, false, false),
	(25, 2, 9, 'cash_payment_vouchers', false, false, false, false, false),
	(26, 2, 9, 'cash_receipt_vouchers', false, false, false, false, false),
	(27, 2, 9, 'bank_payment_vouchers', false, false, false, false, false),
	(28, 2, 9, 'bank_receipt_vouchers', false, false, false, false, false),
	(29, 2, 9, 'journal_vouchers', true, false, false, false, false),
	(30, 2, 9, 'chart_of_accounts', true, false, false, false, false),
	(31, 2, 9, 'bank_reconciliation', false, false, false, false, false),
	(32, 2, 9, 'fbr_dashboard', false, false, false, false, false),
	(33, 2, 9, 'fbr_settings', false, false, false, false, false),
	(34, 2, 9, 'fixed_assets_dashboard', false, false, false, false, false),
	(35, 2, 9, 'fixed_assets_assets', false, false, false, false, false),
	(36, 2, 9, 'fixed_assets_categories', false, false, false, false, false),
	(37, 2, 9, 'fixed_assets_reports', false, false, false, false, false),
	(38, 2, 9, 'executive_reports', false, false, false, false, false);

INSERT INTO public.users VALUES
	(2, 'ADM001', 'admin@solarkon.com', 'admin@solarkon.com', 'scrypt:32768:8:1$v47L1PfAuz8VYMdO$711c97f0911ce41e1f0ffb927c11e7ec7fb714a82277703c479effde021732a48559c93e748b706cbe9f28ddeae7736522ed3d0830ec1b73561c176e85c50ba8', 'System Admin', 3, NULL, 'Employee', NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, false, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 08:52:22.412657', '2026-10-29 08:52:23.106995'),
	(3, 'MGR002', 'manager@solarkon.com', 'manager@solarkon.com', 'scrypt:32768:8:1$Jjtb9hf1CNwwG29H$4a9bd2aebe7544a4500da299b1134768bcfc1f391ee62983c8be98740f3f01e694a2919e260759049dbda8a52ee587746b9b971f2e9cf74c719216dd24c1eb7f', 'Manager User', 2, NULL, 'Manager', NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, true, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 08:52:22.494348', '2026-10-29 08:52:23.116124'),
	(4, 'EMP001', 'emp@solarkon.com', 'emp@solarkon.com', 'scrypt:32768:8:1$k1NCQXFEhQTKCN5L$ff2b720b614e50a31716a429c1655d1116e9238bd55c4b68d450e949e7a3922cb719ec07790d8490a8b63c9a5e9fdba90fbfe36983177ac74900e7187c3581a5', 'Employee User', 3, NULL, 'Employee', NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, false, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 08:52:22.590932', '2026-10-29 08:52:23.124307'),
	(1, 'SYSADMIN', 'admin@gmail.com', 'admin@gmail.com', 'scrypt:32768:8:1$7vuSPhDTV7SOD0B4$4c1a6ee45f85d3ab1ec6843237f62dc72034ec3289ba7978a7ec606b4667f02c1ded735884ad7a4cdd26738135f7bb7d126b316835e5ef02b06f59c79eb107d9', 'Administrator', 1, NULL, 'System Administrator', NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, true, false, false, false, false, false, false, true, NULL, NULL, '2026-10-29 08:52:22.340746', '2026-10-29 08:52:24.16423'),
	(6, 'SA0006', 'owner.one@ref.test', 'owner.one@ref.test', 'scrypt:32768:8:1$XTGeHnYc90FkcWFK$7f72d01c1e507035801c744080d206de4070e880089ca6691d679e60be8b71fb7134550c11844bd6f5bb57e1973cf574b88d1a4d75baf4c9617ea416632976b3', 'Owner console-one', 1, NULL, NULL, NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, true, true, true, true, true, true, true, false, NULL, NULL, '2026-10-29 08:52:24.373795', '2026-10-29 08:52:24.373798'),
	(7, 'SA0007', 'owner.two@ref.test', 'owner.two@ref.test', 'scrypt:32768:8:1$z7dKBRLa8VLPK9l4$a36f0318ec277d228dfc7bc3ee166962e1ddd0dc990c04540ce8289ec090587146df186d25e6fb52fae02874ba6153e5144fae903d7a898db63edb9c3c97e035', 'Owner console-two', 1, NULL, NULL, NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, true, true, true, true, true, true, true, false, NULL, NULL, '2026-10-29 08:52:25.333239', '2026-10-29 08:52:25.333243'),
	(8, 'SA0008', 'owner.three@ref.test', 'owner.three@ref.test', 'scrypt:32768:8:1$pALh71R4HF8uIjQn$75d2c2c35cdeb133b54642d15fe1a762e43f315014539e1464437015c8d52a0f9fdfe4d02160a7275051f65c1e6035996301ca0c4ac78f198a8054a7e8cda31f', 'Owner console-three', 1, NULL, NULL, NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, true, true, true, true, true, true, true, false, NULL, NULL, '2026-10-29 08:52:26.330258', '2026-10-29 08:52:26.330261'),
	(10, 'SA0010', 'second.admin@ref.test', 'second.admin@ref.test', 'scrypt:32768:8:1$QK45dSOBczzfNYpw$83dae23779500a4768e7466347221dbf42d9f498e3af0804d68ce7a3183d3b3c0a14be0e9e341539925c1a461e77b649c8689e75cc718d09c0e374bc2db1191a', 'Second Admin', 3, NULL, NULL, NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, false, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 08:52:27.503208', '2026-10-29 08:52:27.503211'),
	(11, 'SA0011', 'invitee.mixed@ref.test', 'invitee.mixed@ref.test', 'scrypt:32768:8:1$X6qupto9NWCnNUUt$ff7e38c3be2c418333ba78add2006c28c7de147d4cf1c304adef5ee60712d1802ee5dbe21077966521a2e13339413df9ced79923cf2b28e5a910ba53853ecde4', 'Invitee Mixed', 3, NULL, NULL, NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, false, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 08:52:27.608622', '2026-10-29 08:52:27.608625'),
	(9, 'SA0009', 'Mixed.Case@Ref.Test', 'mixed.case@ref.test', 'scrypt:32768:8:1$yD1IZ2fceYjZ3zc5$26bdc3095fbf8d81cb23cacf9ccb549c19d259239bf10ccd3654694db10ba179c114bf5a02a92fa824b37e3b5ea53b71aa3f4fa6da2f474d734318b46806a65a', 'Mixed Case', 3, NULL, NULL, NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, false, false, false, false, false, false, false, false, NULL, NULL, '2026-10-29 08:52:27.393153', '2026-10-29 08:52:27.393156'),
	(5, 'EMP002', 'john.doe@solarkon.com', 'john.doe@solarkon.com', 'scrypt:32768:8:1$xRPcArJ84myfTWHD$233279d6acef22f17e6db1a5790d456671490fb440fa11acc10d013543e9597552e8cfed8dea0595dd8b52a956089a0e79b8bd81fac644eea5568d402a32564c', 'John Doe', 3, NULL, 'Employee', NULL, NULL, '2026-10-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, true, false, false, false, false, NULL, false, false, false, NULL, NULL, '2026-10-29 08:52:22.685798', '2026-10-29 08:52:23.132576');

INSERT INTO public.voucher_numbers VALUES
	(1, 1, 'PI', 1),
	(2, 1, 'PR', 1),
	(3, 1, 'CONS', 1),
	(4, 1, 'SCRAP', 1),
	(5, 1, 'ADJ', 1),
	(6, 1, 'ST', 1),
	(7, 1, 'CPV', 1),
	(8, 1, 'CRV', 1),
	(9, 1, 'BPV', 1),
	(10, 1, 'BRV', 1),
	(11, 1, 'JV', 1),
	(12, 1, 'PRL', 1),
	(13, 1, 'FA-TRF', 1),
	(14, 1, 'INV-FA', 1),
	(15, 2, 'PI', 1),
	(16, 2, 'PR', 1),
	(17, 2, 'CONS', 1),
	(18, 2, 'SCRAP', 1),
	(19, 2, 'ADJ', 1),
	(20, 2, 'ST', 1),
	(21, 2, 'CPV', 1),
	(22, 2, 'CRV', 1),
	(23, 2, 'BPV', 1),
	(24, 2, 'BRV', 1),
	(25, 2, 'JV', 1),
	(26, 2, 'PRL', 1),
	(27, 2, 'FA-TRF', 1),
	(28, 2, 'INV-FA', 1),
	(29, 3, 'PI', 1),
	(30, 3, 'PR', 1),
	(31, 3, 'CONS', 1),
	(32, 3, 'SCRAP', 1),
	(33, 3, 'ADJ', 1),
	(34, 3, 'ST', 1),
	(35, 3, 'CPV', 1),
	(36, 3, 'CRV', 1),
	(37, 3, 'BPV', 1),
	(38, 3, 'BRV', 1),
	(39, 3, 'JV', 1),
	(40, 3, 'PRL', 1),
	(41, 3, 'FA-TRF', 1),
	(42, 3, 'INV-FA', 1),
	(43, 4, 'PI', 1),
	(44, 4, 'PR', 1),
	(45, 4, 'CONS', 1),
	(46, 4, 'SCRAP', 1),
	(47, 4, 'ADJ', 1),
	(48, 4, 'ST', 1),
	(49, 4, 'CPV', 1),
	(50, 4, 'CRV', 1),
	(51, 4, 'BPV', 1),
	(52, 4, 'BRV', 1),
	(53, 4, 'JV', 1),
	(54, 4, 'PRL', 1),
	(55, 4, 'FA-TRF', 1),
	(56, 4, 'INV-FA', 1);

SELECT pg_catalog.setval('public.accounting_periods_id_seq', 32, true);

SELECT pg_catalog.setval('public.accounting_voucher_lines_id_seq', 1, false);

SELECT pg_catalog.setval('public.accounting_vouchers_id_seq', 1, false);

SELECT pg_catalog.setval('public.additional_charges_id_seq', 1, false);

SELECT pg_catalog.setval('public.announcements_id_seq', 1, false);

SELECT pg_catalog.setval('public.approval_workflows_id_seq', 1, false);

SELECT pg_catalog.setval('public.asset_depreciation_id_seq', 1, false);

SELECT pg_catalog.setval('public.asset_transfers_id_seq', 1, false);

SELECT pg_catalog.setval('public.attendance_corrections_id_seq', 1, false);

SELECT pg_catalog.setval('public.attendance_id_seq', 1, false);

SELECT pg_catalog.setval('public.attendance_logs_id_seq', 1, false);

SELECT pg_catalog.setval('public.audit_logs_id_seq', 811, true);

SELECT pg_catalog.setval('public.bank_rec_items_id_seq', 1, false);

SELECT pg_catalog.setval('public.bank_reconciliations_id_seq', 1, false);

SELECT pg_catalog.setval('public.break_logs_id_seq', 1, false);

SELECT pg_catalog.setval('public.button_permissions_id_seq', 1, false);

SELECT pg_catalog.setval('public.category_revenue_accounts_id_seq', 1, false);

SELECT pg_catalog.setval('public.change_requests_id_seq', 1, false);

SELECT pg_catalog.setval('public.charge_ledger_defaults_id_seq', 1, false);

SELECT pg_catalog.setval('public.chart_of_accounts_id_seq', 681, true);

SELECT pg_catalog.setval('public.companies_id_seq', 4, true);

SELECT pg_catalog.setval('public.company_holidays_id_seq', 1, false);

SELECT pg_catalog.setval('public.company_info_id_seq', 4, true);

SELECT pg_catalog.setval('public.company_invitations_id_seq', 3, true);

SELECT pg_catalog.setval('public.company_memberships_id_seq', 9, true);

SELECT pg_catalog.setval('public.consumption_items_id_seq', 1, false);

SELECT pg_catalog.setval('public.consumption_vouchers_id_seq', 1, false);

SELECT pg_catalog.setval('public.digital_files_id_seq', 1, false);

SELECT pg_catalog.setval('public.email_logs_id_seq', 1, false);

SELECT pg_catalog.setval('public.exec_account_selections_id_seq', 1, false);

SELECT pg_catalog.setval('public.fa_categories_id_seq', 24, true);

SELECT pg_catalog.setval('public.fbr_config_id_seq', 1, false);

SELECT pg_catalog.setval('public.fbr_invoice_records_id_seq', 1, false);

SELECT pg_catalog.setval('public.file_categories_id_seq', 1, false);

SELECT pg_catalog.setval('public.fiscal_year_rule_id_seq', 4, true);

SELECT pg_catalog.setval('public.fixed_assets_id_seq', 1, false);

SELECT pg_catalog.setval('public.gl_daily_balances_id_seq', 44, true);

SELECT pg_catalog.setval('public.global_limits_id_seq', 1, true);

SELECT pg_catalog.setval('public.income_tax_slabs_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_categories_id_seq', 8, true);

SELECT pg_catalog.setval('public.inv_customers_id_seq', 4, true);

SELECT pg_catalog.setval('public.inv_invoice_items_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_invoices_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_products_id_seq', 22, true);

SELECT pg_catalog.setval('public.inv_purchase_invoice_items_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_purchase_invoices_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_purchase_order_items_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_purchase_orders_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_purchase_return_items_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_purchase_returns_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_sales_order_items_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_sales_orders_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_sales_return_items_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_sales_returns_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_stock_movements_id_seq', 1, false);

SELECT pg_catalog.setval('public.inv_suppliers_id_seq', 6, true);

SELECT pg_catalog.setval('public.inv_units_id_seq', 14, true);

SELECT pg_catalog.setval('public.inventory_settings_id_seq', 4, true);

SELECT pg_catalog.setval('public.invoice_settings_id_seq', 1, false);

SELECT pg_catalog.setval('public.invoice_templates_id_seq', 16, true);

SELECT pg_catalog.setval('public.journal_entries_id_seq', 22, true);

SELECT pg_catalog.setval('public.journal_lines_id_seq', 44, true);

SELECT pg_catalog.setval('public.kanban_boards_id_seq', 1, false);

SELECT pg_catalog.setval('public.kanban_tasks_id_seq', 1, false);

SELECT pg_catalog.setval('public.layer_consumptions_id_seq', 1, false);

SELECT pg_catalog.setval('public.leave_approvals_id_seq', 1, false);

SELECT pg_catalog.setval('public.leave_quotas_id_seq', 1, false);

SELECT pg_catalog.setval('public.leave_requests_id_seq', 1, false);

SELECT pg_catalog.setval('public.leave_types_id_seq', 1, false);

SELECT pg_catalog.setval('public.loan_advance_requests_id_seq', 1, false);

SELECT pg_catalog.setval('public.loan_repayments_id_seq', 1, false);

SELECT pg_catalog.setval('public.notification_recipients_id_seq', 1, false);

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);

SELECT pg_catalog.setval('public.overtime_accounts_id_seq', 1, false);

SELECT pg_catalog.setval('public.payment_allocations_id_seq', 1, false);

SELECT pg_catalog.setval('public.payroll_audit_logs_id_seq', 1, false);

SELECT pg_catalog.setval('public.payroll_components_id_seq', 1, false);

SELECT pg_catalog.setval('public.payroll_profiles_id_seq', 1, false);

SELECT pg_catalog.setval('public.payroll_runs_id_seq', 1, false);

SELECT pg_catalog.setval('public.payroll_settings_id_seq', 1, false);

SELECT pg_catalog.setval('public.payroll_slips_id_seq', 1, false);

SELECT pg_catalog.setval('public.performance_goals_id_seq', 1, false);

SELECT pg_catalog.setval('public.performance_reviews_id_seq', 1, false);

SELECT pg_catalog.setval('public.permissions_id_seq', 54, true);

SELECT pg_catalog.setval('public.pf_config_id_seq', 1, false);

SELECT pg_catalog.setval('public.pf_contributions_id_seq', 1, false);

SELECT pg_catalog.setval('public.pf_ledger_id_seq', 1, false);

SELECT pg_catalog.setval('public.pf_loan_requests_id_seq', 1, false);

SELECT pg_catalog.setval('public.pf_profit_distributions_id_seq', 1, false);

SELECT pg_catalog.setval('public.pf_settlements_id_seq', 1, false);

SELECT pg_catalog.setval('public.pf_withdrawal_requests_id_seq', 1, false);

SELECT pg_catalog.setval('public.project_labels_id_seq', 1, false);

SELECT pg_catalog.setval('public.project_tasks_id_seq', 1, false);

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);

SELECT pg_catalog.setval('public.registration_requests_id_seq', 1, false);

SELECT pg_catalog.setval('public.report_settings_id_seq', 4, true);

SELECT pg_catalog.setval('public.roles_id_seq', 3, true);

SELECT pg_catalog.setval('public.salary_revisions_id_seq', 1, false);

SELECT pg_catalog.setval('public.scrap_items_id_seq', 1, false);

SELECT pg_catalog.setval('public.scrap_vouchers_id_seq', 1, false);

SELECT pg_catalog.setval('public.stock_adjustment_items_id_seq', 1, false);

SELECT pg_catalog.setval('public.stock_adjustment_vouchers_id_seq', 1, false);

SELECT pg_catalog.setval('public.stock_cost_adjustments_id_seq', 1, false);

SELECT pg_catalog.setval('public.stock_layers_id_seq', 22, true);

SELECT pg_catalog.setval('public.stock_ledger_id_seq', 22, true);

SELECT pg_catalog.setval('public.stock_take_items_id_seq', 1, false);

SELECT pg_catalog.setval('public.stock_takes_id_seq', 1, false);

SELECT pg_catalog.setval('public.stored_files_id_seq', 1, false);

SELECT pg_catalog.setval('public.tax_rate_accounts_id_seq', 1, false);

SELECT pg_catalog.setval('public.team_events_id_seq', 1, false);

SELECT pg_catalog.setval('public.time_policies_id_seq', 1, false);

SELECT pg_catalog.setval('public.timesheet_approvals_id_seq', 1, false);

SELECT pg_catalog.setval('public.timesheet_entries_id_seq', 1, false);

SELECT pg_catalog.setval('public.timesheet_merged_reports_id_seq', 1, false);

SELECT pg_catalog.setval('public.timesheet_weeks_id_seq', 1, false);

SELECT pg_catalog.setval('public.twcf_lines_id_seq', 1, false);

SELECT pg_catalog.setval('public.user_permissions_id_seq', 38, true);

SELECT pg_catalog.setval('public.users_id_seq', 11, true);

SELECT pg_catalog.setval('public.voucher_numbers_id_seq', 56, true);

SELECT pg_catalog.setval('public.work_packages_id_seq', 1, false);

ALTER TABLE ONLY public.accounting_periods
    ADD CONSTRAINT accounting_periods_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.accounting_voucher_lines
    ADD CONSTRAINT accounting_voucher_lines_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT accounting_vouchers_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.additional_charges
    ADD CONSTRAINT additional_charges_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.asset_depreciation
    ADD CONSTRAINT asset_depreciation_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.asset_transfers
    ADD CONSTRAINT asset_transfers_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.attendance_corrections
    ADD CONSTRAINT attendance_corrections_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.attendance_logs
    ADD CONSTRAINT attendance_logs_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.bank_rec_items
    ADD CONSTRAINT bank_rec_items_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.break_logs
    ADD CONSTRAINT break_logs_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.button_permissions
    ADD CONSTRAINT button_permissions_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.category_revenue_accounts
    ADD CONSTRAINT category_revenue_accounts_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.change_requests
    ADD CONSTRAINT change_requests_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.charge_ledger_defaults
    ADD CONSTRAINT charge_ledger_defaults_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_slug_key UNIQUE (slug);

ALTER TABLE ONLY public.company_holidays
    ADD CONSTRAINT company_holidays_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.company_info
    ADD CONSTRAINT company_info_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.company_invitations
    ADD CONSTRAINT company_invitations_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT company_memberships_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.consumption_items
    ADD CONSTRAINT consumption_items_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT consumption_vouchers_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.digital_files
    ADD CONSTRAINT digital_files_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.exec_account_selections
    ADD CONSTRAINT exec_account_selections_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.fa_categories
    ADD CONSTRAINT fa_categories_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.fbr_config
    ADD CONSTRAINT fbr_config_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.fbr_invoice_records
    ADD CONSTRAINT fbr_invoice_records_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.file_categories
    ADD CONSTRAINT file_categories_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.fiscal_year_rule
    ADD CONSTRAINT fiscal_year_rule_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.gl_daily_balances
    ADD CONSTRAINT gl_daily_balances_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.global_limits
    ADD CONSTRAINT global_limits_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.income_tax_slabs
    ADD CONSTRAINT income_tax_slabs_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_categories
    ADD CONSTRAINT inv_categories_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_customers
    ADD CONSTRAINT inv_customers_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_products
    ADD CONSTRAINT inv_products_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_purchase_order_items
    ADD CONSTRAINT inv_purchase_order_items_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT inv_purchase_orders_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_purchase_return_items
    ADD CONSTRAINT inv_purchase_return_items_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT inv_purchase_returns_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_sales_order_items
    ADD CONSTRAINT inv_sales_order_items_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT inv_sales_orders_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_sales_return_items
    ADD CONSTRAINT inv_sales_return_items_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_stock_movements
    ADD CONSTRAINT inv_stock_movements_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_suppliers
    ADD CONSTRAINT inv_suppliers_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inv_units
    ADD CONSTRAINT inv_units_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.invoice_settings
    ADD CONSTRAINT invoice_settings_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.invoice_templates
    ADD CONSTRAINT invoice_templates_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.kanban_boards
    ADD CONSTRAINT kanban_boards_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.kanban_tasks
    ADD CONSTRAINT kanban_tasks_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.layer_consumptions
    ADD CONSTRAINT layer_consumptions_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.leave_approvals
    ADD CONSTRAINT leave_approvals_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.leave_quotas
    ADD CONSTRAINT leave_quotas_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT leave_types_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.loan_advance_requests
    ADD CONSTRAINT loan_advance_requests_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.loan_repayments
    ADD CONSTRAINT loan_repayments_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.notification_recipients
    ADD CONSTRAINT notification_recipients_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.overtime_accounts
    ADD CONSTRAINT overtime_accounts_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.payroll_audit_logs
    ADD CONSTRAINT payroll_audit_logs_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.payroll_components
    ADD CONSTRAINT payroll_components_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.payroll_profiles
    ADD CONSTRAINT payroll_profiles_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.payroll_settings
    ADD CONSTRAINT payroll_settings_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.payroll_slips
    ADD CONSTRAINT payroll_slips_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.performance_goals
    ADD CONSTRAINT performance_goals_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.pf_config
    ADD CONSTRAINT pf_config_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.pf_contributions
    ADD CONSTRAINT pf_contributions_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.pf_ledger
    ADD CONSTRAINT pf_ledger_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.pf_loan_requests
    ADD CONSTRAINT pf_loan_requests_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.pf_profit_distributions
    ADD CONSTRAINT pf_profit_distributions_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.pf_settlements
    ADD CONSTRAINT pf_settlements_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.pf_withdrawal_requests
    ADD CONSTRAINT pf_withdrawal_requests_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.project_labels
    ADD CONSTRAINT project_labels_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.report_settings
    ADD CONSTRAINT report_settings_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.salary_revisions
    ADD CONSTRAINT salary_revisions_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.scrap_items
    ADD CONSTRAINT scrap_items_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT scrap_vouchers_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.stock_adjustment_items
    ADD CONSTRAINT stock_adjustment_items_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.stock_adjustment_vouchers
    ADD CONSTRAINT stock_adjustment_vouchers_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.stock_cost_adjustments
    ADD CONSTRAINT stock_cost_adjustments_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.stock_layers
    ADD CONSTRAINT stock_layers_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.stored_files
    ADD CONSTRAINT stored_files_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.tax_rate_accounts
    ADD CONSTRAINT tax_rate_accounts_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.team_events
    ADD CONSTRAINT team_events_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.time_policies
    ADD CONSTRAINT time_policies_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.timesheet_approvals
    ADD CONSTRAINT timesheet_approvals_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.timesheet_entries
    ADD CONSTRAINT timesheet_entries_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.timesheet_merged_reports
    ADD CONSTRAINT timesheet_merged_reports_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.timesheet_weeks
    ADD CONSTRAINT timesheet_weeks_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.twcf_lines
    ADD CONSTRAINT twcf_lines_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT uq_accounting_vouchers_voucher_number UNIQUE (company_id, voucher_number);

ALTER TABLE ONLY public.asset_transfers
    ADD CONSTRAINT uq_asset_transfers_voucher_number UNIQUE (company_id, voucher_number);

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT uq_attendance_company_date UNIQUE (company_id, user_id, date);

ALTER TABLE ONLY public.bank_rec_items
    ADD CONSTRAINT uq_bank_rec_item UNIQUE (reconciliation_id, journal_line_id);

ALTER TABLE ONLY public.button_permissions
    ADD CONSTRAINT uq_button_perm_company UNIQUE (company_id, role_id, button_code);

ALTER TABLE ONLY public.category_revenue_accounts
    ADD CONSTRAINT uq_category_revenue_accounts_category_id UNIQUE (company_id, category_id);

ALTER TABLE ONLY public.charge_ledger_defaults
    ADD CONSTRAINT uq_charge_ledger_defaults_account_id UNIQUE (company_id, account_id);

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT uq_chart_of_accounts_code UNIQUE (company_id, code);

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT uq_consumption_vouchers_voucher_number UNIQUE (company_id, voucher_number);

ALTER TABLE ONLY public.exec_account_selections
    ADD CONSTRAINT uq_exec_selection_company_account UNIQUE (company_id, account_id);

ALTER TABLE ONLY public.fa_categories
    ADD CONSTRAINT uq_fa_categories_name UNIQUE (company_id, name);

ALTER TABLE ONLY public.file_categories
    ADD CONSTRAINT uq_file_categories_name UNIQUE (company_id, name);

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT uq_fixed_assets_asset_code UNIQUE (company_id, asset_code);

ALTER TABLE ONLY public.gl_daily_balances
    ADD CONSTRAINT uq_gl_daily_balances_key UNIQUE (company_id, account_id, label_id, day);

ALTER TABLE ONLY public.company_holidays
    ADD CONSTRAINT uq_holiday_date_dept_company UNIQUE (company_id, holiday_date, department);

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT uq_inv_invoices_invoice_number UNIQUE (company_id, invoice_number);

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT uq_inv_invoices_voucher_number UNIQUE (company_id, voucher_number);

ALTER TABLE ONLY public.inv_products
    ADD CONSTRAINT uq_inv_products_sku UNIQUE (company_id, sku);

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT uq_inv_purchase_invoices_invoice_number UNIQUE (company_id, invoice_number);

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT uq_inv_purchase_invoices_voucher_number UNIQUE (company_id, voucher_number);

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT uq_inv_purchase_orders_po_number UNIQUE (company_id, po_number);

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT uq_inv_purchase_returns_return_number UNIQUE (company_id, return_number);

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT uq_inv_sales_orders_so_number UNIQUE (company_id, so_number);

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT uq_inv_sales_returns_return_number UNIQUE (company_id, return_number);

ALTER TABLE ONLY public.inv_units
    ADD CONSTRAINT uq_inv_units_abbreviation UNIQUE (company_id, abbreviation);

ALTER TABLE ONLY public.inv_units
    ADD CONSTRAINT uq_inv_units_name UNIQUE (company_id, name);

ALTER TABLE ONLY public.leave_quotas
    ADD CONSTRAINT uq_leave_quota_company UNIQUE (company_id, user_id, leave_type_id, year);

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT uq_leave_types_code UNIQUE (company_id, code);

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT uq_leave_types_name UNIQUE (company_id, name);

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT uq_membership_company_emp_code UNIQUE (company_id, employee_code);

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT uq_membership_company_user UNIQUE (company_id, user_id);

ALTER TABLE ONLY public.overtime_accounts
    ADD CONSTRAINT uq_overtime_date_company UNIQUE (company_id, user_id, date);

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT uq_payment_allocations_line_doc UNIQUE (company_id, voucher_line_id, doc_type, doc_id);

ALTER TABLE ONLY public.payroll_profiles
    ADD CONSTRAINT uq_payroll_profiles_user_id UNIQUE (company_id, user_id);

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT uq_payroll_run_company UNIQUE (company_id, month, year);

ALTER TABLE ONLY public.payroll_slips
    ADD CONSTRAINT uq_payroll_slip_company UNIQUE (company_id, payroll_run_id, user_id);

ALTER TABLE ONLY public.pf_contributions
    ADD CONSTRAINT uq_pf_contribution_company UNIQUE (company_id, user_id, month, year);

ALTER TABLE ONLY public.project_labels
    ADD CONSTRAINT uq_project_labels_company_name UNIQUE (company_id, name);

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT uq_projects_code UNIQUE (company_id, code);

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT uq_scrap_vouchers_voucher_number UNIQUE (company_id, voucher_number);

ALTER TABLE ONLY public.stock_adjustment_vouchers
    ADD CONSTRAINT uq_stock_adjustment_vouchers_voucher_number UNIQUE (company_id, voucher_number);

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT uq_stock_takes_reference UNIQUE (company_id, reference);

ALTER TABLE ONLY public.stored_files
    ADD CONSTRAINT uq_stored_files_company_key UNIQUE (company_id, key);

ALTER TABLE ONLY public.tax_rate_accounts
    ADD CONSTRAINT uq_tax_rate_accounts_rate_pct UNIQUE (company_id, rate_pct);

ALTER TABLE ONLY public.timesheet_weeks
    ADD CONSTRAINT uq_ts_week_company UNIQUE (company_id, user_id, week_start);

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT uq_user_perm_company UNIQUE (company_id, user_id, resource);

ALTER TABLE ONLY public.voucher_numbers
    ADD CONSTRAINT uq_voucher_numbers_prefix UNIQUE (company_id, prefix);

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_employee_code_key UNIQUE (employee_code);

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_login_id_key UNIQUE (login_id);

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.voucher_numbers
    ADD CONSTRAINT voucher_numbers_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT work_packages_pkey PRIMARY KEY (id);

CREATE INDEX ix_accounting_periods_company_id ON public.accounting_periods USING btree (company_id);

CREATE INDEX ix_accounting_periods_fiscal_year ON public.accounting_periods USING btree (fiscal_year);

CREATE INDEX ix_accounting_voucher_lines_company_id ON public.accounting_voucher_lines USING btree (company_id);

CREATE INDEX ix_accounting_vouchers_company_id ON public.accounting_vouchers USING btree (company_id);

CREATE INDEX ix_additional_charges_company_id ON public.additional_charges USING btree (company_id);

CREATE INDEX ix_announcements_company_id ON public.announcements USING btree (company_id);

CREATE INDEX ix_approval_workflows_company_id ON public.approval_workflows USING btree (company_id);

CREATE INDEX ix_asset_depreciation_company_id ON public.asset_depreciation USING btree (company_id);

CREATE INDEX ix_asset_transfers_company_id ON public.asset_transfers USING btree (company_id);

CREATE INDEX ix_attendance_company_id ON public.attendance USING btree (company_id);

CREATE INDEX ix_attendance_corrections_company_id ON public.attendance_corrections USING btree (company_id);

CREATE INDEX ix_attendance_logs_company_id ON public.attendance_logs USING btree (company_id);

CREATE INDEX ix_audit_logs_action ON public.audit_logs USING btree (action);

CREATE INDEX ix_audit_logs_company_id ON public.audit_logs USING btree (company_id);

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);

CREATE INDEX ix_audit_logs_entity_id ON public.audit_logs USING btree (entity_id);

CREATE INDEX ix_audit_logs_entity_type ON public.audit_logs USING btree (entity_type);

CREATE INDEX ix_audit_logs_module ON public.audit_logs USING btree (module);

CREATE INDEX ix_audit_logs_reference ON public.audit_logs USING btree (reference);

CREATE INDEX ix_audit_logs_user_id ON public.audit_logs USING btree (user_id);

CREATE INDEX ix_bank_rec_items_company_id ON public.bank_rec_items USING btree (company_id);

CREATE INDEX ix_bank_rec_items_journal_line_id ON public.bank_rec_items USING btree (journal_line_id);

CREATE INDEX ix_bank_rec_items_reconciliation_id ON public.bank_rec_items USING btree (reconciliation_id);

CREATE INDEX ix_bank_reconciliations_company_id ON public.bank_reconciliations USING btree (company_id);

CREATE INDEX ix_break_logs_company_id ON public.break_logs USING btree (company_id);

CREATE INDEX ix_button_permissions_company_id ON public.button_permissions USING btree (company_id);

CREATE INDEX ix_category_revenue_accounts_company_id ON public.category_revenue_accounts USING btree (company_id);

CREATE INDEX ix_change_requests_company_id ON public.change_requests USING btree (company_id);

CREATE INDEX ix_charge_ledger_defaults_company_id ON public.charge_ledger_defaults USING btree (company_id);

CREATE INDEX ix_chart_of_accounts_company_id ON public.chart_of_accounts USING btree (company_id);

CREATE INDEX ix_company_holidays_company_id ON public.company_holidays USING btree (company_id);

CREATE INDEX ix_company_info_company_id ON public.company_info USING btree (company_id);

CREATE INDEX ix_company_invitations_company_id ON public.company_invitations USING btree (company_id);

CREATE INDEX ix_company_memberships_company_id ON public.company_memberships USING btree (company_id);

CREATE INDEX ix_company_memberships_manager_id ON public.company_memberships USING btree (manager_id);

CREATE INDEX ix_company_memberships_user_id ON public.company_memberships USING btree (user_id);

CREATE INDEX ix_consumption_items_company_id ON public.consumption_items USING btree (company_id);

CREATE INDEX ix_consumption_vouchers_company_id ON public.consumption_vouchers USING btree (company_id);

CREATE INDEX ix_digital_files_company_id ON public.digital_files USING btree (company_id);

CREATE INDEX ix_email_logs_company_id ON public.email_logs USING btree (company_id);

CREATE INDEX ix_exec_account_selections_account_id ON public.exec_account_selections USING btree (account_id);

CREATE INDEX ix_exec_account_selections_company_id ON public.exec_account_selections USING btree (company_id);

CREATE INDEX ix_fa_categories_company_id ON public.fa_categories USING btree (company_id);

CREATE INDEX ix_fbr_config_company_id ON public.fbr_config USING btree (company_id);

CREATE INDEX ix_fbr_invoice_records_company_id ON public.fbr_invoice_records USING btree (company_id);

CREATE INDEX ix_file_categories_company_id ON public.file_categories USING btree (company_id);

CREATE INDEX ix_fiscal_year_rule_company_id ON public.fiscal_year_rule USING btree (company_id);

CREATE INDEX ix_fixed_assets_company_id ON public.fixed_assets USING btree (company_id);

CREATE INDEX ix_gl_daily_balances_account_day ON public.gl_daily_balances USING btree (account_id, day);

CREATE INDEX ix_gl_daily_balances_company_day ON public.gl_daily_balances USING btree (company_id, day);

CREATE INDEX ix_gl_daily_balances_company_id ON public.gl_daily_balances USING btree (company_id);

CREATE INDEX ix_income_tax_slabs_company_id ON public.income_tax_slabs USING btree (company_id);

CREATE INDEX ix_inv_categories_company_id ON public.inv_categories USING btree (company_id);

CREATE INDEX ix_inv_customers_company_id ON public.inv_customers USING btree (company_id);

CREATE INDEX ix_inv_invoice_items_company_id ON public.inv_invoice_items USING btree (company_id);

CREATE INDEX ix_inv_invoices_company_id ON public.inv_invoices USING btree (company_id);

CREATE INDEX ix_inv_products_company_id ON public.inv_products USING btree (company_id);

CREATE INDEX ix_inv_purchase_invoice_items_company_id ON public.inv_purchase_invoice_items USING btree (company_id);

CREATE INDEX ix_inv_purchase_invoices_company_id ON public.inv_purchase_invoices USING btree (company_id);

CREATE INDEX ix_inv_purchase_order_items_company_id ON public.inv_purchase_order_items USING btree (company_id);

CREATE INDEX ix_inv_purchase_orders_company_id ON public.inv_purchase_orders USING btree (company_id);

CREATE INDEX ix_inv_purchase_return_items_company_id ON public.inv_purchase_return_items USING btree (company_id);

CREATE INDEX ix_inv_purchase_returns_company_id ON public.inv_purchase_returns USING btree (company_id);

CREATE INDEX ix_inv_sales_order_items_company_id ON public.inv_sales_order_items USING btree (company_id);

CREATE INDEX ix_inv_sales_orders_company_id ON public.inv_sales_orders USING btree (company_id);

CREATE INDEX ix_inv_sales_return_items_company_id ON public.inv_sales_return_items USING btree (company_id);

CREATE INDEX ix_inv_sales_returns_company_id ON public.inv_sales_returns USING btree (company_id);

CREATE INDEX ix_inv_stock_movements_company_id ON public.inv_stock_movements USING btree (company_id);

CREATE INDEX ix_inv_suppliers_company_id ON public.inv_suppliers USING btree (company_id);

CREATE INDEX ix_inv_units_company_id ON public.inv_units USING btree (company_id);

CREATE INDEX ix_inventory_settings_company_id ON public.inventory_settings USING btree (company_id);

CREATE INDEX ix_invoice_settings_company_id ON public.invoice_settings USING btree (company_id);

CREATE INDEX ix_invoice_templates_company_id ON public.invoice_templates USING btree (company_id);

CREATE INDEX ix_journal_entries_company_id ON public.journal_entries USING btree (company_id);

CREATE INDEX ix_journal_entries_company_posted_date ON public.journal_entries USING btree (company_id, is_posted, entry_date);

CREATE INDEX ix_journal_entries_voucher ON public.journal_entries USING btree (voucher_type, voucher_id);

CREATE INDEX ix_journal_entries_voucher_number ON public.journal_entries USING btree (voucher_number);

CREATE INDEX ix_journal_lines_account_entry ON public.journal_lines USING btree (account_id, journal_entry_id);

CREATE INDEX ix_journal_lines_company_id ON public.journal_lines USING btree (company_id);

CREATE INDEX ix_journal_lines_entry ON public.journal_lines USING btree (journal_entry_id);

CREATE INDEX ix_kanban_boards_company_id ON public.kanban_boards USING btree (company_id);

CREATE INDEX ix_kanban_tasks_company_id ON public.kanban_tasks USING btree (company_id);

CREATE INDEX ix_layer_consumptions_company_id ON public.layer_consumptions USING btree (company_id);

CREATE INDEX ix_layer_consumptions_layer_id ON public.layer_consumptions USING btree (layer_id);

CREATE INDEX ix_layer_consumptions_out_ledger_id ON public.layer_consumptions USING btree (out_ledger_id);

CREATE INDEX ix_layer_consumptions_product_id ON public.layer_consumptions USING btree (product_id);

CREATE INDEX ix_leave_approvals_company_id ON public.leave_approvals USING btree (company_id);

CREATE INDEX ix_leave_quotas_company_id ON public.leave_quotas USING btree (company_id);

CREATE INDEX ix_leave_requests_company_id ON public.leave_requests USING btree (company_id);

CREATE INDEX ix_leave_types_company_id ON public.leave_types USING btree (company_id);

CREATE INDEX ix_loan_advance_requests_company_id ON public.loan_advance_requests USING btree (company_id);

CREATE INDEX ix_loan_repayments_company_id ON public.loan_repayments USING btree (company_id);

CREATE INDEX ix_notification_recipients_company_id ON public.notification_recipients USING btree (company_id);

CREATE INDEX ix_notifications_company_id ON public.notifications USING btree (company_id);

CREATE INDEX ix_overtime_accounts_company_id ON public.overtime_accounts USING btree (company_id);

CREATE INDEX ix_payment_allocations_company_id ON public.payment_allocations USING btree (company_id);

CREATE INDEX ix_payment_allocations_doc_id ON public.payment_allocations USING btree (doc_id);

CREATE INDEX ix_payment_allocations_party_id ON public.payment_allocations USING btree (party_id);

CREATE INDEX ix_payment_allocations_voucher_id ON public.payment_allocations USING btree (voucher_id);

CREATE INDEX ix_payment_allocations_voucher_line_id ON public.payment_allocations USING btree (voucher_line_id);

CREATE INDEX ix_payroll_audit_logs_company_id ON public.payroll_audit_logs USING btree (company_id);

CREATE INDEX ix_payroll_components_company_id ON public.payroll_components USING btree (company_id);

CREATE INDEX ix_payroll_profiles_company_id ON public.payroll_profiles USING btree (company_id);

CREATE INDEX ix_payroll_runs_company_id ON public.payroll_runs USING btree (company_id);

CREATE INDEX ix_payroll_settings_company_id ON public.payroll_settings USING btree (company_id);

CREATE INDEX ix_payroll_slips_company_id ON public.payroll_slips USING btree (company_id);

CREATE INDEX ix_performance_goals_company_id ON public.performance_goals USING btree (company_id);

CREATE INDEX ix_performance_reviews_company_id ON public.performance_reviews USING btree (company_id);

CREATE INDEX ix_pf_config_company_id ON public.pf_config USING btree (company_id);

CREATE INDEX ix_pf_contributions_company_id ON public.pf_contributions USING btree (company_id);

CREATE INDEX ix_pf_ledger_company_id ON public.pf_ledger USING btree (company_id);

CREATE INDEX ix_pf_loan_requests_company_id ON public.pf_loan_requests USING btree (company_id);

CREATE INDEX ix_pf_profit_distributions_company_id ON public.pf_profit_distributions USING btree (company_id);

CREATE INDEX ix_pf_settlements_company_id ON public.pf_settlements USING btree (company_id);

CREATE INDEX ix_pf_withdrawal_requests_company_id ON public.pf_withdrawal_requests USING btree (company_id);

CREATE INDEX ix_project_labels_company_id ON public.project_labels USING btree (company_id);

CREATE INDEX ix_project_tasks_company_id ON public.project_tasks USING btree (company_id);

CREATE INDEX ix_projects_company_id ON public.projects USING btree (company_id);

CREATE INDEX ix_registration_requests_email ON public.registration_requests USING btree (email);

CREATE INDEX ix_registration_requests_phone ON public.registration_requests USING btree (phone);

CREATE INDEX ix_registration_requests_status ON public.registration_requests USING btree (status);

CREATE INDEX ix_report_settings_company_id ON public.report_settings USING btree (company_id);

CREATE INDEX ix_salary_revisions_company_id ON public.salary_revisions USING btree (company_id);

CREATE INDEX ix_scrap_items_company_id ON public.scrap_items USING btree (company_id);

CREATE INDEX ix_scrap_vouchers_company_id ON public.scrap_vouchers USING btree (company_id);

CREATE INDEX ix_stock_adjustment_items_company_id ON public.stock_adjustment_items USING btree (company_id);

CREATE INDEX ix_stock_adjustment_vouchers_company_id ON public.stock_adjustment_vouchers USING btree (company_id);

CREATE INDEX ix_stock_cost_adjustments_company_id ON public.stock_cost_adjustments USING btree (company_id);

CREATE INDEX ix_stock_cost_adjustments_ledger_id ON public.stock_cost_adjustments USING btree (ledger_id);

CREATE INDEX ix_stock_cost_adjustments_product_id ON public.stock_cost_adjustments USING btree (product_id);

CREATE INDEX ix_stock_layers_company_id ON public.stock_layers USING btree (company_id);

CREATE INDEX ix_stock_layers_product_id ON public.stock_layers USING btree (product_id);

CREATE INDEX ix_stock_layers_qty_remaining ON public.stock_layers USING btree (qty_remaining);

CREATE INDEX ix_stock_ledger_company_id ON public.stock_ledger USING btree (company_id);

CREATE INDEX ix_stock_ledger_product_id ON public.stock_ledger USING btree (product_id);

CREATE INDEX ix_stock_ledger_txn_date ON public.stock_ledger USING btree (txn_date);

CREATE INDEX ix_stock_ledger_voucher_number ON public.stock_ledger USING btree (voucher_number);

CREATE INDEX ix_stock_take_items_company_id ON public.stock_take_items USING btree (company_id);

CREATE INDEX ix_stock_takes_company_id ON public.stock_takes USING btree (company_id);

CREATE INDEX ix_stored_files_company_id ON public.stored_files USING btree (company_id);

CREATE INDEX ix_tax_rate_accounts_company_id ON public.tax_rate_accounts USING btree (company_id);

CREATE INDEX ix_team_events_company_id ON public.team_events USING btree (company_id);

CREATE INDEX ix_time_policies_company_id ON public.time_policies USING btree (company_id);

CREATE INDEX ix_timesheet_approvals_company_id ON public.timesheet_approvals USING btree (company_id);

CREATE INDEX ix_timesheet_entries_company_id ON public.timesheet_entries USING btree (company_id);

CREATE INDEX ix_timesheet_merged_reports_company_id ON public.timesheet_merged_reports USING btree (company_id);

CREATE INDEX ix_timesheet_weeks_company_id ON public.timesheet_weeks USING btree (company_id);

CREATE INDEX ix_twcf_lines_company_id ON public.twcf_lines USING btree (company_id);

CREATE INDEX ix_user_permissions_company_id ON public.user_permissions USING btree (company_id);

CREATE INDEX ix_user_permissions_user_id ON public.user_permissions USING btree (user_id);

CREATE INDEX ix_voucher_numbers_company_id ON public.voucher_numbers USING btree (company_id);

CREATE INDEX ix_work_packages_company_id ON public.work_packages USING btree (company_id);

ALTER TABLE ONLY public.accounting_voucher_lines
    ADD CONSTRAINT accounting_voucher_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.accounting_voucher_lines
    ADD CONSTRAINT accounting_voucher_lines_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.accounting_voucher_lines
    ADD CONSTRAINT accounting_voucher_lines_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.accounting_vouchers(id);

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT accounting_vouchers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT accounting_vouchers_cash_bank_account_id_fkey FOREIGN KEY (cash_bank_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT accounting_vouchers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.accounting_vouchers
    ADD CONSTRAINT accounting_vouchers_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.additional_charges
    ADD CONSTRAINT additional_charges_charge_account_id_fkey FOREIGN KEY (charge_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.approval_workflows
    ADD CONSTRAINT approval_workflows_leave_type_id_fkey FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);

ALTER TABLE ONLY public.asset_depreciation
    ADD CONSTRAINT asset_depreciation_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.fixed_assets(id);

ALTER TABLE ONLY public.asset_depreciation
    ADD CONSTRAINT asset_depreciation_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id);

ALTER TABLE ONLY public.asset_transfers
    ADD CONSTRAINT asset_transfers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.asset_transfers
    ADD CONSTRAINT asset_transfers_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.fixed_assets(id);

ALTER TABLE ONLY public.asset_transfers
    ADD CONSTRAINT asset_transfers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.attendance_corrections
    ADD CONSTRAINT attendance_corrections_attendance_id_fkey FOREIGN KEY (attendance_id) REFERENCES public.attendance(id);

ALTER TABLE ONLY public.attendance_corrections
    ADD CONSTRAINT attendance_corrections_corrected_by_fkey FOREIGN KEY (corrected_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.attendance_logs
    ADD CONSTRAINT attendance_logs_attendance_id_fkey FOREIGN KEY (attendance_id) REFERENCES public.attendance(id);

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.bank_rec_items
    ADD CONSTRAINT bank_rec_items_journal_line_id_fkey FOREIGN KEY (journal_line_id) REFERENCES public.journal_lines(id);

ALTER TABLE ONLY public.bank_rec_items
    ADD CONSTRAINT bank_rec_items_reconciliation_id_fkey FOREIGN KEY (reconciliation_id) REFERENCES public.bank_reconciliations(id);

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.break_logs
    ADD CONSTRAINT break_logs_attendance_id_fkey FOREIGN KEY (attendance_id) REFERENCES public.attendance(id);

ALTER TABLE ONLY public.button_permissions
    ADD CONSTRAINT button_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);

ALTER TABLE ONLY public.category_revenue_accounts
    ADD CONSTRAINT category_revenue_accounts_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.category_revenue_accounts
    ADD CONSTRAINT category_revenue_accounts_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.inv_categories(id);

ALTER TABLE ONLY public.change_requests
    ADD CONSTRAINT change_requests_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.change_requests
    ADD CONSTRAINT change_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.charge_ledger_defaults
    ADD CONSTRAINT charge_ledger_defaults_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.company_invitations
    ADD CONSTRAINT company_invitations_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);

ALTER TABLE ONLY public.company_invitations
    ADD CONSTRAINT company_invitations_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.company_invitations
    ADD CONSTRAINT company_invitations_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT company_memberships_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT company_memberships_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT company_memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.consumption_items
    ADD CONSTRAINT consumption_items_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.consumption_vouchers(id);

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT consumption_vouchers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT consumption_vouchers_charge_account_id_fkey FOREIGN KEY (charge_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT consumption_vouchers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.consumption_vouchers
    ADD CONSTRAINT consumption_vouchers_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.digital_files
    ADD CONSTRAINT digital_files_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.file_categories(id);

ALTER TABLE ONLY public.digital_files
    ADD CONSTRAINT digital_files_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.digital_files
    ADD CONSTRAINT digital_files_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.exec_account_selections
    ADD CONSTRAINT exec_account_selections_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.exec_account_selections
    ADD CONSTRAINT exec_account_selections_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.fbr_invoice_records
    ADD CONSTRAINT fbr_invoice_records_inv_invoice_id_fkey FOREIGN KEY (inv_invoice_id) REFERENCES public.inv_invoices(id);

ALTER TABLE ONLY public.fbr_invoice_records
    ADD CONSTRAINT fbr_invoice_records_submitted_by_fkey FOREIGN KEY (submitted_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_accum_dep_account_id_fkey FOREIGN KEY (accum_dep_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_acquisition_credit_account_id_fkey FOREIGN KEY (acquisition_credit_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.fa_categories(id);

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_dep_expense_account_id_fkey FOREIGN KEY (dep_expense_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_fixed_asset_account_id_fkey FOREIGN KEY (fixed_asset_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.global_limits
    ADD CONSTRAINT global_limits_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_categories
    ADD CONSTRAINT inv_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.inv_categories(id);

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.inv_invoices(id);

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_source_order_id_fkey FOREIGN KEY (source_order_id) REFERENCES public.inv_sales_orders(id);

ALTER TABLE ONLY public.inv_invoice_items
    ADD CONSTRAINT inv_invoice_items_source_order_item_id_fkey FOREIGN KEY (source_order_item_id) REFERENCES public.inv_sales_order_items(id);

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.inv_customers(id);

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_party_account_id_fkey FOREIGN KEY (party_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.inv_invoices
    ADD CONSTRAINT inv_invoices_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.inv_sales_orders(id);

ALTER TABLE ONLY public.inv_products
    ADD CONSTRAINT inv_products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.inv_categories(id);

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.inv_purchase_invoices(id);

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_source_order_id_fkey FOREIGN KEY (source_order_id) REFERENCES public.inv_purchase_orders(id);

ALTER TABLE ONLY public.inv_purchase_invoice_items
    ADD CONSTRAINT inv_purchase_invoice_items_source_order_item_id_fkey FOREIGN KEY (source_order_item_id) REFERENCES public.inv_purchase_order_items(id);

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_party_account_id_fkey FOREIGN KEY (party_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.inv_purchase_orders(id);

ALTER TABLE ONLY public.inv_purchase_invoices
    ADD CONSTRAINT inv_purchase_invoices_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.inv_suppliers(id);

ALTER TABLE ONLY public.inv_purchase_order_items
    ADD CONSTRAINT inv_purchase_order_items_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.inv_purchase_orders(id);

ALTER TABLE ONLY public.inv_purchase_order_items
    ADD CONSTRAINT inv_purchase_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT inv_purchase_orders_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT inv_purchase_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT inv_purchase_orders_party_account_id_fkey FOREIGN KEY (party_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.inv_purchase_orders
    ADD CONSTRAINT inv_purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.inv_suppliers(id);

ALTER TABLE ONLY public.inv_purchase_return_items
    ADD CONSTRAINT inv_purchase_return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);

ALTER TABLE ONLY public.inv_purchase_return_items
    ADD CONSTRAINT inv_purchase_return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.inv_purchase_returns(id);

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT inv_purchase_returns_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT inv_purchase_returns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT inv_purchase_returns_original_invoice_id_fkey FOREIGN KEY (original_invoice_id) REFERENCES public.inv_purchase_invoices(id);

ALTER TABLE ONLY public.inv_purchase_returns
    ADD CONSTRAINT inv_purchase_returns_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.inv_suppliers(id);

ALTER TABLE ONLY public.inv_sales_order_items
    ADD CONSTRAINT inv_sales_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);

ALTER TABLE ONLY public.inv_sales_order_items
    ADD CONSTRAINT inv_sales_order_items_so_id_fkey FOREIGN KEY (so_id) REFERENCES public.inv_sales_orders(id);

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT inv_sales_orders_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT inv_sales_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT inv_sales_orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.inv_customers(id);

ALTER TABLE ONLY public.inv_sales_orders
    ADD CONSTRAINT inv_sales_orders_party_account_id_fkey FOREIGN KEY (party_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.inv_sales_return_items
    ADD CONSTRAINT inv_sales_return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);

ALTER TABLE ONLY public.inv_sales_return_items
    ADD CONSTRAINT inv_sales_return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.inv_sales_returns(id);

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.inv_customers(id);

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_original_invoice_id_fkey FOREIGN KEY (original_invoice_id) REFERENCES public.inv_invoices(id);

ALTER TABLE ONLY public.inv_sales_returns
    ADD CONSTRAINT inv_sales_returns_party_account_id_fkey FOREIGN KEY (party_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.inv_stock_movements
    ADD CONSTRAINT inv_stock_movements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.inv_stock_movements
    ADD CONSTRAINT inv_stock_movements_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.inv_products(id);

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_default_cogs_account_id_fkey FOREIGN KEY (default_cogs_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_default_inventory_account_id_fkey FOREIGN KEY (default_inventory_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_default_invoice_label_id_fkey FOREIGN KEY (default_invoice_label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_default_return_account_id_fkey FOREIGN KEY (default_return_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.inventory_settings
    ADD CONSTRAINT inventory_settings_default_voucher_label_id_fkey FOREIGN KEY (default_voucher_label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id);

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.kanban_boards
    ADD CONSTRAINT kanban_boards_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.kanban_tasks
    ADD CONSTRAINT kanban_tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.kanban_tasks
    ADD CONSTRAINT kanban_tasks_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.kanban_boards(id);

ALTER TABLE ONLY public.layer_consumptions
    ADD CONSTRAINT layer_consumptions_layer_id_fkey FOREIGN KEY (layer_id) REFERENCES public.stock_layers(id);

ALTER TABLE ONLY public.layer_consumptions
    ADD CONSTRAINT layer_consumptions_out_ledger_id_fkey FOREIGN KEY (out_ledger_id) REFERENCES public.stock_ledger(id);

ALTER TABLE ONLY public.leave_approvals
    ADD CONSTRAINT leave_approvals_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.leave_approvals
    ADD CONSTRAINT leave_approvals_leave_request_id_fkey FOREIGN KEY (leave_request_id) REFERENCES public.leave_requests(id);

ALTER TABLE ONLY public.leave_quotas
    ADD CONSTRAINT leave_quotas_leave_type_id_fkey FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);

ALTER TABLE ONLY public.leave_quotas
    ADD CONSTRAINT leave_quotas_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_leave_type_id_fkey FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.loan_advance_requests
    ADD CONSTRAINT loan_advance_requests_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.loan_advance_requests
    ADD CONSTRAINT loan_advance_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.loan_repayments
    ADD CONSTRAINT loan_repayments_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.loan_advance_requests(id);

ALTER TABLE ONLY public.loan_repayments
    ADD CONSTRAINT loan_repayments_payroll_run_id_fkey FOREIGN KEY (payroll_run_id) REFERENCES public.payroll_runs(id);

ALTER TABLE ONLY public.notification_recipients
    ADD CONSTRAINT notification_recipients_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notifications(id);

ALTER TABLE ONLY public.notification_recipients
    ADD CONSTRAINT notification_recipients_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.overtime_accounts
    ADD CONSTRAINT overtime_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.accounting_vouchers(id);

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_voucher_line_id_fkey FOREIGN KEY (voucher_line_id) REFERENCES public.accounting_voucher_lines(id);

ALTER TABLE ONLY public.payroll_audit_logs
    ADD CONSTRAINT payroll_audit_logs_payroll_run_id_fkey FOREIGN KEY (payroll_run_id) REFERENCES public.payroll_runs(id);

ALTER TABLE ONLY public.payroll_audit_logs
    ADD CONSTRAINT payroll_audit_logs_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.payroll_components
    ADD CONSTRAINT payroll_components_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.payroll_profiles(id);

ALTER TABLE ONLY public.payroll_profiles
    ADD CONSTRAINT payroll_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_processed_by_fkey FOREIGN KEY (processed_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.payroll_slips
    ADD CONSTRAINT payroll_slips_payroll_run_id_fkey FOREIGN KEY (payroll_run_id) REFERENCES public.payroll_runs(id);

ALTER TABLE ONLY public.payroll_slips
    ADD CONSTRAINT payroll_slips_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.performance_goals
    ADD CONSTRAINT performance_goals_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.performance_goals
    ADD CONSTRAINT performance_goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.performance_reviews
    ADD CONSTRAINT performance_reviews_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);

ALTER TABLE ONLY public.pf_contributions
    ADD CONSTRAINT pf_contributions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.pf_ledger
    ADD CONSTRAINT pf_ledger_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.pf_loan_requests
    ADD CONSTRAINT pf_loan_requests_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.pf_loan_requests
    ADD CONSTRAINT pf_loan_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.pf_profit_distributions
    ADD CONSTRAINT pf_profit_distributions_distributed_by_fkey FOREIGN KEY (distributed_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.pf_settlements
    ADD CONSTRAINT pf_settlements_settled_by_fkey FOREIGN KEY (settled_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.pf_settlements
    ADD CONSTRAINT pf_settlements_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.pf_withdrawal_requests
    ADD CONSTRAINT pf_withdrawal_requests_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.pf_withdrawal_requests
    ADD CONSTRAINT pf_withdrawal_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_work_package_id_fkey FOREIGN KEY (work_package_id) REFERENCES public.work_packages(id);

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_project_manager_id_fkey FOREIGN KEY (project_manager_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.report_settings
    ADD CONSTRAINT report_settings_purchase_template_id_fkey FOREIGN KEY (purchase_template_id) REFERENCES public.invoice_templates(id);

ALTER TABLE ONLY public.report_settings
    ADD CONSTRAINT report_settings_sales_template_id_fkey FOREIGN KEY (sales_template_id) REFERENCES public.invoice_templates(id);

ALTER TABLE ONLY public.salary_revisions
    ADD CONSTRAINT salary_revisions_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.salary_revisions
    ADD CONSTRAINT salary_revisions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.scrap_items
    ADD CONSTRAINT scrap_items_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.scrap_vouchers(id);

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT scrap_vouchers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT scrap_vouchers_charge_account_id_fkey FOREIGN KEY (charge_account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT scrap_vouchers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.scrap_vouchers
    ADD CONSTRAINT scrap_vouchers_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.stock_adjustment_items
    ADD CONSTRAINT stock_adjustment_items_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES public.stock_adjustment_vouchers(id);

ALTER TABLE ONLY public.stock_adjustment_vouchers
    ADD CONSTRAINT stock_adjustment_vouchers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.stock_adjustment_vouchers
    ADD CONSTRAINT stock_adjustment_vouchers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.stock_adjustment_vouchers
    ADD CONSTRAINT stock_adjustment_vouchers_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.project_labels(id);

ALTER TABLE ONLY public.stock_cost_adjustments
    ADD CONSTRAINT stock_cost_adjustments_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id);

ALTER TABLE ONLY public.stock_layers
    ADD CONSTRAINT stock_layers_source_ledger_id_fkey FOREIGN KEY (source_ledger_id) REFERENCES public.stock_ledger(id);

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.stock_take_items
    ADD CONSTRAINT stock_take_items_stock_take_id_fkey FOREIGN KEY (stock_take_id) REFERENCES public.stock_takes(id);

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_adjustment_voucher_id_fkey FOREIGN KEY (adjustment_voucher_id) REFERENCES public.stock_adjustment_vouchers(id);

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.stock_takes
    ADD CONSTRAINT stock_takes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.tax_rate_accounts
    ADD CONSTRAINT tax_rate_accounts_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.chart_of_accounts(id);

ALTER TABLE ONLY public.team_events
    ADD CONSTRAINT team_events_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.timesheet_approvals
    ADD CONSTRAINT timesheet_approvals_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.timesheet_approvals
    ADD CONSTRAINT timesheet_approvals_week_id_fkey FOREIGN KEY (week_id) REFERENCES public.timesheet_weeks(id);

ALTER TABLE ONLY public.timesheet_entries
    ADD CONSTRAINT timesheet_entries_week_id_fkey FOREIGN KEY (week_id) REFERENCES public.timesheet_weeks(id);

ALTER TABLE ONLY public.timesheet_merged_reports
    ADD CONSTRAINT timesheet_merged_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.timesheet_weeks
    ADD CONSTRAINT timesheet_weeks_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);

ALTER TABLE ONLY public.timesheet_weeks
    ADD CONSTRAINT timesheet_weeks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id);

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT work_packages_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);
